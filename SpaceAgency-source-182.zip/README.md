# Space Agency — milestone 1 (Raptor 3 test stand)

Custom engine in Swift + Metal (no SceneKit/RealityKit/Unity). Landscape only, iOS 26.

## Controls
- **One finger drag** — orbit camera · **two fingers** — pan · **pinch** — zoom
- **Tap** the engine to select it (opens the engine panel), tap empty space to deselect
- **Parts tray** (right): drag the Raptor 3 card onto the test stand (snaps when close), or tap the card to place it
- **Engine panel**: START / SHUTDOWN, throttle 40–100 %, GIMBAL MODE toggle with CIRCLE / SWEEP test patterns, collapsible telemetry
- **Gimbal joystick** (bottom-left, when gimbal mode is on): ±15° pitch/yaw, rate-limited actuators
- **Altitude slider** (left): sea level → 120 km, top end = vacuum
- **Speaker button** (top-right): sound on/off (remembered)
- **HANGAR / TEST STAND button** (top bar): switch between the outdoor McGregor-style vertical test stand (default) and the indoor hangar (only while the engine is safed; remembered)

## Layout
- `Engine/` fixed-timestep loop (120 Hz), entities, orbit camera, ray picking, particles
- `Renderer/` forward PBR renderer, procedural geometry, GPU types
- `Shaders/` PBR (GGX, procedural materials), plume raymarch, SSAO, IBL, bloom, ACES, FXAA
- `Parts/` data-driven part definitions (`parts.json`), procedural Raptor 3 + hangar/stand meshes
- `Physics/` US Standard Atmosphere 1976, isentropic nozzle flow, Raptor start/shutdown state machine, gimbal servo
- `Audio/` AVAudioEngine: recorded static-fire samples + procedural synth layer
- `UI/` SwiftUI overlay (webcast-style HUD, panels)

## TV-1 RCS pods
- `Parts/RCSPod.swift` defines pod variants with a per-nozzle table (exit position, exhaust direction, exit radius):
  **quad** (Apollo-style housing, four bell nozzles that stick out, canted 35 degrees outward) on the top ring and
  **flush** (Shuttle-style bank of three ports flush with the skin) on the skirt ring. Assignment: `TV1Mesh.rcsVariants`.
- Firing is per nozzle: each pod's summed exhaust request (`RCSActuator.podFiring`) is projected onto its nozzle
  directions, so a radial request fires all four canted bells, a roll request fires one, and a flush bank fires its ports.
- Plume: translucent blue core, arrowhead Mach diamonds at ~3 exit diameters, narrow streaky pink/lavender column.

## Launch arguments (CI screenshots)
- `-demoScreenshot` — Raptor pre-mounted, camera framed
- `-demoScreenshot -demoFire` — also starts the engine automatically (short chill-down)
- `-hangar` — start in the indoor hangar instead of the outdoor test stand
