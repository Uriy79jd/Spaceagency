import SwiftUI

final class GameController: ObservableObject {
    let ui: GameUIModel
    let engine: GameEngine
    init() {
        let ui = GameUIModel()
        self.ui = ui
        self.engine = GameEngine(ui: ui)
    }
}

struct ContentView: View {
    let controller: GameController
    @ObservedObject var ui: GameUIModel
    @AppStorage("soundEnabled") private var soundEnabled = true

    var body: some View {
        // Every overlay layer fills the screen and pins its content with an alignment, so a panel changing
        // size (engine selected, telemetry open) can never grow the ZStack and push the other layers around.
        ZStack {
            MetalView(engine: controller.engine)
                .ignoresSafeArea()

            if !ui.uiHidden {
                WebcastHUD(ui: ui)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .ignoresSafeArea()
            }

            GeometryReader { geo in
            ZStack {
                topBar
                    .padding(.horizontal, 14)
                    .padding(.top, 6)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

                if !ui.uiHidden {
                if ui.showHint && !ui.enginePlaced {
                    Text("Drag the Raptor 3 from the tray onto the test stand")
                        .font(.system(size: 10, weight: .medium)).foregroundColor(.white)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Capsule().fill(Color.black.opacity(0.5)))
                        .padding(.top, 44)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                        .allowsHitTesting(false)
                }

                // right side: parts tray or engine panel, fixed width, height capped above the HUD strip
                rightPanel
                    .frame(width: UIMetrics.panelWidth, alignment: .topTrailing)
                    .frame(maxHeight: max(geo.size.height - 42 - 84, 120), alignment: .top)
                    .padding(.top, 42)
                    .padding(.trailing, 10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)

                // camera selection (MAIN / vehicle-mounted cameras)
                CameraBar(ui: ui)
                    .padding(.top, 40)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

                // left side: altitude slider + gimbal joystick (stand) / TV-1 telemetry + manual stick (pad)
                HStack(alignment: .bottom, spacing: 10) {
                    if ui.site == "pad" {
                        TV1LeftPanel(ui: ui)
                        if !ui.tv1Autopilot {
                            GimbalJoystick { v in controller.engine.joystick = v }
                        }
                    } else {
                        AltitudeSlider(value: $ui.altitudeSlider)
                            .frame(height: 124)
                        if ui.gimbalMode && ui.enginePlaced {
                            GimbalJoystick { v in controller.engine.joystick = v }
                        }
                    }
                }
                .padding(.bottom, 84)
                .padding(.leading, 14)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            }
        }
        .onChange(of: ui.altitudeSlider) { _, _ in controller.engine.applyAltitude() }
        .onChange(of: soundEnabled) { _, on in controller.engine.audio.setEnabled(on) }
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .preferredColorScheme(.dark)
    }

    @ViewBuilder private var rightPanel: some View {
        if ui.site == "pad" {
            TV1Panel(ui: ui, engine: controller.engine)
        } else if ui.engineSelected && ui.enginePlaced {
            EnginePanel(ui: ui, engine: controller.engine)
        } else {
            PartsTray(ui: ui, engine: controller.engine)
        }
    }

    private var topBar: some View {
        HStack(alignment: .center, spacing: 6) {
            VStack(alignment: .leading, spacing: 1) {
                Text("SPACE AGENCY").font(.system(size: 10, weight: .semibold)).tracking(1.6).foregroundColor(.white)
                TinyLabel(text: ui.site == "pad" ? "McGregor · TV-1 launch pad" : (ui.outdoor ? "McGregor · Vertical test stand" : "Hangar · Test stand A"))
            }
            .fixedSize()
            Spacer(minLength: 8)
            Button {
                withAnimation(.easeInOut(duration: 0.15)) { ui.uiHidden.toggle() }
            } label: {
                Text(ui.uiHidden ? "SHOW UI" : "HIDE UI")
                    .font(.system(size: 8.5, weight: .semibold)).tracking(0.8).foregroundColor(.white)
                    .padding(.horizontal, 8).frame(height: 26)
                    .background(Capsule().fill(Color.black.opacity(0.45)))
                    .frame(minWidth: 36, minHeight: 36)
                    .contentShape(Rectangle())
            }
            if !ui.uiHidden {
            Button {
                // the engine owns the site (and persists it); the UI only asks for the next one
                controller.engine.cycleSite()
            } label: {
                Text(ui.site == "stand" ? "TV-1 PAD" : (ui.site == "pad" ? "HANGAR" : "TEST STAND"))
                    .font(.system(size: 8.5, weight: .semibold)).tracking(0.8).foregroundColor(.white)
                    .padding(.horizontal, 8).frame(height: 26)
                    .background(Capsule().fill(Color.black.opacity(0.45)))
                    .frame(minWidth: 36, minHeight: 36)
                    .contentShape(Rectangle())
            }
            .disabled(ui.running || ui.starting)
            .opacity(ui.running || ui.starting ? 0.4 : 1)
            }
            Text(String(format: "%3.0f FPS · %4.1f MS · %@ · %@", ui.fps, ui.gpuMs, ui.qualityName.uppercased(), ui.thermalName))
                .font(.system(size: 7.5, weight: .medium)).monospacedDigit().foregroundColor(.white.opacity(0.5))
                .lineLimit(1)
                .frame(width: 150, alignment: .trailing)
            if !ui.uiHidden {
            Button {
                soundEnabled.toggle()
            } label: {
                Image(systemName: soundEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill")
                    .font(.system(size: 10)).foregroundColor(.white)
                    .frame(width: 26, height: 26)
                    .background(Circle().fill(Color.black.opacity(0.45)))
                    .frame(width: 36, height: 36)
                    .contentShape(Rectangle())
            }
            }
        }
    }
}

/// Shared HUD sizing (UI scaled ~27 % down from build 179; tap targets stay ≥ 36 pt).
enum UIMetrics {
    static let panelWidth: CGFloat = 180
    static let gauge: CGFloat = 48
    static let minTap: CGFloat = 36
}
