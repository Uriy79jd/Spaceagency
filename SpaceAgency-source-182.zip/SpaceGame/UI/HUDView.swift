import SwiftUI
import UIKit

// SpaceX-webcast-style bottom HUD.

private let hudWhite = Color.white
private let hudGrey = Color.white.opacity(0.45)

struct TinyLabel: View {
    let text: String
    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 6.5, weight: .semibold))
            .tracking(0.6)
            .foregroundColor(hudGrey)
    }
}

/// Circular gauge with a thin arc (270°), value in the middle.
struct ArcGauge: View {
    let title: String
    let value: String
    let unit: String
    let fraction: Double
    var valueSize: CGFloat = 13

    var body: some View {
        ZStack {
            Circle().fill(Color.black.opacity(0.25))
            Circle()
                .trim(from: 0, to: 0.75)
                .stroke(Color.white.opacity(0.18), style: StrokeStyle(lineWidth: 1.5, lineCap: .round))
                .rotationEffect(.degrees(135))
            Circle()
                .trim(from: 0, to: 0.75 * max(0, min(1, fraction)))
                .stroke(hudWhite, style: StrokeStyle(lineWidth: 1.8, lineCap: .round))
                .rotationEffect(.degrees(135))
                .shadow(color: .white.opacity(0.6), radius: 2)
            VStack(spacing: 0) {
                // one line, shrinks to fit the 48 pt ring ("ALTITUDE" wrapped to "ALTITUD / E" in build 180)
                TinyLabel(text: title)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                    .fixedSize(horizontal: false, vertical: true)
                Text(value)
                    .font(.system(size: valueSize, weight: .light))
                    .monospacedDigit()
                    .foregroundColor(hudWhite)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .shadow(color: .white.opacity(0.35), radius: 3)
                TinyLabel(text: unit)
            }
            .padding(.horizontal, 4)
        }
        .frame(width: UIMetrics.gauge, height: UIMetrics.gauge)
    }
}

/// Single-engine status ring: dim when off, white when running, pulsing during start / shutdown.
struct EngineStatusCircle: View {
    let state: Int
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            let pulse = 0.45 + 0.55 * (0.5 + 0.5 * sin(t * 7))
            let level: Double = state == 2 ? 1 : (state == 1 ? pulse : 0.22)
            ZStack {
                Circle().fill(Color.black.opacity(0.25))
                Circle().stroke(Color.white.opacity(0.35), lineWidth: 1.2)
                Circle().stroke(Color.white.opacity(0.12), lineWidth: 1).padding(6)
                Circle()
                    .fill(Color.white.opacity(level))
                    .frame(width: 12, height: 12)
                    .shadow(color: .white.opacity(state == 0 ? 0 : 0.9 * level), radius: 5)
            }
            .frame(width: UIMetrics.gauge, height: UIMetrics.gauge)
        }
    }
}

struct TimelineArcShape: Shape {
    var from: Double = 0
    var to: Double = 1
    func path(in rect: CGRect) -> Path {
        // gentle arc: circle much larger than the rect, top of the circle near rect.minY
        let r = rect.width * 1.6
        let center = CGPoint(x: rect.midX, y: rect.minY + r)
        let half = asin(Double(rect.width / 2 / r))
        let a0 = -Double.pi / 2 - half
        let a1 = -Double.pi / 2 + half
        var p = Path()
        let s = a0 + (a1 - a0) * from
        let e = a0 + (a1 - a0) * to
        p.addArc(center: center, radius: r, startAngle: .radians(s), endAngle: .radians(e), clockwise: false)
        return p
    }

    static func point(in rect: CGRect, at f: Double) -> CGPoint {
        let r = Double(rect.width) * 1.6
        let cx = Double(rect.midX), cy = Double(rect.minY) + r
        let half = asin(Double(rect.width) / 2 / r)
        let a = -Double.pi / 2 - half + 2 * half * f
        return CGPoint(x: cx + r * cos(a), y: cy + r * sin(a))
    }
}

struct WebcastTimeline: View {
    let progress: Double   // 0..(events.count − 1)
    let clock: String
    var events = ["CHILL-DOWN", "SPIN START", "IGNITION", "MAINSTAGE", "SHUTDOWN"]
    var title = "Raptor 3 static fire"

    var body: some View {
        GeometryReader { geo in
            let rect = CGRect(x: 0, y: 11, width: geo.size.width, height: 22)
            let last = Double(max(events.count - 1, 1))
            let f = { (i: Double) -> Double in 0.08 + 0.84 * i / last }
            ZStack(alignment: .topLeading) {
                TimelineArcShape()
                    .path(in: rect)
                    .stroke(Color.white.opacity(0.22), lineWidth: 1)
                TimelineArcShape(from: 0, to: f(max(0, min(last, progress))))
                    .path(in: rect)
                    .stroke(Color.white, lineWidth: 1.4)
                    .shadow(color: .white.opacity(0.6), radius: 2)
                ForEach(0..<events.count, id: \.self) { i in
                    let p = TimelineArcShape.point(in: rect, at: f(Double(i)))
                    let passed = progress >= Double(i)
                    Circle()
                        .strokeBorder(Color.white.opacity(passed ? 1 : 0.4), lineWidth: 1)
                        .background(Circle().fill(passed ? Color.white : Color.black.opacity(0.4)))
                        .frame(width: 5, height: 5)
                        .position(p)
                    Text(events[i])
                        .font(.system(size: 6, weight: .semibold))
                        .tracking(0.4)
                        .foregroundColor(Color.white.opacity(passed ? 0.9 : 0.4))
                        .fixedSize()
                        .position(x: p.x, y: p.y - 8)
                }
                VStack(spacing: 1) {
                    clockView
                    TinyLabel(text: title)
                }
                .frame(width: geo.size.width)
                .offset(y: 22)
            }
        }
        .frame(height: 62)
    }

    private var clockView: some View {
        let sign = String(clock.prefix(2))
        let digits = String(clock.dropFirst(3))
        return HStack(alignment: .firstTextBaseline, spacing: 3) {
            Text(sign).font(.system(size: 11, weight: .regular)).foregroundColor(.white)
            Text(digits)
                .font(.system(size: 19, weight: .light))
                .monospacedDigit()
                .foregroundColor(.white)
                .shadow(color: .white.opacity(0.35), radius: 4)
        }
    }
}

/// Small engine glyph tilted by the gimbal angles.
struct GimbalIcon: View {
    let pitchDeg: Double
    let yawDeg: Double
    var body: some View {
        ZStack {
            Circle().fill(Color.black.opacity(0.25))
            Circle().stroke(Color.white.opacity(0.35), lineWidth: 1.2)
            Path { p in
                p.move(to: CGPoint(x: -0.12, y: -0.45)); p.addLine(to: CGPoint(x: 0.12, y: -0.45))
                p.addLine(to: CGPoint(x: 0.10, y: -0.12)); p.addLine(to: CGPoint(x: 0.30, y: 0.42))
                p.addLine(to: CGPoint(x: -0.30, y: 0.42)); p.addLine(to: CGPoint(x: -0.10, y: -0.12)); p.closeSubpath()
            }
            .applying(CGAffineTransform(scaleX: 28, y: 28))
            .fill(Color.white.opacity(0.9))
            .frame(width: 1, height: 1)
            .rotationEffect(.degrees(-yawDeg * 2), anchor: .center)
            .scaleEffect(x: 1, y: 1 - min(abs(pitchDeg) / 60, 0.25))
            .offset(y: 2)
        }
        .frame(width: UIMetrics.gauge, height: UIMetrics.gauge)
    }
}

struct WebcastHUD: View {
    @ObservedObject var ui: GameUIModel

    var body: some View {
        let t = ui.telemetry
        let alt = GameUIModel.altitude(forSlider: ui.altitudeSlider).0
        let vac = GameUIModel.altitude(forSlider: ui.altitudeSlider).1
        ZStack(alignment: .bottom) {
            LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.55), Color.black.opacity(0.8)], startPoint: .top, endPoint: .bottom)
                .frame(height: 86)
                .allowsHitTesting(false)
            HStack(alignment: .bottom, spacing: 8) {
                VStack(spacing: 2) {
                    EngineStatusCircle(state: ui.enginePlaced ? t.engineState : 0)
                    TinyLabel(text: "Raptor 3")
                }
                if ui.site == "pad" {
                    ArcGauge(title: "Altitude", value: String(format: "%.2f", ui.tv1.altitude / 1000), unit: "km",
                             fraction: ui.tv1.altitude / 10_000)
                        .padding(.bottom, 9)
                } else {
                    ArcGauge(title: "Altitude", value: vac ? "VAC" : String(format: alt < 10_000 ? "%.1f" : "%.0f", alt / 1000),
                             unit: vac ? "vacuum" : "km", fraction: vac ? 1 : alt / 120_000)
                        .padding(.bottom, 9)
                }
                Spacer(minLength: 12)
                if ui.site == "pad" {
                    WebcastTimeline(progress: ui.tv1.timelineProgress, clock: t.clockText, events: TV1Flight.timelineEvents,
                                    title: "TV-1 · " + ui.tv1Profile.rawValue + " · " + ui.tv1Scenario.rawValue)
                        .frame(maxWidth: 360)
                        .padding(.bottom, 2)
                } else {
                    WebcastTimeline(progress: t.timelineProgress, clock: t.clockText)
                        .frame(maxWidth: 330)
                        .padding(.bottom, 2)
                }
                Spacer(minLength: 12)
                ArcGauge(title: "Thrust", value: Self.grouped(t.thrustLbf), unit: "lbf", fraction: t.thrustLbf / 680_000, valueSize: 10)
                    .padding(.bottom, 9)
                VStack(spacing: 2) {
                    GimbalIcon(pitchDeg: t.gimbalPitchDeg, yawDeg: t.gimbalYawDeg)
                    TinyLabel(text: "Gimbal")
                }
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 4)
            .allowsHitTesting(false)
        }
    }

    static func grouped(_ v: Double) -> String {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.maximumFractionDigits = 0
        return f.string(from: NSNumber(value: (v / 100).rounded() * 100)) ?? "0"
    }
}
