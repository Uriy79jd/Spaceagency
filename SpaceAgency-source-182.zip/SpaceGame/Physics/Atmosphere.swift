import Foundation

/// U.S. Standard Atmosphere 1976.
/// 0–86 km: the seven geopotential layers of the standard (hydrostatic, piecewise-linear temperature).
/// 86–120 km: log-linear interpolation of the tabulated 1976 pressures/temperatures.
/// `vacuum` = true returns p = 0.
struct AtmosphereSample {
    var altitude: Double      // geometric, m
    var pressure: Double      // Pa
    var temperature: Double   // K
    var density: Double       // kg/m^3
    var speedOfSound: Double  // m/s
}

enum Atmosphere {
    static let p0 = 101_325.0
    static let g0 = 9.80665
    static let R = 287.053          // J/(kg K) dry air
    static let r0 = 6_356_766.0     // effective Earth radius for geopotential, m

    // base geopotential height (m), base temperature (K), lapse rate (K/m), base pressure (Pa)
    private static let layers: [(Double, Double, Double, Double)] = [
        (0, 288.15, -0.0065, 101_325.0),
        (11_000, 216.65, 0.0, 22_632.06),
        (20_000, 216.65, 0.001, 5_474.889),
        (32_000, 228.65, 0.0028, 868.0187),
        (47_000, 270.65, 0.0, 110.9063),
        (51_000, 270.65, -0.0028, 66.93887),
        (71_000, 214.65, -0.002, 3.956420),
        (84_852, 186.946, 0.0, 0.3734),
    ]

    // geometric altitude (km), pressure (Pa), temperature (K) — 1976 tables above 86 km
    private static let upper: [(Double, Double, Double)] = [
        (86, 0.3734, 186.87), (90, 0.18359, 186.87), (95, 0.07597, 188.42), (100, 0.032011, 195.08),
        (105, 0.014510, 208.84), (110, 0.0071042, 240.0), (115, 0.0040096, 300.0), (120, 0.0025382, 360.0),
    ]

    static func sample(altitude z: Double, vacuum: Bool = false) -> AtmosphereSample {
        if vacuum {
            return AtmosphereSample(altitude: z, pressure: 0, temperature: 3, density: 0, speedOfSound: 0)
        }
        let zc = max(0, z)
        var p: Double, t: Double
        if zc <= 86_000 {
            let h = r0 * zc / (r0 + zc) // geopotential
            var i = layers.count - 1
            while i > 0 && h < layers[i].0 { i -= 1 }
            let (hb, tb, lb, pb) = layers[i]
            t = tb + lb * (h - hb)
            if abs(lb) < 1e-12 {
                p = pb * exp(-g0 * (h - hb) / (R * tb))
            } else {
                p = pb * pow(tb / t, g0 / (R * lb))
            }
        } else {
            let km = min(zc / 1000, 120)
            var i = 0
            while i < upper.count - 2 && km > upper[i + 1].0 { i += 1 }
            let a = upper[i], b = upper[i + 1]
            let f = (km - a.0) / (b.0 - a.0)
            p = exp(log(a.1) + (log(b.1) - log(a.1)) * f)
            t = a.2 + (b.2 - a.2) * f
            if zc > 120_000 { p *= exp(-(zc - 120_000) / 7_000) }
        }
        let rho = p / (R * t)
        return AtmosphereSample(altitude: zc, pressure: p, temperature: t, density: rho, speedOfSound: sqrt(1.4 * R * t))
    }
}
