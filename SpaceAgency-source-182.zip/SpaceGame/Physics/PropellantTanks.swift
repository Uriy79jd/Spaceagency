import Foundation

/// One cryogenic propellant tank: liquid + ullage gas (ideal gas), autogenous pressurisation, boil-off from a
/// heat leak, relief valve and vent valve. Lumped-parameter model, SI units (kg, Pa, K, m³).
struct CryoTank {
    let name: String
    let volume: Double              // m³ total
    let gasR: Double                // J/(kg K) of the vapour (GOX / GCH4)
    let latentHeat: Double          // J/kg
    let boilingK: Double            // normal boiling point
    let densityAtBoil: Double       // kg/m³
    let densitySlope: Double        // kg/m³ per K (denser when subcooled)
    let pressurantTemp: Double      // K, warm autogenous gas from the engine heat exchanger
    let heatLeakUA: Double          // W/K wall heat leak (insulation-free stainless)
    var operatingPressure: Double   // Pa abs, held by autogenous pressurisation while the engine runs
    var reliefPressure: Double      // Pa abs, relief valve cracks here

    var liquidMass: Double
    var liquidTemp: Double
    var ullageMass: Double
    var ullageTemp: Double
    var wallTemp: Double
    var ventOpen = false            // commanded vent (depressurisation)
    private(set) var ventRate: Double = 0       // kg/s out of the vents (relief + commanded)
    private(set) var pressurantRate: Double = 0
    private(set) var boilOffRate: Double = 0
    var capacity: Double { volume * 0.94 * densityAtBoil }

    init(name: String, volume: Double, gasR: Double, latentHeat: Double, boilingK: Double, densityAtBoil: Double,
         densitySlope: Double, pressurantTemp: Double, heatLeakUA: Double, operatingBar: Double, reliefBar: Double,
         fill: Double, subcoolK: Double, startBar: Double) {
        self.name = name; self.volume = volume; self.gasR = gasR; self.latentHeat = latentHeat; self.boilingK = boilingK
        self.densityAtBoil = densityAtBoil; self.densitySlope = densitySlope; self.pressurantTemp = pressurantTemp
        self.heatLeakUA = heatLeakUA; operatingPressure = operatingBar * 1e5; reliefPressure = reliefBar * 1e5
        liquidTemp = boilingK - subcoolK
        let rho = densityAtBoil + densitySlope * subcoolK
        liquidMass = min(fill, 1) * volume * 0.94 * rho
        ullageTemp = boilingK + 8
        wallTemp = boilingK + 15
        let vu = max(volume - liquidMass / rho, 0.5)
        ullageMass = startBar * 1e5 * vu / (gasR * ullageTemp)
    }

    var liquidDensity: Double { densityAtBoil + densitySlope * (boilingK - liquidTemp) }
    var liquidVolume: Double { liquidMass / liquidDensity }
    var ullageVolume: Double { max(volume - liquidVolume, 0.3) }
    var pressure: Double { ullageMass * gasR * ullageTemp / ullageVolume }
    var fillFraction: Double { liquidMass / capacity }

    /// - Parameters: outflow = liquid drawn by the engine (kg/s), pressurise = autogenous gas available (0…1).
    mutating func step(dt: Double, outflow: Double, pressurise: Double, ambientK: Double, ambientPa: Double) {
        let out = min(outflow, liquidMass / dt)
        liquidMass -= out * dt
        // heat leak through the wall: wall sits between ambient and the liquid (frost layer insulates a little)
        let wetFrac = clampd(fillFraction, 0.05, 1)
        wallTemp += ((liquidTemp * wetFrac + ullageTemp * (1 - wetFrac)) * 0.8 + ambientK * 0.2 - wallTemp) * min(1, dt / 30)
        let q = heatLeakUA * max(ambientK - liquidTemp, 0)
        // the liquid warms toward its saturation temperature, then the leak boils it off
        let satK = boilingK + 9.0 * log(max(pressure / 101_325, 0.2))
        if liquidTemp < satK && liquidMass > 1 {
            liquidTemp += q * dt * 0.35 / max(liquidMass * 1700, 1)
            boilOffRate = 0.65 * q / latentHeat
        } else {
            boilOffRate = q / latentHeat
        }
        boilOffRate = min(boilOffRate, liquidMass / dt)
        liquidMass -= boilOffRate * dt
        // autogenous pressurisation: controller holds the operating pressure while the engine supplies warm gas
        pressurantRate = pressurise > 0 ? pressurise * clampd((operatingPressure - pressure) * 4e-5, 0, 30) : 0
        // relief valve + commanded vent (choked-ish flow ∝ p)
        var vent = 0.0
        let p = pressure
        if p > reliefPressure { vent += (p - reliefPressure) * 2e-5 + 0.5 }
        if ventOpen { vent += max(p - ambientPa, 0) * 4e-5 * (ullageVolume / 10 + 1) }
        ventRate = min(vent, ullageMass / dt * 0.5)
        // ullage energy balance (gas mixing): pressurant brings warm gas, boil-off cold vapour, wall heat and
        // condensation on the cold liquid surface pull it back toward the liquid
        let mIn = pressurantRate * dt, mBoil = boilOffRate * dt
        let newMass = max(ullageMass + mIn + mBoil - ventRate * dt, 1e-3)
        let tMix = (ullageMass * ullageTemp + mIn * pressurantTemp + mBoil * (liquidTemp + 2)) / max(ullageMass + mIn + mBoil, 1e-3)
        ullageMass = newMass
        ullageTemp = tMix + ((boilingK + 6) - tMix) * min(1, dt / 45)
        // isentropic-ish cooling while venting
        if ventRate > 0 { ullageTemp -= ullageTemp * 0.2857 * (ventRate * dt / max(ullageMass, 1e-3)) * 0.5 }
        ullageTemp = max(ullageTemp, boilingK - 5)
    }
}

/// LOX + LCH4 tanks of TV-1, sampled for the HUD (sparkline history at 2 Hz).
final class PropellantSystem {
    var lox: CryoTank
    var ch4: CryoTank
    private(set) var loxHistory: [Float] = []
    private(set) var ch4History: [Float] = []
    private var histTimer = 0.0
    static let historyLength = 40

    /// Tank volumes for TV-1 (Ø5 m barrel): LOX aft, CH4 forward.
    static let loxVolume = 60.0
    static let ch4Volume = 44.0

    init(fill: Double) {
        lox = CryoTank(name: "LOX", volume: PropellantSystem.loxVolume, gasR: 259.8, latentHeat: 213e3, boilingK: 90.2,
                       densityAtBoil: 1141, densitySlope: 4.8, pressurantTemp: 390, heatLeakUA: 2600,
                       operatingBar: 5.5, reliefBar: 6.2, fill: fill, subcoolK: 18, startBar: 4.6)
        ch4 = CryoTank(name: "CH4", volume: PropellantSystem.ch4Volume, gasR: 518.3, latentHeat: 510e3, boilingK: 111.7,
                       densityAtBoil: 422, densitySlope: 1.35, pressurantTemp: 330, heatLeakUA: 2000,
                       operatingBar: 5.0, reliefBar: 5.7, fill: fill, subcoolK: 12, startBar: 4.2)
    }

    var totalPropellant: Double { lox.liquidMass + ch4.liquidMass }
    var ventRate: Double { lox.ventRate + ch4.ventRate }

    /// Fuel-side starvation 0…1 for the engine model (inlet pressure lost as the CH4 tank empties or ullage collapses).
    var fuelStarve: Double {
        let level = smoothstepd(0.04, 0.0, ch4.fillFraction)
        let npsh = smoothstepd(2.0e5, 1.2e5, ch4.pressure)
        return max(level, npsh)
    }
    var oxStarve: Double { smoothstepd(0.04, 0.0, lox.fillFraction) }

    func step(dt: Double, oxFlow: Double, fuelFlow: Double, running: Double, ambientK: Double, ambientPa: Double) {
        lox.step(dt: dt, outflow: oxFlow, pressurise: running, ambientK: ambientK, ambientPa: ambientPa)
        ch4.step(dt: dt, outflow: fuelFlow, pressurise: running, ambientK: ambientK, ambientPa: ambientPa)
        histTimer += dt
        if histTimer >= 0.5 {
            histTimer = 0
            loxHistory.append(Float(lox.pressure / 1e5)); ch4History.append(Float(ch4.pressure / 1e5))
            if loxHistory.count > PropellantSystem.historyLength { loxHistory.removeFirst() }
            if ch4History.count > PropellantSystem.historyLength { ch4History.removeFirst() }
        }
    }

    func setVents(_ open: Bool) { lox.ventOpen = open; ch4.ventOpen = open }

    /// Remaining burn time at the given total mass flow, limited by whichever tank runs dry first (mixture ratio).
    func burnTime(massFlow: Double, mixtureRatio: Double) -> Double {
        guard massFlow > 1 else {
            return min(lox.liquidMass / (650 * 3.6 / 4.6), ch4.liquidMass / (650 / 4.6))
        }
        let ox = massFlow * mixtureRatio / (1 + mixtureRatio)
        let fu = massFlow / (1 + mixtureRatio)
        return min(lox.liquidMass / max(ox, 1e-3), ch4.liquidMass / max(fu, 1e-3))
    }
}
