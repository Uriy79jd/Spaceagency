import Foundation
import AVFoundation

/// Parameters pushed from the game every frame.
struct SynthParams {
    var vent: Float = 0          // cryogenic venting 0..1
    var rpm: Float = 0           // turbopump speed fraction
    var combustion: Float = 0    // 0..1
    var pc: Float = 0            // chamber pressure fraction (throttle)
    var air: Float = 1           // ambient pressure / sea level
    var ground: Float = 0        // ground-reflection factor
    var ignitionEvents: Int = 0
    var popEvents: Int = 0
    var distanceGain: Float = 1
    var ambient: Float = 0        // 0..1 space factor: 0 on the pad, 1 in black space
    var ambientVolume: Float = 0.8 // user volume for the space pad, 0..1
}

/// Audio engine: real static-fire samples (startup one-shot → seamless mainstage loop) layered over a
/// procedural synth (vent hiss, turbopump whine, ignition crack, filtered-noise roar, crackle, rumble).
/// Throttle drives pitch/level/brightness, altitude thins and quiets everything, vacuum leaves only a faint
/// structure-borne rumble.
final class SynthAudio {
    private let engine = AVAudioEngine()
    private var source: AVAudioSourceNode?
    private let dsp = SynthDSP()
    private var started = false
    private var lastIgnition = 0
    private var lastPop = 0
    private var enabled = true

    init() {
        dsp.startupSample = SynthAudio.loadSample("raptor_startup")
        dsp.loopSample = SynthAudio.loadSample("raptor_mainstage_loop")
    }

    static func loadSample(_ name: String) -> [Float] {
        guard let url = Bundle.main.url(forResource: name, withExtension: "wav"),
              let file = try? AVAudioFile(forReading: url),
              let buf = AVAudioPCMBuffer(pcmFormat: file.processingFormat, frameCapacity: AVAudioFrameCount(file.length)) else { return [] }
        do { try file.read(into: buf) } catch { return [] }
        guard let ch = buf.floatChannelData else { return [] }
        return Array(UnsafeBufferPointer(start: ch[0], count: Int(buf.frameLength)))
    }

    private func startIfNeeded() {
        guard !started else { return }
        started = true
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)
        let sr = engine.outputNode.outputFormat(forBus: 0).sampleRate
        let rate = sr > 0 ? sr : 48_000
        dsp.sampleRate = Float(rate)
        guard let fmt = AVAudioFormat(standardFormatWithSampleRate: rate, channels: 2) else { return }
        let d = dsp
        let node = AVAudioSourceNode(format: fmt) { _, _, frameCount, audioBufferList -> OSStatus in
            let abl = UnsafeMutableAudioBufferListPointer(audioBufferList)
            d.render(frames: Int(frameCount), buffers: abl)
            return noErr
        }
        source = node
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: fmt)
        engine.mainMixerNode.outputVolume = enabled ? 1 : 0
        do { try engine.start() } catch { started = false }
    }

    func setEnabled(_ on: Bool) {
        enabled = on
        UserDefaults.standard.set(on, forKey: "soundEnabled")
        if on { startIfNeeded() }
        engine.mainMixerNode.outputVolume = on ? 1 : 0
        dsp.master = on ? 1 : 0
    }

    /// Space music on/off (persisted in UserDefaults as "spaceMusicEnabled").
    func setSpaceMusicEnabled(_ on: Bool) {
        dsp.ambientEnabled = on
    }

    /// Space music volume 0..1 (persisted in UserDefaults as "spaceMusicVolume").
    func setAmbientVolume(_ v: Float) {
        dsp.ambientVolume = v
    }

    func update(_ p: SynthParams) {
        if enabled { startIfNeeded() }
        if p.ignitionEvents != lastIgnition {
            if p.ignitionEvents > lastIgnition { dsp.triggerIgnition = true }
            lastIgnition = p.ignitionEvents
        }
        if p.popEvents != lastPop {
            if p.popEvents > lastPop { dsp.triggerPop = true }
            lastPop = p.popEvents
        }
        dsp.target = p
    }
}

/// Runs on the audio render thread. Parameter fields are written from the main thread; single-word
/// reads/writes of Float/Bool are benign races here (values are smoothed per sample).
final class SynthDSP {
    var target = SynthParams()
    var triggerIgnition = false
    var triggerPop = false
    var master: Float = 1
    var ambientEnabled = true
    var ambientVolume: Float = 0.8
    var sampleRate: Float = 48_000
    var startupSample: [Float] = []
    var loopSample: [Float] = []
    let sampleSR: Float = 44_100

    // smoothed params
    private var vent: Float = 0, rpm: Float = 0, comb: Float = 0, pc: Float = 0, air: Float = 1, ground: Float = 0, dist: Float = 1
    private var masterS: Float = 0
    // calm ambient pad for space (procedural: three detuned sines + slow LFO)
    private var amb: Float = 0
    private var padP1: Float = 0, padP2: Float = 0, padP3: Float = 0, lfoP: Float = 0
    // noise / filters
    private var seed: UInt32 = 22222
    private var hpPrev: Float = 0, hpOut: Float = 0
    private var brown: Float = 0
    private var lpRoar: Float = 0, lpRoar2: Float = 0
    private var lpSample: Float = 0, lpSample2: Float = 0
    private var phase1: Float = 0, phase2: Float = 0, phase3: Float = 0, rumbleP1: Float = 0, rumbleP2: Float = 0
    private var crackle: Float = 0
    // one-shots
    private var ignT: Float = 10, popT: Float = 10
    // samples
    private var startupPos: Double = -1
    private var loopPos: Double = 0
    private var loopGain: Float = 0
    private var startupGain: Float = 0
    // slapback delay (ground reflection)
    private var delay = [Float](repeating: 0, count: 4096)
    private var delayIdx = 0

    @inline(__always) private func noise() -> Float {
        seed = seed &* 1664525 &+ 1013904223
        return Float(Int32(bitPattern: seed)) / Float(Int32.max)
    }

    @inline(__always) private func sampleAt(_ s: [Float], _ pos: Double) -> Float {
        let n = s.count
        if n < 2 { return 0 }
        let i = Int(pos)
        let f = Float(pos - Double(i))
        let a = s[i % n], b = s[(i + 1) % n]
        return a + (b - a) * f
    }

    func render(frames: Int, buffers: UnsafeMutableAudioBufferListPointer) {
        guard buffers.count > 0, let l = buffers[0].mData?.assumingMemoryBound(to: Float.self) else { return }
        let r: UnsafeMutablePointer<Float>? = buffers.count > 1 ? buffers[1].mData?.assumingMemoryBound(to: Float.self) : nil
        let sr = sampleRate
        let dt = 1 / sr
        let t = target
        if triggerIgnition {
            triggerIgnition = false
            ignT = 0
            // start the recorded start-up just before its ignition transient
            startupPos = Double(0.30 * sampleSR)
            startupGain = 1
        }
        if triggerPop { triggerPop = false; popT = 0 }
        let kSlow = 1 - expf(-dt / 0.06)
        let kFast = 1 - expf(-dt / 0.015)
        let sampleStep = Double(sampleSR / sr)
        let delaySamples = min(Int(0.026 * sr), delay.count - 1)

        for i in 0..<frames {
            vent += (t.vent - vent) * kSlow
            rpm += (t.rpm - rpm) * kSlow
            // roar: fast attack, very fast release (abrupt shutdown cut-off)
            let kc: Float = t.combustion > comb ? kSlow : kFast * 1.5
            comb += (t.combustion - comb) * min(kc, 1)
            pc += (t.pc - pc) * kSlow
            air += (t.air - air) * kSlow
            ground += (t.ground - ground) * kSlow
            dist += (t.distanceGain - dist) * kSlow
            masterS += (master - masterS) * kSlow
            // ambient pad target: the space factor, gated by the music setting
            amb += ((ambientEnabled ? t.ambient : 0) - amb) * (1 - expf(-dt / 1.5))

            let airLevel = 0.04 + 0.96 * powf(air, 0.6)
            let wn = noise()

            // 1. cryogenic vent hiss (high-passed white noise)
            hpOut = 0.93 * (hpOut + wn - hpPrev)
            hpPrev = wn
            var out = hpOut * vent * 0.16 * powf(air, 0.5)

            // 2. turbopump whine, rising with RPM, masked once the chamber roars
            if rpm > 0.01 {
                let f1 = rpm * 540, f2 = rpm * 1320, f3 = rpm * 3300
                phase1 += f1 * dt; phase2 += f2 * dt; phase3 += f3 * dt
                phase1 -= floorf(phase1); phase2 -= floorf(phase2); phase3 -= floorf(phase3)
                let w = sinf(phase1 * 2 * .pi) * 0.5 + sinf(phase2 * 2 * .pi) * 0.35 + sinf(phase3 * 2 * .pi) * 0.22
                out += w * 0.05 * min(rpm * 3, 1) * (1 - 0.55 * comb) * airLevel
            }

            // 3. ignition crack + thump, 4. pops (preburner light / shutdown)
            if ignT < 1.2 {
                let crack = wn * expf(-ignT / 0.025) * 0.9
                let thump = sinf(2 * .pi * (48 - 20 * ignT) * ignT) * expf(-ignT / 0.22) * 0.7
                out += (crack + thump) * airLevel
                ignT += dt
            }
            if popT < 0.6 {
                out += (wn * expf(-popT / 0.012) * 0.5 + sinf(2 * .pi * 70 * popT) * expf(-popT / 0.08) * 0.35) * airLevel
                popT += dt
            }

            // 5. recorded static-fire: start-up one-shot crossfading into the seamless mainstage loop
            var smp: Float = 0
            let pitch = Double(0.88 + 0.12 * pc)
            if startupPos >= 0 && !startupSample.isEmpty {
                let s = sampleAt(startupSample, startupPos)
                let tS = Float(startupPos) / sampleSR
                // crossfade window 2.3–2.8 s of the recording (already into its mainstage section)
                let x = min(max((tS - 2.3) / 0.5, 0), 1)
                let gS = cosf(x * .pi / 2)
                smp += s * gS * startupGain
                loopGain = max(loopGain, sinf(x * .pi / 2))
                startupPos += sampleStep * pitch
                if Int(startupPos) >= startupSample.count - 2 || x >= 1 { startupPos = -1 }
            }
            if comb > 0.02 && !loopSample.isEmpty {
                if startupPos < 0 && loopGain < 1 { loopGain = min(1, loopGain + dt * 2) }
                smp += sampleAt(loopSample, loopPos) * loopGain
                loopPos += sampleStep * pitch
                if loopPos >= Double(loopSample.count) { loopPos -= Double(loopSample.count) }
            } else if comb <= 0.02 {
                loopGain = 0
            }
            // altitude / throttle tone: low-pass the recording as the air thins and at low throttle
            let fc = (900 + 15_000 * powf(air, 0.7)) * (0.6 + 0.4 * pc)
            let a = min(1, 2 * .pi * fc * dt)
            lpSample += (smp - lpSample) * a
            lpSample2 += (lpSample - lpSample2) * a
            let sampleLevel = comb * (0.55 + 0.45 * pc) * powf(air, 0.65)
            out += lpSample2 * sampleLevel * 0.9

            // 6. procedural roar layer: filtered brown noise + crackle + low rumble
            brown = (brown + wn * 0.02) * 0.998
            let fcR = 160 + 700 * pc * (0.3 + 0.7 * air)
            let aR = min(1, 2 * .pi * fcR * dt)
            lpRoar += (brown * 6 - lpRoar) * aR
            lpRoar2 += (lpRoar - lpRoar2) * aR
            var roar = lpRoar2 * 0.55
            // Poisson crackle (shock-associated N-waves), rate ∝ throttle, needs air
            if noise() * 0.5 + 0.5 < 45 * pc * air * dt { crackle = (noise() > 0 ? 1 : -1) * (0.3 + 0.5 * (noise() * 0.5 + 0.5)) }
            roar += crackle * 0.35
            crackle *= 0.86
            rumbleP1 += 31 * dt; rumbleP2 += 46 * dt
            rumbleP1 -= floorf(rumbleP1); rumbleP2 -= floorf(rumbleP2)
            let rumble = (sinf(rumbleP1 * 2 * .pi) + 0.6 * sinf(rumbleP2 * 2 * .pi)) * (0.6 + 0.4 * lpRoar2 * 4)
            let synthLevel = comb * (0.4 + 0.6 * pc)
            out += roar * synthLevel * airLevel * 0.55
            // vacuum: only a faint structure-borne rumble remains
            out += rumble * synthLevel * (0.04 + 0.12 * air) * 0.5

            // 7. ground reflection: slapback + low-end boost
            let delayed = delay[(delayIdx - delaySamples + delay.count) % delay.count]
            delay[delayIdx] = out
            delayIdx = (delayIdx + 1) % delay.count
            out += delayed * 0.32 * ground + lpRoar2 * 0.25 * ground * comb

            // 8. calm ambient pad for space: detuned sines (A1/E2/A2) breathing on a
            // slow LFO. Fades in with altitude (ambient = spaceFactor), fades out on
            // descent, and ducks under the engine (1 − 0.7 × combustion) so it never
            // drowns the roar on the pad. No audio file — fully procedural.
            if amb > 0.001 {
                padP1 += 55 * dt; padP2 += 82.41 * dt; padP3 += 110.3 * dt; lfoP += 0.05 * dt
                padP1 -= floorf(padP1); padP2 -= floorf(padP2); padP3 -= floorf(padP3); lfoP -= floorf(lfoP)
                let lfo = 0.8 + 0.2 * sinf(lfoP * 2 * .pi)
                let pad = (sinf(padP1 * 2 * .pi) * 0.5 + sinf(padP2 * 2 * .pi) * 0.32 + sinf(padP3 * 2 * .pi) * 0.22) * lfo
                out += pad * amb * t.ambientVolume * 0.10 * (1 - 0.7 * comb)
            }

            // master, distance, soft clip
            out = tanhf(out * dist * masterS * 1.1)
            l[i] = out
            r?[i] = out
        }
    }
}
