import Foundation
import simd

enum ParticleKind: Int {
    case vapor = 0, dust = 1, cloud = 2, spark = 3, debris = 4, greenSpark = 5
}

/// A particle as the CPU describes it at spawn time. The GPU owns it from then on.
struct Particle {
    var pos: Vec3
    var vel: Vec3
    var age: Float
    var life: Float
    var size0: Float
    var size1: Float
    var kind: ParticleKind
    var rot: Float
    var seed: Float
}

/// GPU-side particle slot. Must match `GPUParticle` in ShaderCommon.h (3 x float4).
struct GPUParticle {
    var posLife: Vec4
    var velAge: Vec4
    var params: Vec4
}

/// Spawn record. Must match `ParticleSpawn` in ShaderCommon.h.
struct ParticleSpawn {
    var p: GPUParticle
    var slot: SIMD4<UInt32>
}

/// Must match `ParticleSimUniforms` in ShaderCommon.h.
struct ParticleSimUniforms {
    var imp = Vec4.zero
    var jet = Vec4.zero
    var tilt = Vec4.zero
    var counts = Vec4.zero
    var axis = Vec4.zero
    var exitPos = Vec4.zero
    var wind = Vec4.zero
}

/// Particle emitter front-end. Particles live entirely on the GPU in a fixed-size ring buffer
/// (integrated, collided with the stand and drawn by Shaders/Particles.metal). The CPU only queues
/// spawn records into a preallocated array each frame — no per-frame allocation, no per-particle CPU work.
final class ParticleSystem {
    static let maxSpawnsPerFrame = 512
    /// Ring size actually used (≤ the GPU buffer size). Set by the renderer from the quality level.
    var capacity = 2048
    private(set) var spawns: [ParticleSpawn]
    private(set) var spawnCount = 0
    private var head = 0
    private var rng = XorShift(seed: 0xC0FFEE)
    private var accum = [Float](repeating: 0, count: 8)
    /// Emission scale from the quality level (fewer particles when hot / on low quality).
    var rateScale: Float = 1

    init() {
        let blank = ParticleSpawn(p: GPUParticle(posLife: .zero, velAge: .zero, params: .zero), slot: .zero)
        spawns = [ParticleSpawn](repeating: blank, count: ParticleSystem.maxSpawnsPerFrame)
    }

    private func push(_ p: Particle) {
        guard spawnCount < ParticleSystem.maxSpawnsPerFrame, capacity > 0 else { return }
        let g = GPUParticle(posLife: Vec4(p.pos, p.life), velAge: Vec4(p.vel, p.age),
                            params: Vec4(Float(p.kind.rawValue), p.size0, p.size1, p.seed))
        spawns[spawnCount] = ParticleSpawn(p: g, slot: SIMD4<UInt32>(UInt32(head % capacity), 0, 0, 0))
        head = (head + 1) % capacity
        spawnCount += 1
    }

    func emit(_ kind: ParticleKind, rate: Float, dt: Float, _ make: (inout XorShift) -> Particle?) {
        let k = kind.rawValue
        var a = accum[k] + rate * rateScale * dt
        while a >= 1 {
            a -= 1
            if let p = make(&rng) { push(p) }
        }
        accum[k] = min(a, 4)
    }

    func burst(count: Int, _ make: (inout XorShift) -> Particle?) {
        let n = Int(Float(count) * rateScale)
        for _ in 0..<n {
            if let p = make(&rng) { push(p) }
        }
    }

    /// Called by the renderer after it has copied this frame's spawns to the GPU.
    func consumeSpawns() { spawnCount = 0 }

    /// Drop every queued spawn and restart the ring (e.g. after a capacity change).
    func reset() {
        spawnCount = 0
        head = 0
    }
}
