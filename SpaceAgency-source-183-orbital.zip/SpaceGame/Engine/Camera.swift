import Foundation
import simd
import CoreGraphics

/// Orbit camera: one-finger orbit, two-finger pan, pinch zoom. World positions in double precision.
final class OrbitCamera {
    var target = DVec3(0, 5.0, 0)
    var yaw: Double = 0.5
    var pitch: Double = 0.05
    var distance: Double = 15
    var fovY: Float = 0.92
    var near: Float = 0.05
    var far: Float = 60000
    var shake = DVec3.zero
    /// Vehicle-mounted camera pose (world eye, forward, up) — replaces the orbit while set.
    var override: (eye: DVec3, forward: DVec3, up: DVec3)? = nil
    var overrideFov: Float? = nil
    var maxDistance: Double = 120

    var eye: DVec3 {
        if let o = override { return o.eye }
        let cp = cos(pitch)
        var e = target + distance * DVec3(cp * sin(yaw), sin(pitch), cp * cos(yaw))
        e.y = max(e.y, 0.25)
        return e + shake
    }

    func orbit(dx: Double, dy: Double) {
        yaw -= dx * 0.008
        pitch = clampd(pitch + dy * 0.006, -0.35, 1.45)
        applyPivot()            // the view shift rotates with the camera; the pivot stays on the object
    }

    /// Orbit pivot (world): while set, swipes orbit AROUND this point (the vehicle's CoM, the engine on the
    /// stand) in a frame centred on it, and pinch zooms toward it. A two-finger pan is a screen-space shift of
    /// the view (`screenOffset`, metres along the camera's right / up), so it re-frames without moving the
    /// pivot: orbiting after a pan still circles the object. The site pan box is only used without a pivot.
    var followAnchor: DVec3? = nil
    var screenOffset = SIMD2<Double>(0, 0)
    var followPanRadius: Double = 40
    /// Site pan box (world) used without a pivot.
    var panCenter = DVec3(0, 30, 0)
    var panHalfExtent = DVec3(60, 30, 60)

    /// Camera right / up for the current yaw and pitch (independent of the target, so no feedback loop).
    private var basis: (right: DVec3, up: DVec3) {
        let cp = cos(pitch)
        let back = DVec3(cp * sin(yaw), sin(pitch), cp * cos(yaw))       // pivot → eye
        let fwd = -back
        let right = simd_normalize(simd_cross(fwd, DVec3(0, 1, 0)))
        return (right, simd_cross(right, fwd))
    }

    private func applyPivot() {
        guard let a = followAnchor else { return }
        let b = basis
        target = a + b.right * screenOffset.x + b.up * screenOffset.y
    }

    func pan(dx: Double, dy: Double, viewHeight: Double) {
        let scale = distance * 2 * tan(Double(fovY) / 2) / max(viewHeight, 1)
        if followAnchor != nil {
            screenOffset += SIMD2(-dx, dy) * scale
            let l = simd_length(screenOffset)
            if l > followPanRadius { screenOffset *= followPanRadius / l }
            applyPivot()
            return
        }
        let fwd = simd_normalize(target - eye)
        let right = simd_normalize(simd_cross(fwd, DVec3(0, 1, 0)))
        let up = simd_cross(right, fwd)
        target += (-right * dx + up * dy) * scale
        let lo = panCenter - panHalfExtent, hi = panCenter + panHalfExtent
        target.x = clampd(target.x, lo.x, hi.x)
        target.y = clampd(target.y, max(lo.y, 0.5), hi.y)
        target.z = clampd(target.z, lo.z, hi.z)
    }

    /// Set / move the orbit pivot (the camera rig calls this every frame for a moving vehicle).
    func follow(_ anchor: DVec3) {
        followAnchor = anchor
        applyPivot()
    }

    func stopFollowing() {
        followAnchor = nil
        screenOffset = .zero
    }

    func zoom(scale: Double) {
        distance = clampd(distance / max(scale, 0.01), 2.5, maxDistance)
    }

    /// View matrix in camera-relative space (camera at origin) — avoids float precision loss far from origin.
    func viewMatrixRelative() -> float4x4 {
        if let o = override {
            return float4x4.lookAt(eye: .zero, center: o.forward.float, up: o.up.float)
        }
        let e = eye
        let f = (target + shake * 0.5 - e).float
        return float4x4.lookAt(eye: .zero, center: f, up: Vec3(0, 1, 0))
    }

    func projection(aspect: Float) -> float4x4 {
        // near plane scales with the orbit distance so a 10 km flight keeps depth precision; mounted cameras sit close
        let n: Float = override != nil ? 0.05 : max(near, Float(distance) * 0.004)
        return float4x4.perspective(fovyRadians: overrideFov ?? fovY, aspect: aspect, near: n, far: far)
    }

    /// World-space ray through a point in view coordinates (points, origin top-left).
    func ray(at p: CGPoint, viewSize: CGSize) -> Ray {
        let aspect = Float(viewSize.width / max(viewSize.height, 1))
        let ndc = SIMD2<Float>(Float(p.x / viewSize.width) * 2 - 1, 1 - Float(p.y / viewSize.height) * 2)
        let inv = (projection(aspect: aspect) * viewMatrixRelative()).inverse
        let a = inv * Vec4(ndc.x, ndc.y, 0, 1)
        let b = inv * Vec4(ndc.x, ndc.y, 1, 1)
        let pa = Vec3(a.x, a.y, a.z) / a.w
        let pb = Vec3(b.x, b.y, b.z) / b.w
        let d = simd_normalize(pb - pa).double
        return Ray(origin: eye, direction: d)
    }
}
