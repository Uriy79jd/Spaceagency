import Foundation
import simd
import CoreGraphics
import QuartzCore

/// A placed part instance.
final class Entity {
    let id: Int
    let def: PartDefinition
    var position: DVec3      // world position of the part origin (top of gimbal block for engines)

    init(id: Int, def: PartDefinition, position: DVec3) {
        self.id = id
        self.def = def
        self.position = position
    }
}

/// Everything the renderer needs for one frame (camera-relative where noted).
struct FrameState {
    var cameraWorld = DVec3.zero
    var view = matrix_identity_float4x4
    var engineFixedModel: float4x4? = nil         // camera-relative
    var engineGimbalModel: float4x4? = nil
    var engineHighlight: Float = 0
    var engineGhost = false
    var engineDef: PartDefinition? = nil
    var actuator0: (Vec3, Vec3)? = nil            // camera-relative endpoints (stand end, engine end)
    var actuator1: (Vec3, Vec3)? = nil
    var particleSim = ParticleSimUniforms()        // GPU particle flow field / collision parameters
    var lastInteraction: CFTimeInterval = 0
    var plume = PlumeState()
    var plumeExit = Vec3.zero                     // camera-relative
    var plumeAxis = Vec3(0, -1, 0)
    var plumeAxisFar = Vec3(0, -1, 0)
    var impingement = Vec3.zero                   // camera-relative point on pad
    var exitRadius: Float = 0.665
    var wallTemp: Float = 293
    var padTemp: Float = 293
    var padCenterWorld = SIMD2<Float>(0, 0)
    var scorch: Float = 0
    var shockRingAge: Float = 99
    var altitude: Double = 0
    var vacuum = false
    var outdoor = true
    var time: Double = 0
    var thrustFraction: Float = 0
    var vent: Float = 0
    // TV-1
    var vehicleModel: float4x4? = nil             // camera-relative
    var vehicleFrost: Float = 1
    var vehicleDent: Float = 0
    // Orbital
    var boosterModel: float4x4? = nil             // camera-relative, booster after separation
    var orbitalVehicle = false                    // vehicleModel is the orbital stack, not TV-1
    var orbitalStage: Int = 1
    var shadowCenter: Vec3? = nil                 // world, when the shadow map should follow a vehicle
    var vehicleKey = SIMD4<Float>(0, 0, 0, 0)     // changes whenever the vehicle moved (shadow cache key)
    var copper: Float = 0
    var wind = Vec3(1.2, 0, 0.4)                  // surface wind (world, m/s) for grass / steam
}

/// Game/editor core: owns the world, fixed-timestep simulation, camera, input and selection.
final class GameEngine {
    let ui: GameUIModel
    let camera = OrbitCamera()
    let particles = ParticleSystem()
    let audio = SynthAudio()
    let impingement = ImpingementSystem()

    private(set) var engineEntity: Entity?
    private(set) var sim: RaptorSim?
    private var nextId = 1
    private(set) var outdoor = true
    /// TV-1 launch-pad site: the engine rides the vehicle, the flight sim drives everything.
    private(set) var tv1Mode = false
    private(set) var flight: TV1Flight?
    /// Orbital launch-pad site: the Falcon-size two-stage vehicle, ECI physics.
    private(set) var orbitalMode = false
    private(set) var orbitalFlight: OrbitalFlight?
    private var lastBoosterSplashed = false
    var mountPoint: DVec3 { DVec3(0, Double(outdoor ? TestSiteMesh.mountHeight : HangarMesh.mountHeight), 0) }

    // fixed timestep
    let simDt = 1.0 / 120.0
    private var accumulator = 0.0
    private(set) var simTime = 0.0
    private var lastFrame: CFTimeInterval = 0
    private var lastUIPush: CFTimeInterval = 0
    private var fpsAccum = 0.0
    private var fpsFrames = 0

    // drag-from-tray ghost
    private var ghostPos: DVec3?
    private var ghostSnaps = false
    var viewSize = CGSize(width: 1, height: 1)

    // gimbal input
    var joystick = SIMD2<Double>(0, 0)
    private var patternTime = 0.0
    private var farAxis = DVec3(0, -1, 0)
    private var shakePhase = 0.0

    // demo / screenshot mode
    let demoScreenshot: Bool
    let demoFire: Bool
    let demoOrbital: Bool
    private var demoStarted = false
    private var lastClock = "T+ 00:00:00"

    static func clock(_ seconds: Double) -> String {
        let s = max(0, Int(seconds.rounded(.down)))
        return String(format: "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
    }

    init(ui: GameUIModel) {
        self.ui = ui
        let args = ProcessInfo.processInfo.arguments
        demoScreenshot = args.contains("-demoScreenshot")
        demoFire = args.contains("-demoFire")
        demoOrbital = args.contains("-demoOrbital")
        outdoor = UserDefaults.standard.object(forKey: "sceneOutdoor") as? Bool ?? true
        if args.contains("-hangar") { outdoor = false }
        ui.outdoor = outdoor
        ui.site = outdoor ? "stand" : "hangar"
        configureImpingementSurfaces()
        frameCamera()
        if demoScreenshot {
            placeEngine(at: mountPoint)
            ui.showHint = false
            ui.engineSelected = false
        }
        // the TV-1 pad is a site of its own: restore it too (build 180 persisted only stand / hangar)
        if !demoScreenshot && !args.contains("-hangar") && outdoor && UserDefaults.standard.string(forKey: "site") == "pad" {
            enterPad()
        }
        // orbital demo / restore: the Falcon-size stainless rocket on the new pad, framed full-vehicle.
        // -demoOrbital places it; -demoFire (with it) starts the launch countdown.
        if demoOrbital {
            enterOrbitalPad()
            ui.showHint = false
            ui.engineSelected = false
        } else if !demoScreenshot && !args.contains("-hangar") && outdoor && UserDefaults.standard.string(forKey: "site") == "orbital" {
            enterOrbitalPad()
        }
        let enabled = UserDefaults.standard.object(forKey: "soundEnabled") as? Bool ?? true
        audio.setEnabled(enabled)
        ui.spaceMusicEnabled = UserDefaults.standard.object(forKey: "spaceMusicEnabled") as? Bool ?? true
        ui.spaceMusicVolume = UserDefaults.standard.object(forKey: "spaceMusicVolume") as? Double ?? 0.8
        audio.setSpaceMusicEnabled(ui.spaceMusicEnabled)
        audio.setAmbientVolume(Float(ui.spaceMusicVolume))
    }

    // MARK: scene

    /// Switch between the outdoor McGregor-style test stand and the indoor hangar (only while the engine is safed).
    func setScene(outdoor o: Bool) {
        if let s = sim, s.phase != .safed { return }
        if tv1Mode { leavePad() }
        if orbitalMode { leaveOrbitalPad() }
        outdoor = o
        configureImpingementSurfaces()
        if let e = engineEntity { e.position = mountPoint }
        frameCamera()
        ui.site = o ? "stand" : "hangar"
        ui.outdoor = o
        persistSite()
    }

    private func persistSite() {
        UserDefaults.standard.set(ui.site, forKey: "site")
        UserDefaults.standard.set(outdoor, forKey: "sceneOutdoor")
    }

    /// Cycle STAND → TV-1 PAD → ORBITAL PAD → HANGAR (only while nothing is firing / flying).
    func cycleSite() {
        if let s = sim, s.phase != .safed && s.phase != .purge { return }
        if let f = flight, f.phase == .countdown { return }
        if let f = flight, f.missionTime >= 0 && f.phase != .done && f.phase != .lost && f.phase != .aborted { return }
        if let f = orbitalFlight, f.phase == .countdown { return }
        if let f = orbitalFlight, f.missionTime >= 0 && f.phase != .done && f.phase != .lost && f.phase != .aborted
            && f.phase != .orbit && f.phase != .landed { return }
        if orbitalMode { setScene(outdoor: false) }
        else if tv1Mode { enterOrbitalPad() }
        else if outdoor { enterPad() }
        else { setScene(outdoor: true) }
    }

    func enterPad() {
        outdoor = true
        tv1Mode = true
        configureImpingementSurfaces()
        if engineEntity == nil { placeEngine(at: mountPoint) }
        resetFlight()
        ui.site = "pad"
        ui.outdoor = true
        ui.cameraNames = ["MAIN"] + TV1Cameras.mounts.map { $0.name }
        ui.cameraMode = 0
        frameCamera()
        persistSite()
    }

    private func leavePad() {
        tv1Mode = false
        flight = nil
        if let e = engineEntity {
            let s = RaptorSim(def: e.def)
            sim = s
            applyAltitude()
            e.position = mountPoint
        }
        ui.cameraNames = ["MAIN"] + StandCameras.mounts.map { $0.name }
        ui.cameraMode = 0
        camera.override = nil
        camera.overrideFov = nil
        camera.maxDistance = 120
    }

    /// New TV-1 flight on the pad with the selected profile / scenario (fresh engine, full tanks for the profile).
    func resetFlight() {
        guard tv1Mode, let e = engineEntity else { return }
        let s = RaptorSim(def: e.def)
        sim = s
        let f = TV1Flight(engine: s, surfaces: impingement, pad: TV1Site.padCenter, landingZone: TV1Site.landingZone,
                          profile: ui.tv1Profile, scenario: ui.tv1Scenario)
        if ui.tv1Profile == .tenK { f.landAtPad = ui.tv1LandAtPad }
        f.autopilot = ui.tv1Autopilot
        flight = f
        e.position = f.vehicle.mountWorld
        ui.running = false
        ui.starting = false
    }

    /// LAUNCH button: START AUTOPILOT runs the T-10 countdown; with the autopilot off it is a manual ignition.
    func tv1Launch() {
        guard let f = flight else { return }
        if f.autopilot { f.startCountdown() } else { f.manualStart() }
    }
    func tv1Abort() { flight?.abort() }

    /// Orbital pad site: the Falcon-size vehicle on the coastal pad (strongback, trench, masts).
    func enterOrbitalPad() {
        if tv1Mode { leavePad() }
        outdoor = true
        orbitalMode = true
        configureImpingementSurfaces()
        if engineEntity == nil { placeEngine(at: mountPoint) }
        resetOrbitalFlight()
        ui.site = "orbital"
        ui.outdoor = true
        ui.cameraNames = ["MAIN"] + OrbitalCameras.mounts.map { $0.name }
        ui.cameraMode = 0
        frameCamera()
        persistSite()
    }

    private func leaveOrbitalPad() {
        orbitalMode = false
        orbitalFlight = nil
        if let e = engineEntity {
            let s = RaptorSim(def: e.def)
            sim = s
            applyAltitude()
            e.position = mountPoint
        }
        ui.cameraNames = ["MAIN"] + StandCameras.mounts.map { $0.name }
        ui.cameraMode = 0
        camera.override = nil
        camera.overrideFov = nil
        camera.maxDistance = 120
    }

    /// New orbital flight on the pad (fresh engines, full tanks, FX-9 snap stack).
    func resetOrbitalFlight() {
        guard orbitalMode, let e = engineEntity else { return }
        let of = OrbitalFlight(def: e.def, surfaces: impingement)
        orbitalFlight = of
        sim = of.vehicle.stage1Engines[0]
        e.position = OrbitalSite.padCenter + DVec3(0, OrbitalVehicle.s1MountY, 0)
        ui.running = false
        ui.starting = false
        ui.orbitalSelectedEngine = nil
        ui.orbitalSelectedRCSThruster = nil
        ui.orbitalDestination = nil
        lastBoosterSplashed = false
    }

    /// LAUNCH button (orbital): START AUTOPILOT runs the T-10 countdown to orbit.
    func orbitalLaunch() { orbitalFlight?.startCountdown() }
    func orbitalAbort() { orbitalFlight?.abort() }
    func orbitalSetAutopilot(_ on: Bool) {
        guard let of = orbitalFlight else { return }
        if on { of.autopilot = true } else { of.requestManualControl() }   // manual is a stub: warns, stays on autopilot
        ui.orbitalAutopilot = of.autopilot
    }
    func orbitalSetWarp(_ w: Double) {
        orbitalFlight?.setWarp(w)
        ui.orbitalWarp = orbitalFlight?.warpRequest ?? 1
    }
    func orbitalShutdownEngine(_ i: Int) { orbitalFlight?.shutDownEngine(i) }
    func orbitalRelightEngine(_ i: Int) { orbitalFlight?.relightEngine(i) }
    func orbitalShutdownStage2Engine() { orbitalFlight?.shutDownStage2Engine() }
    func orbitalToggleRCSThruster(_ id: String, enabled: Bool) { orbitalFlight?.setRCSThruster(id, enabled: enabled) }
    func orbitalSelectDestination(_ dest: MapDestination?) {
        orbitalFlight?.selectDestination(dest)
        ui.orbitalDestination = dest
    }
    func orbitalBeginDeorbit() { orbitalFlight?.beginDeorbitLanding() }
    func orbitalSetSpaceMusicEnabled(_ on: Bool) {
        ui.spaceMusicEnabled = on
        UserDefaults.standard.set(on, forKey: "spaceMusicEnabled")
        audio.setSpaceMusicEnabled(on)
    }
    func orbitalSetSpaceMusicVolume(_ v: Double) {
        ui.spaceMusicVolume = v
        UserDefaults.standard.set(v, forKey: "spaceMusicVolume")
        audio.setAmbientVolume(Float(v))
    }
    func tv1EngineStart() { flight?.manualStart() }
    func tv1EngineStop() { flight?.manualShutdown() }
    func tv1SetAutopilot(_ on: Bool) {
        guard let f = flight else { return }
        if on { f.resumeAutopilot() } else {
            if f.phase == .countdown { f.abort() }          // turning the autopilot off holds the count
            f.autopilot = false
        }
    }

    func resetCamera() {
        ui.cameraMode = 0
        camera.override = nil
        camera.overrideFov = nil
        frameCamera()
    }

    private func configureImpingementSurfaces() {
        if orbitalMode {
            impingement.surfaces = OrbitalSite.surfaces()
            return
        }
        impingement.surfaces = outdoor ? TestSiteMesh.impingementSurfaces()
                                       : [.plane(point: DVec3(0, 0, 0), normal: DVec3(0, 1, 0))]
    }

    /// Orbit pivot on the stand / in the hangar: the middle of the placed engine (the selectable object).
    private var standPivot: DVec3? { engineEntity.map { $0.position + DVec3(0, -1.5, 0) } }
    /// Default lens shift around the pivot so the engine and its plume down to the deflector are framed.
    private var standScreenOffset: SIMD2<Double> { SIMD2(0, outdoor ? -11.5 : -1.8) }

    func frameCamera() {
        camera.stopFollowing()
        if orbitalMode, let of = orbitalFlight {
            camera.maxDistance = 3000
            camera.yaw = 0.55; camera.pitch = 0.10; camera.distance = 90
            camera.screenOffset = SIMD2(0, 4)
            camera.follow(of.comWorld)               // orbit pivot = vehicle CoM, full 68 m vehicle in frame
            return
        }
        if tv1Mode, let f = flight {
            camera.maxDistance = 3000
            camera.yaw = 0.55; camera.pitch = 0.10; camera.distance = 48
            camera.screenOffset = SIMD2(0, 2)
            camera.follow(f.vehicle.comWorld)           // orbit pivot = vehicle CoM
            return
        }
        camera.maxDistance = 120
        camera.panCenter = DVec3(0, 30, 0)
        if outdoor {
            // real-scale tripod: engine 38 m up, frame the engine and the plume down to the deflector
            camera.target = DVec3(0, 25, 0); camera.yaw = 0.42; camera.pitch = 0.07; camera.distance = 52
        } else {
            camera.target = DVec3(0, 5.0, 0); camera.yaw = 0.5; camera.pitch = 0.05; camera.distance = 15
        }
        if let p = standPivot {
            camera.screenOffset = standScreenOffset
            camera.follow(p)                            // orbit pivot = the engine
        }
    }

    // MARK: placement

    func placeEngine(at p: DVec3) {
        guard engineEntity == nil, let def = PartCatalog.shared.part("raptor3") else { return }
        engineEntity = Entity(id: nextId, def: def, position: p)
        nextId += 1
        let s = RaptorSim(def: def)
        s.fastStart = demoFire
        sim = s
        applyAltitude()
        ui.enginePlaced = true
        ui.showHint = false
        ui.engineSelected = true
    }

    func removeEngine() {
        engineEntity = nil
        sim = nil
        ui.enginePlaced = false
        ui.engineSelected = false
        ui.running = false
        ui.starting = false
    }

    // tray drag (points in the Metal view's coordinate space)
    func dragUpdate(_ p: CGPoint) {
        guard engineEntity == nil else { return }
        let ray = camera.ray(at: p, viewSize: viewSize)
        // plane through the mount point facing the camera horizontally
        let planeY = mountPoint.y - 1.5
        var hit: DVec3
        if abs(ray.direction.y) > 1e-4 {
            let t = (planeY - ray.origin.y) / ray.direction.y
            hit = t > 0 ? ray.origin + ray.direction * t : ray.origin + ray.direction * 12
        } else {
            hit = ray.origin + ray.direction * 12
        }
        hit.y += 1.5
        let d = simd_length(DVec3(hit.x - mountPoint.x, 0, hit.z - mountPoint.z))
        ghostSnaps = d < 4.0
        ghostPos = ghostSnaps ? mountPoint : hit
        if ui.dragSnaps != ghostSnaps { ui.dragSnaps = ghostSnaps }
        if !ui.dragging { ui.dragging = true }
    }

    func dragEnd(_ p: CGPoint, overTray: Bool) {
        if let _ = ghostPos, ghostSnaps, !overTray { placeEngine(at: mountPoint) }
        ghostPos = nil
        ghostSnaps = false
        ui.dragging = false
        ui.dragSnaps = false
    }

    func quickPlace() { placeEngine(at: mountPoint) }

    // MARK: input

    func tap(at p: CGPoint) {
        if orbitalMode, let of = orbitalFlight {
            orbitalTap(at: p, flight: of)
            return
        }
        guard let e = engineEntity else { ui.engineSelected = false; return }
        let ray = camera.ray(at: p, viewSize: viewSize)
        let r = e.def.pickRadius
        let minB = e.position + DVec3(-r, -e.def.heightM - 0.1, -r)
        let maxB = e.position + DVec3(r, 0.1, r)
        ui.engineSelected = intersectAABB(ray: ray, minB: minB, maxB: maxB) != nil
    }

    /// Orbital tap-to-select: the nearest of the 9 S1 engine bells (or the single
    /// S2 engine) within 1.2 m of the ray, else the nearest RCS thruster within
    /// 1.0 m. The panel then offers SHUT DOWN / RESTART (engines) or ON/OFF (RCS).
    private func orbitalTap(at p: CGPoint, flight of: OrbitalFlight) {
        let ray = camera.ray(at: p, viewSize: viewSize)
        let v = of.vehicle
        let origin = OrbitalSite.padCenter + v.localPosition
        let q = of.orientationLocal
        func rayDist(_ pt: DVec3) -> Double {
            let d = pt - ray.origin
            let t = simd_dot(d, ray.direction)
            guard t > 0 else { return .infinity }
            return simd_length(d - ray.direction * t)
        }
        var bestEngine: Int? = nil
        var bestD = 1.2
        if v.stage == 1 {
            for (i, pos) in OrbitalVehicle.enginePositions.enumerated() {
                let d = rayDist(origin + simd_act(q, pos))
                if d < bestD { bestD = d; bestEngine = i }
            }
        } else if rayDist(origin + simd_act(q, DVec3(0, OrbitalVehicle.s2MountY, 0))) < bestD {
            bestEngine = 0
        }
        if let i = bestEngine {
            ui.orbitalSelectedEngine = i
            ui.orbitalSelectedRCSThruster = nil
            return
        }
        var bestThruster: String? = nil
        var bestT = 1.0
        for t in v.rcs.thrusters {
            let d = rayDist(origin + simd_act(q, t.position))
            if d < bestT { bestT = d; bestThruster = t.id }
        }
        ui.orbitalSelectedRCSThruster = bestThruster
        if bestThruster != nil { ui.orbitalSelectedEngine = nil }
    }

    func start() { sim?.requestStart() }
    /// Green-copper test: starve the methane side (fuel-pump inlet pressure collapses → oxidiser-rich).
    func starveMethane() { sim?.starveFuel() }
    func refillRunTank() { sim?.refill() }
    func shutdown() { sim?.requestShutdown() }
    func setThrottle(_ t: Double) { sim?.throttleCmd = t }

    func applyAltitude() {
        let (alt, vac) = GameUIModel.altitude(forSlider: ui.altitudeSlider)
        sim?.ambient = Atmosphere.sample(altitude: alt, vacuum: vac)
    }

    var currentAmbient: AtmosphereSample {
        let (alt, vac) = GameUIModel.altitude(forSlider: ui.altitudeSlider)
        return Atmosphere.sample(altitude: alt, vacuum: vac)
    }

    // MARK: frame

    /// Called once per rendered frame. Steps the simulation at a fixed rate, independent of frame rate.
    func frame(now: CFTimeInterval) -> FrameState {
        if lastFrame == 0 { lastFrame = now }
        let realDt = min(now - lastFrame, 0.1)
        lastFrame = now
        accumulator += realDt
        var steps = 0
        // Time warp (orbital only): run extra fixed-timestep substeps per frame —
        // the physics dt never changes, so the sim stays stable at 1x/2x/4x/8x.
        let maxSteps = Int(12 * (orbitalFlight?.effectiveWarp ?? 1))
        while accumulator >= simDt && steps < maxSteps {
            fixedStep(simDt)
            accumulator -= simDt
            steps += 1
        }
        if steps == maxSteps { accumulator = 0 }

        fpsAccum += realDt; fpsFrames += 1
        if now - lastUIPush > 0.1 { pushUI(now: now) }
        return buildFrameState()
    }

    private func gimbalCommand() {
        guard let s = sim else { return }
        let maxA = s.gimbal.maxAngle
        if ui.gimbalMode {
            if simd_length(joystick) > 0.02 {
                s.gimbal.cmdPitch = -joystick.y * maxA
                s.gimbal.cmdYaw = -joystick.x * maxA
            } else if ui.gimbalPattern != .none {
                let c = ui.gimbalPattern.command(time: patternTime, amplitude: maxA * 0.8)
                s.gimbal.cmdPitch = c.0
                s.gimbal.cmdYaw = c.1
            } else {
                s.gimbal.cmdPitch = 0; s.gimbal.cmdYaw = 0
            }
        } else {
            s.gimbal.cmdPitch = 0; s.gimbal.cmdYaw = 0
        }
    }

    private func fixedStep(_ dt: Double) {
        simTime += dt
        patternTime += dt
        if demoFire, !demoStarted, simTime > 0.6, !orbitalMode, let s = sim {
            demoStarted = true
            s.requestStart()
        }
        if orbitalMode, let of = orbitalFlight, let e = engineEntity {
            // Demo: -demoFire with -demoOrbital starts the launch countdown.
            if demoFire, !demoStarted, simTime > 0.6 {
                demoStarted = true
                of.startCountdown()
            }
            of.step(dt: dt)
            // The live Raptor mesh rides the active engine: centre S1 engine on
            // the way up, the single S2 engine after separation.
            sim = of.vehicle.stage == 1 ? of.vehicle.stage1Engines[0] : of.vehicle.stage2Engine
            let mountY = of.vehicle.stage == 1 ? OrbitalVehicle.s1MountY : OrbitalVehicle.s2MountY
            e.position = OrbitalSite.padCenter + of.vehicle.localPosition + simd_act(of.orientationLocal, DVec3(0, mountY, 0))
            guard let s = sim else { return }
            let geo = engineGeometry(e, s)
            farAxis += (geo.axis - farAxis) * (1 - exp(-dt / 0.25))
            farAxis = simd_normalize(farAxis)
            emitParticles(dt: dt, sim: s, geo: geo)
            emitOrbitalParticles(dt: dt, flight: of, geo: geo)
            return
        }
        if tv1Mode, let f = flight, let e = engineEntity {
            f.manualThrottle = ui.throttle
            f.manualStick = joystick
            f.manualTranslate = ui.tv1Translate
            f.assistAttitude = ui.tv1AssistAttitude
            f.assistHover = ui.tv1AssistHover
            f.step(dt: dt)
            e.position = f.vehicle.mountWorld
            let geo = engineGeometry(e, f.engine)
            farAxis += (geo.axis - farAxis) * (1 - exp(-dt / 0.25))
            farAxis = simd_normalize(farAxis)
            emitParticles(dt: dt, sim: f.engine, geo: geo)
            emitTV1Particles(dt: dt, flight: f, geo: geo)
            return
        }
        gimbalCommand()
        guard let s = sim, let e = engineEntity else { return }
        let geo = engineGeometry(e, s)
        s.exitHeight = max(geo.exit.y, 0.5)
        s.impingement = geo.hit
        s.step(dt: dt)
        // far plume lags the nozzle (gas inertia / transport delay)
        farAxis += (s.gimbal.exhaustAxis - farAxis) * (1 - exp(-dt / 0.25))
        farAxis = simd_normalize(farAxis)
        emitParticles(dt: dt, sim: s, geo: geo)
    }

    struct EngineGeometry {
        var exit: DVec3
        var axis: DVec3
        var impingement: DVec3
        var rotation: simd_quatd
        var hit: ImpingementHit
    }

    private func engineGeometry(_ e: Entity, _ s: RaptorSim) -> EngineGeometry {
        if orbitalMode, let of = orbitalFlight {
            let hit = s.impingement
            let axis = of.exhaustAxisWorld
            let exit = of.exitWorld
            return EngineGeometry(exit: exit, axis: axis, impingement: hit.hit ? hit.point : exit + axis * 200,
                                  rotation: of.orientationLocal * s.gimbal.rotation, hit: hit)
        }
        if tv1Mode, let f = flight {
            let hit = s.impingement
            let axis = f.exhaustAxisWorld
            let exit = f.exitWorld
            return EngineGeometry(exit: exit, axis: axis, impingement: hit.hit ? hit.point : exit + axis * 200,
                                  rotation: f.vehicle.orientation * s.gimbal.rotation, hit: hit)
        }
        let q = s.gimbal.rotation
        let pivot = DVec3(0, Double(RaptorMesh.pivotY), 0)
        let exitLocal = DVec3(0, -Double(RaptorMesh.height), 0)
        let exit = e.position + pivot + simd_act(q, exitLocal - pivot)
        let axis = s.gimbal.exhaustAxis
        let hit = impingement.cast(origin: exit, direction: axis)
        let imp: DVec3 = hit.hit ? hit.point : exit + axis * 200
        return EngineGeometry(exit: exit, axis: axis, impingement: imp, rotation: q, hit: hit)
    }

    private func emitParticles(dt: Double, sim s: RaptorSim, geo: EngineGeometry) {
        let fdt = Float(dt)
        let p = s.plume
        let exit = geo.exit.float
        let imp = geo.impingement.float
        let axis = geo.axis.float
        let thr = Float(s.thrust / s.def.thrustSeaLevelN)
        let gf = Float(p.groundFactor)
        let re = Float(s.exitRadiusPhysical)
        let rj = Float(max(p.jetRadius, s.exitRadiusPhysical)) * 1.15
        let rw = Float(max(p.wallJetRadius, 1))
        let air = Float(clampd(s.ambient.pressure / Atmosphere.p0, 0, 1))
        let uVis = Float(p.wallJetSpeed) * 0.16
        let horiz = SIMD2<Float>(axis.x, axis.z)
        let tiltS = simd_length(horiz)
        let phiAxis = atan2f(axis.z, axis.x)

        // Cryogenic venting: cold vapour pours from the head bleed points and the nozzle.
        if s.vent > 0.01 && air > 0.02 {
            let head = (engineEntity?.position ?? .zero).float + Vec3(0, -0.9, 0)
            particles.emit(.vapor, rate: Float(s.vent) * 90 * air, dt: fdt) { r in
                let a = r.unit() * 2 * .pi
                let fromNozzle = r.unit() < 0.45
                let rad: Float = fromNozzle ? re * (0.6 + 0.4 * r.unit()) : 0.35 + 0.2 * r.unit()
                let base = fromNozzle ? exit + Vec3(0, 0.2 + r.unit() * 0.8, 0) : head + Vec3(0, r.signed() * 0.25, 0)
                let pos = base + Vec3(cosf(a) * rad, 0, sinf(a) * rad)
                let vel = Vec3(cosf(a) * (0.3 + r.unit() * 0.5), -0.2 - r.unit() * 0.6, sinf(a) * (0.3 + r.unit() * 0.5))
                return Particle(pos: pos, vel: vel, age: 0, life: 2.5 + r.unit() * 2.5, size0: 0.12, size1: 1.0 + r.unit() * 1.2,
                                kind: .vapor, rot: r.unit() * 6.28, seed: r.unit())
            }
        }

        guard p.active > 0.05 else { return }

        // copper erosion (engine-rich): green sparks / molten copper bits blown out of the nozzle
        if s.engineRich > 0.15 && s.combustion > 0.3 {
            particles.emit(.greenSpark, rate: 110 * Float(s.engineRich), dt: fdt) { r in
                let side = Vec3(r.signed(), r.signed() * 0.3, r.signed()) * 0.4
                let vel = (axis + side * 0.3) * (60 + r.unit() * 120)
                return Particle(pos: exit + side, vel: vel, age: 0, life: 0.6 + r.unit() * 0.8, size0: 0.06, size1: 0.03,
                                kind: .greenSpark, rot: 0, seed: r.unit())
            }
        }

        func radialDir(_ r: inout XorShift) -> (Float, SIMD2<Float>, Float) {
            // oblique impingement throws more flow downstream of the tilt
            var a = r.unit() * 2 * .pi
            if tiltS > 0.02, r.unit() < tiltS * 2.5 { a = phiAxis + r.signed() * 1.2 }
            let d = SIMD2<Float>(cosf(a), sinf(a))
            let asym = 1 + 2.5 * tiltS * cosf(a - phiAxis)
            return (a, d, max(asym, 0.25))
        }

        let onWater = tv1Mode && geo.hit.hit && TV1Site.isWater(geo.hit.point)
        if gf > 0.02 && !onWater {
            // dust / grit stripped off the pad by the stagnation flow
            particles.emit(.dust, rate: 170 * gf * min(thr, 1.2), dt: fdt) { r in
                let (_, d, asym) = radialDir(&r)
                let rr = rj * (0.7 + r.unit() * 1.0)
                let pos = imp + Vec3(d.x * rr, 0.05 + r.unit() * 0.25, d.y * rr)
                let sp = uVis * asym * (0.5 + r.unit() * 0.6)
                return Particle(pos: pos, vel: Vec3(d.x * sp, 0.5 + r.unit() * 2.0, d.y * sp), age: 0, life: 1.0 + r.unit() * 1.4,
                                size0: 0.2, size1: 0.9 + r.unit() * 1.3, kind: .dust, rot: r.unit() * 6.28, seed: r.unit())
            }
            // steam / smoke billows rolling out with the wall jet, deflected upward at the edges
            particles.emit(.cloud, rate: 20 * gf * min(thr, 1.2), dt: fdt) { r in
                let (_, d, asym) = radialDir(&r)
                let rr = rj * 1.2 + r.unit() * rw * 0.35
                let pos = imp + Vec3(d.x * rr, 0.4 + r.unit() * 1.2, d.y * rr)
                let sp = uVis * 0.55 * asym * (0.6 + r.unit() * 0.5)
                return Particle(pos: pos, vel: Vec3(d.x * sp, 1.0 + r.unit() * 3.0, d.y * sp), age: 0, life: 4.5 + r.unit() * 4.0,
                                size0: 1.6, size1: 6.0 + r.unit() * 6.0, kind: .cloud, rot: r.unit() * 6.28, seed: r.unit())
            }
            // sparks: hot grit / concrete spall from the stagnation zone
            particles.emit(.spark, rate: 110 * gf * min(thr, 1.2), dt: fdt) { r in
                let (_, d, asym) = radialDir(&r)
                let rr = rj * r.unit() * 0.9
                let pos = imp + Vec3(d.x * rr, 0.05, d.y * rr)
                let sp = (14 + r.unit() * 30) * asym
                return Particle(pos: pos, vel: Vec3(d.x * sp, 3 + r.unit() * 12, d.y * sp), age: 0, life: 0.5 + r.unit() * 1.0,
                                size0: 0.05, size1: 0.025, kind: .spark, rot: 0, seed: r.unit())
            }
            particles.emit(.debris, rate: 10 * gf * min(thr, 1.2), dt: fdt) { r in
                let (_, d, asym) = radialDir(&r)
                let rr = rj * (0.8 + r.unit())
                let pos = imp + Vec3(d.x * rr, 0.1, d.y * rr)
                let sp = (8 + r.unit() * 18) * asym
                return Particle(pos: pos, vel: Vec3(d.x * sp, 2 + r.unit() * 9, d.y * sp), age: 0, life: 1.5 + r.unit() * 1.5,
                                size0: 0.06 + r.unit() * 0.08, size1: 0.06, kind: .debris, rot: r.unit() * 6.28, seed: r.unit())
            }
            // ignition overpressure: dust ring kicked out across the pad
            if s.shockRingAge < dt * 1.5 {
                particles.burst(count: 150) { r in
                    let a = r.unit() * 2 * .pi
                    let rr = rj * (1 + r.unit())
                    let pos = imp + Vec3(cosf(a) * rr, 0.1 + r.unit() * 0.3, sinf(a) * rr)
                    let sp = 28 + r.unit() * 16
                    return Particle(pos: pos, vel: Vec3(cosf(a) * sp, 0.5 + r.unit() * 2.5, sinf(a) * sp), age: 0, life: 1.6 + r.unit() * 1.2,
                                    size0: 0.4, size1: 3.0 + r.unit() * 2, kind: .dust, rot: r.unit() * 6.28, seed: r.unit())
                }
            }
        }

    }

    /// TV-1 effects: steam where the plume flashes the trench water, deluge spray, tank vents (relief and
    /// post-landing depressurisation), RCS puffs.
    private func emitTV1Particles(dt: Double, flight f: TV1Flight, geo: EngineGeometry) {
        let fdt = Float(dt)
        let v = f.vehicle
        let s = f.engine
        let thr = Float(s.thrust / s.def.thrustSeaLevelN)
        let wind = v.wind.velocity(altitude: 5, time: v.time).float
        let qv = v.orientation
        func world(_ p: Vec3) -> Vec3 { v.toWorld(p.double).float }
        func dirW(_ d: Vec3) -> Vec3 { simd_act(qv, d.double).float }
        // steam: plume hitting the trench water flashes it to big white billows, rate ∝ interaction strength
        if s.plume.active > 0.05 && geo.hit.hit && TV1Site.isWater(geo.hit.point) {
            let strength = Float(geo.hit.strength) * min(thr, 1.2)
            let hp = geo.hit.point.float
            particles.emit(.cloud, rate: 150 * strength, dt: fdt) { r in
                let pos = hp + Vec3(r.signed() * 2.5 + 1.5, 0.3 + r.unit() * 1.2, r.signed() * 1.6)
                let vel = Vec3(8 + r.unit() * 18, 5 + r.unit() * 10, r.signed() * 3) + wind
                return Particle(pos: pos, vel: vel, age: 0, life: 6 + r.unit() * 6, size0: 2.5, size1: 10 + r.unit() * 10,
                                kind: .cloud, rot: r.unit() * 6.28, seed: r.unit())
            }
        }
        // deluge: water pouring from the trench headers while the engine runs near the pad
        let nearPad = simd_length(v.position - TV1Site.padCenter) < 30 && v.position.y < 40
        if nearPad && (s.phase.isStarting || s.phase.isRunning) {
            let tc = TV1Site.trenchCenter.float, th = TV1Site.trenchHalf.float
            particles.emit(.vapor, rate: 70, dt: fdt) { r in
                let side: Float = r.unit() < 0.5 ? -1 : 1
                let pos = Vec3(tc.x - th.x + r.unit() * 12, 0.4, tc.z + side * (th.z + 0.3))
                return Particle(pos: pos, vel: Vec3(r.signed() * 0.5, -1.5 - r.unit() * 2, -side * (1.5 + r.unit() * 2)), age: 0,
                                life: 1.2 + r.unit(), size0: 0.3, size1: 1.4, kind: .vapor, rot: r.unit() * 6.28, seed: r.unit())
            }
        }
        // tank vents: relief-valve bursts and the post-landing depressurisation blast
        let vent = Float(min(v.tanks.ventRate / 6, 1))
        let boil = f.missionTime < 0 ? Float(0.12) : 0
        if vent + boil > 0.01 {
            for (pos, dir) in TV1Mesh.vents {
                let pw = world(pos), dw = dirW(dir)
                particles.emit(.vapor, rate: (vent * 140 + boil * 30) / Float(TV1Mesh.vents.count), dt: fdt) { r in
                    let sp: Float = 6 + 18 * vent + r.unit() * 6
                    let jitter = Vec3(r.signed(), r.signed(), r.signed()) * 0.25
                    return Particle(pos: pw, vel: (dw + jitter) * sp + wind * 0.5, age: 0, life: 1.6 + r.unit() * 2.2,
                                    size0: 0.2, size1: 1.8 + 2.5 * vent, kind: .vapor, rot: r.unit() * 6.28, seed: r.unit())
                }
            }
        }
        // RCS: short white N2 puffs, one stream per firing nozzle. Each pod's summed exhaust request is projected
        // onto its nozzles' own directions, so a canted quad fires all four bells for a radial request but only
        // one for a roll request, and a flush bank fires its ports straight out of the skin.
        for (i, fire) in v.rcs.podFiring.enumerated() where simd_length(fire) > 1 {
            for n in TV1Mesh.rcsNozzles(pod: i) {
                let drive = Float(simd_dot(fire, n.dir.double) / v.rcs.thrusterForce)
                guard drive > 0.08 else { continue }
                let pw = world(n.exit), dw = dirW(n.dir)
                let rad = n.radius
                particles.emit(.vapor, rate: 70 * min(drive, 1.2), dt: fdt) { r in
                    let jitter = Vec3(r.signed(), r.signed(), r.signed()) * 0.12
                    return Particle(pos: pw + dw * 0.05 + Vec3(r.signed(), r.signed(), r.signed()) * rad * 0.4,
                                    vel: (dw + jitter) * (25 + r.unit() * 15) * min(drive + 0.3, 1.1) + v.velocity.float, age: 0,
                                    life: 0.35 + r.unit() * 0.3, size0: rad * 1.2, size1: 0.9 + 0.6 * rad, kind: .vapor,
                                    rot: r.unit() * 6.28, seed: r.unit())
                }
            }
        }
    }

    /// Orbital effects: the transonic vapor cone (a separate atmospheric effect,
    /// never the plume), booster splashdown spray, and RCS puffs. The vapor
    /// cone is a translucent white ring hugging the nose half of the body while
    /// `vaporCone` > 0 (Mach ~0.95–1.2 in thick air); it cannot appear in vacuum.
    private func emitOrbitalParticles(dt: Double, flight of: OrbitalFlight, geo: EngineGeometry) {
        let fdt = Float(dt)
        let v = of.vehicle
        let origin = OrbitalSite.padCenter + v.localPosition
        let up = simd_act(of.orientationLocal, DVec3(0, 1, 0))
        if v.vaporCone > 0.02 {
            particles.emit(.vapor, rate: Float(v.vaporCone) * 220, dt: fdt) { r in
                let a = r.unit() * 2 * .pi
                let h: Float = 18 + r.unit() * 38          // along the body, nose half
                let rad: Float = 2.6 + r.unit() * 0.9
                let pos = (origin + up * Double(h)).float + Vec3(cosf(a) * rad, 0, sinf(a) * rad)
                let vel = Vec3(cosf(a) * 2, -1 - r.unit() * 2, sinf(a) * 2) + v.velocityECI.float * 0.05
                return Particle(pos: pos, vel: vel, age: 0, life: 0.5 + r.unit() * 0.5, size0: 0.5, size1: 2.5 + r.unit() * 2,
                                kind: .vapor, rot: r.unit() * 6.28, seed: r.unit())
            }
        }
        // Booster splashdown: a white spray burst where it hits the water.
        if let b = of.booster, b.splashed, !lastBoosterSplashed {
            lastBoosterSplashed = true
            let bp = (OrbitalSite.padCenter + Planet.localFromECI(b.positionECI, originECI: OrbitalFlight.padECI)).float
            particles.burst(count: 220) { r in
                let a = r.unit() * 2 * .pi
                let rr = 1 + r.unit() * 6
                return Particle(pos: bp + Vec3(cosf(a) * rr, 0.5 + r.unit(), sinf(a) * rr),
                                vel: Vec3(cosf(a) * (4 + r.unit() * 10), 8 + r.unit() * 18, sinf(a) * (4 + r.unit() * 10)),
                                age: 0, life: 1.5 + r.unit() * 1.5, size0: 0.8, size1: 4 + r.unit() * 4,
                                kind: .vapor, rot: r.unit() * 6.28, seed: r.unit())
            }
        }
        // RCS puffs: short white N2 jets from the thruster rings while the
        // allocator is firing. (Visual approximation: the allocator does not
        // expose per-thruster duty, so all enabled thrusters puff while any
        // torque is being served.)
        if v.rcs.isFiring {
            let q = of.orientationLocal
            for t in v.rcs.thrusters where t.enabled {
                let pw = origin + simd_act(q, t.position)
                let dw = simd_act(q, t.exhaust)
                particles.emit(.vapor, rate: 8, dt: fdt) { r in
                    return Particle(pos: pw.float + dw.float * 0.1, vel: (dw * 25).float, age: 0, life: 0.3 + r.unit() * 0.2,
                                    size0: 0.15, size1: 0.7, kind: .vapor, rot: 0, seed: r.unit())
                }
            }
        }
    }

    /// Flow-field / collision parameters for the GPU particle kernel (world space).
    private func particleSimUniforms(geo: EngineGeometry, sim s: RaptorSim) -> ParticleSimUniforms {
        let p = s.plume
        var u = ParticleSimUniforms()
        let rj = Float(max(p.jetRadius, s.exitRadiusPhysical)) * 1.15
        let axis = geo.axis.float
        let horiz = SIMD2<Float>(axis.x, axis.z)
        let hl = simd_length(horiz)
        let hn: SIMD2<Float> = hl > 1e-4 ? horiz / hl : SIMD2<Float>(1, 0)
        u.imp = Vec4(geo.impingement.float, 0)
        u.jet = Vec4(rj, Float(max(p.wallJetRadius, 1)), Float(p.wallJetSpeed) * 0.16, Float(simTime.truncatingRemainder(dividingBy: 1000)))
        u.tilt = Vec4(hn.x, hn.y, hl, Float(p.groundFactor))
        u.counts = Vec4(0, 0, Float(s.engineRich), Float(p.active))
        u.axis = Vec4(axis, outdoor ? 1 : 0)
        u.exitPos = Vec4(geo.exit.float, 0)
        if let f = flight, tv1Mode {
            u.wind = Vec4(f.vehicle.wind.velocity(altitude: 6, time: f.vehicle.time).float, 0)
        } else {
            u.wind = Vec4(1.2, 0, 0.4, 0)
        }
        return u
    }

    private(set) var lastInteraction: CFTimeInterval = 0
    /// A TV-1 or orbital flight is in progress (keeps the frame rate at 60 even while the engine is off in a coast).
    var flightActive: Bool {
        if orbitalMode, let of = orbitalFlight {
            return of.missionTime >= 0 && of.phase != .done && of.phase != .aborted && of.phase != .orbit && of.phase != .landed
        }
        guard tv1Mode, let f = flight else { return false }
        return f.missionTime >= 0 && f.phase != .done && f.phase != .aborted
    }
    /// Touch / gesture activity (keeps the frame rate at 60 while the user is moving the camera).
    func noteInteraction() { lastInteraction = CACurrentMediaTime() }

    private func buildFrameState() -> FrameState {
        var f = FrameState()
        f.lastInteraction = lastInteraction
        f.particleSim.axis = Vec4(0, -1, 0, outdoor ? 1 : 0)
        f.time = simTime
        f.outdoor = outdoor
        // camera shake: thrust-scaled, boosted by ground reflection, falls off with distance
        updateCameraRig()
        if let s = sim {
            let thr = s.thrust / s.def.thrustSeaLevelN
            let air = clampd(s.ambient.pressure / Atmosphere.p0, 0, 1)
            let dist = simd_length(camera.eye - (engineEntity?.position ?? mountPoint))
            let ring = s.shockRingAge < 1.0 ? (1 - s.shockRingAge) * 2.5 : 0
            let base: Double = 0.010 * thr * (0.25 + 0.75 * air) * (1 + 0.8 * s.plume.groundFactor)
            let jolt: Double = 0.02 * s.flash + 0.01 * ring * s.plume.groundFactor
            let amp: Double = (base + jolt) * (12 / max(dist, 6))
            shakePhase = simTime
            let t = shakePhase
            let sx: Double = sin(t * 71.3) + 0.5 * sin(t * 113.7)
            let sy: Double = sin(t * 89.1) + 0.5 * sin(t * 131.9)
            let sz: Double = sin(t * 97.7)
            camera.shake = camera.override != nil ? .zero : DVec3(sx, sy, sz) * amp
        } else {
            camera.shake = .zero
        }
        let cam = camera.eye
        f.cameraWorld = cam
        f.view = camera.viewMatrixRelative()
        if orbitalMode, let of = orbitalFlight {
            // The sky shader follows the real flight altitude, not the stand slider:
            // blue sky at the pad fading to black space above ~100 km, stars fading in.
            f.altitude = of.vehicle.altitude
            f.vacuum = of.vehicle.altitude > 100_000
        } else {
            let (alt, vac) = GameUIModel.altitude(forSlider: ui.altitudeSlider)
            f.altitude = alt
            f.vacuum = vac
        }
        f.engineDef = engineEntity?.def ?? PartCatalog.shared.part("raptor3")

        let pivot = Vec3(0, RaptorMesh.pivotY, 0)
        // body rotation of whatever the engine is mounted on (identity on the stand)
        var qBody = simd_quatf(ix: 0, iy: 0, iz: 0, r: 1)
        if tv1Mode, let fl = flight {
            let v = fl.vehicle
            let qd = v.orientation
            qBody = simd_quatf(ix: Float(qd.imag.x), iy: Float(qd.imag.y), iz: Float(qd.imag.z), r: Float(qd.real))
            f.vehicleModel = float4x4(translation: (v.position - cam).float) * float4x4(qBody)
            f.vehicleFrost = Float(v.frost)
            f.vehicleDent = Float(v.dent)
            f.shadowCenter = v.comWorld.float
            let p = v.position
            f.vehicleKey = SIMD4<Float>(Float((p.x * 50).rounded()), Float((p.y * 50).rounded()), Float((p.z * 50).rounded()),
                                        Float((qd.imag.x * 2000).rounded() + (qd.imag.z * 2000).rounded() * 0.001))
        }
        if orbitalMode, let of = orbitalFlight {
            // Orbital stack: stage-1 parts ride the vehicle model while attached,
            // the booster model after separation; stage-2 parts always ride the vehicle.
            let v = of.vehicle
            let qd = of.orientationLocal
            qBody = simd_quatf(ix: Float(qd.imag.x), iy: Float(qd.imag.y), iz: Float(qd.imag.z), r: Float(qd.real))
            let wp = OrbitalSite.padCenter + v.localPosition
            f.vehicleModel = float4x4(translation: (wp - cam).float) * float4x4(qBody)
            f.vehicleFrost = Float(v.frost)
            f.orbitalVehicle = true
            f.orbitalStage = v.stage
            f.shadowCenter = of.comWorld.float
            let p = wp
            f.vehicleKey = SIMD4<Float>(Float((p.x * 50).rounded()), Float((p.y * 50).rounded()), Float((p.z * 50).rounded()),
                                        Float((qd.imag.x * 2000).rounded() + (qd.imag.z * 2000).rounded() * 0.001))
            if let b = of.booster, !b.sunk, let qb = of.boosterOrientationLocal {
                let bp = OrbitalSite.padCenter + Planet.localFromECI(b.positionECI, originECI: OrbitalFlight.padECI)
                let qbf = simd_quatf(ix: Float(qb.imag.x), iy: Float(qb.imag.y), iz: Float(qb.imag.z), r: Float(qb.real))
                f.boosterModel = float4x4(translation: (bp - cam).float) * float4x4(qbf)
            }
        }
        if let e = engineEntity, let s = sim {
            let q = s.gimbal.rotation
            let qf = simd_quatf(ix: Float(q.imag.x), iy: Float(q.imag.y), iz: Float(q.imag.z), r: Float(q.real))
            let base = float4x4(translation: (e.position - cam).float) * float4x4(qBody)
            f.engineFixedModel = base
            f.engineGimbalModel = base * float4x4(translation: pivot) * float4x4(qf) * float4x4(translation: -pivot)
            // Highlight the live Raptor: the stand engine, or the centre S1 engine (E1) when tapped in orbital mode.
            f.engineHighlight = orbitalMode ? (ui.orbitalSelectedEngine == 0 ? 1 : 0) : (ui.engineSelected ? 1 : 0)
            let geo = engineGeometry(e, s)
            f.plume = s.plume
            f.plumeExit = (geo.exit - cam).float
            f.plumeAxis = geo.axis.float
            f.plumeAxisFar = farAxis.float
            f.impingement = (geo.impingement - cam).float
            f.padCenterWorld = SIMD2<Float>(Float(geo.impingement.x), Float(geo.impingement.z))
            f.exitRadius = Float(s.exitRadiusPhysical)
            f.wallTemp = Float(s.wallTemp)
            f.padTemp = Float(s.padTemp)
            f.scorch = Float(s.scorch)
            f.shockRingAge = Float(s.shockRingAge)
            f.thrustFraction = Float(s.thrust / s.def.thrustSeaLevelN)
            f.vent = Float(s.vent)
            f.copper = Float(s.engineRich)
            // Gimbal actuators exist only on the test stand — not on a flying vehicle.
            if !orbitalMode {
                for i in 0..<2 {
                    let standEnd: DVec3 = e.position + simd_act(qBody, RaptorMesh.actuatorStandEnds[i]).double
                    let engLocal: Vec3 = simd_act(qBody, pivot + simd_act(qf, RaptorMesh.actuatorEngineEnds[i] - pivot))
                    let engEnd: DVec3 = e.position + engLocal.double
                    let pair: (Vec3, Vec3) = ((standEnd - cam).float, (engEnd - cam).float)
                    if i == 0 { f.actuator0 = pair } else { f.actuator1 = pair }
                }
            }
            f.particleSim = particleSimUniforms(geo: geo, sim: s)
            f.wind = Vec3(f.particleSim.wind.x, f.particleSim.wind.y, f.particleSim.wind.z)
        } else if let g = ghostPos {
            let base = float4x4(translation: (g - cam).float)
            f.engineFixedModel = base
            f.engineGimbalModel = base
            f.engineGhost = true
            f.engineHighlight = ghostSnaps ? 1 : 0.5
        }
        return f
    }

    /// MAIN follows the vehicle (free orbit/zoom around it); other modes ride a named mount with thrust shake.
    private func updateCameraRig() {
        let mode = ui.cameraMode
        let vib: Double = {
            guard let s = sim else { return 0 }
            return s.thrust / s.def.thrustSeaLevelN + s.flash
        }()
        if orbitalMode, let of = orbitalFlight {
            let v = of.vehicle
            if mode > 0 && mode <= OrbitalCameras.mounts.count {
                let m = OrbitalCameras.mounts[mode - 1]
                camera.override = CameraRigMath.pose(m, origin: OrbitalSite.padCenter + v.localPosition,
                                                    orientation: of.orientationLocal, vibration: vib, time: simTime)
                camera.overrideFov = m.fovY
            } else {
                camera.override = nil
                camera.overrideFov = nil
                // MAIN follows the vehicle rigidly (pad, liftoff, ascent, orbit): the orbit target is the
                // vehicle's CoM + the player's pan offset, so orbit / pinch-zoom / pan stay free while it tracks.
                camera.follow(of.comWorld)
                // keep the whole vehicle in frame when it is far up / fast (zoom eases out, never in)
                let speed = simd_length(v.velocityECI)
                let want = 90 + min(speed * 0.08, 60)
                if of.missionTime >= 0 && camera.distance < want { camera.distance += (want - camera.distance) * 0.02 }
            }
            return
        }
        if tv1Mode, let fl = flight {
            let v = fl.vehicle
            if mode > 0 && mode <= TV1Cameras.mounts.count {
                let m = TV1Cameras.mounts[mode - 1]
                camera.override = CameraRigMath.pose(m, origin: v.position, orientation: v.orientation, vibration: vib, time: simTime)
                camera.overrideFov = m.fovY
            } else {
                camera.override = nil
                camera.overrideFov = nil
                // MAIN follows the vehicle rigidly (pad, liftoff, ascent, apogee, landing): the orbit target is the
                // vehicle's CoM + the player's pan offset, so orbit / pinch-zoom / pan stay free while it tracks.
                // (Build 180 lerped the target and the stand-centred pan clamp of ±60 m around the origin then
                // yanked it back toward the test stand on any pinch/pan: the pad is at x = −400.)
                camera.follow(v.comWorld)
                // keep the whole vehicle in frame when it is far up / fast (zoom eases out, never in)
                let speed = simd_length(v.velocity)
                let want = 48 + min(speed * 0.08, 40)
                if fl.missionTime >= 0 && camera.distance < want { camera.distance += (want - camera.distance) * 0.02 }
            }
            return
        }
        // stand / hangar: swipes orbit around the placed engine; without one, the free site camera
        if let p = standPivot {
            if camera.followAnchor == nil { camera.screenOffset = standScreenOffset }
            camera.follow(p)
        } else {
            camera.stopFollowing()
        }
        if mode > 0 && mode <= StandCameras.mounts.count, engineEntity != nil {
            let m = StandCameras.mounts[mode - 1]
            camera.override = CameraRigMath.pose(m, origin: mountPoint, orientation: simd_quatd(ix: 0, iy: 0, iz: 0, r: 1),
                                                 vibration: vib, time: simTime)
            camera.overrideFov = m.fovY
        } else {
            camera.override = nil
            camera.overrideFov = nil
        }
    }

    private func pushUI(now: CFTimeInterval) {
        lastUIPush = now
        if fpsAccum > 0.5 {
            let fps = Double(fpsFrames) / fpsAccum
            fpsAccum = 0; fpsFrames = 0
            if abs(ui.fps - fps) > 0.5 { ui.fps = fps }
        }
        guard let s = sim else { return }
        if tv1Mode, let fl = flight { pushTV1(fl) }
        if orbitalMode, let of = orbitalFlight { pushOrbital(of) }
        var t = Telemetry()
        t.phase = s.phase.rawValue
        t.chamberPressureBar = s.chamberPressureBar
        t.thrustKN = s.thrust / 1000
        t.oxRPM = s.oxRPM
        t.fuelRPM = s.fuelRPM
        t.massFlow = s.massFlow
        t.oxFlow = s.oxFlow
        t.fuelFlow = s.fuelFlow
        t.isp = s.isp
        t.exitPressureBar = s.exitPressure / 1e5
        t.ambientPressurePa = s.ambient.pressure
        t.expansionState = s.combustion > 0.1 ? s.plume.expansionState : "—"
        t.nozzleTempK = s.wallTemp
        t.padTempK = s.padTemp
        t.gimbalPitchDeg = s.gimbal.pitch * 180 / .pi
        t.gimbalYawDeg = s.gimbal.yaw * 180 / .pi
        t.sideForceKN = s.sideForce / 1000
        t.throttleActual = s.throttleActualValue
        t.shockSpacing = s.plume.shockSpacing
        // webcast clock + timeline
        if orbitalMode, let of = orbitalFlight, let c = of.countdownClock, of.phase != .aborted {
            // autopilot countdown: T- to the clamp release, then T+ on the same clock
            t.clockText = c < 0 ? "T- " + GameEngine.clock((-c).rounded(.up)) : "T+ " + GameEngine.clock(c)
        } else if orbitalMode, let of = orbitalFlight, of.missionTime >= 0 {
            t.clockText = "T+ " + GameEngine.clock(of.missionTime)
        } else if orbitalMode, let of = orbitalFlight, of.phase == .idle {
            t.clockText = "T- " + GameEngine.clock(OrbitalFlight.countdownLength)
        } else if tv1Mode, let fl = flight, let c = fl.countdownClock, fl.phase != .aborted {
            // autopilot countdown: T- to the clamp release, then T+ on the same clock
            t.clockText = c < 0 ? "T- " + GameEngine.clock((-c).rounded(.up)) : "T+ " + GameEngine.clock(c)
        } else if tv1Mode, let fl = flight, fl.missionTime >= 0 {
            t.clockText = "T+ " + GameEngine.clock(fl.missionTime)
        } else if tv1Mode, let fl = flight, fl.phase == .idle {
            t.clockText = "T- " + GameEngine.clock(TV1Flight.countdownLength)
        } else if let cd = s.countdownToIgnition {
            t.clockText = "T- " + GameEngine.clock(cd)
        } else if s.timeSinceIgnition >= 0 {
            if s.phase != .safed { lastClock = "T+ " + GameEngine.clock(s.timeSinceIgnition) }
            t.clockText = lastClock
        } else {
            t.clockText = "T- " + GameEngine.clock(s.chillDuration + 1.5)
        }
        switch s.phase {
        case .safed: t.timelineProgress = s.timeSinceIgnition >= 0 ? 4 : 0
        case .chilldown: t.timelineProgress = min(s.phaseTime / s.chillDuration, 1)
        case .spinStart: t.timelineProgress = 1 + min(s.phaseTime / 0.9, 1) * 0.6
        case .preburnerIgnition: t.timelineProgress = 1.6 + min(s.phaseTime / 0.6, 1) * 0.4
        case .mainIgnition: t.timelineProgress = 2 + min(s.phaseTime / 0.25, 1) * 0.15
        case .ramp: t.timelineProgress = 2.15 + min(s.phaseTime / 1.45, 1) * 0.85
        case .mainstage: t.timelineProgress = 3 + min(s.phaseTime / 60, 0.9)
        case .shutdown, .purge, .failure: t.timelineProgress = 4
        }
        t.engineState = s.phase.isRunning ? 2 : ((s.phase == .safed) ? 0 : 1)
        t.engineRich = s.engineRich
        t.ch4Pct = s.ch4Level * 100
        t.mixtureRatio = s.mixtureRatio
        if s.phase == .failure { t.warning = "ENGINE FAILURE · CHAMBER BREACH" }
        else if s.engineRich > 0.5 { t.warning = "ENGINE-RICH · COPPER EROSION · SHUT DOWN" }
        else if s.engineRich > 0.15 { t.warning = "MIXTURE RATIO HIGH · GREEN PLUME" }
        else if s.phase.isRunning && s.fuelStarve > 0.2 { t.warning = "CH4 INLET PRESSURE LOW" }
        else { t.warning = "" }
        t.vacuum = s.ambient.pressure <= 0
        if t != ui.telemetry { ui.telemetry = t }
        let running = s.phase.isRunning
        let starting = s.phase.isStarting || s.phase == .shutdown
        if ui.running != running { ui.running = running }
        if ui.starting != starting { ui.starting = starting }
    }

    private var lastLoxBar = 0.0, lastCh4Bar = 0.0

    private func tankReadout(_ k: CryoTank, history: [Float], last: inout Double) -> TankReadout {
        var r = TankReadout()
        r.name = k.name
        r.bar = k.pressure / 1e5
        r.psi = k.pressure / 6894.757
        r.liquidK = k.liquidTemp
        r.ullageK = k.ullageTemp
        r.wallK = k.wallTemp
        r.fillPct = k.fillFraction * 100
        r.massKg = k.liquidMass
        let d = r.bar - last
        r.trend = d > 0.004 ? 1 : (d < -0.004 ? -1 : 0)
        last = r.bar
        r.history = history
        r.venting = k.ventRate > 0.05
        return r
    }

    private func pushTV1(_ fl: TV1Flight) {
        let v = fl.vehicle
        let e = fl.engine
        var t = TV1Telemetry()
        t.phase = fl.phase.rawValue
        t.altitude = max(fl.altitudeAGL, 0)
        t.vSpeed = v.velocity.y
        t.hSpeed = simd_length(DVec3(v.velocity.x, 0, v.velocity.z))
        t.maxAltitude = fl.maxAltitude
        t.targetApogee = fl.targetApogee
        let tgt = fl.landAtPad ? fl.padCenter : fl.landingZone
        let d = DVec3(tgt.x - v.position.x, 0, tgt.z - v.position.z)
        t.lzDistance = simd_length(d)
        var b = atan2(d.x, -d.z) * 180 / .pi
        if b < 0 { b += 360 }
        t.lzBearing = b
        t.accuracy = fl.landingAccuracy
        t.touchdownSpeed = v.touchdownSpeed
        t.marginKg = fl.propellantMarginKg
        t.tw = fl.thrustToWeight
        t.massT = v.mass / 1000
        t.lox = tankReadout(v.tanks.lox, history: v.tanks.loxHistory, last: &lastLoxBar)
        t.ch4 = tankReadout(v.tanks.ch4, history: v.tanks.ch4History, last: &lastCh4Bar)
        t.burnTime = v.tanks.burnTime(massFlow: e.massFlow, mixtureRatio: e.def.mixtureRatio)
        t.n2Pct = v.rcs.n2Mass / v.rcs.n2Capacity * 100
        var avail = DVec3.zero
        for a in v.actuators { avail += a.authority(v, e) }
        let dist = max(simd_length(DVec3(v.aeroTorqueBody.x, 0, v.aeroTorqueBody.z)), 1)
        t.authority = simd_length(DVec3(avail.x, 0, avail.z)) / dist
        let ach = simd_length(v.achievedTorque)
        t.gimbalShare = ach > 1 ? max(0, 1 - simd_length(v.rcs.lastTorqueBody) / ach) : 0
        t.warnings = fl.warnings
        if let td = v.touchdownSpeed, td > 2.5, !t.warnings.contains(where: { $0.hasPrefix("HARD") }) {
            t.warnings.append(String(format: "HARD TOUCHDOWN · %.1f M/S", td))
        }
        t.timelineProgress = fl.timelineProgress
        t.autopilot = fl.autopilot
        t.missionTime = fl.missionTime
        t.countdown = fl.countdownClock
        t.mach = v.mach
        t.dynPressureKPa = v.dynamicPressure / 1000
        if t != ui.tv1 { ui.tv1 = t }
        if ui.tv1Autopilot != fl.autopilot { ui.tv1Autopilot = fl.autopilot }
    }

    /// Orbital flight telemetry (pushed at ~10 Hz).
    private func pushOrbital(_ of: OrbitalFlight) {
        let v = of.vehicle
        var t = OrbitalTelemetry()
        t.phase = of.phase.rawValue
        t.altitude = max(v.altitude, 0)
        t.apoapsis = max(of.elements.apoapsisAltitude, 0)
        t.periapsis = max(of.elements.periapsisAltitude, 0)
        t.orbitalVelocity = v.speed
        t.tw = of.thrustToWeight
        t.stage = v.stage
        t.mach = v.mach
        t.dynPressureKPa = v.dynamicPressure / 1000
        t.timeToCircularization = of.timeToCircularization
        t.dvMargin = of.dvMargin
        t.dvNeeded = of.dvNeeded
        t.warp = of.effectiveWarp
        t.warpAvailable = of.timeWarpAvailable
        t.vaporCone = v.vaporCone
        let sky = Atmosphere.skyState(altitude: max(v.altitude, 0))
        t.starVisibility = sky.starVisibility
        t.spaceFactor = sky.spaceFactor
        if let b = of.booster {
            t.boosterStatus = b.sunk ? "BOOSTER SUNK" : (b.destroyed ? "BOOSTER LOST · SPLASHDOWN" : (b.splashed ? "BOOSTER FLOATING · OCEAN" : "BOOSTER FALLING"))
        } else {
            t.boosterStatus = v.stage == 1 ? "BOOSTER ATTACHED" : "—"
        }
        t.s1PropPct = (v.stage1Tanks.lox.fillFraction + v.stage1Tanks.ch4.fillFraction) * 50
        t.s2PropPct = (v.stage2Tanks.lox.fillFraction + v.stage2Tanks.ch4.fillFraction) * 50
        t.n2Pct = v.rcs.n2Mass / v.rcs.n2Capacity * 100
        t.warnings = of.warnings
        t.timelineProgress = of.timelineProgress
        t.autopilot = of.autopilot
        t.missionTime = of.missionTime
        t.countdown = of.countdownClock
        t.engineOut = v.engineOut.enumerated().filter { $0.element }.map { $0.offset }
        t.rcsOut = v.rcs.outThrusters
        t.rcsIds = v.rcs.thrusters.map { $0.id }
        t.destinationName = of.selectedDestination?.name ?? ""
        if let d = of.selectedDestination, case .landing = d.kind { t.destinationIsLanding = true }
        t.fuelWarning = of.fuelCheck?.warning
        t.fuelSuggestionName = of.fuelCheck?.suggestedAlternative?.name ?? ""
        t.massT = v.mass / 1000
        t.engineCount = v.capabilities.engineCount
        t.activeEngineCount = v.activeEngineCount
        let c = v.capabilities
        t.capabilitiesNote = "\(c.engineCount) ENG · \(Int(c.totalThrustSeaLevelN / 1_000_000)) MN · ΔV \(Int(c.deltaVTotal)) M/S · \(c.stageCount) STG"
        if t != ui.orbital { ui.orbital = t }
        if ui.orbitalWarpAvailable != t.warpAvailable { ui.orbitalWarpAvailable = t.warpAvailable }
        if ui.orbitalAutopilot != of.autopilot { ui.orbitalAutopilot = of.autopilot }
    }

    /// Audio parameters, called every frame.
    func updateAudio() {
        guard let s = sim else {
            audio.update(SynthParams())
            return
        }
        var p = SynthParams()
        p.vent = Float(s.vent)
        p.rpm = Float(s.rpmFrac)
        p.combustion = Float(s.combustion)
        p.pc = Float(s.chamberPressureBar / s.def.chamberPressureBar)
        p.air = Float(clampd(s.ambient.pressure / Atmosphere.p0, 0, 1))
        p.ground = Float(s.plume.groundFactor)
        p.ignitionEvents = s.ignitionEvents
        p.popEvents = s.popEvents
        if let fl = flight, tv1Mode {
            let rcs = fl.vehicle.rcs.podFiring.contains { simd_length($0) > 1 } ? Float(0.5) : 0
            p.vent = max(p.vent, max(rcs, Float(min(fl.vehicle.tanks.ventRate / 5, 1))))
        }
        if let of = orbitalFlight, orbitalMode {
            // Calm ambient pad fades in with altitude / in orbit, and never drowns
            // the engine: the DSP scales it by (1 − 0.7 × combustion).
            p.ambient = Float(Atmosphere.skyState(altitude: max(of.vehicle.altitude, 0)).spaceFactor)
            p.ambientVolume = Float(ui.spaceMusicVolume)
            let rcs = of.vehicle.rcs.isFiring ? Float(0.5) : 0
            p.vent = max(p.vent, rcs)
        }
        let dist = Float(simd_length(camera.eye - (engineEntity?.position ?? mountPoint)))
        p.distanceGain = min(1.0, 14 / max(dist, 4))
        audio.update(p)
    }
}
