import simd
import Foundation

typealias Vec3 = SIMD3<Float>
typealias Vec4 = SIMD4<Float>
typealias DVec3 = SIMD3<Double>

extension float4x4 {
    init(translation t: Vec3) {
        self.init(columns: (Vec4(1, 0, 0, 0), Vec4(0, 1, 0, 0), Vec4(0, 0, 1, 0), Vec4(t.x, t.y, t.z, 1)))
    }

    init(scaling s: Vec3) {
        self.init(columns: (Vec4(s.x, 0, 0, 0), Vec4(0, s.y, 0, 0), Vec4(0, 0, s.z, 0), Vec4(0, 0, 0, 1)))
    }

    init(rotationAxis axis: Vec3, angle: Float) {
        let q = simd_quatf(angle: angle, axis: simd_normalize(axis))
        self.init(q)
    }

    /// Right-handed perspective projection with Metal's [0, 1] clip-space depth.
    static func perspective(fovyRadians fovy: Float, aspect: Float, near: Float, far: Float) -> float4x4 {
        let ys = 1 / tanf(fovy * 0.5)
        let xs = ys / aspect
        let zs = far / (near - far)
        return float4x4(columns: (Vec4(xs, 0, 0, 0), Vec4(0, ys, 0, 0), Vec4(0, 0, zs, -1), Vec4(0, 0, zs * near, 0)))
    }

    /// Right-handed look-at view matrix.
    static func lookAt(eye: Vec3, center: Vec3, up: Vec3) -> float4x4 {
        let f = simd_normalize(center - eye)
        let s = simd_normalize(simd_cross(f, up))
        let u = simd_cross(s, f)
        return float4x4(columns: (
            Vec4(s.x, u.x, -f.x, 0),
            Vec4(s.y, u.y, -f.y, 0),
            Vec4(s.z, u.z, -f.z, 0),
            Vec4(-simd_dot(s, eye), -simd_dot(u, eye), simd_dot(f, eye), 1)))
    }

    /// Right-handed orthographic projection, [0, 1] depth.
    static func orthographic(left l: Float, right r: Float, bottom b: Float, top t: Float, near n: Float, far f: Float) -> float4x4 {
        return float4x4(columns: (
            Vec4(2 / (r - l), 0, 0, 0),
            Vec4(0, 2 / (t - b), 0, 0),
            Vec4(0, 0, 1 / (n - f), 0),
            Vec4((l + r) / (l - r), (t + b) / (b - t), n / (n - f), 1)))
    }

    var upperLeftNormalMatrix: float4x4 {
        let m3 = simd_float3x3(Vec3(columns.0.x, columns.0.y, columns.0.z),
                               Vec3(columns.1.x, columns.1.y, columns.1.z),
                               Vec3(columns.2.x, columns.2.y, columns.2.z))
        let n = m3.inverse.transpose
        return float4x4(columns: (Vec4(n.columns.0, 0), Vec4(n.columns.1, 0), Vec4(n.columns.2, 0), Vec4(0, 0, 0, 1)))
    }
}

extension SIMD3 where Scalar == Double {
    var float: Vec3 { Vec3(Float(x), Float(y), Float(z)) }
}

extension SIMD3 where Scalar == Float {
    var double: DVec3 { DVec3(Double(x), Double(y), Double(z)) }
}

@inline(__always) func clampf(_ x: Float, _ a: Float, _ b: Float) -> Float { min(max(x, a), b) }
@inline(__always) func clampd(_ x: Double, _ a: Double, _ b: Double) -> Double { min(max(x, a), b) }
@inline(__always) func mixd(_ a: Double, _ b: Double, _ t: Double) -> Double { a + (b - a) * t }
@inline(__always) func smoothstepd(_ e0: Double, _ e1: Double, _ x: Double) -> Double {
    let t = clampd((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)
}

/// Small deterministic RNG (xorshift) for procedural generation and particles.
struct XorShift {
    var state: UInt64
    init(seed: UInt64) { state = seed == 0 ? 0x9E3779B97F4A7C15 : seed }
    mutating func next() -> UInt64 {
        state ^= state << 13
        state ^= state >> 7
        state ^= state << 17
        return state
    }
    mutating func unit() -> Float { Float(next() >> 40) / Float(1 << 24) }
    mutating func signed() -> Float { unit() * 2 - 1 }
    mutating func unitD() -> Double { Double(next() >> 11) / Double(1 << 53) }
}

struct Ray {
    var origin: DVec3
    var direction: DVec3
}

/// Slab test; returns entry distance or nil.
func intersectAABB(ray: Ray, minB: DVec3, maxB: DVec3) -> Double? {
    var tmin = -Double.infinity
    var tmax = Double.infinity
    for i in 0..<3 {
        let o = ray.origin[i], d = ray.direction[i]
        if abs(d) < 1e-12 {
            if o < minB[i] || o > maxB[i] { return nil }
        } else {
            var t0 = (minB[i] - o) / d
            var t1 = (maxB[i] - o) / d
            if t0 > t1 { swap(&t0, &t1) }
            tmin = max(tmin, t0)
            tmax = min(tmax, t1)
            if tmax < tmin { return nil }
        }
    }
    if tmax < 0 { return nil }
    return max(tmin, 0)
}
