import Foundation
import simd

/// A camera bolted to a vehicle part: position and view direction in the part's local frame.
struct CameraMount {
    var name: String
    var position: DVec3
    var forward: DVec3
    var up: DVec3 = DVec3(0, 0, 1)
    var fovY: Float = 1.05
    var shake: Double = 1          // how much thrust vibration reaches this camera
}

/// Camera selection for any vehicle: MAIN (free orbit that follows the vehicle) or one of its named mounts.
/// Future vehicles add cameras by defining mounts; the math here is platform-free.
enum CameraRigMath {
    /// World eye / forward / up of a mount on a body (origin + orientation), with thrust-scaled vibration.
    static func pose(_ m: CameraMount, origin: DVec3, orientation: simd_quatd, vibration: Double, time: Double)
        -> (eye: DVec3, forward: DVec3, up: DVec3) {
        let a = vibration * m.shake
        let jitter = DVec3(sin(time * 83.1) + 0.5 * sin(time * 141.7), sin(time * 97.3), sin(time * 71.9 + 1.1)) * (0.012 * a)
        let wob = DVec3(sin(time * 37.0), 0, cos(time * 41.0)) * (0.004 * a)
        let eye = origin + simd_act(orientation, m.position) + jitter
        let fwd = simd_normalize(simd_act(orientation, simd_normalize(m.forward) + wob))
        let up = simd_normalize(simd_act(orientation, m.up))
        return (eye, fwd, up)
    }
}

enum TV1Cameras {
    /// Engine-bay camera looking straight down the nozzle past the engine (reference: IMG_2581),
    /// one on the tank looking down its side at the ground/plume, one looking up the tank.
    static let mounts: [CameraMount] = [
        CameraMount(name: "ENGINE", position: DVec3(0.85, 4.05, 0.55), forward: DVec3(-0.22, -1, -0.12), up: DVec3(0, 0, -1), fovY: 1.15, shake: 1.4),
        CameraMount(name: "TANK ↓", position: DVec3(2.75, 11.5, 0.6), forward: DVec3(0.08, -1, 0.02), up: DVec3(-1, 0, 0), fovY: 1.0, shake: 0.7),
        CameraMount(name: "TANK ↑", position: DVec3(2.75, 4.6, -0.6), forward: DVec3(0.06, 1, 0.0), up: DVec3(-1, 0, 0), fovY: 1.0, shake: 0.8),
    ]
}

enum StandCameras {
    /// Engine-bay camera on the test stand (local to the engine mount point, under the deck).
    static let mounts: [CameraMount] = [
        CameraMount(name: "ENGINE", position: DVec3(0.85, -0.15, 0.55), forward: DVec3(-0.22, -1, -0.12), up: DVec3(0, 0, -1), fovY: 1.15, shake: 1.2),
    ]
}

enum OrbitalCameras {
    /// Mounts on the orbital stack (vehicle-local frame, origin = S1 base):
    /// engine bay looking down the bells, a side view of the interstage,
    /// the fairing looking up the body, and a nose camera looking down at the
    /// planet (the orbit view).
    static let mounts: [CameraMount] = [
        CameraMount(name: "ENGINES", position: DVec3(3.2, 6.5, 0.8), forward: DVec3(-0.25, -1, -0.1), up: DVec3(0, 0, -1), fovY: 1.15, shake: 1.4),
        CameraMount(name: "INTERSTAGE", position: DVec3(3.4, 40, 0.8), forward: DVec3(-0.9, 0.25, 0), up: DVec3(0, 1, 0), fovY: 1.0, shake: 0.8),
        CameraMount(name: "FAIRING ↑", position: DVec3(2.75, 56, -0.6), forward: DVec3(0.06, 1, 0.0), up: DVec3(-1, 0, 0), fovY: 1.0, shake: 0.6),
        CameraMount(name: "NOSE ↓", position: DVec3(0, 67.5, 0), forward: DVec3(0, -1, 0), up: DVec3(0, 0, -1), fovY: 1.05, shake: 0.3),
    ]
}
