import Metal
import simd

/// Interleaved vertex. Layout must match `VertexIn` in ShaderCommon.h (3 x float4, stride 48).
/// position.w = baked ambient occlusion (1 = open)
/// normal.w   = detail channel (material-specific: e.g. weld seam / panel mask)
/// uv.xy      = surface parameterisation in metres (u around, v along), uv.z = heat weight, uv.w = decal flag
struct Vertex {
    var position: Vec4
    var normal: Vec4
    var uv: Vec4
}

enum MaterialKind: Float {
    case standard = 0
    case concrete = 1
    case nozzle = 2      // matte coated nozzle: decal, wear, heat glow
    case emissive = 3
    case corrugated = 4
    case brushed = 5     // brushed / machined metal: anisotropic-looking streaks + heat tint
    case paint = 6       // painted steel (stand), chips and grime
    case field = 7       // ploughed soil
    case weatheredConcrete = 8  // stained structural concrete (test stand legs)
    case nozzleInterior = 9     // liner: white-hot while the chamber is lit
    case grass = 10             // instanced grass blades (own pipeline)
    case frostedSteel = 11      // brushed stainless with frost (cryogenic run tank)
    case water = 12             // flowing trench water (animated normals, fresnel)
    case landingPad = 13        // concrete with painted landing target
}

struct Material {
    var baseColor: Vec3
    var metallic: Float
    var roughness: Float
    var kind: MaterialKind = .standard
    var emissive: Vec3 = .zero

    static let nozzleBlack = Material(baseColor: Vec3(0.028, 0.028, 0.030), metallic: 0.0, roughness: 0.62, kind: .nozzle)
    static let coatedBlack = Material(baseColor: Vec3(0.035, 0.035, 0.037), metallic: 0.05, roughness: 0.55, kind: .brushed)
    static let darkSteel = Material(baseColor: Vec3(0.30, 0.30, 0.31), metallic: 1.0, roughness: 0.42, kind: .brushed)
    static let inconel = Material(baseColor: Vec3(0.62, 0.60, 0.56), metallic: 1.0, roughness: 0.33, kind: .brushed)
    static let polishedSteel = Material(baseColor: Vec3(0.86, 0.85, 0.83), metallic: 1.0, roughness: 0.10, kind: .brushed)
    static let brushedSteel = Material(baseColor: Vec3(0.75, 0.74, 0.72), metallic: 1.0, roughness: 0.26, kind: .brushed)
    static let boltSteel = Material(baseColor: Vec3(0.70, 0.69, 0.66), metallic: 1.0, roughness: 0.30, kind: .brushed)
    static let copperish = Material(baseColor: Vec3(0.80, 0.55, 0.42), metallic: 1.0, roughness: 0.35, kind: .brushed)
    static let blueCap = Material(baseColor: Vec3(0.05, 0.22, 0.62), metallic: 0.0, roughness: 0.38)
    static let blackPlastic = Material(baseColor: Vec3(0.02, 0.02, 0.022), metallic: 0.0, roughness: 0.45)
    static let concrete = Material(baseColor: Vec3(0.40, 0.39, 0.37), metallic: 0.0, roughness: 0.82, kind: .concrete)
    static let pitConcrete = Material(baseColor: Vec3(0.16, 0.155, 0.15), metallic: 0.0, roughness: 0.9, kind: .concrete)
    static let corrugated = Material(baseColor: Vec3(0.80, 0.81, 0.82), metallic: 0.85, roughness: 0.36, kind: .corrugated)
    static let whitePaint = Material(baseColor: Vec3(0.80, 0.80, 0.78), metallic: 0.0, roughness: 0.48, kind: .paint)
    static let structureGray = Material(baseColor: Vec3(0.32, 0.33, 0.34), metallic: 0.0, roughness: 0.6, kind: .paint)
    static let lightPanel = Material(baseColor: Vec3(0.9, 0.9, 0.9), metallic: 0, roughness: 0.5, kind: .emissive, emissive: Vec3(14, 13.4, 12.6))
}

/// CPU-side geometry for one material.
struct MeshData {
    var vertices: [Vertex] = []
    var indices: [UInt32] = []

    mutating func append(_ other: MeshData, transform: float4x4 = matrix_identity_float4x4) {
        let base = UInt32(vertices.count)
        let nm = transform.upperLeftNormalMatrix
        for v in other.vertices {
            let p = transform * Vec4(v.position.x, v.position.y, v.position.z, 1)
            var n = nm * Vec4(v.normal.x, v.normal.y, v.normal.z, 0)
            let l = simd_length(Vec3(n.x, n.y, n.z))
            if l > 0 { n /= l }
            vertices.append(Vertex(position: Vec4(p.x, p.y, p.z, v.position.w), normal: Vec4(n.x, n.y, n.z, v.normal.w), uv: v.uv))
        }
        indices.append(contentsOf: other.indices.map { $0 + base })
    }

    mutating func setAO(_ f: (Vec3, Vec3) -> Float) {
        for i in vertices.indices {
            let v = vertices[i]
            vertices[i].position.w = min(v.position.w, f(Vec3(v.position.x, v.position.y, v.position.z), Vec3(v.normal.x, v.normal.y, v.normal.z)))
        }
    }

    var bounds: (Vec3, Vec3) {
        var lo = Vec3(repeating: .greatestFiniteMagnitude), hi = Vec3(repeating: -.greatestFiniteMagnitude)
        for v in vertices {
            let p = Vec3(v.position.x, v.position.y, v.position.z)
            lo = simd_min(lo, p); hi = simd_max(hi, p)
        }
        return (lo, hi)
    }
}

/// GPU mesh: one vertex/index buffer pair + material.
final class GPUMesh {
    let vertexBuffer: MTLBuffer
    let indexBuffer: MTLBuffer
    let indexCount: Int
    var material: Material
    let castsShadow: Bool

    init?(device: MTLDevice, data: MeshData, material: Material, castsShadow: Bool = true) {
        guard !data.vertices.isEmpty, !data.indices.isEmpty,
              let vb = device.makeBuffer(bytes: data.vertices, length: MemoryLayout<Vertex>.stride * data.vertices.count, options: .storageModeShared),
              let ib = device.makeBuffer(bytes: data.indices, length: MemoryLayout<UInt32>.stride * data.indices.count, options: .storageModeShared)
        else { return nil }
        vertexBuffer = vb
        indexBuffer = ib
        indexCount = data.indices.count
        self.material = material
        self.castsShadow = castsShadow
    }
}

/// A material + geometry group produced by a procedural generator.
struct MeshPart {
    var name: String
    var data: MeshData
    var material: Material
    var castsShadow: Bool = true
    var gimballed: Bool = false
}
