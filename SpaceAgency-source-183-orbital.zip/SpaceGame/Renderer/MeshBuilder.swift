import simd
import Foundation

/// Procedural geometry primitives. All produce `MeshData` in local space.
enum MeshBuilder {

    /// Surface of revolution around +Y. `profile` is a list of (radius, y) points.
    /// Creases are kept sharp where the profile turns more than `creaseDegrees`.
    /// `heat` maps (y) -> heat weight; `decal` marks vertices that may carry the "1" decal.
    static func lathe(_ profile: [SIMD2<Float>], segments: Int = 64, creaseDegrees: Float = 32,
                      heat: ((Float) -> Float)? = nil, decal: Bool = false, detail: Float = 0,
                      aoFn: ((Float, Float) -> Float)? = nil) -> MeshData {
        var m = MeshData()
        guard profile.count >= 2 else { return m }
        let n = profile.count
        // segment normals in (r, y) plane, outward
        var segN: [SIMD2<Float>] = []
        var segLen: [Float] = []
        for i in 0..<(n - 1) {
            let d = profile[i + 1] - profile[i]
            let l = max(simd_length(d), 1e-6)
            segLen.append(l)
            // Walking the profile top -> bottom on an outer surface, (-dy, dr) points away from the axis.
            // This also matches counter-clockwise winding, so back-face culling is consistent.
            let nn = SIMD2<Float>(-d.y, d.x) / l
            segN.append(nn)
        }
        let cosCrease = cosf(creaseDegrees * .pi / 180)
        var vAcc: Float = 0
        for s in 0..<(n - 1) {
            let a = profile[s], b = profile[s + 1]
            var na = segN[s], nb = segN[s]
            if s > 0, simd_dot(segN[s - 1], segN[s]) > cosCrease { na = simd_normalize(segN[s - 1] + segN[s]) }
            if s < n - 2, simd_dot(segN[s + 1], segN[s]) > cosCrease { nb = simd_normalize(segN[s + 1] + segN[s]) }
            let base = UInt32(m.vertices.count)
            let v0 = vAcc, v1 = vAcc + segLen[s]
            vAcc = v1
            for k in 0...segments {
                let t = Float(k) / Float(segments)
                let ang = t * 2 * .pi
                let c = cosf(ang), sn = sinf(ang)
                for (p, nn, vv) in [(a, na, v0), (b, nb, v1)] {
                    let pos = Vec3(p.x * sn, p.y, p.x * c)
                    let nor = Vec3(nn.x * sn, nn.y, nn.x * c)
                    let h = heat?(p.y) ?? 0
                    let ao = aoFn?(p.x, p.y) ?? 1
                    m.vertices.append(Vertex(position: Vec4(pos, ao), normal: Vec4(nor, detail),
                                             uv: Vec4(t * 2 * .pi * max(p.x, 0.001), vv, h, decal ? 1 : 0)))
                }
            }
            for k in 0..<segments {
                let i0 = base + UInt32(k * 2)
                let i1 = i0 + 1, i2 = i0 + 2, i3 = i0 + 3
                m.indices += [i0, i1, i2, i2, i1, i3]
            }
        }
        return m
    }

    static func cylinder(radius: Float, height: Float, segments: Int = 32, capped: Bool = true) -> MeshData {
        let h = height / 2
        var prof: [SIMD2<Float>] = []
        if capped { prof.append(SIMD2(0, h)) }
        prof += [SIMD2(radius, h), SIMD2(radius, -h)]
        if capped { prof.append(SIMD2(0, -h)) }
        return lathe(prof, segments: segments)
    }

    /// Bolt / stud with hex-ish head (8-sided lathe looks like a hex at this scale).
    static func bolt(radius: Float, height: Float) -> MeshData {
        let prof: [SIMD2<Float>] = [SIMD2(0, height), SIMD2(radius * 0.8, height), SIMD2(radius, height * 0.85),
                                    SIMD2(radius, 0), SIMD2(0, 0)]
        return lathe(prof, segments: 6, creaseDegrees: 20)
    }

    static func torus(major: Float, minor: Float, majorSegments: Int = 64, minorSegments: Int = 16, heat: Float = 0) -> MeshData {
        var m = MeshData()
        for i in 0...majorSegments {
            let u = Float(i) / Float(majorSegments) * 2 * .pi
            let cu = cosf(u), su = sinf(u)
            for j in 0...minorSegments {
                let v = Float(j) / Float(minorSegments) * 2 * .pi
                let cv = cosf(v), sv = sinf(v)
                let r = major + minor * cv
                let p = Vec3(r * su, minor * sv, r * cu)
                let n = Vec3(cv * su, sv, cv * cu)
                // crevice AO on the inner/lower side
                let ao: Float = 0.75 + 0.25 * max(0, cv * 0.5 + sv * 0.5 + 0.5)
                m.vertices.append(Vertex(position: Vec4(p, ao), normal: Vec4(n, 0), uv: Vec4(u * major, v * minor, heat, 0)))
            }
        }
        let stride = UInt32(minorSegments + 1)
        for i in 0..<UInt32(majorSegments) {
            for j in 0..<UInt32(minorSegments) {
                let a = i * stride + j, b = (i + 1) * stride + j
                m.indices += [a, b, a + 1, a + 1, b, b + 1]
            }
        }
        return m
    }

    static func box(size: Vec3, uvScale: Float = 1) -> MeshData {
        var m = MeshData()
        let h = size / 2
        let faces: [(Vec3, Vec3, Vec3)] = [
            (Vec3(1, 0, 0), Vec3(0, 0, -1), Vec3(0, 1, 0)), (Vec3(-1, 0, 0), Vec3(0, 0, 1), Vec3(0, 1, 0)),
            (Vec3(0, 1, 0), Vec3(1, 0, 0), Vec3(0, 0, -1)), (Vec3(0, -1, 0), Vec3(1, 0, 0), Vec3(0, 0, 1)),
            (Vec3(0, 0, 1), Vec3(1, 0, 0), Vec3(0, 1, 0)), (Vec3(0, 0, -1), Vec3(-1, 0, 0), Vec3(0, 1, 0))]
        for (n, u, v) in faces {
            let base = UInt32(m.vertices.count)
            let c = n * h
            let uh = simd_abs(u) * h, vh = simd_abs(v) * h
            let ul = simd_length(uh), vl = simd_length(vh)
            for (su, sv) in [(-1, -1), (1, -1), (-1, 1), (1, 1)] as [(Float, Float)] {
                let p = c + u * ul * su + v * vl * sv
                m.vertices.append(Vertex(position: Vec4(p, 1), normal: Vec4(n, 0),
                                         uv: Vec4((su * 0.5 + 0.5) * ul * 2 * uvScale, (sv * 0.5 + 0.5) * vl * 2 * uvScale, 0, 0)))
            }
            m.indices += [base, base + 1, base + 2, base + 2, base + 1, base + 3]
        }
        return m
    }

    /// Box between two points with a square cross-section (struts, beams).
    static func beam(from a: Vec3, to b: Vec3, width: Float) -> MeshData {
        let d = b - a
        let len = simd_length(d)
        let box = box(size: Vec3(width, len, width))
        let up = Vec3(0, 1, 0)
        let dir = d / len
        var rot = matrix_identity_float4x4
        let axis = simd_cross(up, dir)
        let s = simd_length(axis)
        if s > 1e-5 { rot = float4x4(rotationAxis: axis / s, angle: atan2f(s, simd_dot(up, dir))) }
        else if simd_dot(up, dir) < 0 { rot = float4x4(rotationAxis: Vec3(1, 0, 0), angle: .pi) }
        var m = MeshData()
        m.append(box, transform: float4x4(translation: (a + b) / 2) * rot)
        return m
    }

    /// Tube swept along a Catmull-Rom spline through `points` using parallel-transport frames.
    static func tube(points: [Vec3], radius: Float, radialSegments: Int = 20, samplesPerSpan: Int = 14,
                     heat: Float = 0, capEnds: Bool = true) -> MeshData {
        var m = MeshData()
        guard points.count >= 2 else { return m }
        var pts: [Vec3] = []
        let first: Vec3 = points[0] + (points[0] - points[1])
        let lastP: Vec3 = points[points.count - 1]
        let last: Vec3 = lastP + (lastP - points[points.count - 2])
        var p: [Vec3] = [first]
        p.append(contentsOf: points)
        p.append(last)
        for i in 1..<(p.count - 2) {
            for s in 0..<samplesPerSpan {
                let t = Float(s) / Float(samplesPerSpan)
                pts.append(catmull(p[i - 1], p[i], p[i + 1], p[i + 2], t))
            }
        }
        pts.append(points[points.count - 1])
        var tangents: [Vec3] = []
        for i in 0..<pts.count {
            let a = pts[max(i - 1, 0)], b = pts[min(i + 1, pts.count - 1)]
            tangents.append(simd_normalize(b - a))
        }
        var normal = simd_normalize(simd_cross(tangents[0], abs(tangents[0].y) < 0.9 ? Vec3(0, 1, 0) : Vec3(1, 0, 0)))
        var along: Float = 0
        for i in 0..<pts.count {
            if i > 0 {
                along += simd_length(pts[i] - pts[i - 1])
                let axis = simd_cross(tangents[i - 1], tangents[i])
                let s = simd_length(axis)
                if s > 1e-6 {
                    let ang = atan2f(s, simd_dot(tangents[i - 1], tangents[i]))
                    normal = simd_act(simd_quatf(angle: ang, axis: axis / s), normal)
                }
            }
            let binormal = simd_cross(tangents[i], normal)
            for j in 0...radialSegments {
                let a = Float(j) / Float(radialSegments) * 2 * .pi
                let n = normal * cosf(a) + binormal * sinf(a)
                m.vertices.append(Vertex(position: Vec4(pts[i] + n * radius, 1), normal: Vec4(n, 0),
                                         uv: Vec4(a * radius, along, heat, 0)))
            }
        }
        let stride = UInt32(radialSegments + 1)
        for i in 0..<UInt32(pts.count - 1) {
            for j in 0..<UInt32(radialSegments) {
                let a = i * stride + j, b = (i + 1) * stride + j
                m.indices += [a, a + 1, b, b, a + 1, b + 1]
            }
        }
        if capEnds {
            for (idx, sign) in [(0, Float(-1)), (pts.count - 1, Float(1))] {
                var disc = cylinder(radius: radius * 1.18, height: radius * 0.5, segments: radialSegments)
                disc.setAO { _, _ in 0.9 }
                let t = tangents[idx]
                let up = Vec3(0, 1, 0)
                let axis = simd_cross(up, t)
                let s = simd_length(axis)
                var rot = matrix_identity_float4x4
                if s > 1e-5 { rot = float4x4(rotationAxis: axis / s, angle: atan2f(s, simd_dot(up, t))) }
                m.append(disc, transform: float4x4(translation: pts[idx] + t * sign * radius * 0.1) * rot)
            }
        }
        return m
    }

    static func catmull(_ p0: Vec3, _ p1: Vec3, _ p2: Vec3, _ p3: Vec3, _ t: Float) -> Vec3 {
        let t2: Float = t * t
        let t3: Float = t2 * t
        let a: Vec3 = p1 * 2
        let b: Vec3 = (p2 - p0) * t
        var c: Vec3 = p0 * 2
        c -= p1 * 5
        c += p2 * 4
        c -= p3
        c *= t2
        var d: Vec3 = p1 * 3
        d -= p0
        d -= p2 * 3
        d += p3
        d *= t3
        let sum: Vec3 = a + b + c + d
        return sum * 0.5
    }

    /// Flat grid in XZ facing +Y.
    static func plane(minX: Float, maxX: Float, minZ: Float, maxZ: Float, y: Float, normalUp: Bool = true) -> MeshData {
        var m = MeshData()
        let n: Vec3 = normalUp ? Vec3(0, 1, 0) : Vec3(0, -1, 0)
        let ps = [Vec3(minX, y, minZ), Vec3(maxX, y, minZ), Vec3(minX, y, maxZ), Vec3(maxX, y, maxZ)]
        for p in ps { m.vertices.append(Vertex(position: Vec4(p, 1), normal: Vec4(n, 0), uv: Vec4(p.x, p.z, 0, 0))) }
        m.indices = normalUp ? [0, 2, 1, 1, 2, 3] : [0, 1, 2, 2, 1, 3]
        return m
    }

    /// Vertical quad from (x0,z0) to (x1,z1), facing `facing`.
    static func wall(from a: SIMD2<Float>, to b: SIMD2<Float>, y0: Float, y1: Float, facing: Vec3) -> MeshData {
        var m = MeshData()
        let ps = [Vec3(a.x, y0, a.y), Vec3(b.x, y0, b.y), Vec3(a.x, y1, a.y), Vec3(b.x, y1, b.y)]
        let len = simd_length(b - a)
        let uvs: [SIMD2<Float>] = [SIMD2(0, y0), SIMD2(len, y0), SIMD2(0, y1), SIMD2(len, y1)]
        for i in 0..<4 { m.vertices.append(Vertex(position: Vec4(ps[i], 1), normal: Vec4(facing, 0), uv: Vec4(uvs[i].x, uvs[i].y, 0, 0))) }
        let geomN = simd_cross(ps[1] - ps[0], ps[2] - ps[0])
        m.indices = simd_dot(geomN, facing) > 0 ? [0, 1, 2, 2, 1, 3] : [0, 2, 1, 1, 2, 3]
        return m
    }
}
