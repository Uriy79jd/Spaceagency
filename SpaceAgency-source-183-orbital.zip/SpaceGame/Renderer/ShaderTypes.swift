import simd

// Swift mirrors of the structs in Shaders/ShaderCommon.h. Only float4x4 / SIMD4<Float> members, so layouts match.

struct FrameUniforms {
    var viewProj = matrix_identity_float4x4
    var invViewProj = matrix_identity_float4x4
    var view = matrix_identity_float4x4
    var proj = matrix_identity_float4x4
    var lightViewProj = matrix_identity_float4x4
    var cameraWorld = Vec4.zero
    var lightDir = Vec4.zero
    var lightColor = Vec4.zero
    var plumeLight0 = Vec4.zero
    var plumeLight0Color = Vec4.zero
    var plumeLight1 = Vec4.zero
    var plumeLight1Color = Vec4.zero
    var sky = Vec4.zero
    var screen = Vec4.zero
    var pad = Vec4.zero
    var pad2 = Vec4.zero
    var misc = Vec4.zero
    var scene = Vec4.zero
}

struct DrawUniforms {
    var model = matrix_identity_float4x4
    var normalMatrix = matrix_identity_float4x4
    var baseColor = Vec4.zero
    var params = Vec4.zero
    var emissive = Vec4.zero
    var extra = Vec4.zero
}

struct PlumeUniforms {
    var exitPos = Vec4.zero
    var axis = Vec4.zero
    var axisFar = Vec4.zero
    var shape = Vec4.zero
    var look = Vec4.zero
    var anim = Vec4.zero
    var ground = Vec4.zero
    var ground2 = Vec4.zero
    var ground3 = Vec4.zero
    var boundsMin = Vec4.zero
    var boundsMax = Vec4.zero
}

struct SSAOParams {
    var proj = matrix_identity_float4x4
    var invProj = matrix_identity_float4x4
    var p = Vec4.zero
}

struct CompositeParams {
    var p = Vec4.zero
    var q = Vec4.zero
}

/// Mirrors TemporalParams in Shaders/Post.metal.
struct TemporalParams {
    var prevViewProj = matrix_identity_float4x4
    var camDelta = Vec4.zero
    var p = Vec4.zero
}

/// Mirrors UpsampleParams in Shaders/Post.metal.
struct UpsampleParams {
    var p = Vec4.zero
}

/// Mirrors CloudParams in Shaders/Clouds.metal.
struct CloudParams {
    var p = Vec4.zero
    var q = Vec4.zero
}

/// Mirrors TreeParams in Shaders/Trees.metal.
struct TreeParams {
    var grid = Vec4.zero
    var misc = Vec4.zero
    var lod = Vec4.zero
}

/// Mirrors GrassParams in Shaders/Grass.metal.
struct GrassParams {
    var grid = Vec4.zero
    var blast = Vec4.zero
    var misc = Vec4.zero
}

struct QualityLevel {
    var name: String
    var renderScale: Float
    var msaa: Int
    var shadowSize: Int
    var shadowTaps: Float
    var ssao: Bool
    var bloomLevels: Int
    var plumeSteps: Int
    var groundSteps: Int
    var particleCap: Int
    var particleRate: Float
    var fxaa: Bool
    var cloudSteps: Int = 20
    var cloudLightSteps: Int = 2
    var grassCells: Int = 220          // blades per side of the camera-centred grass patch
    var grassCell: Float = 0.32        // m between blades
    var treeNear: Int = 28             // near-mesh tree grid cells per side (16 m cells)
    var treeFar: Int = 100             // impostor grid cells per side
    var treeDensity: Float = 0.8       // fraction of eligible (clumped) cells that hold a tree

    /// GPU budget per frame is ~12 ms on a recent iPhone. The plume / particles are drawn at half of the
    /// render resolution; Low must hold 60 fps while firing on its own.
    /// `renderScale` is the 3-D render density in PIXELS PER POINT (the drawable itself is at the screen's
    /// native scale, so UI-free upscaling and the final composite are sharp); capped at the native scale.
    /// Build 180 rendered at 0.60–0.75 of a 2× drawable (1.2–1.5 px/pt) with no MSAA on Low.
    static let levels: [QualityLevel] = [
        QualityLevel(name: "Low", renderScale: 1.30, msaa: 2, shadowSize: 1024, shadowTaps: 0, ssao: false, bloomLevels: 4,
                     plumeSteps: 18, groundSteps: 12, particleCap: 1024, particleRate: 0.5, fxaa: false, cloudSteps: 14, cloudLightSteps: 1, grassCells: 150, grassCell: 0.45,
                     treeNear: 18, treeFar: 70, treeDensity: 0.6),
        QualityLevel(name: "Medium", renderScale: 1.50, msaa: 2, shadowSize: 1536, shadowTaps: 1, ssao: false, bloomLevels: 5,
                     plumeSteps: 24, groundSteps: 14, particleCap: 1536, particleRate: 0.75, fxaa: false, cloudSteps: 20, cloudLightSteps: 2, grassCells: 220, grassCell: 0.32,
                     treeNear: 26, treeFar: 100, treeDensity: 0.8),
        QualityLevel(name: "High", renderScale: 1.75, msaa: 2, shadowSize: 2048, shadowTaps: 1, ssao: true, bloomLevels: 5,
                     plumeSteps: 30, groundSteps: 18, particleCap: 2048, particleRate: 1.0, fxaa: false, cloudSteps: 28, cloudLightSteps: 3, grassCells: 290, grassCell: 0.26,
                     treeNear: 34, treeFar: 130, treeDensity: 1.0),
    ]
    static let maxParticles = 2048
}
