import Metal
import MetalKit
import simd
import QuartzCore

/// Forward PBR renderer: shadow map (cached while nothing moves) → MSAA HDR scene (sky, PBR) → SSAO →
/// GPU particle simulation (compute) → HALF-RES translucent layer (volumetric plume + particles) → upsample onto
/// the HDR image → auto-exposure → bloom → composite (heat haze, ACES) → [FXAA] → drawable.
/// Frame pacing: capped at 60 fps (30 when idle), quality drops on GPU time or thermal state.
final class Renderer: NSObject, MTKViewDelegate {
    let device: MTLDevice
    let queue: MTLCommandQueue
    let engine: GameEngine
    private let library: MTLLibrary

    static let hdrFormat = MTLPixelFormat.rgba16Float
    static let depthFormat = MTLPixelFormat.depth32Float
    static let distortFormat = MTLPixelFormat.r16Float

    // pipelines
    private var pbrPipelines: [Int: MTLRenderPipelineState] = [:]
    private var skyPipelines: [Int: MTLRenderPipelineState] = [:]
    private var grassPipelines: [Int: MTLRenderPipelineState] = [:]
    private var treePipelines: [Int: MTLRenderPipelineState] = [:]
    private var treeImpostorPipelines: [Int: MTLRenderPipelineState] = [:]
    private var treeMesh: GPUMesh?
    private var shadowPipeline: MTLRenderPipelineState!
    private var aoApplyPipeline: MTLRenderPipelineState!
    private var plumePipeline: MTLRenderPipelineState!
    private var particlePipeline: MTLRenderPipelineState!
    private var compositePipeline: MTLRenderPipelineState!
    private var compositeDrawablePipeline: MTLRenderPipelineState!
    private var transCompositePipeline: MTLRenderPipelineState!
    private var cloudPipeline: MTLRenderPipelineState!
    private var particleSpawnPipeline: MTLComputePipelineState!
    private var particleUpdatePipeline: MTLComputePipelineState!
    private var noiseBasePipeline: MTLComputePipelineState!
    private var noiseDetailPipeline: MTLComputePipelineState!
    private var materialDetailPipeline: MTLComputePipelineState!
    private var fxaaPipeline: MTLRenderPipelineState!
    private var envGenPipeline: MTLComputePipelineState!
    private var envPrefilterPipeline: MTLComputePipelineState!
    private var ssaoPipeline: MTLComputePipelineState!
    private var lumPipeline: MTLComputePipelineState!
    private var bloomDownPipeline: MTLComputePipelineState!
    private var bloomUpPipeline: MTLComputePipelineState!
    private var depthWrite: MTLDepthStencilState!
    private var depthSky: MTLDepthStencilState!
    private var depthNone: MTLDepthStencilState!
    private let vertexDescriptor: MTLVertexDescriptor

    // scene meshes
    private var hangarMeshes: [GPUMesh] = []
    private var siteMeshes: [GPUMesh] = []
    private var lastEnvOutdoor = true
    private var engineMeshes: [(GPUMesh, Bool, Bool)] = []    // (mesh, gimballed, interior liner: drawn double-sided)
    private var unitCylinder: GPUMesh?
    private var tv1Meshes: [(GPUMesh, Bool, Bool)] = []    // (mesh, double-sided, frosted tank)
    private var orbitalS1Meshes: [(GPUMesh, Bool, Bool)] = []  // stage 1 (booster), drawn at vehicle or booster model
    private var orbitalS2Meshes: [(GPUMesh, Bool, Bool)] = []  // stage 2 + fairing, drawn at the vehicle model
    private var tv1SkirtMesh: GPUMesh?
    private var tv1SkirtBase: [Vertex] = []
    private var tv1LastDent: Float = 0

    // targets
    private var hdrMSAA: MTLTexture?
    private var hdr: MTLTexture?
    private var depthMSAA: MTLTexture?
    private var depth: MTLTexture?
    private var distort: MTLTexture?          // half-res heat-haze channel
    private var trans: MTLTexture?            // half-res premultiplied plume + particles
    private var cloudTex: [MTLTexture] = []   // half-res volumetric clouds: [0] this frame's march
    private var cloudHist: [MTLTexture] = []  // resolved clouds, ping-pong (temporal history)
    private var transHist: [MTLTexture] = []  // resolved plume + particles, ping-pong
    private var histIndex = 0
    private var cloudHistoryValid = false
    private var transHistoryValid = false
    private var prevViewProj = matrix_identity_float4x4
    private var prevCamWorld = SIMD3<Double>(0, 0, 0)
    private var temporalPipeline: MTLRenderPipelineState!
    /// Screen scale of the drawable (px per pt), set by the view.
    var drawableScale: Float = 2
    private var noiseBaseTex: MTLTexture?
    private var noiseDetailTex: MTLTexture?
    private var noiseReady = false
    private var materialDetailTex: MTLTexture?       // 512² tileable procedural PBR detail map (mipmapped)
    private var aoTex: MTLTexture?
    private var ldr: MTLTexture?
    private var bloomDown: [MTLTexture] = []
    private var bloomUp: [MTLTexture] = []
    private var shadowMap: MTLTexture?
    private var envBase: MTLTexture?
    private var envSpec: MTLTexture?
    private var envSpecViews: [MTLTexture] = []
    private let envSize = 128
    private let envMips = 6
    private var targetSize = CGSize.zero
    private var builtQuality = -1
    private var lastEnvAltitude: Double = -1
    private var lastEnvVacuum = false

    // frame pacing / buffers
    private let inFlight = DispatchSemaphore(value: 3)
    private var particleState: MTLBuffer?
    private var spawnBuffers: [MTLBuffer] = []
    private var lastDrawTime: CFTimeInterval = 0
    private var shadowKey = SIMD4<Float>(-1, -1, -1, -1)
    private var shadowValid = false
    private var thermalCap = 2
    private var thermalCheck = 0
    private var frameIndex = 0
    private let lumBuffer: MTLBuffer

    // quality / exposure
    private(set) var quality = 2
    private var gpuTimes: [Double] = []
    private var lastQualityChange: CFTimeInterval = 0
    private var goodSince: CFTimeInterval = 0
    private var exposure: Float = 0.5
    private let isSimulator: Bool
    private let lock = NSLock()
    private var gpuTimeLatest: Double = 0
    private var frameMsAvg: Double = 16.7

    init?(view: MTKView, engine: GameEngine) {
        guard let device = view.device ?? MTLCreateSystemDefaultDevice(),
              let queue = device.makeCommandQueue(),
              let library = device.makeDefaultLibrary(),
              let lum = device.makeBuffer(length: 16, options: .storageModeShared) else { return nil }
        self.device = device
        self.queue = queue
        self.library = library
        self.engine = engine
        self.lumBuffer = lum
        lum.contents().storeBytes(of: Float(0.4), as: Float.self)
        #if targetEnvironment(simulator)
        isSimulator = true
        #else
        isSimulator = false
        #endif
        let vd = MTLVertexDescriptor()
        for i in 0..<3 {
            vd.attributes[i].format = .float4
            vd.attributes[i].offset = i * 16
            vd.attributes[i].bufferIndex = 0
        }
        vd.layouts[0].stride = MemoryLayout<Vertex>.stride
        vertexDescriptor = vd
        super.init()
        view.device = device
        view.colorPixelFormat = .bgra8Unorm
        view.depthStencilPixelFormat = .invalid
        view.sampleCount = 1
        view.framebufferOnly = true
        view.preferredFramesPerSecond = 60
        if isSimulator { quality = 0 } else { quality = 1 }   // start at Medium, climb if the GPU has headroom
        buildPipelines()
        buildScene()
        let stateLen = MemoryLayout<GPUParticle>.stride * QualityLevel.maxParticles
        if let b = device.makeBuffer(length: stateLen, options: .storageModeShared) {
            memset(b.contents(), 0, stateLen)       // life = 0: every slot starts dead
            particleState = b
        }
        for _ in 0..<3 {
            if let b = device.makeBuffer(length: MemoryLayout<ParticleSpawn>.stride * ParticleSystem.maxSpawnsPerFrame, options: .storageModeShared) {
                spawnBuffers.append(b)
            }
        }
        makeNoiseTextures()
    }

    // MARK: setup

    private func fn(_ name: String) -> MTLFunction? { library.makeFunction(name: name) }

    private func makeRender(_ v: String, _ f: String?, colors: [MTLPixelFormat], depth: MTLPixelFormat, samples: Int = 1,
                            vertexDesc: Bool = false, configure: ((MTLRenderPipelineDescriptor) -> Void)? = nil) -> MTLRenderPipelineState? {
        let d = MTLRenderPipelineDescriptor()
        d.vertexFunction = fn(v)
        if let f = f { d.fragmentFunction = fn(f) }
        for (i, c) in colors.enumerated() { d.colorAttachments[i].pixelFormat = c }
        d.depthAttachmentPixelFormat = depth
        d.rasterSampleCount = samples
        if vertexDesc { d.vertexDescriptor = vertexDescriptor }
        configure?(d)
        do { return try device.makeRenderPipelineState(descriptor: d) } catch {
            print("Pipeline \(v)/\(f ?? "-") failed: \(error)")
            return nil
        }
    }

    private func makeNoiseTextures() {
        let b = MTLTextureDescriptor()
        b.textureType = .type3D
        b.pixelFormat = .rg16Float
        b.width = 64; b.height = 64; b.depth = 64
        b.usage = [.shaderRead, .shaderWrite]
        b.storageMode = .private
        noiseBaseTex = device.makeTexture(descriptor: b)
        let d = MTLTextureDescriptor()
        d.textureType = .type3D
        d.pixelFormat = .r16Float
        d.width = 32; d.height = 32; d.depth = 32
        d.usage = [.shaderRead, .shaderWrite]
        d.storageMode = .private
        noiseDetailTex = device.makeTexture(descriptor: d)
        let m = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: 512, height: 512, mipmapped: true)
        m.usage = [.shaderRead, .shaderWrite]
        m.storageMode = .private
        materialDetailTex = device.makeTexture(descriptor: m)
    }

    /// Generates the tileable 3D noise once (first frame).
    private func ensureNoise(_ cb: MTLCommandBuffer) {
        guard !noiseReady, let bt = noiseBaseTex, let dt = noiseDetailTex,
              let bp = noiseBasePipeline, let dp = noiseDetailPipeline, let enc = cb.makeComputeCommandEncoder() else { return }
        enc.setComputePipelineState(bp)
        enc.setTexture(bt, index: 0)
        enc.dispatchThreads(MTLSize(width: 64, height: 64, depth: 64), threadsPerThreadgroup: MTLSize(width: 4, height: 4, depth: 4))
        enc.setComputePipelineState(dp)
        enc.setTexture(dt, index: 0)
        enc.dispatchThreads(MTLSize(width: 32, height: 32, depth: 32), threadsPerThreadgroup: MTLSize(width: 4, height: 4, depth: 4))
        if let mp = materialDetailPipeline, let mt = materialDetailTex {
            enc.setComputePipelineState(mp)
            enc.setTexture(mt, index: 0)
            enc.dispatchThreads(MTLSize(width: mt.width, height: mt.height, depth: 1), threadsPerThreadgroup: MTLSize(width: 8, height: 8, depth: 1))
        }
        enc.endEncoding()
        if let mt = materialDetailTex, let blit = cb.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: mt)
            blit.endEncoding()
        }
        noiseReady = true
    }

    private func makeCompute(_ name: String) -> MTLComputePipelineState? {
        guard let f = fn(name) else { return nil }
        return try? device.makeComputePipelineState(function: f)
    }

    private func pbrPipeline(samples: Int) -> MTLRenderPipelineState? {
        if let p = pbrPipelines[samples] { return p }
        let p = makeRender("pbrVertex", "pbrFragment", colors: [Renderer.hdrFormat], depth: Renderer.depthFormat, samples: samples, vertexDesc: true)
        pbrPipelines[samples] = p
        return p
    }

    private func grassPipeline(samples: Int) -> MTLRenderPipelineState? {
        if let p = grassPipelines[samples] { return p }
        let p = makeRender("grassVertex", "grassFragment", colors: [Renderer.hdrFormat], depth: Renderer.depthFormat, samples: samples)
        grassPipelines[samples] = p
        return p
    }

    private func treePipeline(samples: Int) -> MTLRenderPipelineState? {
        if let p = treePipelines[samples] { return p }
        let p = makeRender("treeVertex", "treeFragment", colors: [Renderer.hdrFormat], depth: Renderer.depthFormat, samples: samples, vertexDesc: true)
        treePipelines[samples] = p
        return p
    }

    private func treeImpostorPipeline(samples: Int) -> MTLRenderPipelineState? {
        if let p = treeImpostorPipelines[samples] { return p }
        let p = makeRender("treeImpostorVertex", "treeImpostorFragment", colors: [Renderer.hdrFormat], depth: Renderer.depthFormat, samples: samples) { d in
            d.isAlphaToCoverageEnabled = samples > 1          // soft silhouette edge with MSAA, no sorting needed
        }
        treeImpostorPipelines[samples] = p
        return p
    }

    private func skyPipeline(samples: Int) -> MTLRenderPipelineState? {
        if let p = skyPipelines[samples] { return p }
        let p = makeRender("skyVertex", "skyFragment", colors: [Renderer.hdrFormat], depth: Renderer.depthFormat, samples: samples)
        skyPipelines[samples] = p
        return p
    }

    private func buildPipelines() {
        shadowPipeline = makeRender("shadowVertex", nil, colors: [], depth: Renderer.depthFormat, vertexDesc: true)
        aoApplyPipeline = makeRender("fullscreenVertex", "aoApplyFragment", colors: [Renderer.hdrFormat], depth: .invalid) { d in
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.rgbBlendOperation = .add; c.alphaBlendOperation = .add
            c.sourceRGBBlendFactor = .zero; c.destinationRGBBlendFactor = .sourceColor
            c.sourceAlphaBlendFactor = .zero; c.destinationAlphaBlendFactor = .one
        }
        transCompositePipeline = makeRender("fullscreenVertex", "transCompositeFragment", colors: [Renderer.hdrFormat], depth: .invalid) { d in
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.rgbBlendOperation = .add; c.alphaBlendOperation = .add
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .zero; c.destinationAlphaBlendFactor = .one
        }
        cloudPipeline = makeRender("fullscreenVertex", "cloudFragment", colors: [Renderer.hdrFormat], depth: .invalid)
        temporalPipeline = makeRender("fullscreenVertex", "temporalResolveFragment", colors: [Renderer.hdrFormat], depth: .invalid)
        plumePipeline = makeRender("plumeVertex", "plumeFragment", colors: [Renderer.hdrFormat, Renderer.distortFormat], depth: .invalid) { d in
            // colour: premultiplied emission + absorption (dense far plume partly hides what is behind it)
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.rgbBlendOperation = .add; c.alphaBlendOperation = .add
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
            // heat-haze channel: additive
            let h = d.colorAttachments[1]!
            h.isBlendingEnabled = true
            h.rgbBlendOperation = .add; h.alphaBlendOperation = .add
            h.sourceRGBBlendFactor = .one; h.destinationRGBBlendFactor = .one
            h.sourceAlphaBlendFactor = .zero; h.destinationAlphaBlendFactor = .one
        }
        particlePipeline = makeRender("particleVertex", "particleFragment", colors: [Renderer.hdrFormat, Renderer.distortFormat], depth: .invalid) { d in
            let c = d.colorAttachments[0]!
            c.isBlendingEnabled = true
            c.rgbBlendOperation = .add; c.alphaBlendOperation = .add
            c.sourceRGBBlendFactor = .one; c.destinationRGBBlendFactor = .oneMinusSourceAlpha
            c.sourceAlphaBlendFactor = .one; c.destinationAlphaBlendFactor = .oneMinusSourceAlpha
            let h = d.colorAttachments[1]!
            h.isBlendingEnabled = true
            h.rgbBlendOperation = .add; h.alphaBlendOperation = .add
            h.sourceRGBBlendFactor = .one; h.destinationRGBBlendFactor = .one
            h.sourceAlphaBlendFactor = .zero; h.destinationAlphaBlendFactor = .one
        }
        compositePipeline = makeRender("fullscreenVertex", "compositeFragment", colors: [.rgba8Unorm], depth: .invalid)
        compositeDrawablePipeline = makeRender("fullscreenVertex", "compositeFragment", colors: [.bgra8Unorm], depth: .invalid)
        particleSpawnPipeline = makeCompute("particleSpawn")
        particleUpdatePipeline = makeCompute("particleUpdate")
        noiseBasePipeline = makeCompute("noiseBaseKernel")
        noiseDetailPipeline = makeCompute("noiseDetailKernel")
        materialDetailPipeline = makeCompute("materialDetailKernel")
        fxaaPipeline = makeRender("fullscreenVertex", "fxaaFragment", colors: [.bgra8Unorm], depth: .invalid)
        envGenPipeline = makeCompute("envGenerate")
        envPrefilterPipeline = makeCompute("envPrefilter")
        ssaoPipeline = makeCompute("ssaoKernel")
        lumPipeline = makeCompute("luminanceKernel")
        bloomDownPipeline = makeCompute("bloomDownsample")
        bloomUpPipeline = makeCompute("bloomUpsample")

        let dw = MTLDepthStencilDescriptor()
        dw.depthCompareFunction = .less
        dw.isDepthWriteEnabled = true
        depthWrite = device.makeDepthStencilState(descriptor: dw)
        let ds = MTLDepthStencilDescriptor()
        ds.depthCompareFunction = .lessEqual
        ds.isDepthWriteEnabled = false
        depthSky = device.makeDepthStencilState(descriptor: ds)
        let dn = MTLDepthStencilDescriptor()
        dn.depthCompareFunction = .always
        dn.isDepthWriteEnabled = false
        depthNone = device.makeDepthStencilState(descriptor: dn)
    }

    private func buildScene() {
        for part in HangarMesh.buildHangar() + HangarMesh.buildStand() {
            if let m = GPUMesh(device: device, data: part.data, material: part.material, castsShadow: part.castsShadow) { hangarMeshes.append(m) }
        }
        for part in TestSiteMesh.buildSite() + TV1SiteMesh.build() + OrbitalSiteMesh.build() {
            if let m = GPUMesh(device: device, data: part.data, material: part.material, castsShadow: part.castsShadow) { siteMeshes.append(m) }
        }
        let tv1 = TV1Mesh.build()
        for (i, (part, twoSided)) in tv1.parts.enumerated() {
            guard let m = GPUMesh(device: device, data: part.data, material: part.material, castsShadow: part.castsShadow) else { continue }
            tv1Meshes.append((m, twoSided, part.material.kind == .frostedSteel))
            if i == tv1.skirtIndex { tv1SkirtMesh = m; tv1SkirtBase = part.data.vertices }
        }
        // Orbital vehicle: stainless Falcon-size stack (photo-matched: 9 dark bells,
        // black interstage, steel fairing, no fins, no legs). Stage 1 and stage 2
        // are separate lists so the booster can be drawn on its own after separation.
        for (part, twoSided) in OrbitalMesh.buildStage1().parts {
            guard let m = GPUMesh(device: device, data: part.data, material: part.material, castsShadow: part.castsShadow) else { continue }
            orbitalS1Meshes.append((m, twoSided, part.material.kind == .frostedSteel))
        }
        for (part, twoSided) in OrbitalMesh.buildStage2().parts {
            guard let m = GPUMesh(device: device, data: part.data, material: part.material, castsShadow: part.castsShadow) else { continue }
            orbitalS2Meshes.append((m, twoSided, part.material.kind == .frostedSteel))
        }
        let def = PartCatalog.shared.part("raptor3") ?? PartDefinition.raptor3Fallback
        for part in PartMeshLibrary.build(def.mesh) {
            if let m = GPUMesh(device: device, data: part.data, material: part.material) {
                engineMeshes.append((m, !part.name.hasPrefix("fixed"), part.name == "nozzleInner"))
            }
        }
        unitCylinder = GPUMesh(device: device, data: MeshBuilder.cylinder(radius: 1, height: 1, segments: 20), material: .polishedSteel)
        treeMesh = GPUMesh(device: device, data: TreeMesh.build(), material: .darkSteel, castsShadow: false)
    }

    // MARK: targets

    private func makeTex(_ fmt: MTLPixelFormat, _ w: Int, _ h: Int, usage: MTLTextureUsage, samples: Int = 1, memoryless: Bool = false) -> MTLTexture? {
        let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: fmt, width: max(w, 1), height: max(h, 1), mipmapped: false)
        d.usage = usage
        if samples > 1 {
            d.textureType = .type2DMultisample
            d.sampleCount = samples
        }
        d.storageMode = (memoryless && !isSimulator) ? .memoryless : .private
        return device.makeTexture(descriptor: d)
    }

    private func rebuildTargets(drawableSize: CGSize) {
        let q = QualityLevel.levels[quality]
        let scale = min(q.renderScale / max(drawableScale, 1), 1)
        let w = Int(Float(drawableSize.width) * scale)
        let h = Int(Float(drawableSize.height) * scale)
        let msaa = isSimulator ? 1 : q.msaa
        if msaa > 1 {
            hdrMSAA = makeTex(Renderer.hdrFormat, w, h, usage: .renderTarget, samples: msaa, memoryless: true)
            depthMSAA = makeTex(Renderer.depthFormat, w, h, usage: .renderTarget, samples: msaa, memoryless: true)
        } else {
            hdrMSAA = nil
            depthMSAA = nil
        }
        hdr = makeTex(Renderer.hdrFormat, w, h, usage: [.renderTarget, .shaderRead])
        depth = makeTex(Renderer.depthFormat, w, h, usage: [.renderTarget, .shaderRead])
        let hw = max(w / 2, 1), hh = max(h / 2, 1)
        distort = makeTex(Renderer.distortFormat, hw, hh, usage: [.renderTarget, .shaderRead])
        trans = makeTex(Renderer.hdrFormat, hw, hh, usage: [.renderTarget, .shaderRead])
        cloudTex = (0..<1).compactMap { _ in makeTex(Renderer.hdrFormat, hw, hh, usage: [.renderTarget, .shaderRead]) }
        cloudHist = (0..<2).compactMap { _ in makeTex(Renderer.hdrFormat, hw, hh, usage: [.renderTarget, .shaderRead]) }
        transHist = (0..<2).compactMap { _ in makeTex(Renderer.hdrFormat, hw, hh, usage: [.renderTarget, .shaderRead]) }
        cloudHistoryValid = false
        transHistoryValid = false
        aoTex = makeTex(.r16Float, max(w / 2, 1), max(h / 2, 1), usage: [.shaderRead, .shaderWrite])
        ldr = makeTex(.rgba8Unorm, Int(drawableSize.width), Int(drawableSize.height), usage: [.renderTarget, .shaderRead])
        bloomDown = []
        bloomUp = []
        var bw = w / 2, bh = h / 2
        for _ in 0..<q.bloomLevels {
            if let t = makeTex(Renderer.hdrFormat, max(bw, 1), max(bh, 1), usage: [.shaderRead, .shaderWrite]) { bloomDown.append(t) }
            bw /= 2; bh /= 2
        }
        for i in 0..<max(bloomDown.count - 1, 0) {
            if let t = makeTex(Renderer.hdrFormat, bloomDown[i].width, bloomDown[i].height, usage: [.shaderRead, .shaderWrite]) { bloomUp.append(t) }
        }
        if shadowMap?.width != q.shadowSize {
            shadowMap = makeTex(Renderer.depthFormat, q.shadowSize, q.shadowSize, usage: [.renderTarget, .shaderRead])
        }
        if engine.particles.capacity != q.particleCap {
            engine.particles.capacity = min(q.particleCap, QualityLevel.maxParticles)
            engine.particles.reset()
        }
        engine.particles.rateScale = q.particleRate
        shadowValid = false
        targetSize = drawableSize
        builtQuality = quality
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.engine.ui.qualityName = QualityLevel.levels[self.quality].name
        }
    }

    private func ensureEnv(_ cb: MTLCommandBuffer, altitude: Double, vacuum: Bool, time: Double, outdoor: Bool) {
        if envBase == nil {
            let d = MTLTextureDescriptor.textureCubeDescriptor(pixelFormat: Renderer.hdrFormat, size: envSize, mipmapped: true)
            d.usage = [.shaderRead, .shaderWrite]
            d.storageMode = .private
            envBase = device.makeTexture(descriptor: d)
            let s = MTLTextureDescriptor.textureCubeDescriptor(pixelFormat: Renderer.hdrFormat, size: envSize, mipmapped: true)
            s.mipmapLevelCount = envMips
            s.usage = [.shaderRead, .shaderWrite]
            s.storageMode = .private
            envSpec = device.makeTexture(descriptor: s)
            if let spec = envSpec {
                envSpecViews = (0..<envMips).compactMap { lvl in
                    spec.makeTextureView(pixelFormat: Renderer.hdrFormat, textureType: .typeCube, levels: lvl..<(lvl + 1), slices: 0..<6)
                }
            }
        }
        let altKm = altitude / 1000
        let changed = lastEnvAltitude < 0 || abs(altKm - lastEnvAltitude) > 0.8 || vacuum != lastEnvVacuum || outdoor != lastEnvOutdoor
        guard changed, let base = envBase, let gen = envGenPipeline, let pre = envPrefilterPipeline else { return }
        lastEnvAltitude = altKm
        lastEnvVacuum = vacuum
        lastEnvOutdoor = outdoor
        var sky = Vec4(Float(altKm), vacuum ? 1 : 0, Float(time), outdoor ? 2 : 1)
        if let enc = cb.makeComputeCommandEncoder() {
            enc.setComputePipelineState(gen)
            enc.setTexture(base, index: 0)
            enc.setBytes(&sky, length: MemoryLayout<Vec4>.stride, index: 0)
            enc.dispatchThreads(MTLSize(width: envSize, height: envSize, depth: 6), threadsPerThreadgroup: MTLSize(width: 8, height: 8, depth: 1))
            enc.endEncoding()
        }
        if let blit = cb.makeBlitCommandEncoder() {
            blit.generateMipmaps(for: base)
            blit.endEncoding()
        }
        if let enc = cb.makeComputeCommandEncoder() {
            enc.setComputePipelineState(pre)
            enc.setTexture(base, index: 0)
            for (lvl, view) in envSpecViews.enumerated() {
                var p = Vec4(Float(lvl) / Float(envMips - 1), Float(base.mipmapLevelCount - 1), 0, 0)
                enc.setTexture(view, index: 1)
                enc.setBytes(&p, length: MemoryLayout<Vec4>.stride, index: 0)
                let sz = max(envSize >> lvl, 1)
                enc.dispatchThreads(MTLSize(width: sz, height: sz, depth: 6), threadsPerThreadgroup: MTLSize(width: min(8, sz), height: min(8, sz), depth: 1))
            }
            enc.endEncoding()
        }
    }

    // MARK: MTKViewDelegate

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        rebuildTargets(drawableSize: size)
    }

    func draw(in view: MTKView) {
        let size = view.drawableSize
        guard size.width > 8, size.height > 8 else { return }
        let ds = Float(view.contentScaleFactor)
        if abs(ds - drawableScale) > 0.01 { drawableScale = ds; builtQuality = -1 }
        inFlight.wait()
        updateThermalCap()
        adaptQuality()
        if builtQuality != quality || targetSize != size { rebuildTargets(drawableSize: size) }
        engine.viewSize = view.bounds.size
        let now = CACurrentMediaTime()
        let fs = engine.frame(now: now)
        engine.updateAudio()
        let frameDt = Float(lastDrawTime > 0 ? min(max(now - lastDrawTime, 0.001), 0.05) : 1.0 / 60.0)
        frameMsAvg += (Double(frameDt) * 1000 - frameMsAvg) * 0.1
        lastDrawTime = now
        // frame pacing: 60 fps cap while anything is happening, 30 fps when the scene is idle (less heat)
        let busy = fs.plume.active > 0.01 || fs.plume.flash > 0.01 || fs.vent > 0.01 || now - fs.lastInteraction < 3
            || engine.ui.dragging || (engine.sim.map { $0.phase != .safed } ?? false) || engine.flightActive
        let wantFPS = (busy && thermalCap > 0) || fs.lastInteraction > now - 3 ? 60 : 30
        if view.preferredFramesPerSecond != wantFPS { view.preferredFramesPerSecond = wantFPS }

        guard let cb = queue.makeCommandBuffer() else { inFlight.signal(); return }
        let sem = inFlight
        cb.addCompletedHandler { [weak self] buf in
            let t = buf.gpuEndTime - buf.gpuStartTime
            // keep the last valid reading: a buffer without timestamps (0) must not zero the readout
            if t > 0, let s = self { s.lock.lock(); s.gpuTimeLatest = t; s.lock.unlock() }
            sem.signal()
        }
        guard let hdr = hdr, let depth = depth, let distort = distort, let trans = trans, let ldr = ldr, let shadowMap = shadowMap else { cb.commit(); return }
        ensureNoise(cb)
        let q = QualityLevel.levels[quality]
        let outdoor = fs.outdoor
        ensureEnv(cb, altitude: fs.altitude, vacuum: fs.vacuum, time: fs.time, outdoor: outdoor)

        // ---------- uniforms ----------
        let aspect = Float(size.width / size.height)
        let proj = engine.camera.projection(aspect: aspect)
        let viewM = fs.view
        var fu = FrameUniforms()
        fu.view = viewM
        fu.proj = proj
        fu.viewProj = proj * viewM
        fu.invViewProj = fu.viewProj.inverse
        fu.cameraWorld = Vec4(fs.cameraWorld.float, 1)
        let lightDir = simd_normalize(Vec3(0.45, 0.62, 0.65))   // matches the sun in skyRadiance()
        let altKm = Float(fs.altitude / 1000)
        let sunDim: Float = fs.vacuum ? 1.15 : 1.0
        fu.lightDir = Vec4(lightDir, (outdoor ? 4.6 : 3.0) * sunDim)
        fu.lightColor = Vec4(1.0, 0.94, 0.86, 1)
        // y: per-frame golden-ratio offset of every ray-march start (accumulated by the temporal resolve)
        fu.scene = Vec4(outdoor ? 1 : 0, Float((Double(frameIndex % 4096) * 0.6180339887).truncatingRemainder(dividingBy: 1)), 0, 0)
        // light matrix in absolute world space, then shifted to camera-relative (stable shadows)
        let center = fs.shadowCenter ?? (outdoor ? Vec3(0, 22, 0) : Vec3(0, 4, 0))
        let ext: Float = fs.shadowCenter != nil ? 26 : (outdoor ? 36 : 22)
        let lv = float4x4.lookAt(eye: center + lightDir * 80, center: center, up: Vec3(0, 1, 0))
        let lp = float4x4.orthographic(left: -ext, right: ext, bottom: -ext, top: ext, near: 1, far: 180)
        fu.lightViewProj = lp * lv * float4x4(translation: fs.cameraWorld.float)
        let pl = fs.plume
        let bright = Float(pl.brightness)
        let rich = Float(engine.sim?.richness ?? 0)
        // warm light spill: pink-white column with amber afterburning (violet only in thin air)
        var c0 = simd_mix(Vec3(0.70, 0.62, 1.0), Vec3(1.0, 0.70, 0.48), Vec3(repeating: Float(pl.afterburn) * 0.85))
        c0 = simd_mix(c0, Vec3(1.0, 0.45, 0.15), Vec3(repeating: rich))
        fu.plumeLight0 = Vec4(fs.plumeExit + fs.plumeAxis * 1.5, 150 * bright + Float(pl.flash) * 1800)
        fu.plumeLight0Color = Vec4(c0, 1)
        fu.plumeLight1 = Vec4(fs.impingement + Vec3(0, 0.8, 0), 260 * bright * Float(pl.groundFactor))
        fu.plumeLight1Color = Vec4(1.0, 0.58, 0.32, 1)
        fu.sky = Vec4(altKm, fs.vacuum ? 1 : 0, Float(fs.time.truncatingRemainder(dividingBy: 1000)), 1.0)
        fu.screen = Vec4(Float(hdr.width), Float(hdr.height), 1 / Float(hdr.width), 1 / Float(hdr.height))
        let reVis = Float(RaptorMesh.exitRadius)
        let reScale = reVis / max(fs.exitRadius, 0.01)
        let rjVis = Float(max(pl.jetRadius, Double(fs.exitRadius))) * reScale
        fu.pad = Vec4(fs.padCenterWorld.x, fs.padCenterWorld.y, fs.padTemp, fs.scorch)
        fu.pad2 = Vec4(rjVis * 1.2, Float(pl.wallJetRadius), Float(pl.groundFactor), fs.shockRingAge)
        fu.misc = Vec4(1 / Float(shadowMap.width), Float(envMips), exposure, q.shadowTaps)
        // reprojection for the temporal resolve: last frame's camera-relative viewProj + camera motion
        let camDeltaD = fs.cameraWorld - prevCamWorld
        let camJump = simd_length(camDeltaD) > 60          // site switch / reset: drop history
        if camJump { cloudHistoryValid = false; transHistoryValid = false }
        let camDelta = Vec3(Float(camDeltaD.x), Float(camDeltaD.y), Float(camDeltaD.z))
        let pvp = prevViewProj
        defer { prevViewProj = fu.viewProj; prevCamWorld = fs.cameraWorld }
        let hi = histIndex, hiPrev = 1 - histIndex
        defer { histIndex = 1 - histIndex }

        // TV-1 skirt crumple after a hard landing: rewrite the skirt vertices once per new dent
        if abs(fs.vehicleDent - tv1LastDent) > 0.002, let sk = tv1SkirtMesh, !tv1SkirtBase.isEmpty {
            tv1LastDent = fs.vehicleDent
            let verts = TV1Mesh.dentSkirt(tv1SkirtBase, dent: fs.vehicleDent)
            verts.withUnsafeBytes { raw in
                if let b = raw.baseAddress { sk.vertexBuffer.contents().copyMemory(from: b, byteCount: min(raw.count, sk.vertexBuffer.length)) }
            }
        }
        // ---------- shadow pass (only when the engine moved / scene changed: the sun and stand are static) ----------
        var key = SIMD4<Float>(fs.outdoor ? 1 : 0, fs.engineFixedModel == nil ? 0 : 1, 0, 0) + fs.vehicleKey * 1e-3
        if let g = fs.engineGimbalModel {
            let c2 = g.columns.2
            let c3 = g.columns.3 + Vec4(fs.cameraWorld.float, 0)
            key.z = (c2.x * 1000).rounded() + (c2.z * 1000).rounded() * 0.001
            key.w = (c3.x * 100).rounded() + (c3.y * 100).rounded() * 7 + (c3.z * 100).rounded() * 0.0001
        }
        let shadowNeeded = !shadowValid || key != shadowKey
        shadowKey = key
        shadowValid = true
        let sp = MTLRenderPassDescriptor()
        sp.depthAttachment.texture = shadowMap
        sp.depthAttachment.loadAction = .clear
        sp.depthAttachment.storeAction = .store
        sp.depthAttachment.clearDepth = 1
        if shadowNeeded, let enc = cb.makeRenderCommandEncoder(descriptor: sp), let pso = shadowPipeline {
            enc.setRenderPipelineState(pso)
            enc.setDepthStencilState(depthWrite)
            enc.setFrontFacing(.counterClockwise)
            enc.setCullMode(.none)
            enc.setDepthBias(0.002, slopeScale: 2.0, clamp: 0.01)
            enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
            drawScene(enc, fs: fs, shadowPass: true)
            enc.endEncoding()
        }

        // ---------- main HDR pass ----------
        let msaa = isSimulator ? 1 : q.msaa
        let mp = MTLRenderPassDescriptor()
        if msaa > 1, let cm = hdrMSAA, let dm = depthMSAA {
            mp.colorAttachments[0].texture = cm
            mp.colorAttachments[0].resolveTexture = hdr
            mp.colorAttachments[0].storeAction = .multisampleResolve
            mp.depthAttachment.texture = dm
            mp.depthAttachment.resolveTexture = depth
            mp.depthAttachment.storeAction = .multisampleResolve
            mp.depthAttachment.depthResolveFilter = .sample0
        } else {
            mp.colorAttachments[0].texture = hdr
            mp.colorAttachments[0].storeAction = .store
            mp.depthAttachment.texture = depth
            mp.depthAttachment.storeAction = .store
        }
        mp.colorAttachments[0].loadAction = .clear
        mp.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 1)
        mp.depthAttachment.loadAction = .clear
        mp.depthAttachment.clearDepth = 1
        if let enc = cb.makeRenderCommandEncoder(descriptor: mp), let pso = pbrPipeline(samples: msaa) {
            enc.setRenderPipelineState(pso)
            enc.setDepthStencilState(depthWrite)
            enc.setFrontFacing(.counterClockwise)
            enc.setCullMode(.back)
            enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
            enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
            enc.setFragmentTexture(shadowMap, index: 0)
            enc.setFragmentTexture(envSpec, index: 1)
            enc.setFragmentTexture(materialDetailTex, index: 2)
            drawScene(enc, fs: fs, shadowPass: false)
            // instanced grass around the camera (skipped high above the ground)
            if outdoor && fs.cameraWorld.y < 150, let gp = grassPipeline(samples: msaa) {
                let n = q.grassCells
                let cell = q.grassCell
                let half = Float(n) * cell * 0.5
                let fwd = Vec3(-viewM.columns.0.z, -viewM.columns.1.z, -viewM.columns.2.z)
                var fl = SIMD2<Float>(fwd.x, fwd.z)
                fl = simd_length(fl) > 1e-3 ? simd_normalize(fl) : SIMD2<Float>(0, -1)
                let camXZ = SIMD2<Float>(Float(fs.cameraWorld.x), Float(fs.cameraWorld.z))
                var c = camXZ + fl * half * 0.55
                c = (c / cell).rounded(.toNearestOrAwayFromZero) * cell
                let impW = fs.impingement + fs.cameraWorld.float
                var gpar = GrassParams(grid: Vec4(c.x, c.y, cell, Float(n)),
                                       blast: Vec4(impW.x, impW.z, Float(pl.wallJetRadius), Float(pl.groundFactor) * Float(pl.active)),
                                       misc: Vec4(Float(fs.time.truncatingRemainder(dividingBy: 1000)), fs.wind.x, fs.wind.z, impW.y))
                enc.setRenderPipelineState(gp)
                enc.setCullMode(.none)
                enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setVertexBytes(&gpar, length: MemoryLayout<GrassParams>.stride, index: 2)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentTexture(shadowMap, index: 0)
                enc.setFragmentTexture(envSpec, index: 1)          // image-based irradiance, as on the ground
                enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 7, instanceCount: n * n)
                enc.setCullMode(.back)
            }
            // South-Texas scrub trees: near instanced meshes + far impostors around the camera (skipped high up)
            if outdoor && fs.cameraWorld.y < 2500, let tm = treeMesh, let tp = treePipeline(samples: msaa),
               let ip = treeImpostorPipeline(samples: msaa) {
                let cell: Float = 16
                let camXZ = SIMD2<Float>(Float(fs.cameraWorld.x), Float(fs.cameraWorld.z))
                let c = (camXZ / cell).rounded(.toNearestOrAwayFromZero) * cell
                let nearHalf = Float(q.treeNear) * cell * 0.5
                let farHalf = Float(q.treeFar) * cell * 0.5
                let tmisc = Vec4(Float(fs.time.truncatingRemainder(dividingBy: 1000)), fs.wind.x, fs.wind.z, q.treeDensity)
                let tlod = Vec4(nearHalf * 0.55, nearHalf * 0.85, farHalf * 0.95, 0)
                var near = TreeParams(grid: Vec4(c.x, c.y, cell, Float(q.treeNear)), misc: tmisc, lod: tlod)
                var far = TreeParams(grid: Vec4(c.x, c.y, cell, Float(q.treeFar)), misc: tmisc, lod: tlod)
                enc.setCullMode(.none)
                enc.setRenderPipelineState(tp)
                enc.setVertexBuffer(tm.vertexBuffer, offset: 0, index: 0)
                enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setVertexBytes(&near, length: MemoryLayout<TreeParams>.stride, index: 2)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentTexture(shadowMap, index: 0)
                enc.setFragmentTexture(envSpec, index: 1)
                enc.drawIndexedPrimitives(type: .triangle, indexCount: tm.indexCount, indexType: .uint32, indexBuffer: tm.indexBuffer,
                                          indexBufferOffset: 0, instanceCount: q.treeNear * q.treeNear)
                enc.setRenderPipelineState(ip)
                enc.setVertexBytes(&far, length: MemoryLayout<TreeParams>.stride, index: 2)
                enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4, instanceCount: q.treeFar * q.treeFar)
                enc.setCullMode(.back)
            }
            if let sky = skyPipeline(samples: msaa) {
                enc.setRenderPipelineState(sky)
                enc.setDepthStencilState(depthSky)
                enc.setCullMode(.none)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }
            enc.endEncoding()
        }

        // ---------- SSAO ----------
        let useAO = q.ssao && aoTex != nil
        if useAO, let ao = aoTex, let pso = ssaoPipeline, let enc = cb.makeComputeCommandEncoder() {
            var p = SSAOParams(proj: proj, invProj: proj.inverse, p: Vec4(0.55, 0.85, Float(hdr.width), Float(hdr.height)))
            enc.setComputePipelineState(pso)
            enc.setTexture(depth, index: 0)
            enc.setTexture(ao, index: 1)
            enc.setBytes(&p, length: MemoryLayout<SSAOParams>.stride, index: 0)
            enc.dispatchThreads(MTLSize(width: ao.width, height: ao.height, depth: 1), threadsPerThreadgroup: MTLSize(width: 8, height: 8, depth: 1))
            enc.endEncoding()
        }

        // ---------- volumetric clouds at real altitudes (half res, jittered march + reprojected temporal resolve) ----------
        var cloudOut: MTLTexture? = nil
        if outdoor && cloudTex.count == 1 && cloudHist.count == 2, let pso = cloudPipeline, let tpso = temporalPipeline {
            let raw = cloudTex[0]
            let tm = Float(fs.time.truncatingRemainder(dividingBy: 100_000))
            var cp = CloudParams(p: Vec4(0.42, tm, Float(q.cloudSteps), Float(q.cloudLightSteps)),
                                 q: Vec4(0, tm * 9, tm * 3, 0))
            let rp = MTLRenderPassDescriptor()
            rp.colorAttachments[0].texture = raw
            rp.colorAttachments[0].loadAction = .dontCare
            rp.colorAttachments[0].storeAction = .store
            if let enc = cb.makeRenderCommandEncoder(descriptor: rp) {
                enc.setRenderPipelineState(pso)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentBytes(&cp, length: MemoryLayout<CloudParams>.stride, index: 0)
                enc.setFragmentTexture(depth, index: 0)
                enc.setFragmentTexture(noiseBaseTex, index: 1)
                enc.setFragmentTexture(noiseDetailTex, index: 2)
                enc.setFragmentTexture(cloudHist[hiPrev], index: 3)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
                enc.endEncoding()
            }
            // clouds are kilometres away: reproject at 3 km; 12 % of the new frame per frame (~8-frame average)
            var tpar = TemporalParams(prevViewProj: pvp, camDelta: Vec4(camDelta, 3000),
                                      p: Vec4(0.12, cloudHistoryValid ? 1 : 0, 0, 0))
            if resolveTemporal(cb, fu: &fu, params: &tpar, current: raw, history: cloudHist[hiPrev], out: cloudHist[hi], pso: tpso) {
                cloudOut = cloudHist[hi]
                cloudHistoryValid = true
            }
        } else {
            cloudHistoryValid = false
        }

        // site collision shapes for the GPU, packed from the same surface list the CPU raycast uses
        var siteShapes = engine.impingement.gpuShapes()
        let siteLen = MemoryLayout<SIMD4<Float>>.stride * siteShapes.count

        // ---------- GPU particles: spawn this frame's queue into the ring, integrate + collide ----------
        let pcap = min(engine.particles.capacity, QualityLevel.maxParticles)
        var psim = fs.particleSim
        psim.imp.w = frameDt
        psim.counts.x = Float(pcap)
        let nSpawn = min(engine.particles.spawnCount, ParticleSystem.maxSpawnsPerFrame)
        psim.counts.y = Float(nSpawn)
        if let state = particleState, !spawnBuffers.isEmpty, let spawnP = particleSpawnPipeline, let updP = particleUpdatePipeline,
           let enc = cb.makeComputeCommandEncoder() {
            let sbuf = spawnBuffers[frameIndex % spawnBuffers.count]
            if nSpawn > 0 {
                engine.particles.spawns.withUnsafeBytes { raw in
                    if let base = raw.baseAddress { sbuf.contents().copyMemory(from: base, byteCount: nSpawn * MemoryLayout<ParticleSpawn>.stride) }
                }
                enc.setComputePipelineState(spawnP)
                enc.setBuffer(state, offset: 0, index: 0)
                enc.setBuffer(sbuf, offset: 0, index: 1)
                enc.setBytes(&psim, length: MemoryLayout<ParticleSimUniforms>.stride, index: 2)
                enc.dispatchThreads(MTLSize(width: nSpawn, height: 1, depth: 1), threadsPerThreadgroup: MTLSize(width: 64, height: 1, depth: 1))
            }
            enc.setComputePipelineState(updP)
            enc.setBuffer(state, offset: 0, index: 0)
            enc.setBytes(&psim, length: MemoryLayout<ParticleSimUniforms>.stride, index: 2)
            enc.setBytes(&siteShapes, length: siteLen, index: 3)
            enc.dispatchThreads(MTLSize(width: pcap, height: 1, depth: 1), threadsPerThreadgroup: MTLSize(width: 64, height: 1, depth: 1))
            enc.endEncoding()
        }
        engine.particles.consumeSpawns()

        // ---------- half-res translucent layer: plume (jet + ground interaction), particles ----------
        let tp = MTLRenderPassDescriptor()
        tp.colorAttachments[0].texture = trans
        tp.colorAttachments[0].loadAction = .clear
        tp.colorAttachments[0].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        tp.colorAttachments[0].storeAction = .store
        tp.colorAttachments[1].texture = distort
        tp.colorAttachments[1].loadAction = .clear
        tp.colorAttachments[1].clearColor = MTLClearColor(red: 0, green: 0, blue: 0, alpha: 0)
        tp.colorAttachments[1].storeAction = .store
        if let enc = cb.makeRenderCommandEncoder(descriptor: tp) {
            enc.setDepthStencilState(depthNone)
            enc.setFrontFacing(.counterClockwise)
            if (pl.active > 0.01 || pl.flash > 0.01), let pso = plumePipeline {
                enc.setRenderPipelineState(pso)
                enc.setCullMode(.front)
                enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentTexture(depth, index: 0)
                enc.setFragmentTexture(noiseBaseTex, index: 1)
                enc.setFragmentTexture(noiseDetailTex, index: 2)
                enc.setFragmentBytes(&siteShapes, length: siteLen, index: 3)
                var jet = plumeUniforms(fs, mode: 0, steps: q.plumeSteps, rjVis: rjVis, rich: rich)
                enc.setVertexBytes(&jet, length: MemoryLayout<PlumeUniforms>.stride, index: 2)
                enc.setFragmentBytes(&jet, length: MemoryLayout<PlumeUniforms>.stride, index: 2)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 36)
                if pl.groundFactor > 0.02 {
                    var gr = plumeUniforms(fs, mode: 1, steps: q.groundSteps, rjVis: rjVis, rich: rich)
                    enc.setVertexBytes(&gr, length: MemoryLayout<PlumeUniforms>.stride, index: 2)
                    enc.setFragmentBytes(&gr, length: MemoryLayout<PlumeUniforms>.stride, index: 2)
                    enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 36)
                }
            }
            if let state = particleState, let pso = particlePipeline, pcap > 0 {
                enc.setRenderPipelineState(pso)
                enc.setCullMode(.none)
                enc.setVertexBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
                enc.setVertexBuffer(state, offset: 0, index: 2)
                enc.setVertexBytes(&psim, length: MemoryLayout<ParticleSimUniforms>.stride, index: 3)
                enc.setFragmentTexture(depth, index: 0)
                enc.setFragmentTexture(noiseBaseTex, index: 1)
                enc.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4, instanceCount: pcap)
            }
            enc.endEncoding()
        }

        // ---------- temporal resolve of the translucent layer (reprojected at the plume's distance) ----------
        var transOut: MTLTexture = trans
        if transHist.count == 2, let tpso = temporalPipeline {
            let L = Float(pl.length)
            let zImp = pl.groundFactor > 0.02 ? Float(pl.impingementDistance) : L
            let mid = fs.plumeExit + fs.plumeAxis * (0.35 * min(L, zImp + 1))
            let dist = pl.active > 0.01 ? max(simd_length(mid), 2) : max(simd_length(fs.plumeExit), 5)
            // the plume flickers: keep 30 % of the new frame, clipped to its neighbourhood (no smear)
            var tpar = TemporalParams(prevViewProj: pvp, camDelta: Vec4(camDelta, dist),
                                      p: Vec4(0.30, transHistoryValid ? 1 : 0, 0, 0))
            if resolveTemporal(cb, fu: &fu, params: &tpar, current: trans, history: transHist[hiPrev], out: transHist[hi], pso: tpso) {
                transOut = transHist[hi]
                transHistoryValid = true
            }
        }
        var ups = UpsampleParams(p: Vec4(proj.columns.2.z, proj.columns.3.z, Float(hdr.width) / Float(max(trans.width, 1)), 0))

        // ---------- full-res: AO multiply, then the upsampled translucent layer over the HDR image ----------
        let up = MTLRenderPassDescriptor()
        up.colorAttachments[0].texture = hdr
        up.colorAttachments[0].loadAction = .load
        up.colorAttachments[0].storeAction = .store
        if let enc = cb.makeRenderCommandEncoder(descriptor: up) {
            enc.setDepthStencilState(depthNone)
            enc.setCullMode(.none)
            if useAO, let ao = aoTex, let pso = aoApplyPipeline {
                enc.setRenderPipelineState(pso)
                enc.setFragmentTexture(ao, index: 0)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }
            if let pso = transCompositePipeline, let ct = cloudOut {
                enc.setRenderPipelineState(pso)
                enc.setFragmentTexture(ct, index: 0)
                enc.setFragmentTexture(depth, index: 1)
                enc.setFragmentBytes(&ups, length: MemoryLayout<UpsampleParams>.stride, index: 0)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }
            if let pso = transCompositePipeline {
                enc.setRenderPipelineState(pso)
                enc.setFragmentTexture(transOut, index: 0)
                enc.setFragmentTexture(depth, index: 1)
                enc.setFragmentBytes(&ups, length: MemoryLayout<UpsampleParams>.stride, index: 0)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }
            enc.endEncoding()
        }

        // ---------- auto exposure (metered from the HDR image; read back next frame) ----------
        let measured = max(lumBuffer.contents().load(as: Float.self), 1e-4)
        let targetExp = clampf((fs.outdoor ? 0.19 : 0.16) / measured, 0.04, 2.2)
        let k: Float = targetExp < exposure ? 0.08 : 0.03
        exposure += (targetExp - exposure) * k
        if let pso = lumPipeline, let enc = cb.makeComputeCommandEncoder() {
            enc.setComputePipelineState(pso)
            enc.setTexture(hdr, index: 0)
            enc.setBuffer(lumBuffer, offset: 0, index: 0)
            enc.dispatchThreadgroups(MTLSize(width: 1, height: 1, depth: 1), threadsPerThreadgroup: MTLSize(width: 16, height: 16, depth: 1))
            enc.endEncoding()
        }

        // ---------- bloom ----------
        if !bloomDown.isEmpty, let down = bloomDownPipeline, let up = bloomUpPipeline, let enc = cb.makeComputeCommandEncoder() {
            enc.setComputePipelineState(down)
            var src: MTLTexture = hdr
            for (i, dst) in bloomDown.enumerated() {
                var p = Vec4(1.0, 0.5, i == 0 ? 1 : 0, exposure)
                enc.setTexture(src, index: 0)
                enc.setTexture(dst, index: 1)
                enc.setBytes(&p, length: MemoryLayout<Vec4>.stride, index: 0)
                enc.dispatchThreads(MTLSize(width: dst.width, height: dst.height, depth: 1), threadsPerThreadgroup: MTLSize(width: 8, height: 8, depth: 1))
                src = dst
            }
            enc.setComputePipelineState(up)
            var low: MTLTexture = bloomDown[bloomDown.count - 1]
            for i in stride(from: bloomUp.count - 1, through: 0, by: -1) {
                var p = Vec4(1.0, 0, 0, 0)
                enc.setTexture(low, index: 0)
                enc.setTexture(bloomDown[i], index: 1)
                enc.setTexture(bloomUp[i], index: 2)
                enc.setBytes(&p, length: MemoryLayout<Vec4>.stride, index: 0)
                enc.dispatchThreads(MTLSize(width: bloomUp[i].width, height: bloomUp[i].height, depth: 1), threadsPerThreadgroup: MTLSize(width: 8, height: 8, depth: 1))
                low = bloomUp[i]
            }
            enc.endEncoding()
        }
        let bloomTex: MTLTexture? = bloomUp.first ?? bloomDown.first

        // ---------- composite (→ LDR → FXAA, or straight to the drawable when FXAA is off) ----------
        var cpar = CompositeParams(p: Vec4(exposure, 0.9, Float(fs.time.truncatingRemainder(dividingBy: 1000)), 1.0),
                                   q: Vec4(Float(max(bloomDown.count, 1)) * 0.5, 0.35, q.fxaa ? 1 : 0, 0))
        let useFXAA = q.fxaa || isSimulator
        if useFXAA {
            let cp = MTLRenderPassDescriptor()
            cp.colorAttachments[0].texture = ldr
            cp.colorAttachments[0].loadAction = .dontCare
            cp.colorAttachments[0].storeAction = .store
            if let enc = cb.makeRenderCommandEncoder(descriptor: cp), let pso = compositePipeline {
                enc.setRenderPipelineState(pso)
                enc.setFragmentTexture(hdr, index: 0)
                enc.setFragmentTexture(bloomTex, index: 1)
                enc.setFragmentTexture(distort, index: 2)
                enc.setFragmentBytes(&cpar, length: MemoryLayout<CompositeParams>.stride, index: 0)
                enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
                enc.endEncoding()
            }
        }
        if let rpd = view.currentRenderPassDescriptor, let drawable = view.currentDrawable {
            rpd.colorAttachments[0].loadAction = .dontCare
            rpd.colorAttachments[0].storeAction = .store
            if let enc = cb.makeRenderCommandEncoder(descriptor: rpd) {
                if useFXAA, let pso = fxaaPipeline {
                    var p = Vec4(1, 0, 0, 0)
                    enc.setRenderPipelineState(pso)
                    enc.setFragmentTexture(ldr, index: 0)
                    enc.setFragmentBytes(&p, length: MemoryLayout<Vec4>.stride, index: 0)
                    enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
                } else if let pso = compositeDrawablePipeline {
                    enc.setRenderPipelineState(pso)
                    enc.setFragmentTexture(hdr, index: 0)
                    enc.setFragmentTexture(bloomTex, index: 1)
                    enc.setFragmentTexture(distort, index: 2)
                    enc.setFragmentBytes(&cpar, length: MemoryLayout<CompositeParams>.stride, index: 0)
                    enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
                }
                enc.endEncoding()
            }
            cb.present(drawable)
        }
        cb.commit()
        frameIndex += 1
    }

    // MARK: drawing helpers

    /// Half-res temporal resolve: `current` (this frame's jittered march) + reprojected `history` → `out`.
    @discardableResult
    private func resolveTemporal(_ cb: MTLCommandBuffer, fu: inout FrameUniforms, params: inout TemporalParams,
                                 current: MTLTexture, history: MTLTexture, out: MTLTexture, pso: MTLRenderPipelineState) -> Bool {
        let rp = MTLRenderPassDescriptor()
        rp.colorAttachments[0].texture = out
        rp.colorAttachments[0].loadAction = .dontCare
        rp.colorAttachments[0].storeAction = .store
        guard let enc = cb.makeRenderCommandEncoder(descriptor: rp) else { return false }
        enc.setRenderPipelineState(pso)
        enc.setFragmentBytes(&fu, length: MemoryLayout<FrameUniforms>.stride, index: 1)
        enc.setFragmentBytes(&params, length: MemoryLayout<TemporalParams>.stride, index: 0)
        enc.setFragmentTexture(current, index: 0)
        enc.setFragmentTexture(history, index: 1)
        enc.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        enc.endEncoding()
        return true
    }

    private func drawMesh(_ enc: MTLRenderCommandEncoder, _ m: GPUMesh, model: float4x4, highlight: Float = 0, ghost: Bool = false,
                          wallTemp: Float = 293, materialOverride: Material? = nil, combustion: Float = 0,
                          extraZW: SIMD2<Float> = .zero) {
        let mat = materialOverride ?? m.material
        var du = DrawUniforms()
        du.model = model
        du.normalMatrix = model.upperLeftNormalMatrix
        du.baseColor = Vec4(mat.baseColor, 1)
        du.params = Vec4(mat.metallic, mat.roughness, mat.kind.rawValue, highlight)
        du.emissive = Vec4(mat.emissive, wallTemp)
        du.extra = Vec4(ghost ? 1 : 0, combustion, extraZW.x, extraZW.y)
        enc.setVertexBuffer(m.vertexBuffer, offset: 0, index: 0)
        enc.setVertexBytes(&du, length: MemoryLayout<DrawUniforms>.stride, index: 2)
        enc.setFragmentBytes(&du, length: MemoryLayout<DrawUniforms>.stride, index: 2)
        enc.drawIndexedPrimitives(type: .triangle, indexCount: m.indexCount, indexType: .uint32, indexBuffer: m.indexBuffer, indexBufferOffset: 0)
    }

    private func drawScene(_ enc: MTLRenderCommandEncoder, fs: FrameState, shadowPass: Bool) {
        let rel = float4x4(translation: -fs.cameraWorld.float)
        for m in (fs.outdoor ? siteMeshes : hangarMeshes) where (!shadowPass || m.castsShadow) {
            drawMesh(enc, m, model: rel)
        }
        if let vm = fs.vehicleModel {
            if fs.orbitalVehicle {
                // Orbital stack: stage 2 always rides the vehicle; stage 1 rides the
                // vehicle while attached, the booster model after separation.
                for (m, twoSided, frosted) in orbitalS2Meshes {
                    if twoSided && !shadowPass { enc.setCullMode(.none) }
                    drawMesh(enc, m, model: vm, extraZW: frosted ? SIMD2<Float>(1, fs.vehicleFrost) : .zero)
                    if twoSided && !shadowPass { enc.setCullMode(.back) }
                }
                let s1Model = fs.orbitalStage == 1 ? vm : fs.boosterModel
                if let s1 = s1Model {
                    for (m, twoSided, frosted) in orbitalS1Meshes {
                        if twoSided && !shadowPass { enc.setCullMode(.none) }
                        drawMesh(enc, m, model: s1, extraZW: frosted ? SIMD2<Float>(1, fs.vehicleFrost) : .zero)
                        if twoSided && !shadowPass { enc.setCullMode(.back) }
                    }
                }
            } else {
                for (m, twoSided, frosted) in tv1Meshes {
                    if twoSided && !shadowPass { enc.setCullMode(.none) }
                    drawMesh(enc, m, model: vm, extraZW: frosted ? SIMD2<Float>(1, fs.vehicleFrost) : .zero)
                    if twoSided && !shadowPass { enc.setCullMode(.back) }
                }
            }
        }
        if let fixed = fs.engineFixedModel, let gim = fs.engineGimbalModel {
            for (m, gimballed, inner) in engineMeshes {
                if inner && !shadowPass { enc.setCullMode(.none) }
                defer { if inner && !shadowPass { enc.setCullMode(.back) } }
                drawMesh(enc, m, model: gimballed ? gim : fixed, highlight: fs.engineHighlight, ghost: fs.engineGhost, wallTemp: fs.wallTemp,
                         combustion: Float(fs.plume.brightness) + Float(fs.plume.flash))
            }
        }
        // gimbal actuators: housing fixed to the stand, polished rod to the engine
        if let cyl = unitCylinder {
            for i in 0..<2 {
                guard let (a, b) = (i == 0 ? fs.actuator0 : fs.actuator1) else { continue }
                let d = b - a
                let len = simd_length(d)
                guard len > 0.01 else { continue }
                let dir = d / len
                let axis = simd_cross(Vec3(0, 1, 0), dir)
                let s = simd_length(axis)
                let rot = s > 1e-5 ? float4x4(rotationAxis: axis / s, angle: atan2f(s, simd_dot(Vec3(0, 1, 0), dir))) : matrix_identity_float4x4
                let housingLen: Float = 0.55
                let housing = float4x4(translation: a) * rot * float4x4(translation: Vec3(0, housingLen / 2, 0)) * float4x4(scaling: Vec3(0.05, housingLen, 0.05))
                let rod = float4x4(translation: a) * rot * float4x4(translation: Vec3(0, len / 2, 0)) * float4x4(scaling: Vec3(0.022, len, 0.022))
                drawMesh(enc, cyl, model: housing, materialOverride: .darkSteel)
                drawMesh(enc, cyl, model: rod, materialOverride: .polishedSteel)
                let eye = float4x4(translation: b) * rot * float4x4(scaling: Vec3(0.04, 0.06, 0.04))
                drawMesh(enc, cyl, model: eye, materialOverride: .darkSteel)
            }
        }
    }

    private func plumeUniforms(_ fs: FrameState, mode: Int, steps: Int, rjVis: Float, rich: Float) -> PlumeUniforms {
        let pl = fs.plume
        var u = PlumeUniforms()
        let re = RaptorMesh.exitRadius
        let gf = Float(pl.groundFactor)
        let zImp = gf > 0.02 ? Float(pl.impingementDistance) : 1e4
        let L = Float(pl.length)
        let spreadTan = tanf(clampf(Float(pl.boundaryAngle), 0.05, 1.15)) * 0.85
        u.exitPos = Vec4(fs.plumeExit, re)
        u.axis = Vec4(fs.plumeAxis, L)
        u.axisFar = Vec4(fs.plumeAxisFar, zImp)
        let reScale = re / max(fs.exitRadius, 0.01)
        u.shape = Vec4(rjVis, Float(pl.shockSpacing) * reScale, Float(pl.diamondStrength), spreadTan)
        u.look = Vec4(Float(pl.vacuumness), Float(pl.brightness), Float(pl.afterburn), Float(engine.sim?.engineRich ?? 0))
        u.anim = Vec4(Float(fs.time.truncatingRemainder(dividingBy: 1000)), Float(pl.flash), Float(steps), Float(mode))
        u.ground = Vec4(fs.impingement, gf)
        let h = SIMD2<Float>(fs.plumeAxis.x, fs.plumeAxis.z)
        let hl = simd_length(h)
        let hn = hl > 1e-4 ? h / hl : SIMD2<Float>(1, 0)
        u.ground2 = Vec4(Float(pl.wallJetRadius), Float(pl.wallJetSpeed) * 0.16, fs.shockRingAge, hl)
        u.ground3 = Vec4(hn.x, hn.y, Float(fs.cameraWorld.y), rich)
        let camY = Float(fs.cameraWorld.y)
        if mode == 0 {
            let reach = min(L, zImp + 1)
            var rmax = max(re, rjVis) * 4.0 + 0.2 * reach
            rmax = max(rmax, (re + reach * spreadTan) * Float(pl.vacuumness))
            rmax = min(rmax, 60)
            let a = fs.plumeExit - fs.plumeAxis * 1.7          // include the bell interior up to the throat
            let b = fs.plumeExit + fs.plumeAxis * reach
            var lo = simd_min(a, b) - Vec3(repeating: rmax)
            let hi = simd_max(a, b) + Vec3(repeating: rmax)
            lo.y = max(lo.y, -camY - 4.0)          // down into the TV-1 flame trench
            u.boundsMin = Vec4(lo, rmax)                       // w: bounding-cylinder radius around the axis
            u.boundsMax = Vec4(hi, 0)
        } else {
            let rw = max(Float(pl.wallJetRadius), 2) * 1.3
            let c = fs.impingement
            u.boundsMin = Vec4(c.x - rw, min(c.y - 0.5, -camY - 0.01), c.z - rw, 0)
            u.boundsMax = Vec4(c.x + rw, c.y + max(3.0, 0.40 * rw), c.z + rw, 0)
        }
        return u
    }

    static func matricesClose(_ a: float4x4, _ b: float4x4) -> Bool {
        var d: Float = 0
        for i in 0..<4 {
            let ca = a[i], cb = b[i]
            d = max(d, simd_reduce_max(simd_abs(ca - cb)))
        }
        return d < 1e-4
    }

    // MARK: quality

    /// Simple thermal tiers: fair → at most Medium, serious/critical → Low.
    private func updateThermalCap() {
        thermalCheck += 1
        guard thermalCheck % 30 == 1 else { return }
        let st = ProcessInfo.processInfo.thermalState
        var cap = QualityLevel.levels.count - 1
        var name = "OK"
        switch st {
        case .nominal: cap = QualityLevel.levels.count - 1; name = "OK"
        case .fair: cap = 1; name = "WARM"
        case .serious: cap = 0; name = "HOT"
        case .critical: cap = 0; name = "CRIT"
        @unknown default: cap = 1; name = "?"
        }
        thermalCap = cap
        if quality > cap {
            quality = cap
            lastQualityChange = CACurrentMediaTime()
            gpuTimes.removeAll()
        }
        // GPU time from the command buffer; when the driver reports none (simulator, or a frame whose handler
        // carried no timestamps) show the measured frame interval instead of "0.0 MS"
        lock.lock(); var gms = gpuTimeLatest * 1000; lock.unlock()
        if gms < 0.05 { gms = frameMsAvg }
        DispatchQueue.main.async { [weak self] in
            guard let ui = self?.engine.ui else { return }
            if ui.thermalName != name { ui.thermalName = name }
            if abs(ui.gpuMs - gms) > 0.3 { ui.gpuMs = gms }
        }
    }

    private func adaptQuality() {
        lock.lock(); let t = gpuTimeLatest; lock.unlock()
        guard t > 0, !isSimulator else { return }
        gpuTimes.append(t)
        if gpuTimes.count > 45 { gpuTimes.removeFirst(gpuTimes.count - 45) }
        guard gpuTimes.count >= 45 else { return }
        let avg = gpuTimes.reduce(0, +) / Double(gpuTimes.count)
        let now = CACurrentMediaTime()
        if avg > 0.0135 && quality > 0 && now - lastQualityChange > 1.5 {
            quality -= 1
            lastQualityChange = now
            gpuTimes.removeAll()
            goodSince = now
        } else if avg < 0.0080 && quality < min(QualityLevel.levels.count - 1, thermalCap) {
            if goodSince == 0 { goodSince = now }
            if now - goodSince > 6 && now - lastQualityChange > 10 {
                quality += 1
                lastQualityChange = now
                gpuTimes.removeAll()
                goodSince = now
            }
        } else {
            goodSince = now
        }
    }
}
