#include "ShaderCommon.h"

// South-Texas scrub: honey mesquite (wide, flat, airy, olive / grey-green) and live-oak mottes (dense, rounded,
// dark green) scattered in clumps around the sites. No instance buffer: like the grass, every instance id maps
// to a cell of a camera-centred grid snapped to WORLD cells (trees never swim), and a hash of the world cell
// decides presence, species, size, yaw. Two LODs:
//   near  instanced TreeMesh (stems + lumpy canopy), wind sway, shrinks out between lod.x and lod.y
//   far   camera-facing impostor quad with a procedural canopy silhouette (alpha-to-coverage), grows in
//         over the same band, out to the grid edge
// Trees are kept back from the stand apron, the TV-1 pad + flame trench and the landing zone.

struct TreeParams {
    float4 grid;   // xy grid centre (world xz, snapped to cells), z cell size (m), w cells per side
    float4 misc;   // x time, y wind x, z wind z, w density 0..1
    float4 lod;    // x near-LOD fade start (m), y near-LOD end / impostor fully in (m), z far fade end (m), w mode (0 near, 1 far)
};

struct TreeInst {
    float2 root;
    float scale;
    float yaw;
    float oak;       // 0 mesquite … 1 live oak
    float seed;
    bool valid;
};

inline bool treeExcluded(float2 p) {
    if (length(p) < 85.0) return true;                                                        // test stand + apron
    if (p.x > -470.0 && p.x < -330.0 && abs(p.y) < 55.0) return true;                         // TV-1 pad + trench
    if (length(p - float2(-400.0, -300.0)) < 48.0) return true;                               // landing zone
    if (abs(p.x + 400.0) < 9.0 && p.y < 0.0 && p.y > -300.0) return true;                     // pad → LZ crawler path
    return false;
}

inline TreeInst treeInstance(uint iid, constant TreeParams& g) {
    TreeInst t;
    int n = int(g.grid.w);
    float cell = g.grid.z;
    int ix = int(iid) % n, iz = int(iid) / n;
    float2 cellPos = g.grid.xy + (float2(float(ix), float(iz)) - float(n) * 0.5) * cell;
    float2 cellId = floor(cellPos / cell + 0.5);
    float r1 = hash21(cellId * 1.31 + 3.7), r2 = hash21(cellId * 0.71 + 11.3), r3 = hash21(cellId + 29.1), r4 = hash21(cellId + 57.9);
    // clumped: mottes / thickets with open grass between (two noise scales)
    float clump = vnoise2(cellId * cell * 0.011) * 0.7 + vnoise2(cellId * cell * 0.043 + 7.0) * 0.3;
    float p = g.misc.w * smoothstep(0.38, 0.72, clump);
    t.root = cellId * cell + (float2(r1, r2) - 0.5) * cell * 0.8;
    t.valid = r3 < p && !treeExcluded(t.root);
    t.oak = smoothstep(0.6, 0.75, clump) * step(0.45, r4);          // oaks in the dense heart of a motte
    t.scale = mix(0.65, 1.25, r4) * mix(1.0, 1.15, t.oak);
    t.yaw = r1 * 6.2831853;
    t.seed = r2;
    return t;
}

struct TreeOut {
    float4 position [[position]];
    float3 worldPos;           // camera-relative
    float3 normal;
    float3 color;
    float ao;
    float2 quad;               // impostor: quad coordinates (-1…1, 0…1); near: unused
    float leaf;                // 1 canopy, 0 wood
    float4 shadowPos;
};

inline float3 leafColor(float oak, float v) {
    float3 mesq = mix(float3(0.30, 0.34, 0.17), float3(0.40, 0.42, 0.25), v);   // olive / grey-green, sun-bleached
    float3 live = mix(float3(0.13, 0.20, 0.09), float3(0.19, 0.26, 0.12), v);   // dark live-oak green
    return mix(mesq, live, oak);
}

vertex TreeOut treeVertex(VertexIn in [[stage_in]], uint iid [[instance_id]],
                          constant FrameUniforms& f [[buffer(1)]],
                          constant TreeParams& g [[buffer(2)]]) {
    TreeOut o;
    TreeInst t = treeInstance(iid, g);
    float dist = length(t.root - f.cameraWorld.xz);
    float lodK = 1.0 - smoothstep(g.lod.x, g.lod.y, dist);
    if (!t.valid || lodK < 0.01) {
        o.position = float4(0.0, 0.0, -2.0, 1.0);
        o.worldPos = float3(0.0); o.normal = float3(0.0, 1.0, 0.0); o.color = float3(0.0); o.ao = 1.0;
        o.quad = float2(0.0); o.leaf = 0.0; o.shadowPos = float4(0.0);
        return o;
    }
    float3 p = in.position.xyz;
    float3 nrm = in.normal.xyz;
    bool canopy = in.uv.y > 0.5;
    if (canopy) {
        // mesquite: wide, flat, open crown; live oak: rounder and denser, lower
        float3 cs = mix(float3(1.35, 0.62, 1.35), float3(1.15, 0.9, 1.15), t.oak);
        float3 c0 = float3(0.0, 4.0, 0.0);
        p = c0 + (p - c0) * cs;
        p.y -= t.oak * 0.5;
        nrm = normalize(nrm / cs);
    }
    // yaw + size (+ the LOD shrink)
    float cy = cos(t.yaw), sy = sin(t.yaw);
    p = float3(p.x * cy - p.z * sy, p.y, p.x * sy + p.z * cy) * t.scale * lodK;
    nrm = float3(nrm.x * cy - nrm.z * sy, nrm.y, nrm.x * sy + nrm.z * cy);
    // wind sway: whole crown leans with the gusts, leaves flutter
    float time = g.misc.x;
    float2 wind = g.misc.yz;
    float gust = 0.55 + 0.45 * sin(dot(t.root, float2(0.05, 0.031)) - time * 0.9) + 0.2 * sin(time * 2.3 + t.seed * 20.0);
    float sw = in.uv.x;
    float2 lean = wind * 0.035 * gust * sw * t.scale * 6.0 / (1.0 + t.oak);
    float flutter = canopy ? 0.06 * sin(time * 7.0 + dot(p.xz, float2(1.3, 0.7)) + t.seed * 30.0) * sw : 0.0;
    p.xz += lean + flutter;
    float3 wp = float3(t.root.x + p.x, p.y, t.root.y + p.z);
    float3 rel = wp - f.cameraWorld.xyz;
    o.position = f.viewProj * float4(rel, 1.0);
    o.worldPos = rel;
    o.normal = nrm;
    o.color = canopy ? leafColor(t.oak, in.uv.z * 0.7 + t.seed * 0.3) : mix(float3(0.22, 0.19, 0.16), float3(0.16, 0.14, 0.12), t.oak);
    o.ao = in.position.w;
    o.quad = float2(0.0);
    o.leaf = canopy ? 1.0 : 0.0;
    o.shadowPos = f.lightViewProj * float4(rel, 1.0);
    return o;
}

// Far impostor: cylindrical billboard (stays upright), 4 vertices per instance.
vertex TreeOut treeImpostorVertex(uint vid [[vertex_id]], uint iid [[instance_id]],
                                  constant FrameUniforms& f [[buffer(1)]],
                                  constant TreeParams& g [[buffer(2)]]) {
    TreeOut o;
    TreeInst t = treeInstance(iid, g);
    float dist = length(t.root - f.cameraWorld.xz);
    float k = smoothstep(g.lod.x, g.lod.y, dist) * (1.0 - smoothstep(g.lod.z * 0.85, g.lod.z, dist));
    if (!t.valid || k < 0.01) {
        o.position = float4(0.0, 0.0, -2.0, 1.0);
        o.worldPos = float3(0.0); o.normal = float3(0.0, 1.0, 0.0); o.color = float3(0.0); o.ao = 1.0;
        o.quad = float2(0.0); o.leaf = 0.0; o.shadowPos = float4(0.0);
        return o;
    }
    float2 c = float2(float(vid & 1u), float((vid >> 1u) & 1u));      // 0..1
    float w = mix(8.6, 7.4, t.oak) * t.scale * k;
    float h = mix(6.0, 5.8, t.oak) * t.scale * k;
    float3 toCam = f.cameraWorld.xyz - float3(t.root.x, 0.0, t.root.y);
    float2 side = normalize(float2(toCam.z, -toCam.x) + float2(1e-4, 0.0));
    float3 wp = float3(t.root.x, 0.0, t.root.y) + float3(side.x, 0.0, side.y) * (c.x - 0.5) * w + float3(0.0, c.y * h - 0.15, 0.0);
    float3 rel = wp - f.cameraWorld.xyz;
    o.position = f.viewProj * float4(rel, 1.0);
    o.worldPos = rel;
    o.normal = normalize(float3(toCam.x, 0.0, toCam.z) + float3(0.0, 1e-3, 0.0));
    o.color = leafColor(t.oak, t.seed);
    o.ao = 1.0;
    o.quad = float2(c.x * 2.0 - 1.0, c.y);
    o.leaf = 2.0 + t.oak + floor(t.seed * 64.0) * 4.0;            // impostor marker + species + a stable seed
    o.shadowPos = float4(0.0);
    return o;
}

inline float3 treeLight(float3 albedo, float3 N, float3 V, float3 pos, float ao, float sh, float leaf, constant FrameUniforms& f,
                        texturecube<float> envMap) {
    constexpr sampler envS(filter::linear, mip_filter::linear);
    float3 L = normalize(f.lightDir.xyz);
    float ndl = clamp((dot(N, L) + 0.4) / 1.4, 0.0, 1.0);                  // wrapped: foliage scatters
    float trans = leaf > 0.5 ? pow(max(dot(-V, L), 0.0), 4.0) * 0.45 : 0.0;
    float3 sun = f.lightColor.rgb * f.lightDir.w * (ndl + trans) * sh;
    float mips = max(f.misc.y - 1.0, 1.0);
    float3 irr = envMap.sample(envS, N, level(mips)).rgb;
    float3 col = albedo * (sun / M_PI_F + irr * f.sky.w) * ao;
    // flame light from the plume
    for (int li = 0; li < 2; li++) {
        float4 pl = li == 0 ? f.plumeLight0 : f.plumeLight1;
        float3 pc = li == 0 ? f.plumeLight0Color.rgb : f.plumeLight1Color.rgb;
        if (pl.w <= 0.0) continue;
        float3 Lv = pl.xyz - pos;
        float d2 = max(dot(Lv, Lv), 1.0);
        col += albedo * pc * (pl.w / d2) * 0.5 / M_PI_F;
    }
    return col;
}

inline float3 treeFog(float3 col, float3 worldPos, constant FrameUniforms& f) {
    float dist = length(worldPos);
    float fogO = 1.0 - exp(-dist * 0.0015);
    float3 hz = skyRadiance(normalize(float3(worldPos.x, 0.0, worldPos.z) + float3(0.0, 0.03, 0.0)), f.sky.x, f.sky.y, f.sky.z);
    return mix(col, hz, fogO * 0.7);
}

fragment float4 treeFragment(TreeOut in [[stage_in]],
                             constant FrameUniforms& f [[buffer(1)]],
                             depth2d<float> shadowMap [[texture(0)]],
                             texturecube<float> envMap [[texture(1)]]) {
    constexpr sampler cmp(coord::normalized, filter::linear, address::clamp_to_edge, compare_func::less_equal);
    float3 V = normalize(-in.worldPos + float3(0.0, 1e-4, 0.0));
    float3 N = normalize(in.normal + float3(0.0, 1e-4, 0.0));
    if (dot(N, V) < 0.0) N = -N;                                         // two-sided
    float3 sp = in.shadowPos.xyz / max(in.shadowPos.w, 1e-4);
    float2 suv = float2(sp.x * 0.5 + 0.5, 0.5 - sp.y * 0.5);
    float sh = 1.0;
    if (suv.x > 0.0 && suv.x < 1.0 && suv.y > 0.0 && suv.y < 1.0 && sp.z < 1.0) sh = shadowMap.sample_compare(cmp, suv, sp.z - 0.002);
    // leaf-cluster variation (world-space, stable): clumps of lighter / darker foliage
    float3 albedo = in.color;
    if (in.leaf > 0.5) {
        float3 wpW = in.worldPos + f.cameraWorld.xyz;
        float v = vnoise2(wpW.xz * 1.7 + wpW.y * 0.9) * 0.6 + vnoise2(wpW.xz * 5.3 - wpW.y * 2.1) * 0.4;
        albedo *= 0.75 + 0.5 * v;
    }
    float3 col = treeLight(albedo, N, V, in.worldPos, in.ao, sh, in.leaf, f, envMap);
    return float4(treeFog(col, in.worldPos, f), 1.0);
}

// Impostor silhouette: irregular crown (blob + noise edge) on a short dark trunk; alpha-to-coverage edge.
fragment float4 treeImpostorFragment(TreeOut in [[stage_in]],
                                     constant FrameUniforms& f [[buffer(1)]],
                                     texturecube<float> envMap [[texture(1)]]) {
    float oak = fract(in.leaf * 0.25) * 4.0 - 2.0;            // decode species (0…1)
    oak = clamp(oak, 0.0, 1.0);
    float seed = floor(in.leaf * 0.25) / 64.0;
    float2 q = in.quad;                                        // x −1…1 across, y 0…1 up
    float crownY = mix(0.62, 0.58, oak);
    float2 cq = float2(q.x / mix(0.98, 0.92, oak), (q.y - crownY) / mix(0.36, 0.42, oak));
    float edge = vnoise2(float2(atan2(cq.y, cq.x) * 2.2 + seed * 40.0, seed * 13.0)) * 0.35 + vnoise2(q * 9.0 + seed * 21.0) * 0.18;
    float crown = 1.0 - length(cq) + edge - 0.18;
    float trunk = (abs(q.x) < 0.06 && q.y < crownY) ? 1.0 : 0.0;
    float cov = max(smoothstep(-0.04, 0.04, crown), trunk);
    if (cov < 0.02) discard_fragment();
    float3 V = normalize(-in.worldPos + float3(0.0, 1e-4, 0.0));
    // fake crown normal from the silhouette (lit top, darker underside)
    float3 side = normalize(float3(in.normal.z, 0.0, -in.normal.x) + float3(1e-4, 0.0, 0.0));
    float3 N = normalize(in.normal * 0.6 + side * cq.x * 0.5 + float3(0.0, 1.0, 0.0) * (0.35 + 0.6 * cq.y));
    float3 albedo = trunk > 0.5 && crown < 0.0 ? float3(0.2, 0.17, 0.14) : in.color * (0.8 + 0.4 * vnoise2(q * 6.0 + seed * 9.0));
    float ao = 0.55 + 0.45 * clamp(cq.y * 0.5 + 0.6, 0.0, 1.0);
    float3 col = treeLight(albedo, N, V, in.worldPos, ao, 1.0, 1.0, f, envMap);
    return float4(treeFog(col, in.worldPos, f), cov);
}
