#include "ShaderCommon.h"

// Volumetric clouds at real altitudes, adapted from Ren's Glass Weather sky (branch glass-weather,
// Sky/Shaders.metal: Nubis-style slab, Perlin-Worley base shape eroded by Worley detail, Beer–Lambert with a
// multiple-scattering floor, dual-lobe Henyey–Greenstein, powder) — but in world space around the camera,
// so the camera can sit under, inside or above the layers (TV-1 climbs to 10 km):
//   cumulus      base 1.5 km, tops 2.2–3 km (height-shaped towers)
//   altocumulus  4.2–5.0 km, thin patchy layer
//   cirrus       sheet at 9 km (2-D fibrous)
// Drawn at half resolution with a per-frame low-discrepancy march jitter, then accumulated over frames by the
// reprojecting temporal resolve (Post.metal), limited by the scene depth, composited before the plume.

struct CloudParams {
    float4 p;      // x coverage 0..1, y time (s), z steps, w light steps
    float4 q;      // x history blend 0..1, y wind drift x (m), z wind drift z (m), w unused
};

constexpr sampler kCloudS(filter::linear, address::repeat);

inline float hgPhase(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(max(1.0 + g2 - 2.0 * g * c, 1e-4), 1.5);
}

// Density of one slab at world point p. kind 0 cumulus, 1 altocumulus.
inline float slabDensity(float3 p, int kind, float cover, float2 drift,
                         texture3d<float> bt, texture3d<float> dt, bool full) {
    float hb = kind == 0 ? 1500.0 : 4200.0;
    float ht = kind == 0 ? 2900.0 : 5000.0;
    float h = (p.y - hb) / (ht - hb);
    if (h <= 0.0 || h >= 1.0) return 0.0;
    // cumulus: flat base, rounded narrowing top; alto: thin layer
    float g = kind == 0 ? smoothstep(0.0, 0.07, h) * smoothstep(1.0, 0.35, h)
                        : smoothstep(0.0, 0.25, h) * smoothstep(1.0, 0.6, h);
    float3 q = p + float3(drift.x, 0.0, drift.y) * (kind == 0 ? 1.0 : 1.6);
    float sH = kind == 0 ? 1.0 / 9000.0 : 1.0 / 5000.0;
    float4 n = bt.sample(kCloudS, float3(q.x * sH, q.y * (kind == 0 ? 1.0 / 6000.0 : 1.0 / 2500.0), q.z * sH));
    float lowF = n.g;
    float base = (n.r + 1.0 - lowF) / (2.0 - lowF);
    base = clamp((base - 0.70) * (1.0 / 0.24), 0.0, 1.0);
    float cov = kind == 0 ? cover : cover * 0.7;
    float d = clamp((base * g - (1.0 - cov)) / max(cov, 0.05), 0.0, 1.0) * cov;
    if (!full || d <= 0.0) return d;
    float dn = dt.sample(kCloudS, q * (kind == 0 ? 1.0 / 900.0 : 1.0 / 600.0)).r;
    float hf = mix(dn, 1.0 - dn, clamp(h * 5.0, 0.0, 1.0));
    float er = hf * (kind == 0 ? 0.36 : 0.45);
    return clamp((d - er) / (1.0 - er), 0.0, 1.0);
}

// Ray segment [t0, t1] inside the horizontal slab hb…ht, for a ray from height y0 with direction dy.
inline bool slabRange(float y0, float dy, float hb, float ht, float tMax, thread float& t0, thread float& t1) {
    if (abs(dy) < 1e-4) {
        if (y0 < hb || y0 > ht) return false;
        t0 = 0.0; t1 = tMax; return true;
    }
    float a = (hb - y0) / dy, b = (ht - y0) / dy;
    t0 = max(min(a, b), 0.0);
    t1 = min(max(a, b), tMax);
    return t1 > t0;
}

fragment float4 cloudFragment(FSQOut in [[stage_in]],
                              constant FrameUniforms& f [[buffer(1)]],
                              constant CloudParams& c [[buffer(0)]],
                              depth2d<float> depth [[texture(0)]],
                              texture3d<float> bt [[texture(1)]],
                              texture3d<float> dt [[texture(2)]],
                              texture2d<float> hist [[texture(3)]]) {
    float2 uv = in.uv;
    float4 wv = f.invViewProj * float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, 1.0, 1.0);
    float3 rd = normalize(wv.xyz / wv.w);
    float3 cam = f.cameraWorld.xyz;
    float cover = c.p.x;
    if (cover < 0.01 || f.scene.x < 0.5) return float4(0.0);

    // scene depth limit (clouds never cover the stand / vehicle in front of them)
    uint2 px = uint2(in.position.xy * 2.0);
    px = min(px, uint2(depth.get_width() - 1, depth.get_height() - 1));
    float dz = depth.read(px);
    float tScene = 1e9;
    if (dz < 1.0) {
        float4 w = f.invViewProj * float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, dz, 1.0);
        tScene = length(w.xyz / w.w);
    }
    float tMax = min(60000.0, tScene);

    float3 Ld = normalize(f.lightDir.xyz);
    float3 sunL = f.lightColor.rgb * f.lightDir.w * 0.55;
    float cosT = dot(rd, Ld);
    float ph = min(0.72 * hgPhase(cosT, 0.6) + 0.28 * hgPhase(cosT, -0.25), 3.0);
    float3 skyUp = skyRadiance(float3(0.0, 1.0, 0.0), f.sky.x, f.sky.y, f.sky.z);
    float3 skyHz = skyRadiance(normalize(float3(rd.x, 0.02, rd.z)), f.sky.x, f.sky.y, f.sky.z);
    float jit = marchJitter(in.position.xy, f.scene.y);
    float2 drift = c.q.yz;

    float3 Ls = float3(0.0);
    float T = 1.0;
    float tFirst = -1.0;
    int N = int(c.p.z);
    int NL = int(c.p.w);
    float sig = 0.0065;
    for (int k = 0; k < 2; k++) {
        float hb = k == 0 ? 1500.0 : 4200.0, ht = k == 0 ? 2900.0 : 5000.0;
        float t0, t1;
        if (!slabRange(cam.y, rd.y, hb, ht, tMax, t0, t1)) continue;
        t1 = min(t1, t0 + (k == 0 ? 22000.0 : 30000.0));
        int n = k == 0 ? N : max(N / 3, 6);
        float dtS = (t1 - t0) / float(n);
        for (int i = 0; i < 48; i++) {
            if (i >= n || T < 0.02) break;
            float tt = t0 + (float(i) + jit) * dtS;
            float3 p = cam + rd * tt;
            float dc = slabDensity(p, k, cover, drift, bt, dt, false);
            if (dc <= 0.001) continue;
            float d = slabDensity(p, k, cover, drift, bt, dt, true);
            if (d <= 0.001) continue;
            if (tFirst < 0.0) tFirst = tt;
            // short light march toward the sun
            float od = 0.0;
            float ls = (ht - hb) * 0.09;
            for (int j = 0; j < 4; j++) {
                if (j >= NL) break;
                od += slabDensity(p + Ld * (ls * (float(j) + 0.5)), k, cover, drift, bt, dt, false) * ls;
                ls *= 1.8;
            }
            float beer = exp(-od * sig);
            float ms = max(beer, exp(-od * sig * 0.3) * 0.4);
            float powder = 1.0 - exp(-d * 2.6);
            float hN = clamp((p.y - hb) / (ht - hb), 0.0, 1.0);
            float3 direct = sunL * ms * ph * mix(0.5, 1.0, powder);
            float3 amb = mix(skyHz * 0.55, skyUp * 0.95, hN);
            float st = exp(-d * sig * dtS);
            Ls += T * (direct + amb) * (1.0 - st);
            T *= st;
        }
    }
    // cirrus sheet at 9 km (2-D, fibrous, thin)
    if (rd.y * (9000.0 - cam.y) > 0.0) {
        float tc = (9000.0 - cam.y) / rd.y;
        if (tc < tMax && tc < 90000.0) {
            float2 pc = cam.xz + rd.xz * tc + drift * 1.4;
            float n1 = bt.sample(kCloudS, float3(pc.x * (1.0 / 60000.0), 0.41, pc.y * (1.0 / 9000.0))).g;
            float n2 = dt.sample(kCloudS, float3(pc.x * (1.0 / 14000.0), 0.73, pc.y * (1.0 / 1400.0))).r;
            float ci = smoothstep(0.42, 0.8, n1) * (0.45 + 0.55 * n2) * cover * 0.8;
            ci *= smoothstep(0.0, 0.06, abs(rd.y));
            float3 cc = sunL * 0.6 * min(ph, 3.0) + skyUp * 0.7;
            Ls += T * cc * ci;
            T *= 1.0 - ci;
            if (tFirst < 0.0) tFirst = tc;
        }
    }
    float a = 1.0 - T;
    float3 col = a > 1e-4 ? Ls / a : float3(0.0);
    // aerial perspective: far clouds melt into the horizon sky
    float hz = 1.0 - exp(-max(tFirst, 0.0) / 26000.0);
    col = mix(col, skyHz, clamp(hz * 0.85, 0.0, 0.9));
    a *= 1.0 - 0.3 * hz;
    float4 cur = float4(col * a, a);
    // temporal smoothing of the jittered march while the camera is still
    float hb = c.q.x;
    if (hb > 0.0) {
        float4 h = hist.read(uint2(in.position.xy));
        cur = mix(cur, h, hb);
    }
    return cur;
}

