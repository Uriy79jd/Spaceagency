#include "ShaderCommon.h"

// GPU-instanced dry Texas grass. No instance buffer: every instance id maps to a cell of a grid that is
// centred ahead of the camera (snapped to the cell size so blades never swim), jittered by a hash. Blades
// shrink to nothing toward the grid edge (LOD) and are culled on the concrete (stand apron + ploughed ring,
// TV-1 pad/trench, landing zone). Wind sway, plus the exhaust blast: blades within the wall-jet radius of
// the ImpingementSystem hit point bend outward and flatten, more the stronger the interaction.

struct GrassParams {
    float4 grid;       // xy grid centre (world xz), z cell size (m), w cells per side
    float4 blast;      // xy impingement point (world xz), z wall-jet radius (m), w ground factor 0..1
    float4 misc;       // x time, y wind x, z wind z, w blast y (height of the hit point)
};

struct GrassOut {
    float4 position [[position]];
    float3 worldPos;          // camera-relative
    float3 normal;
    float3 color;
    float ao;
    float4 shadowPos;
};

inline bool onConcrete(float2 p) {
    if (length(p) < 31.0) return true;                                            // stand apron + ploughed ring
    if (p.x > -421.0 && p.x < -369.0 && abs(p.y) < 21.0) return true;            // TV-1 pad + trench
    if (abs(p.x + 400.0) < 16.0 && abs(p.y + 300.0) < 16.0) return true;          // landing zone
    return false;
}

vertex GrassOut grassVertex(uint vid [[vertex_id]], uint iid [[instance_id]],
                            constant FrameUniforms& f [[buffer(1)]],
                            constant GrassParams& g [[buffer(2)]]) {
    GrassOut o;
    int n = int(g.grid.w);
    float cell = g.grid.z;
    int ix = int(iid) % n, iz = int(iid) / n;
    float2 cellPos = g.grid.xy + (float2(float(ix), float(iz)) - float(n) * 0.5) * cell;
    float2 cellId = floor(cellPos / cell + 0.5);
    float r1 = hash21(cellId), r2 = hash21(cellId + 17.3), r3 = hash21(cellId + 41.7), r4 = hash21(cellId + 73.1);
    float2 root = cellPos + (float2(r1, r2) - 0.5) * cell;
    // LOD: blades shrink to nothing toward the edge of the patch; culled on concrete
    float2 cam = f.cameraWorld.xz;
    float dist = length(root - cam);
    float halfExt = float(n) * cell * 0.5;
    float lod = 1.0 - smoothstep(halfExt * 0.55, halfExt * 0.95, length(root - g.grid.xy));
    lod *= 1.0 - smoothstep(0.0, 1.0, (dist - halfExt) / 10.0);
    // patchiness (bare spots, taller clumps)
    float clump = vnoise2(root * 0.25);
    float height = (0.28 + 0.55 * r3) * (0.5 + 0.9 * clump) * lod;
    if (onConcrete(root) || height < 0.02) {
        o.position = float4(0.0, 0.0, -2.0, 1.0);          // degenerate, clipped
        o.worldPos = float3(0.0); o.normal = float3(0.0, 1.0, 0.0); o.color = float3(0.0); o.ao = 1.0; o.shadowPos = float4(0.0);
        return o;
    }
    // blade: 7-vertex strip, 3 segments + tip
    uint seg = vid / 2;                 // 0..3
    float side = (vid & 1u) == 0u ? -1.0 : 1.0;
    float t = min(float(seg) / 3.0, 1.0);
    float width = (0.018 + 0.02 * r4) * (1.0 - t * 0.85) * (1.0 + 1.5 * smoothstep(8.0, 30.0, dist));   // wider far away (fills)
    if (seg >= 3) width = 0.0;
    float yaw = r4 * 6.2831853;
    float2 face = float2(cos(yaw), sin(yaw));
    float2 across = float2(-face.y, face.x);
    // wind sway (gusting, travelling across the field)
    float time = g.misc.x;
    float2 wind = g.misc.yz;
    float gust = 0.6 + 0.4 * sin(dot(root, float2(0.11, 0.07)) - time * 1.7) + 0.25 * sin(root.x * 0.9 + time * 3.1 + r1 * 6.0);
    float2 bendDir = wind * 0.08 * gust + face * (0.12 + 0.1 * r2);
    // exhaust blast: radial outward bend + flattening within the wall-jet reach
    float2 rel = root - g.blast.xy;
    float rr = max(length(rel), 0.01);
    float reach = max(g.blast.z, 1.0) * 1.6;
    float blast = g.blast.w * (1.0 - smoothstep(reach * 0.25, reach, rr)) * step(abs(g.blast.w), 1.0);
    blast *= 1.0 - smoothstep(25.0, 70.0, g.misc.w);       // only when the hit point is near the ground
    float flutter = 0.75 + 0.25 * sin(time * 23.0 + r1 * 40.0);
    bendDir += rel / rr * blast * 2.4 * flutter;
    float bend = clamp(length(bendDir), 0.0, 1.45);
    float2 bdir = length(bendDir) > 1e-4 ? bendDir / length(bendDir) : face;
    // curved blade: horizontal offset grows ~t², height drops as it bends over
    float ang = bend * t * 1.1;
    float2 off = bdir * height * sin(ang) * t;
    float y = height * t * cos(ang) * (1.0 - 0.55 * blast * t);
    float3 wp = float3(root.x + off.x + across.x * width * side, y, root.y + off.y + across.y * width * side);
    float3 rel3 = wp - f.cameraWorld.xyz;
    o.position = f.viewProj * float4(rel3, 1.0);
    o.worldPos = rel3;
    float3 nrm = normalize(float3(face.x, 0.4 + 0.6 * t, face.y) + float3(bdir.x, 0.0, bdir.y) * 0.3);
    o.normal = nrm;
    // dry Texas grass: straw / khaki with greener clumps and dark bases; scorched near the blast
    float3 straw = mix(float3(0.62, 0.53, 0.30), float3(0.47, 0.45, 0.24), r2);
    float3 green = float3(0.30, 0.36, 0.14);
    float3 col = mix(straw, green, smoothstep(0.45, 0.85, clump) * 0.7);
    col *= 0.75 + 0.35 * r3;
    float scorch = f.pad.w * (1.0 - smoothstep(4.0, 16.0, length(root - f.pad.xy)));
    col = mix(col, float3(0.08, 0.07, 0.05), clamp(scorch, 0.0, 0.8));
    o.color = col;
    o.ao = 0.45 + 0.55 * t;
    o.shadowPos = f.lightViewProj * float4(rel3, 1.0);
    return o;
}

fragment float4 grassFragment(GrassOut in [[stage_in]],
                              constant FrameUniforms& f [[buffer(1)]],
                              depth2d<float> shadowMap [[texture(0)]],
                              texturecube<float> envMap [[texture(1)]]) {
    // Build 180 rendered the grass near-black: the two-sided flip (front_facing) pointed the normal of every
    // blade seen from its "back" downward/away from the sun, near-vertical blades got almost no N·L, and the
    // only ambient was 0.35 × the zenith sky (no image-based irradiance like the PBR ground) → ~10× darker
    // than the ground around it. Now: canopy normal facing the viewer, wrapped diffuse + translucency,
    // env-map irradiance (same as the ground) and a ground-bounce term.
    constexpr sampler cmp(coord::normalized, filter::linear, address::clamp_to_edge, compare_func::less_equal);
    constexpr sampler envS(filter::linear, mip_filter::linear);
    float3 V = normalize(-in.worldPos + float3(0.0, 1e-4, 0.0));
    float3 N = normalize(in.normal + float3(0.0, 1e-4, 0.0));
    if (dot(N, V) < 0.0) N = normalize(float3(-N.x, N.y, -N.z));     // face the viewer, keep it pointing up
    N = normalize(mix(N, float3(0.0, 1.0, 0.0), 0.45));                  // grass canopy: half-way to the ground normal
    float3 L = normalize(f.lightDir.xyz);
    // one-tap shadow (bilinear compare)
    float3 sp = in.shadowPos.xyz / max(in.shadowPos.w, 1e-4);
    float2 suv = float2(sp.x * 0.5 + 0.5, 0.5 - sp.y * 0.5);
    float sh = 1.0;
    if (suv.x > 0.0 && suv.x < 1.0 && suv.y > 0.0 && suv.y < 1.0 && sp.z < 1.0) sh = shadowMap.sample_compare(cmp, suv, sp.z - 0.002);
    float ndl = clamp((dot(N, L) + 0.35) / 1.35, 0.0, 1.0);               // wrapped diffuse
    float trans = pow(max(dot(-V, L), 0.0), 3.0) * 0.5;                   // light through thin blades
    float3 sun = f.lightColor.rgb * f.lightDir.w * (ndl + trans) * sh;
    float mips = max(f.misc.y - 1.0, 1.0);
    float3 irr = envMap.sample(envS, N, level(mips)).rgb;
    float3 bounce = float3(0.42, 0.36, 0.25) * f.lightColor.rgb * f.lightDir.w * max(L.y, 0.0) * 0.18;   // sunlit dry ground
    float ao = 0.6 + 0.4 * in.ao;
    float3 col = in.color * (sun / M_PI_F + (irr + bounce) * f.sky.w) * ao;
    // flame light from the plume
    for (int li = 0; li < 2; li++) {
        float4 pl = li == 0 ? f.plumeLight0 : f.plumeLight1;
        float3 pc = li == 0 ? f.plumeLight0Color.rgb : f.plumeLight1Color.rgb;
        if (pl.w <= 0.0) continue;
        float3 Lv = pl.xyz - in.worldPos;
        float d2 = max(dot(Lv, Lv), 0.25);
        col += in.color * pc * (pl.w / d2) * (0.4 + 0.6 * abs(dot(N, Lv * rsqrt(d2)))) / M_PI_F;
    }
    // aerial perspective as on the PBR ground
    float dist = length(in.worldPos);
    float fogO = 1.0 - exp(-dist * 0.0015);
    float3 hz = skyRadiance(normalize(float3(in.worldPos.x, 0.0, in.worldPos.z) + float3(0.0, 0.03, 0.0)), f.sky.x, f.sky.y, f.sky.z);
    col = mix(col, hz, fogO * 0.7);
    return float4(col, 1.0);
}
