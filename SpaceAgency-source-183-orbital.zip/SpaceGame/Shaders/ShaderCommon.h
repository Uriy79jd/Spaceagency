#pragma once
#include <metal_stdlib>
using namespace metal;

// Layouts must match the Swift structs in Renderer/ShaderTypes.swift.

struct FrameUniforms {
    float4x4 viewProj;
    float4x4 invViewProj;
    float4x4 view;
    float4x4 proj;
    float4x4 lightViewProj;
    float4 cameraWorld;      // xyz camera world position
    float4 lightDir;         // xyz toward light, w intensity
    float4 lightColor;
    float4 plumeLight0;      // xyz camera-relative, w intensity
    float4 plumeLight0Color;
    float4 plumeLight1;
    float4 plumeLight1Color;
    float4 sky;              // x altitude km, y vacuum, z time, w env intensity
    float4 screen;           // w, h, 1/w, 1/h
    float4 pad;              // xy pad heat centre (world xz), z pad temperature K, w scorch 0..1
    float4 pad2;             // x stagnation radius, y wall-jet radius, z ground factor, w shock ring age
    float4 misc;             // x shadow texel, y env mip count, z exposure, w quality level
    float4 scene;            // x outdoor (1) / hangar (0), y per-frame jitter offset (golden-ratio sequence), z,w unused
};

struct DrawUniforms {
    float4x4 model;
    float4x4 normalMatrix;
    float4 baseColor;
    float4 params;           // metallic, roughness, kind, highlight
    float4 emissive;         // rgb emissive, w nozzle wall temperature K
    float4 extra;            // x ghost, y thrust fraction
};

struct PlumeUniforms {
    float4 exitPos;          // xyz camera-relative, w exit radius
    float4 axis;             // xyz exhaust direction, w visible length
    float4 axisFar;          // xyz lagged far-field axis, w distance along axis to the pad
    float4 shape;            // jet radius, shock spacing, diamond strength, boundary spread tan
    float4 look;             // vacuumness, brightness, afterburn, core length
    float4 anim;             // time, flash, steps, mode (0 free jet, 1 ground interaction)
    float4 ground;           // xyz impingement point (camera-relative), w ground factor
    float4 ground2;          // wall-jet radius, visual wall-jet speed, shock ring age, tilt sin
    float4 ground3;          // xy horizontal axis dir (world xz), z cameraWorld.y, w fuel-rich start factor
    float4 boundsMin;        // camera-relative AABB of the proxy volume
    float4 boundsMax;
};

// GPU particle state (one slot of the fixed-size ring buffer). Mirrors GPUParticle in Engine/Particles.swift.
struct GPUParticle {
    float4 posLife;          // xyz world position (m), w lifetime (s); life <= 0 = dead slot
    float4 velAge;           // xyz velocity (m/s), w age (s)
    float4 params;           // x kind, y start size (m), z end size (m), w seed
};

// Spawn record: written by the CPU into a small per-frame buffer, copied into the ring by particleSpawn.
struct ParticleSpawn {
    GPUParticle p;
    uint4 slot;              // x ring slot index
};

// Flow field + collision parameters for the particle update kernel. Mirrors ParticleSimUniforms (Swift).
struct ParticleSimUniforms {
    float4 imp;              // xyz impingement point (world), w dt
    float4 jet;              // x stagnation radius, y wall-jet radius, z wall-jet speed (visual), w time
    float4 tilt;             // xy horizontal exhaust direction, z tilt sin, w ground factor
    float4 counts;           // x capacity, y spawn count, z engine-rich 0..1, w jet active 0..1
    float4 axis;             // xyz exhaust axis (world), w outdoor site (1) / hangar floor only (0)
    float4 exitPos;          // xyz nozzle exit (world), w unused
    float4 wind;             // xyz wind velocity (world, m/s) that drifting gas/steam relaxes toward
};

struct VertexIn {
    float4 position [[attribute(0)]];
    float4 normal   [[attribute(1)]];
    float4 uv       [[attribute(2)]];
};

struct FSQOut {
    float4 position [[position]];
    float2 uv;
};

// ---------- noise ----------
inline float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
inline float hash31(float3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}
inline float hash21(float2 p) {
    float3 p3 = fract(float3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
inline float vnoise3(float3 p) {
    float3 i = floor(p);
    float3 f = fract(p);
    float3 u = f * f * (3.0 - 2.0 * f);
    float n000 = hash31(i), n100 = hash31(i + float3(1,0,0));
    float n010 = hash31(i + float3(0,1,0)), n110 = hash31(i + float3(1,1,0));
    float n001 = hash31(i + float3(0,0,1)), n101 = hash31(i + float3(1,0,1));
    float n011 = hash31(i + float3(0,1,1)), n111 = hash31(i + float3(1,1,1));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}
inline float vnoise2(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + float2(1,0)), u.x), mix(hash21(i + float2(0,1)), hash21(i + float2(1,1)), u.x), u.y);
}
inline float fbm3(float3 p, int oct) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < oct; i++) { s += a * vnoise3(p); p = p * 2.03 + float3(1.7, 9.2, 3.1); a *= 0.5; }
    return s;
}
inline float fbm2(float2 p, int oct) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < oct; i++) { s += a * vnoise2(p); p = p * 2.03 + float2(1.7, 9.2); a *= 0.5; }
    return s;
}
inline float ign(float2 px) { return fract(52.9829189 * fract(dot(px, float2(0.06711056, 0.00583715)))); }
/// Ray-march start offset: interleaved gradient noise in space + a golden-ratio offset per frame, so every
/// pixel walks a low-discrepancy sequence over time and the temporal resolve averages it out (no static
/// dither pattern, no white-noise grain).
inline float marchJitter(float2 px, float frameOffset) { return fract(ign(px) + frameOffset); }

inline float luminance(float3 c) { return dot(c, float3(0.2126, 0.7152, 0.0722)); }

// Approximate blackbody colour (linear sRGB, normalised) for 1000–12000 K.
inline float3 blackbodyColor(float t) {
    t = clamp(t, 1000.0, 12000.0) / 100.0;
    float r, g, b;
    if (t <= 66.0) { r = 1.0; g = clamp(0.39008157 * log(t) - 0.63184144, 0.0, 1.0); }
    else { r = clamp(1.29293618 * pow(t - 60.0, -0.1332047592), 0.0, 1.0); g = clamp(1.12989086 * pow(t - 60.0, -0.0755148492), 0.0, 1.0); }
    if (t >= 66.0) b = 1.0; else if (t <= 19.0) b = 0.0; else b = clamp(0.54320678 * log(t - 10.0) - 1.19625408, 0.0, 1.0);
    float3 c = float3(r, g, b);
    return c * c; // to linear
}
// Visible radiance scale of a hot surface (Stefan–Boltzmann-ish, visible band dominated): 0 below ~750 K.
inline float glowIntensity(float tK) {
    float x = max(tK - 720.0, 0.0) / 600.0;
    return x * x * x * 2.5;
}

// Sky radiance seen from the given altitude (km). Sun fixed high in the sky.
inline float3 skyRadiance(float3 d, float altKm, float vacuum, float time) {
    float3 sunDir = normalize(float3(0.45, 0.62, 0.65));   // must match the key light in Renderer.swift
    float a = vacuum > 0.5 ? 200.0 : altKm;
    float thin = clamp(a / 60.0, 0.0, 1.0);
    float up = clamp(d.y, -1.0, 1.0);
    // hazy, pale grey-blue Texas sky at sea level; deep blue → black with altitude
    float3 zenith = mix(float3(0.34, 0.45, 0.62), float3(0.002, 0.003, 0.010), pow(thin, 0.6));
    float3 horizon = mix(float3(0.70, 0.74, 0.78), float3(0.05, 0.10, 0.25), pow(thin, 0.8));
    horizon = mix(horizon, float3(0.0), smoothstep(0.7, 1.0, thin) * 0.85);
    float h = pow(1.0 - max(up, 0.0), 4.0);
    float3 c = mix(zenith, horizon, h) * 2.2;
    if (up < 0.0) {
        float3 ground = mix(float3(0.26, 0.20, 0.15), float3(0.04, 0.07, 0.12), thin);
        c = mix(horizon * 2.2, ground, smoothstep(0.0, 0.15, -up));
    }
    float sd = max(dot(d, sunDir), 0.0);
    c += float3(1.0, 0.93, 0.85) * pow(sd, 8.0) * 0.6 * (1.0 - thin * 0.8);
    c += float3(1.0, 0.97, 0.92) * smoothstep(0.9995, 0.99975, sd) * 400.0;
    // stars once the sky is dark
    if (thin > 0.4 && up > -0.05) {
        float3 sp = d * 420.0;
        float3 cell = floor(sp);
        float s = hash31(cell);
        float3 off = fract(sp) - 0.5;
        float star = step(0.9965, s) * smoothstep(0.25, 0.0, length(off)) * (0.6 + 2.0 * hash31(cell + 3.1));
        c += float3(star) * smoothstep(0.4, 0.9, thin) * 1.5;
    }
    return c;
}

// ---------- site collision geometry (world metres) ----------
// Built on the CPU from the same ImpingementSurface list the plume raycast and the vehicle contact use
// (GameEngine.siteShapes), uploaded every frame — no hand-copied numbers. Used by the plume (clip +
// deflection) and the particle kernel (collisions).
struct SiteShapes {
    float4 info;           // x box count, y ground has the trench cut (1), z ground plane y
    float4 trenchC;
    float4 trenchH;
    float4 boxC[16];
    float4 boxH[16];
};

inline float sdBox(float3 p, float3 c, float3 h) {
    float3 q = abs(p - c) - h;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}
/// Signed distance to the nearest solid surface of the site.
inline float siteSDF(float3 p, constant SiteShapes& s) {
    float d = p.y - s.info.z;
    if (s.info.y > 0.5) d = max(d, -sdBox(p, s.trenchC.xyz + float3(0.0, 1.0, 0.0), s.trenchH.xyz + float3(0.0, 1.0, 0.0)));
    int n = int(s.info.x);
    for (int i = 0; i < 16; i++) {
        if (i >= n) break;
        d = min(d, sdBox(p, s.boxC[i].xyz, s.boxH[i].xyz));
    }
    return d;
}
inline float3 siteNormal(float3 p, constant SiteShapes& s) {
    const float e = 0.05;
    float3 n = float3(siteSDF(p + float3(e, 0.0, 0.0), s) - siteSDF(p - float3(e, 0.0, 0.0), s),
                      siteSDF(p + float3(0.0, e, 0.0), s) - siteSDF(p - float3(0.0, e, 0.0), s),
                      siteSDF(p + float3(0.0, 0.0, e), s) - siteSDF(p - float3(0.0, 0.0, e), s));
    float l = length(n);
    return l > 1e-5 ? n / l : float3(0.0, 1.0, 0.0);
}

// ---------- tileable 3D noise textures (generated once on the GPU, see Noise.metal) ----------
// noiseBase  64^3 rg16f: r = Perlin-Worley billows, g = Worley fbm (low-frequency shape)
// noiseDetail 32^3 r16f: Worley fbm for edge erosion
constexpr sampler kNoiseSampler(filter::linear, address::repeat);
inline float2 noiseBase(texture3d<float> t, float3 p) { return t.sample(kNoiseSampler, p).rg; }
inline float noiseDetail(texture3d<float> t, float3 p) { return t.sample(kNoiseSampler, p).r; }
