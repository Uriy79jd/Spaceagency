#include "ShaderCommon.h"

// ---------------- environment (procedural IBL) ----------------

inline float3 cubeDir(uint face, float2 uv) {
    // uv in [-1, 1], v pointing down the face
    switch (face) {
        case 0: return normalize(float3(1.0, -uv.y, -uv.x));
        case 1: return normalize(float3(-1.0, -uv.y, uv.x));
        case 2: return normalize(float3(uv.x, 1.0, uv.y));
        case 3: return normalize(float3(uv.x, -1.0, -uv.y));
        case 4: return normalize(float3(uv.x, -uv.y, 1.0));
        default: return normalize(float3(-uv.x, -uv.y, -1.0));
    }
}

// Radiance around the engine: open-roof hangar (sky through the roof gaps, overhead light panels,
// corrugated walls, concrete floor, bright open doorway at +Z).
inline float3 hangarEnv(float3 d, float4 sky) {
    float3 skyC = skyRadiance(d, sky.x, sky.y, sky.z);
    float3 c;
    if (d.y > 0.25) {
        // roof: trusses block part of the sky; light panels
        float2 rp = d.xz / d.y * 18.0;
        float truss = step(0.75, fract(rp.y / 6.0 + 0.5)) * 0.85;
        c = mix(skyC, float3(0.10, 0.10, 0.11), truss);
        float2 lp = float2(fract(rp.x / 14.0 + 0.5) - 0.5, fract(rp.y / 9.0 + 0.5) - 0.5) * float2(14.0, 9.0);
        float panel = step(abs(lp.x), 1.2) * step(abs(lp.y), 0.25);
        c += float3(14.0, 13.4, 12.6) * panel;
    } else if (d.y > -0.05) {
        // walls (corrugated metal, lit) and the open front door
        float3 wall = float3(0.42, 0.43, 0.45) * (0.7 + 0.3 * smoothstep(-0.05, 0.25, d.y));
        float door = smoothstep(0.55, 0.75, d.z) * step(d.y, 0.22);
        c = mix(wall, skyC * 1.1 + float3(0.25, 0.23, 0.2), door);
    } else {
        // concrete floor
        c = float3(0.20, 0.195, 0.185) * (0.6 + 0.4 * smoothstep(-1.0, -0.05, d.y));
    }
    return c;
}

kernel void envGenerate(texturecube<float, access::write> dst [[texture(0)]],
                        constant float4& sky [[buffer(0)]],
                        uint3 gid [[thread_position_in_grid]]) {
    uint size = dst.get_width();
    if (gid.x >= size || gid.y >= size) return;
    float2 uv = (float2(gid.xy) + 0.5) / float(size) * 2.0 - 1.0;
    float3 d = cubeDir(gid.z, uv);
    float3 c;
    if (sky.w > 1.5) {
        // outdoors: sky above, sunlit ploughed field below
        float3 sunDir = normalize(float3(0.45, 0.62, 0.65));
        if (d.y > -0.02) c = skyRadiance(d, sky.x, sky.y, sky.z);
        else c = float3(0.30, 0.215, 0.15) * (3.5 * max(sunDir.y, 0.0) / 3.14159 + 0.35) * smoothstep(-1.0, -0.02, d.y) + float3(0.05);
        c = min(c, float3(60.0));
    } else {
        c = hangarEnv(d, sky);
    }
    dst.write(float4(c, 1.0), gid.xy, gid.z);
}

inline float2 hammersley(uint i, uint n) {
    uint b = i;
    b = (b << 16u) | (b >> 16u);
    b = ((b & 0x55555555u) << 1u) | ((b & 0xAAAAAAAAu) >> 1u);
    b = ((b & 0x33333333u) << 2u) | ((b & 0xCCCCCCCCu) >> 2u);
    b = ((b & 0x0F0F0F0Fu) << 4u) | ((b & 0xF0F0F0F0u) >> 4u);
    b = ((b & 0x00FF00FFu) << 8u) | ((b & 0xFF00FF00u) >> 8u);
    return float2(float(i) / float(n), float(b) * 2.3283064365386963e-10);
}

// GGX-importance-sampled prefilter of the environment for one roughness level (split-sum, N = V = R).
kernel void envPrefilter(texturecube<float> src [[texture(0)]],
                         texturecube<float, access::write> dst [[texture(1)]],
                         constant float4& p [[buffer(0)]],
                         uint3 gid [[thread_position_in_grid]]) {
    uint size = dst.get_width();
    if (gid.x >= size || gid.y >= size) return;
    constexpr sampler s(filter::linear, mip_filter::linear);
    float rough = p.x;
    float2 uv = (float2(gid.xy) + 0.5) / float(size) * 2.0 - 1.0;
    float3 N = cubeDir(gid.z, uv);
    if (rough < 0.02) {
        dst.write(src.sample(s, N, level(0.0)), gid.xy, gid.z);
        return;
    }
    float3 up = abs(N.y) < 0.999 ? float3(0, 1, 0) : float3(1, 0, 0);
    float3 T = normalize(cross(up, N));
    float3 B = cross(N, T);
    float a = rough * rough;
    float3 acc = float3(0.0);
    float w = 0.0;
    const uint COUNT = 64u;
    float srcMips = p.y;
    for (uint i = 0u; i < COUNT; i++) {
        float2 xi = hammersley(i, COUNT);
        float phi = 2.0 * M_PI_F * xi.x;
        float cosT = sqrt((1.0 - xi.y) / (1.0 + (a * a - 1.0) * xi.y));
        float sinT = sqrt(1.0 - cosT * cosT);
        float3 H = T * (sinT * cos(phi)) + B * (sinT * sin(phi)) + N * cosT;
        float3 L = 2.0 * dot(N, H) * H - N;
        float NoL = dot(N, L);
        if (NoL > 0.0) {
            float lod = clamp(rough * srcMips, 0.0, srcMips);
            float3 c = min(src.sample(s, L, level(lod)).rgb, float3(40.0)); // clamp fireflies from tiny bright panels
            acc += c * NoL;
            w += NoL;
        }
    }
    dst.write(float4(acc / max(w, 1e-4), 1.0), gid.xy, gid.z);
}

// ---------------- SSAO (depth-only, half resolution) ----------------

struct SSAOParams {
    float4x4 proj;
    float4x4 invProj;
    float4 p;   // x radius (m), y strength, z full width, w full height
};

inline float3 viewPosFromDepth(float2 uv, float d, float4x4 invProj) {
    float4 ndc = float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, d, 1.0);
    float4 v = invProj * ndc;
    return v.xyz / v.w;
}

kernel void ssaoKernel(depth2d<float, access::sample> depth [[texture(0)]],
                       texture2d<float, access::write> ao [[texture(1)]],
                       constant SSAOParams& sp [[buffer(0)]],
                       uint2 gid [[thread_position_in_grid]]) {
    uint w = ao.get_width(), h = ao.get_height();
    if (gid.x >= w || gid.y >= h) return;
    constexpr sampler pt(filter::nearest, address::clamp_to_edge);
    float2 texel = 1.0 / float2(w, h);
    float2 uv = (float2(gid) + 0.5) * texel;
    float d = depth.sample(pt, uv);
    if (d >= 1.0) { ao.write(float4(1.0), gid); return; }
    float3 P = viewPosFromDepth(uv, d, sp.invProj);
    float3 Px = viewPosFromDepth(uv + float2(texel.x, 0), depth.sample(pt, uv + float2(texel.x, 0)), sp.invProj);
    float3 Py = viewPosFromDepth(uv + float2(0, texel.y), depth.sample(pt, uv + float2(0, texel.y)), sp.invProj);
    float3 Pxm = viewPosFromDepth(uv - float2(texel.x, 0), depth.sample(pt, uv - float2(texel.x, 0)), sp.invProj);
    float3 Pym = viewPosFromDepth(uv - float2(0, texel.y), depth.sample(pt, uv - float2(0, texel.y)), sp.invProj);
    float3 dx = abs(Px.z - P.z) < abs(P.z - Pxm.z) ? Px - P : P - Pxm;
    float3 dy = abs(Py.z - P.z) < abs(P.z - Pym.z) ? Py - P : P - Pym;
    float3 N = normalize(cross(dy, dx));
    if (dot(N, P) > 0.0) N = -N;

    float radius = sp.p.x;
    float occ = 0.0;
    const int SAMPLES = 12;
    float rot = ign(float2(gid)) * 6.2831853;
    float3 up = abs(N.y) < 0.99 ? float3(0, 1, 0) : float3(1, 0, 0);
    float3 T = normalize(cross(up, N));
    float3 B = cross(N, T);
    for (int i = 0; i < SAMPLES; i++) {
        float fi = (float(i) + 0.5) / float(SAMPLES);
        float ang = rot + float(i) * 2.399963;
        float rr = sqrt(fi);
        float z = sqrt(1.0 - fi);
        float3 dir = T * (cos(ang) * rr) + B * (sin(ang) * rr) + N * z;
        float scale = mix(0.15, 1.0, fi * fi);
        float3 S = P + dir * radius * scale;
        float4 c = sp.proj * float4(S, 1.0);
        float2 suv = float2(c.x / c.w * 0.5 + 0.5, 0.5 - c.y / c.w * 0.5);
        if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
        float sd = depth.sample(pt, suv);
        float3 SP = viewPosFromDepth(suv, sd, sp.invProj);
        float range = smoothstep(0.0, 1.0, radius / max(abs(P.z - SP.z), 1e-3));
        occ += (SP.z >= S.z + 0.02 ? 1.0 : 0.0) * range;
    }
    float a = 1.0 - occ / float(SAMPLES) * sp.p.y;
    ao.write(float4(clamp(a, 0.0, 1.0)), gid);
}

// multiply-blend the (blurred) AO into the lit HDR image, before translucent plume/particles
fragment float4 aoApplyFragment(FSQOut in [[stage_in]], texture2d<float> ao [[texture(0)]]) {
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float2 t = 1.0 / float2(ao.get_width(), ao.get_height());
    // 3×3 bilinear taps 2 texels apart: a ~6×6 texel tent that removes the per-pixel rotation pattern
    float a = 0.0, wsum = 0.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            float w = (i == 0 ? 2.0 : 1.0) * (j == 0 ? 2.0 : 1.0);
            a += ao.sample(s, in.uv + float2(i, j) * 2.0 * t).r * w;
            wsum += w;
        }
    }
    a /= wsum;
    return float4(a, a, a, 1.0);
}

// ---------------- auto exposure ----------------
kernel void luminanceKernel(texture2d<float> hdr [[texture(0)]],
                            device float* out [[buffer(0)]],
                            uint2 tid [[thread_position_in_threadgroup]],
                            uint tindex [[thread_index_in_threadgroup]]) {
    threadgroup float sums[256];
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float acc = 0.0;
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            float2 uv = (float2(tid) * 4.0 + float2(i, j) + 0.5) / 64.0;
            // centre-weighted metering
            float3 c = hdr.sample(s, uv, level(0.0)).rgb;
            acc += log(max(luminance(c), 1e-4));
        }
    }
    sums[tindex] = acc / 16.0;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint stride = 128u; stride > 0u; stride >>= 1u) {
        if (tindex < stride) sums[tindex] += sums[tindex + stride];
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (tindex == 0u) out[0] = exp(sums[0] / 256.0);
}

// ---------------- bloom ----------------
inline float3 karis(float3 c) { return c / (1.0 + luminance(c) * 0.25); }

kernel void bloomDownsample(texture2d<float> src [[texture(0)]],
                            texture2d<float, access::write> dst [[texture(1)]],
                            constant float4& p [[buffer(0)]],   // x threshold, y knee, z first pass, w exposure
                            uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= dst.get_width() || gid.y >= dst.get_height()) return;
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float2 ts = 1.0 / float2(src.get_width(), src.get_height());
    float2 uv = (float2(gid) + 0.5) / float2(dst.get_width(), dst.get_height());
    float3 a = src.sample(s, uv + ts * float2(-2, -2)).rgb, b = src.sample(s, uv + ts * float2(0, -2)).rgb, c = src.sample(s, uv + ts * float2(2, -2)).rgb;
    float3 d = src.sample(s, uv + ts * float2(-1, -1)).rgb, e = src.sample(s, uv + ts * float2(1, -1)).rgb;
    float3 f = src.sample(s, uv + ts * float2(-2, 0)).rgb, g = src.sample(s, uv).rgb, h = src.sample(s, uv + ts * float2(2, 0)).rgb;
    float3 i = src.sample(s, uv + ts * float2(-1, 1)).rgb, j = src.sample(s, uv + ts * float2(1, 1)).rgb;
    float3 k = src.sample(s, uv + ts * float2(-2, 2)).rgb, l = src.sample(s, uv + ts * float2(0, 2)).rgb, m = src.sample(s, uv + ts * float2(2, 2)).rgb;
    float3 col;
    if (p.z > 0.5) {
        col = karis(d + e + i + j) * 0.5 * 0.25 + karis(a + b + f + g) * 0.125 * 0.25 + karis(b + c + g + h) * 0.125 * 0.25
            + karis(f + g + k + l) * 0.125 * 0.25 + karis(g + h + l + m) * 0.125 * 0.25;
        // soft threshold on exposed luminance: only physically bright pixels bloom
        col *= p.w;
        float br = max(col.r, max(col.g, col.b));
        float soft = clamp(br - p.x + p.y, 0.0, 2.0 * p.y);
        soft = soft * soft / (4.0 * p.y + 1e-4);
        float contrib = max(soft, br - p.x) / max(br, 1e-4);
        col *= contrib;
    } else {
        col = (d + e + i + j) * 0.125 + (a + c + k + m) * 0.03125 + (b + f + h + l) * 0.0625 + g * 0.125;
    }
    dst.write(float4(col, 1.0), gid);
}

kernel void bloomUpsample(texture2d<float> low [[texture(0)]],
                          texture2d<float> base [[texture(1)]],
                          texture2d<float, access::write> dst [[texture(2)]],
                          constant float4& p [[buffer(0)]],   // x radius
                          uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= dst.get_width() || gid.y >= dst.get_height()) return;
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float2 uv = (float2(gid) + 0.5) / float2(dst.get_width(), dst.get_height());
    float2 ts = p.x / float2(low.get_width(), low.get_height());
    float3 c = low.sample(s, uv + ts * float2(-1, -1)).rgb + low.sample(s, uv + ts * float2(0, -1)).rgb * 2.0 + low.sample(s, uv + ts * float2(1, -1)).rgb
             + low.sample(s, uv + ts * float2(-1, 0)).rgb * 2.0 + low.sample(s, uv).rgb * 4.0 + low.sample(s, uv + ts * float2(1, 0)).rgb * 2.0
             + low.sample(s, uv + ts * float2(-1, 1)).rgb + low.sample(s, uv + ts * float2(0, 1)).rgb * 2.0 + low.sample(s, uv + ts * float2(1, 1)).rgb;
    c /= 16.0;
    dst.write(float4(base.sample(s, uv).rgb + c, 1.0), gid);
}

// ---------------- composite: exposure, bloom, heat haze, ACES, grain ----------------
struct CompositeParams {
    float4 p;   // x exposure, y bloom strength, z time, w haze strength
    float4 q;   // x bloom levels, y vignette, z fxaa on, w unused
};

inline float3 acesFitted(float3 v) {
    const float3x3 inM = float3x3(float3(0.59719, 0.07600, 0.02840), float3(0.35458, 0.90834, 0.13383), float3(0.04823, 0.01566, 0.83777));
    const float3x3 outM = float3x3(float3(1.60475, -0.10208, -0.00327), float3(-0.53108, 1.10813, -0.07276), float3(-0.07367, -0.00605, 1.07602));
    v = inM * v;
    float3 a = v * (v + 0.0245786) - 0.000090537;
    float3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
    v = a / b;
    return clamp(outM * v, 0.0, 1.0);
}
inline float3 linearToSRGB(float3 c) {
    float3 lo = c * 12.92;
    float3 hi = 1.055 * pow(max(c, 0.0), 1.0 / 2.4) - 0.055;
    return select(hi, lo, c <= 0.0031308);
}

fragment float4 compositeFragment(FSQOut in [[stage_in]],
                                  texture2d<float> hdr [[texture(0)]],
                                  texture2d<float> bloom [[texture(1)]],
                                  texture2d<float> distort [[texture(2)]],
                                  constant CompositeParams& c [[buffer(0)]]) {
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float2 uv = in.uv;
    float2 dt2 = 1.5 / float2(distort.get_width(), distort.get_height());
    float hz = 0.25 * (distort.sample(s, uv + float2(-dt2.x, -dt2.y)).r + distort.sample(s, uv + float2(dt2.x, -dt2.y)).r
                     + distort.sample(s, uv + float2(-dt2.x, dt2.y)).r + distort.sample(s, uv + float2(dt2.x, dt2.y)).r) * c.p.w;
    if (hz > 0.0005) {
        float t = c.p.z;
        float2 n = float2(vnoise2(uv * float2(90.0, 50.0) + float2(0.0, t * 6.0)), vnoise2(uv * float2(80.0, 60.0) + float2(t * 5.0, 3.7))) - 0.5;
        uv += n * hz * 0.012;
    }
    float3 col = hdr.sample(s, uv).rgb * c.p.x;
    col += bloom.sample(s, uv).rgb * (c.p.y / max(c.q.x, 1.0));
    float2 vc = in.uv - 0.5;
    col *= 1.0 - c.q.y * dot(vc, vc) * 1.4;
    col = acesFitted(col * 0.9);
    float3 srgb = linearToSRGB(col);
    float grain = (hash21(in.position.xy + fract(c.p.z) * 517.0) - 0.5) / 255.0;
    srgb += grain;
    return float4(srgb, dot(srgb, float3(0.299, 0.587, 0.114)));
}

// ---------------- FXAA (3.11-style, simplified) ----------------
fragment float4 fxaaFragment(FSQOut in [[stage_in]],
                             texture2d<float> ldr [[texture(0)]],
                             constant float4& p [[buffer(0)]]) {   // x enabled
    constexpr sampler s(filter::linear, address::clamp_to_edge);
    float4 rgbM = ldr.sample(s, in.uv);
    if (p.x < 0.5) return float4(rgbM.rgb, 1.0);
    float2 rcp = 1.0 / float2(ldr.get_width(), ldr.get_height());
    float lumaNW = ldr.sample(s, in.uv + float2(-1, -1) * rcp).a;
    float lumaNE = ldr.sample(s, in.uv + float2(1, -1) * rcp).a;
    float lumaSW = ldr.sample(s, in.uv + float2(-1, 1) * rcp).a;
    float lumaSE = ldr.sample(s, in.uv + float2(1, 1) * rcp).a;
    float lumaM = rgbM.a;
    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));
    if (lumaMax - lumaMin < max(0.0312, lumaMax * 0.125)) return float4(rgbM.rgb, 1.0);
    float2 dir = float2(-((lumaNW + lumaNE) - (lumaSW + lumaSE)), ((lumaNW + lumaSW) - (lumaNE + lumaSE)));
    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) * 0.25 * 0.125, 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, -8.0, 8.0) * rcp;
    float3 rgbA = 0.5 * (ldr.sample(s, in.uv + dir * (1.0 / 3.0 - 0.5)).rgb + ldr.sample(s, in.uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    float3 rgbB = rgbA * 0.5 + 0.25 * (ldr.sample(s, in.uv + dir * -0.5).rgb + ldr.sample(s, in.uv + dir * 0.5).rgb);
    float lumaB = dot(rgbB, float3(0.299, 0.587, 0.114));
    return float4((lumaB < lumaMin || lumaB > lumaMax) ? rgbA : rgbB, 1.0);
}

// ---------------- half-res translucent layer (plume + particles) → full-res HDR ----------------
// Premultiplied colour + coverage, bilinearly upsampled; blended with (one, oneMinusSourceAlpha).
struct UpsampleParams {
    float4 p;   // x proj[2][2], y proj[3][2] (view depth = y / (d + x)), z depth-sample scale (full / half), w unused
};

inline float linearDepth(float d, constant UpsampleParams& u) {
    return d >= 1.0 ? 1e6 : u.p.y / (d + u.p.x);
}

// Depth-aware (joint bilateral) upsample: of the 4 half-res texels around this full-res pixel, those whose
// own scene depth (the full-res depth the half-res pass tested against) differs from this pixel's depth get
// little weight, so the plume / clouds stay crisp against the stand legs, the vehicle and the horizon instead
// of bleeding a blocky half-res halo over them.
fragment float4 transCompositeFragment(FSQOut in [[stage_in]],
                                       texture2d<float> trans [[texture(0)]],
                                       depth2d<float> depth [[texture(1)]],
                                       constant UpsampleParams& u [[buffer(0)]]) {
    float2 hs = float2(trans.get_width(), trans.get_height());
    uint2 fullMax = uint2(depth.get_width() - 1, depth.get_height() - 1);
    float zc = linearDepth(depth.read(min(uint2(in.position.xy), fullMax)), u);
    float2 pos = in.uv * hs - 0.5;
    float2 i0 = floor(pos);
    float2 fr = pos - i0;
    float4 acc = float4(0.0);
    float wsum = 0.0;
    float4 bil = float4(0.0);
    for (int k = 0; k < 4; k++) {
        float2 o = float2(k & 1, k >> 1);
        int2 t = clamp(int2(i0 + o), int2(0), int2(hs) - 1);
        float wb = (o.x > 0.5 ? fr.x : 1.0 - fr.x) * (o.y > 0.5 ? fr.y : 1.0 - fr.y);
        float4 c = trans.read(uint2(t));
        bil += c * wb;
        float zt = linearDepth(depth.read(min(uint2(float2(t) * u.p.z + floor(u.p.z * 0.5)), fullMax)), u);   // the texel the half-res pass tested
        float rel = abs(zt - zc) / max(min(zt, zc), 0.1);
        float w = wb * (1.0 / (1e-3 + rel * rel * 400.0 + rel * 4.0)) ;
        acc += c * w;
        wsum += w;
    }
    float4 c = wsum > 1e-4 ? acc / wsum : bil;
    return float4(c.rgb, clamp(c.a, 0.0, 1.0));
}

// ---------------- temporal resolve for the half-res ray-marched layers (clouds, plume + particles) ----------------
struct TemporalParams {
    float4x4 prevViewProj;   // previous frame's camera-relative view-projection
    float4 camDelta;         // xyz current camera − previous camera (world m), w reprojection distance (m)
    float4 p;                // x current-frame weight, y history valid (1/0), z,w unused
};

// Reprojects last frame's resolved layer along the view ray at a representative distance (the plume's distance
// from the camera, or far for clouds), clips it to the 3×3 neighbourhood of the current frame (no ghosting /
// smearing when the plume flickers or the camera moves), and blends. The current frame is lightly pre-filtered
// (3×3 tent). Together with the per-frame golden-ratio march offset this turns the jitter into a smooth average.
fragment float4 temporalResolveFragment(FSQOut in [[stage_in]],
                                        constant FrameUniforms& f [[buffer(1)]],
                                        constant TemporalParams& tp [[buffer(0)]],
                                        texture2d<float> cur [[texture(0)]],
                                        texture2d<float> hist [[texture(1)]]) {
    constexpr sampler ls(filter::linear, address::clamp_to_edge);
    int2 sz = int2(cur.get_width(), cur.get_height());
    int2 px = int2(in.position.xy);
    float4 mn = float4(1e9), mx = float4(-1e9);
    float4 filt = float4(0.0);
    float4 m1 = float4(0.0), m2 = float4(0.0);
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            float4 c = cur.read(uint2(clamp(px + int2(i, j), int2(0), sz - 1)));
            float w = (i == 0 ? 2.0 : 1.0) * (j == 0 ? 2.0 : 1.0) / 16.0;
            filt += c * w;
            mn = min(mn, c); mx = max(mx, c);
            m1 += c; m2 += c * c;
        }
    }
    if (tp.p.y < 0.5) return filt;
    // variance-tightened clip box (keeps the crisp core from smearing)
    float4 mu = m1 / 9.0;
    float4 sd = sqrt(max(m2 / 9.0 - mu * mu, 0.0));
    float4 lo = max(mn, mu - 1.25 * sd), hi = min(mx, mu + 1.25 * sd);
    // reprojection along this pixel's view ray
    float2 uv = in.uv;
    float4 w = f.invViewProj * float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, 0.5, 1.0);
    float3 rd = normalize(w.xyz / w.w);
    float3 pPrev = rd * tp.camDelta.w + tp.camDelta.xyz;
    float4 cp = tp.prevViewProj * float4(pPrev, 1.0);
    if (cp.w <= 1e-4) return filt;
    float2 puv = float2(cp.x / cp.w * 0.5 + 0.5, 0.5 - cp.y / cp.w * 0.5);
    if (any(puv < 0.0) || any(puv > 1.0)) return filt;
    float4 h = clamp(hist.sample(ls, puv), lo, hi);
    return mix(h, filt, tp.p.x);
}
