#include "ShaderCommon.h"

struct PBRVOut {
    float4 position [[position]];
    float3 worldPos;      // camera-relative
    float3 normal;
    float4 uv;
    float4 shadowPos;
    float ao;
    float detail;
    float3 localPos;
};

vertex PBRVOut pbrVertex(VertexIn in [[stage_in]],
                         constant FrameUniforms& f [[buffer(1)]],
                         constant DrawUniforms& d [[buffer(2)]]) {
    PBRVOut o;
    float4 wp = d.model * float4(in.position.xyz, 1.0);
    o.position = f.viewProj * wp;
    o.worldPos = wp.xyz;
    o.normal = normalize((d.normalMatrix * float4(in.normal.xyz, 0.0)).xyz);
    o.uv = in.uv;
    o.shadowPos = f.lightViewProj * wp;
    o.ao = in.position.w;
    o.detail = in.normal.w;
    o.localPos = in.position.xyz;
    return o;
}

vertex float4 shadowVertex(VertexIn in [[stage_in]],
                           constant FrameUniforms& f [[buffer(1)]],
                           constant DrawUniforms& d [[buffer(2)]]) {
    return f.lightViewProj * (d.model * float4(in.position.xyz, 1.0));
}

// ---------- BRDF ----------
inline float D_GGX(float NoH, float a) {
    float a2 = a * a;
    float d = NoH * NoH * (a2 - 1.0) + 1.0;
    return a2 / (M_PI_F * d * d + 1e-7);
}
inline float V_SmithGGXCorrelated(float NoV, float NoL, float a) {
    float a2 = a * a;
    float gv = NoL * sqrt(NoV * NoV * (1.0 - a2) + a2);
    float gl = NoV * sqrt(NoL * NoL * (1.0 - a2) + a2);
    return 0.5 / (gv + gl + 1e-6);
}
inline float3 F_Schlick(float3 f0, float VoH) {
    float f = pow(1.0 - VoH, 5.0);
    return f0 + (1.0 - f0) * f;
}
// Karis' analytic approximation of the split-sum environment BRDF.
inline float3 envBRDFApprox(float3 f0, float rough, float NoV) {
    const float4 c0 = float4(-1.0, -0.0275, -0.572, 0.022);
    const float4 c1 = float4(1.0, 0.0425, 1.04, -0.04);
    float4 r = rough * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
    float2 ab = float2(-1.04, 1.04) * a004 + r.zw;
    return f0 * ab.x + ab.y;
}

inline float3 perturbNormal(float3 N, float3 p, float h) {
    float3 dpdx = dfdx(p), dpdy = dfdy(p);
    float dhdx = dfdx(h), dhdy = dfdy(h);
    float3 r1 = cross(dpdy, N), r2 = cross(N, dpdx);
    float det = dot(dpdx, r1);
    float3 grad = sign(det) * (dhdx * r1 + dhdy * r2);
    float3 n = abs(det) * N - grad;
    float l = length(n);
    return l > 1e-6 ? n / l : N;
}

constant float2 poisson16[16] = {
    float2(-0.94201624, -0.39906216), float2(0.94558609, -0.76890725), float2(-0.094184101, -0.92938870), float2(0.34495938, 0.29387760),
    float2(-0.91588581, 0.45771432), float2(-0.81544232, -0.87912464), float2(-0.38277543, 0.27676845), float2(0.97484398, 0.75648379),
    float2(0.44323325, -0.97511554), float2(0.53742981, -0.47373420), float2(-0.26496911, -0.41893023), float2(0.79197514, 0.19090188),
    float2(-0.24188840, 0.99706507), float2(-0.81409955, 0.91437590), float2(0.19984126, 0.78641367), float2(0.14383161, -0.14100790)
};

inline float shadowFactor(depth2d<float> sm, float4 sp, float texel, float2 px, int taps) {
    constexpr sampler cmp(coord::normalized, filter::linear, address::clamp_to_edge, compare_func::less_equal);
    float3 p = sp.xyz / sp.w;
    float2 uv = float2(p.x * 0.5 + 0.5, 0.5 - p.y * 0.5);
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0 || p.z > 1.0) return 1.0;
    // fixed Poisson disc + hardware bilinear compare: smooth penumbra without a per-pixel rotated dither
    float2x2 rot = float2x2(float2(1.0, 0.0), float2(0.0, 1.0));
    float radius = texel * 1.8;
    float s = 0.0;
    for (int i = 0; i < taps; i++) {
        float2 o = rot * poisson16[i] * radius;
        s += sm.sample_compare(cmp, uv + o, p.z - 0.0012);
    }
    return s / float(taps);
}

inline float3 temperTint(float h) {
    // thin-film oxide colours of heat-tinted steel/Inconel: straw -> bronze -> purple -> blue
    float3 straw = float3(0.86, 0.72, 0.45), bronze = float3(0.70, 0.45, 0.28), purple = float3(0.42, 0.30, 0.48), blue = float3(0.30, 0.40, 0.62);
    float3 c = mix(float3(1.0), straw, smoothstep(0.0, 0.3, h));
    c = mix(c, bronze, smoothstep(0.3, 0.55, h));
    c = mix(c, purple, smoothstep(0.55, 0.8, h));
    c = mix(c, blue, smoothstep(0.8, 1.0, h));
    return c;
}

// "1" decal on the nozzle: box SDFs in (arc length, height) space.
inline float decalOne(float s, float t) {
    float2 p = float2(s, t);
    float stem = max(abs(p.x) - 0.022, abs(p.y) - 0.115);
    float2 q = p - float2(-0.035, 0.09);
    float2 qr = float2(q.x * 0.8 + q.y * 0.6, -q.x * 0.6 + q.y * 0.8);
    float flag = max(abs(qr.x) - 0.04, abs(qr.y) - 0.016);
    float base = max(abs(p.x) - 0.06, abs(p.y + 0.105) - 0.014);
    float dd = min(stem, min(flag, base));
    return dd;
}

struct MaterialSample {
    float aniso;             // 0 isotropic, 1 brushed (highlights stretched across the brushing direction)
    float3 albedo;
    float metallic;
    float rough;
    float3 N;
    float ao;
    float3 emissive;
};

fragment float4 pbrFragment(PBRVOut in [[stage_in]],
                            constant FrameUniforms& f [[buffer(1)]],
                            constant DrawUniforms& d [[buffer(2)]],
                            depth2d<float> shadowMap [[texture(0)]],
                            texturecube<float> envMap [[texture(1)]],
                            texture2d<float> detailTex [[texture(2)]]) {
    constexpr sampler envS(filter::linear, mip_filter::linear);
    constexpr sampler detS(filter::linear, mip_filter::linear, address::repeat);
    float3 V = normalize(-in.worldPos);
    float3 Ng = normalize(in.normal);
    float3 wpAbs = in.worldPos + f.cameraWorld.xyz;
    int kind = int(d.params.z + 0.5);

    MaterialSample m;
    m.aniso = 0.0;
    m.albedo = d.baseColor.rgb;
    m.metallic = d.params.x;
    m.rough = d.params.y;
    m.N = Ng;
    m.ao = in.ao;
    m.emissive = float3(0.0);

    float h = 0.0;           // bump height (metres-ish)
    float2 uv = in.uv.xy;

    if (kind == 1) {
        // ---- concrete pad ----
        float2 p = wpAbs.xz;
        float n1 = fbm2(p * 0.35, 4);
        float n2 = fbm2(p * 3.1, 3);
        float n3 = vnoise2(p * 24.0);
        m.albedo *= 0.82 + 0.28 * n1 + 0.10 * (n2 - 0.5);
        m.rough = clamp(m.rough + 0.12 * (n2 - 0.5) - 0.15 * smoothstep(0.55, 0.75, n1), 0.35, 1.0);
        // saw-cut expansion joints every 5 m
        float2 g = abs(fract(p / 5.0 + 0.5) - 0.5) * 5.0;
        float joint = 1.0 - smoothstep(0.006, 0.018, min(g.x, g.y));
        m.albedo *= 1.0 - 0.55 * joint;
        m.ao *= 1.0 - 0.5 * joint;
        h = -joint * 0.01 + (n3 - 0.5) * 0.0015 + (n2 - 0.5) * 0.002;
        // procedural detail map: crack network (more cracking / spalling in the blast zone), grain
        float4 dt = detailTex.sample(detS, p * 0.07);
        float4 dg = detailTex.sample(detS, p * 0.9);
        float blast = 1.0 - smoothstep(4.0, 14.0, length(p - f.pad.xy));
        float crack = dt.g * (0.55 + 0.45 * blast);
        m.albedo *= (1.0 - 0.45 * crack) * (0.9 + 0.2 * dg.a);
        m.rough = clamp(m.rough + 0.1 * (dg.a - 0.5) + 0.1 * crack, 0.3, 1.0);
        m.ao *= 1.0 - 0.35 * crack;
        h += -crack * 0.006 + (dg.a - 0.5) * 0.0015;
        // tyre / oil stains
        float stain = smoothstep(0.62, 0.8, fbm2(p * 0.12 + 7.3, 3));
        m.albedo *= 1.0 - 0.25 * stain;
        m.rough = mix(m.rough, 0.45, stain * 0.6);
        // scorch and soot from the engine, plus live heat glow at the impingement zone
        float rr = length(p - f.pad.xy);
        float rs = max(f.pad2.x, 0.6);
        float scorchR = max(f.pad2.y * 0.45, 3.0);
        float scorch = f.pad.w * (1.0 - smoothstep(rs * 0.4, scorchR, rr + (n1 - 0.5) * 2.0));
        m.albedo = mix(m.albedo, float3(0.035, 0.032, 0.03), clamp(scorch, 0.0, 0.92));
        m.rough = mix(m.rough, 0.95, scorch * 0.6);
        float hot = 1.0 - smoothstep(rs * 0.3, rs * 1.6, rr + (n2 - 0.5) * 0.6);
        float padT = 293.0 + (f.pad.z - 293.0) * hot;
        m.emissive += blackbodyColor(padT) * glowIntensity(padT) * (0.6 + 0.4 * n2);
    } else if (kind == 2) {
        // ---- matte coated nozzle: wear, roughness variation, weld seams, decal, heat ----
        float3 lp = in.localPos;
        float n1 = fbm3(lp * 3.0, 4);
        float n2 = fbm3(lp * 22.0, 3);
        m.rough = clamp(m.rough + 0.14 * (n1 - 0.5) + 0.06 * (n2 - 0.5), 0.35, 0.9);
        // scuffs: worn coating shows lighter, smoother material
        float wear = smoothstep(0.62, 0.78, fbm3(lp * 6.0 + 2.0, 4)) * 0.6 + smoothstep(0.75, 0.9, n2) * 0.25;
        m.albedo = mix(m.albedo, float3(0.075, 0.072, 0.07), wear);
        m.rough = mix(m.rough, 0.42, wear * 0.7);
        // copper/bronze heat discoloration near the throat region (fired hardware)
        float heatZone = smoothstep(-2.25, -1.62, lp.y) * (1.0 - smoothstep(-1.62, -1.5, lp.y));
        m.albedo = mix(m.albedo, float3(0.16, 0.085, 0.05), heatZone * (0.35 + 0.4 * n1));
        m.metallic = mix(m.metallic, 0.45, heatZone * 0.5);
        // blue-gold heat discoloration of the bare alloy under the burnt coating (straw → bronze → purple → blue
        // going down the bell), streaky along the flow
        float4 dn = detailTex.sample(detS, float2(in.uv.x * 0.6, lp.y * 0.25));
        float tintH = clamp((-1.9 - lp.y) / 1.15 + 0.25 * (dn.b - 0.5), 0.0, 1.0);
        float bare = smoothstep(0.35, 0.65, dn.b + 0.35 * (1.0 - smoothstep(-2.0, -2.8, lp.y))) * step(lp.y, -1.9);
        float3 tint = float3(0.62, 0.60, 0.56) * temperTint(tintH);
        m.albedo = mix(m.albedo, tint, bare * 0.85);
        m.metallic = mix(m.metallic, 0.9, bare);
        m.rough = mix(m.rough, 0.32 + 0.1 * dn.r, bare);
        m.aniso = bare * 0.6;
        // circumferential weld seams on the bell
        float v = lp.y;
        float seam = 0.0;
        seam = max(seam, 1.0 - smoothstep(0.0, 0.006, abs(v + 2.02)));
        seam = max(seam, 1.0 - smoothstep(0.0, 0.006, abs(v + 2.55)));
        seam = max(seam, 1.0 - smoothstep(0.0, 0.005, abs(v + 1.66)));
        h += seam * 0.0025 + (n2 - 0.5) * 0.0006;
        m.albedo = mix(m.albedo, float3(0.06, 0.058, 0.055), seam * 0.6);
        // white "1" decal (front, slightly right of centre)
        if (in.uv.w > 0.5) {
            float r = length(lp.xz);
            float ang = atan2(lp.x, lp.z);
            float s = (ang - 0.27) * r;
            float t = lp.y + 2.12;
            float dd = decalOne(s, t);
            float aa = fwidth(dd) + 1e-4;
            float paint = (1.0 - smoothstep(-aa, aa, dd)) * (1.0 - 0.35 * smoothstep(0.7, 0.85, n2));
            m.albedo = mix(m.albedo, float3(0.80, 0.80, 0.78), paint);
            m.rough = mix(m.rough, 0.5, paint);
            h += paint * 0.0003;
        }
        // live blackbody glow of the nozzle wall
        float tW = 293.0 + (d.emissive.w - 293.0) * in.uv.z;
        m.emissive += blackbodyColor(tW) * glowIntensity(tW);
    } else if (kind == 4) {
        // ---- corrugated wall cladding: panel seams, laps, streaking ----
        float x = uv.x, y = uv.y;
        float panel = abs(fract(x / 1.0) - 0.5);
        float seam = 1.0 - smoothstep(0.485, 0.5, panel);
        float lap = 1.0 - smoothstep(0.0, 0.015, abs(fract(y / 3.6) - 0.5) - 0.48);
        float streak = fbm2(float2(x * 3.0, y * 0.15), 4);
        float dirt = smoothstep(0.0, 4.0, 4.0 - y) * 0.35;
        m.albedo *= (0.86 + 0.18 * streak) * (1.0 - dirt) * (1.0 - 0.15 * (1.0 - seam));
        m.rough = clamp(m.rough + 0.18 * (streak - 0.5) + dirt * 0.3, 0.2, 0.9);
        m.ao *= mix(0.75, 1.0, in.detail);
        h += lap * 0.004;
        // screw heads along laps
        float2 sc = float2(fract(x / 0.2), fract(y / 3.6 + 0.5));
        float screw = 1.0 - smoothstep(0.0, 0.25, length((sc - 0.5) * float2(0.2, 3.6) * 8.0));
        h += screw * 0.003 * lap;
    } else if (kind == 5) {
        // ---- brushed / machined metal: circumferential brushing, roughness variation, temper tint ----
        float3 lp = in.localPos;
        float brush = detailTex.sample(detS, float2(uv.x * 0.8, uv.y * 3.0)).r;
        float n1 = detailTex.sample(detS, lp.xz * 0.7 + lp.y * 0.31).b;
        m.aniso = 1.0;
        m.rough = clamp(m.rough + 0.08 * (brush - 0.5) + 0.08 * (n1 - 0.5), 0.05, 0.95);
        h += (brush - 0.5) * 0.0002;
        float heat = in.uv.z;
        if (heat > 0.01) m.albedo *= mix(float3(1.0), temperTint(clamp(heat * 1.2 + 0.2 * (n1 - 0.5), 0.0, 1.0)), 0.55);
        float tW = 293.0 + (d.emissive.w - 293.0) * heat * 0.6;
        m.emissive += blackbodyColor(tW) * glowIntensity(tW);
        m.ao *= 0.85 + 0.15 * n1;
    } else if (kind == 6) {
        // ---- painted steel: grime near the base, chips exposing bare metal ----
        float3 p = wpAbs;
        float n1 = fbm3(p * 2.0, 4);
        float chips = smoothstep(0.74, 0.8, fbm3(p * 9.0, 3));
        float grime = (1.0 - smoothstep(0.0, 2.5, p.y)) * 0.5 + 0.15 * n1;
        m.albedo *= 1.0 - grime * 0.6;
        m.albedo = mix(m.albedo, float3(0.35, 0.34, 0.33), chips);
        m.metallic = mix(m.metallic, 1.0, chips);
        m.rough = clamp(m.rough + 0.2 * (n1 - 0.5) - chips * 0.1, 0.2, 0.95);
        h += -chips * 0.0008;
        // soot near the plume
        float sootR = length(p.xz - f.pad.xy);
        m.albedo *= 1.0 - f.pad.w * 0.7 * (1.0 - smoothstep(0.0, 6.0, p.y)) * (1.0 - smoothstep(2.0, 5.0, sootR));
    } else if (kind == 3) {
        m.emissive = d.emissive.rgb;
    } else if (kind == 9) {
        // ---- nozzle liner: dark copper/Inconel when cold, saturated white-hot glow while firing ----
        float3 lp = in.localPos;
        float n1 = fbm3(lp * 6.0, 3);
        m.albedo *= 0.85 + 0.3 * n1;
        float tW = 293.0 + (d.emissive.w - 293.0) * in.uv.z;
        m.emissive += blackbodyColor(tW) * glowIntensity(tW);
        float lit = d.extra.y;   // combustion brightness
        // deeper inside (toward the throat) is hotter; slightly warm white
        // strong gradient so the bell reads as a hollow cavity: warm, dimmer wall near the exit lip,
        // blinding white toward the throat; fine circumferential cooling-channel streaks
        float depthIn = clamp((lp.y + 3.1) / 1.6, 0.0, 1.0);
        float chan = 0.88 + 0.12 * sin(atan2(lp.x, lp.z) * 180.0);
        float3 cWall = mix(float3(1.0, 0.70, 0.45), float3(1.0, 0.97, 0.94), smoothstep(0.0, 0.7, depthIn));
        m.emissive += cWall * lit * (14.0 + 300.0 * pow(depthIn, 2.4)) * mix(chan, 1.0, depthIn);
        m.albedo *= 1.0 - 0.8 * clamp(lit, 0.0, 1.0);       // emissive dominates while lit
    } else if (kind == 11) {
        // ---- cryogenic run tank: brushed stainless with frost, thicker toward the bottom ----
        float3 p = wpAbs;
        float3 lp = in.localPos;
        // circumferential brushing (streaks along u = arc length), weld seams: rings every 1.8 m, vertical every ~3.5 m
        float4 dtk = detailTex.sample(detS, float2(in.uv.x * 0.35, in.uv.y * 0.12));
        float brush = dtk.r;
        m.rough = clamp(m.rough + 0.10 * (brush - 0.5) + 0.06 * (dtk.b - 0.5), 0.12, 0.5);
        m.aniso = 1.0;
        float ringD = abs(fract(lp.y / 1.8 + 0.5) - 0.5) * 1.8;
        float vertD = abs(fract(in.uv.x / 3.53 + 0.5) - 0.5) * 3.53;
        float seamD = min(ringD, vertD);
        float bead = 1.0 - smoothstep(0.004, 0.012, seamD);
        float heatAff = 1.0 - smoothstep(0.01, 0.045, seamD);
        m.albedo *= mix(float3(1.0), temperTint(0.25 + 0.4 * dtk.a), heatAff * 0.5);
        m.rough = mix(m.rough, 0.45, bead);
        h += bead * 0.0015 * (1.0 - seamD / 0.012);
        bool vehicle = d.extra.z > 0.5;
        float hN = vehicle ? clamp((lp.y - 4.6) / 5.7, 0.0, 1.0)
                           : clamp((p.y - 41.0) / 14.6, 0.0, 1.0);   // stand run tank on the 41 m deck (TestSiteMesh.deckTop)
        float fn = fbm3(p * float3(1.6, 0.8, 1.6), 5);
        float frost = smoothstep(0.62 - 0.45 * (1.0 - hN), 0.70 - 0.40 * (1.0 - hN), fn);
        frost = max(frost, smoothstep(0.25, 0.0, hN) * 0.85);
        if (vehicle) frost *= clamp(d.extra.w, 0.0, 1.0) * (0.75 + 0.25 * (1.0 - hN));  // fades after depressurisation
        m.aniso *= 1.0 - frost;
        float crystals = vnoise2(p.xy * 60.0 + p.z * 13.0);
        m.albedo = mix(m.albedo, float3(0.86, 0.88, 0.90) * (0.9 + 0.1 * crystals), frost);
        m.metallic = mix(m.metallic, 0.0, frost);
        m.rough = mix(m.rough, 0.75, frost);
        h += frost * (0.002 + 0.002 * crystals);
    } else if (kind == 12) {
        // ---- flowing trench water: scrolling ripples along +X, foam where the plume hits it ----
        float2 p = wpAbs.xz;
        float t = f.sky.z;
        float h1 = fbm2(float2(p.x * 0.9 - t * 2.4, p.y * 1.6), 3);
        float h2 = vnoise2(float2(p.x * 3.1 - t * 3.6, p.y * 4.0 + t * 0.4));
        h = (h1 - 0.5) * 0.05 + (h2 - 0.5) * 0.015;
        float boil = f.pad2.z * (1.0 - smoothstep(1.5, 9.0, length(p - f.pad.xy)));
        float foam = clamp(smoothstep(0.55, 0.8, h1 + 0.3 * h2) * 0.35 + boil * (0.6 + 0.4 * h2), 0.0, 1.0);
        h += boil * (h2 - 0.5) * 0.08;
        m.albedo = mix(m.albedo, float3(0.85, 0.87, 0.88), foam);
        m.rough = mix(0.04, 0.6, foam);
        m.metallic = 0.0;
    } else if (kind == 13) {
        // ---- landing zone: concrete with a painted target (ring, centre ring, cross) + scorch ----
        float2 p = wpAbs.xz;
        float2 q = p - float2(-400.0, -300.0);            // TV1Site.landingZone
        float r = length(q);
        float n1 = fbm2(p * 0.35, 4);
        float n2 = fbm2(p * 3.1, 3);
        m.albedo *= 0.82 + 0.28 * n1 + 0.1 * (n2 - 0.5);
        float4 dt = detailTex.sample(detS, p * 0.07);
        m.albedo *= 1.0 - 0.4 * dt.g;
        h -= dt.g * 0.004;
        float ring = smoothstep(0.03, 0.0, abs(r - 9.2) - 0.3) + smoothstep(0.03, 0.0, abs(r - 2.6) - 0.18);
        float crossMark = smoothstep(0.03, 0.0, min(abs(q.x), abs(q.y)) - 0.18) * step(r, 6.5) * step(3.2, r);
        float paint = clamp(ring + crossMark, 0.0, 1.0) * (1.0 - 0.35 * smoothstep(0.6, 0.8, n2));
        m.albedo = mix(m.albedo, float3(0.86, 0.86, 0.84), paint);
        m.rough = mix(m.rough, 0.55, paint);
        float rr = length(p - f.pad.xy);
        float scorch = f.pad.w * (1.0 - smoothstep(1.0, 7.0, rr + (n1 - 0.5) * 2.0));
        m.albedo = mix(m.albedo, float3(0.04, 0.035, 0.03), clamp(scorch, 0.0, 0.9));
    } else if (kind == 7) {
        // ---- ploughed field: furrows (faded with distance to avoid aliasing), clods, moisture patches ----
        float2 p = wpAbs.xz;
        float fw = fwidth(p.y);
        float furrowAmp = 1.0 - smoothstep(0.08, 0.35, fw);
        float fr = sin(p.y * 6.2831853 / 0.9 + vnoise2(p * 0.05) * 3.0);
        float n1 = fbm2(p * 0.02, 4);
        float n2 = fbm2(p * 1.7, 3);
        float clods = vnoise2(p * 9.0);
        m.albedo *= (0.82 + 0.3 * n1) * (1.0 + 0.12 * fr * furrowAmp) * (0.92 + 0.16 * n2);
        m.albedo = mix(m.albedo, m.albedo * float3(0.75, 0.72, 0.7), smoothstep(0.55, 0.75, n1)); // damp patches
        m.rough = clamp(0.92 + 0.06 * (n2 - 0.5), 0.8, 1.0);
        h = (fr * 0.035 + (clods - 0.5) * 0.01) * furrowAmp;
        m.ao *= 1.0 - 0.25 * furrowAmp * (0.5 - 0.5 * fr);
        // beyond the ploughed ring: dry Texas grassland floor (instanced blades sit on top near the stand)
        float rr = length(p);
        float grassMix = smoothstep(28.0, 34.0, rr + (n1 - 0.5) * 10.0);
        float3 dry = mix(float3(0.34, 0.31, 0.17), float3(0.40, 0.37, 0.22), n2) * (0.85 + 0.3 * n1);
        m.albedo = mix(m.albedo, dry, grassMix);
        h *= 1.0 - grassMix;
        m.rough = mix(m.rough, 0.9, grassMix);
    } else if (kind == 8) {
        // ---- weathered structural concrete: vertical rain streaks, rust bleed, orange marker bands, form lines ----
        float3 p = wpAbs;
        float horiz = p.x + p.z;
        float streak = fbm2(float2(horiz * 2.2, p.y * 0.12), 4);
        float stain = smoothstep(0.55, 0.8, fbm2(float2(horiz * 0.6, p.y * 0.35) + 3.1, 4));
        float n2 = fbm3(p * 3.0, 3);
        m.albedo *= (0.78 + 0.32 * streak) * (0.9 + 0.2 * n2);
        m.albedo = mix(m.albedo, float3(0.33, 0.22, 0.15), stain * 0.55);
        // painted orange/red marker bands on the legs (as on the McGregor stands), chipped
        float band = step(0.5, fract(p.y / 1.6)) * step(fract(p.y / 9.6), 0.5) * step(p.y, 36.0);
        float chip = smoothstep(0.55, 0.65, n2);
        m.albedo = mix(m.albedo, float3(0.55, 0.20, 0.08), band * 0.55 * (1.0 - chip) * step(6.8, abs(p.x)));
        float form = 1.0 - smoothstep(0.0, 0.02, abs(fract(p.y / 1.2) - 0.5) - 0.48);
        h = form * 0.004 + (n2 - 0.5) * 0.004;
        m.rough = clamp(m.rough + 0.1 * (streak - 0.5), 0.6, 1.0);
        m.ao *= 0.85 + 0.15 * streak;
        float lc = detailTex.sample(detS, float2(horiz, p.y) * 0.11).g;
        m.albedo *= 1.0 - 0.4 * lc;
        h -= lc * 0.004;
    }

    m.N = perturbNormal(Ng, in.worldPos, h);

    float3 N = m.N;
    float NoV = clamp(dot(N, V), 1e-4, 1.0);
    float a = max(m.rough * m.rough, 0.002);
    float3 f0 = mix(float3(0.04), m.albedo, m.metallic);
    float3 diffColor = m.albedo * (1.0 - m.metallic);

    float3 color = float3(0.0);

    // key light (directional) with soft PCF shadows
    {
        float3 L = normalize(f.lightDir.xyz);
        float NoL = clamp(dot(N, L), 0.0, 1.0);
        if (NoL > 0.0) {
            int taps = f.misc.w > 1.5 ? 16 : (f.misc.w > 0.5 ? 12 : 8);
            float sh = shadowFactor(shadowMap, in.shadowPos, f.misc.x, in.position.xy, taps);
            float3 H = normalize(L + V);
            float NoH = clamp(dot(N, H), 0.0, 1.0);
            float VoH = clamp(dot(V, H), 0.0, 1.0);
            float3 F = F_Schlick(f0, VoH);
            float D = D_GGX(NoH, a);
            if (m.aniso > 0.01) {
                // brushed metal: tangent along the brushing (horizontal around upright parts)
                float3 Tg = cross(float3(0.0, 1.0, 0.0), N);
                float tl = length(Tg);
                if (tl > 0.2) {
                    Tg /= tl;
                    float3 Bg = cross(N, Tg);
                    float at = max(a * mix(1.0, 0.45, m.aniso), 0.002);
                    float ab = min(a * mix(1.0, 2.4, m.aniso), 1.0);
                    float th = dot(Tg, H) / at, bh = dot(Bg, H) / ab;
                    float dd = th * th + bh * bh + NoH * NoH;
                    D = 1.0 / (M_PI_F * at * ab * dd * dd + 1e-7);
                }
            }
            float3 spec = D * V_SmithGGXCorrelated(NoV, NoL, a) * F;
            float3 diff = diffColor * (1.0 / M_PI_F) * (1.0 - F);
            color += (diff + spec) * f.lightColor.rgb * f.lightDir.w * NoL * sh;
        }
    }
    // plume point lights (exhaust column and impingement zone)
    for (int li = 0; li < 2; li++) {
        float4 pl = li == 0 ? f.plumeLight0 : f.plumeLight1;
        float3 pc = li == 0 ? f.plumeLight0Color.rgb : f.plumeLight1Color.rgb;
        if (pl.w <= 0.0) continue;
        float3 Lv = pl.xyz - in.worldPos;
        float dist2 = max(dot(Lv, Lv), 0.25);
        float3 L = Lv * rsqrt(dist2);
        float NoL = clamp(dot(N, L), 0.0, 1.0);
        float3 H = normalize(L + V);
        float NoH = clamp(dot(N, H), 0.0, 1.0);
        float VoH = clamp(dot(V, H), 0.0, 1.0);
        float3 F = F_Schlick(f0, VoH);
        float a2 = max(a, 0.08); // large emitter: widen the lobe
        float3 spec = D_GGX(NoH, a2) * V_SmithGGXCorrelated(NoV, NoL, a2) * F;
        float3 diff = diffColor * (1.0 / M_PI_F) * (1.0 - F);
        color += (diff + spec) * pc * (pl.w / dist2) * NoL;
    }
    // image-based ambient: prefiltered specular cube + diffuse from the lowest mip
    {
        float mips = max(f.misc.y - 1.0, 1.0);
        float3 R = reflect(-V, N);
        float3 pre = envMap.sample(envS, R, level(m.rough * mips)).rgb;
        float3 irr = envMap.sample(envS, N, level(mips)).rgb;
        float3 specAmb = pre * envBRDFApprox(f0, m.rough, NoV);
        float specOcc = clamp(pow(NoV + m.ao, exp2(-16.0 * a - 1.0)) - 1.0 + m.ao, 0.0, 1.0);
        color += (diffColor * irr * m.ao + specAmb * specOcc) * f.sky.w;
    }
    color += m.emissive;

    // selection highlight: thin fresnel rim
    if (d.params.w > 0.0) {
        float rim = pow(1.0 - NoV, 3.0);
        color += float3(0.25, 0.55, 1.0) * rim * d.params.w * 1.2;
    }
    if (d.extra.x > 0.5) {
        color = mix(color, float3(0.3, 0.6, 1.0) * 0.6, 0.35);
    }
    // light haze in the hangar air
    float dist = length(in.worldPos);
    if (f.scene.x > 0.5) {
        // outdoor aerial perspective: hazy toward the horizon colour of the sky
        float fogO = 1.0 - exp(-dist * 0.0015);
        float3 hz = skyRadiance(normalize(float3(in.worldPos.x, 0.0, in.worldPos.z) + float3(0.0, 0.03, 0.0)), f.sky.x, f.sky.y, f.sky.z);
        color = mix(color, hz, fogO * 0.7);
    } else {
        float fog = 1.0 - exp(-dist * 0.004);
        color = mix(color, float3(0.55, 0.6, 0.68) * f.sky.w, fog * 0.6);
    }
    return float4(color, 1.0);
}

// ---------- sky ----------
vertex FSQOut fullscreenVertex(uint vid [[vertex_id]]) {
    FSQOut o;
    float2 p = float2((vid << 1) & 2, vid & 2);
    o.position = float4(p * 2.0 - 1.0, 0.0, 1.0);
    o.uv = float2(p.x, 1.0 - p.y);
    return o;
}

struct SkyVOut { float4 position [[position]]; float2 ndc; };

vertex SkyVOut skyVertex(uint vid [[vertex_id]]) {
    SkyVOut o;
    float2 p = float2((vid << 1) & 2, vid & 2) * 2.0 - 1.0;
    o.position = float4(p, 1.0, 1.0);
    o.ndc = p;
    return o;
}

fragment float4 skyFragment(SkyVOut in [[stage_in]], constant FrameUniforms& f [[buffer(1)]]) {
    float4 w = f.invViewProj * float4(in.ndc, 1.0, 1.0);
    float3 d = normalize(w.xyz / w.w);
    return float4(skyRadiance(d, f.sky.x, f.sky.y, f.sky.z), 1.0);
}
