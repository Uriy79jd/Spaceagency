#include "ShaderCommon.h"

// Raymarched volumetric exhaust, rendered at HALF resolution into the translucent target and upsampled
// onto the HDR image. Two proxy volumes:
//   mode 0  free jet: starts at the throat inside the bell (white-hot core filling the nozzle), translucent
//           blue supersonic core with a lace sheath, a chain of arrowhead Mach diamonds at physical (~3 D)
//           spacing, then a narrow, see-through pink/lavender column of stretched fibres and billows.
//           The jet is clipped against the stand's signed-distance field: it never passes through the pad,
//           the deflector curbs or the legs, and flattens/brightens into a stagnation zone at the hit point.
//   mode 1  ground interaction: stagnation disk + radial wall jet that hugs every surface (distance to the
//           nearest surface from the SDF), thinning and cooling white -> orange, rolling/lifting at its edge.
// Turbulence comes from the precomputed 3D Perlin-Worley noise texture (2 samples per step).

struct PlumeVOut {
    float4 position [[position]];
    float3 worldPos;
};

constant float3 cubeVerts[8] = {
    float3(0,0,0), float3(1,0,0), float3(0,1,0), float3(1,1,0),
    float3(0,0,1), float3(1,0,1), float3(0,1,1), float3(1,1,1)
};
constant ushort cubeIdx[36] = {
    0,2,1, 1,2,3,  4,5,6, 5,7,6,  0,1,4, 1,5,4,  2,6,3, 3,6,7,  0,4,2, 2,4,6,  1,3,5, 3,7,5
};

vertex PlumeVOut plumeVertex(uint vid [[vertex_id]],
                             constant FrameUniforms& f [[buffer(1)]],
                             constant PlumeUniforms& u [[buffer(2)]]) {
    float3 c = cubeVerts[cubeIdx[vid]];
    float3 p = mix(u.boundsMin.xyz, u.boundsMax.xyz, c);
    PlumeVOut o;
    o.position = f.viewProj * float4(p, 1.0);
    o.worldPos = p;
    return o;
}

struct PlumeOut {
    float4 color [[color(0)]];
    float4 distort [[color(1)]];
};

inline bool rayBox(float3 ro, float3 rd, float3 bmin, float3 bmax, thread float& t0, thread float& t1) {
    float3 inv = 1.0 / rd;
    float3 a = (bmin - ro) * inv;
    float3 b = (bmax - ro) * inv;
    float3 lo = min(a, b), hi = max(a, b);
    t0 = max(max(lo.x, lo.y), lo.z);
    t1 = min(min(hi.x, hi.y), hi.z);
    return t1 > max(t0, 0.0);
}

// Distance from the camera to the opaque scene behind this half-res pixel.
inline float sceneDistanceHalf(depth2d<float> depth, float4 fragPos, constant FrameUniforms& f) {
    uint2 px = uint2(fragPos.xy * 2.0);
    px = min(px, uint2(depth.get_width() - 1, depth.get_height() - 1));
    float dz = depth.read(px);
    if (dz >= 1.0) return 1e9;
    float2 uv = (float2(px) + 0.5) * f.screen.zw;
    float4 w = f.invViewProj * float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, dz, 1.0);
    return length(w.xyz / w.w);
}

// Interior radius of the bell as a function of distance below the throat (0 … 1.54 m to the exit plane).
inline float bellInteriorRadius(float d) {
    float t = clamp(d / 1.54, 0.0, 1.0);
    return 0.125 + 0.526 * (1.0 - pow(1.0 - t, 2.2));
}

inline float surfaceDistance(float3 pw, bool outdoor, constant SiteShapes& site) {
    return outdoor ? siteSDF(pw, site) : pw.y;
}

fragment PlumeOut plumeFragment(PlumeVOut in [[stage_in]],
                                constant FrameUniforms& f [[buffer(1)]],
                                constant PlumeUniforms& u [[buffer(2)]],
                                constant SiteShapes& site [[buffer(3)]],
                                depth2d<float> depth [[texture(0)]],
                                texture3d<float> noiseTex [[texture(1)]],
                                texture3d<float> detailTex [[texture(2)]]) {
    PlumeOut o;
    o.color = float4(0.0);
    o.distort = float4(0.0);
    float3 rd = normalize(in.worldPos);
    float t0, t1;
    if (!rayBox(float3(0.0), rd, u.boundsMin.xyz, u.boundsMax.xyz, t0, t1)) return o;
    t0 = max(t0, 0.0);
    t1 = min(t1, sceneDistanceHalf(depth, in.position, f));
    if (t1 <= t0) return o;

    bool outdoor = f.scene.x > 0.5;
    float3 camW = f.cameraWorld.xyz;
    float time = u.anim.x;
    float bright = u.look.y;
    float Re = u.exitPos.w;
    float Rj = u.shape.x;
    float s = max(u.shape.y, 0.3);
    float dstr = u.shape.z;
    float spreadTan = u.shape.w;
    float vac = u.look.x;
    float after = u.look.z;
    float L = max(u.axis.w, 1.0);
    float zImp = u.axisFar.w;
    float3 axis = u.axis.xyz;
    float3 bend = u.axisFar.xyz - axis;
    float gf = u.ground.w;
    float flash = u.anim.y;
    float rich = u.ground3.w;
    float copper = clamp(u.look.w, 0.0, 1.0);    // engine-rich copper erosion: green emission
    float air = 1.0 - vac;
    // distance LOD: a far plume covers few pixels, so it gets fewer steps
    float camDist = length(u.exitPos.xyz);
    int steps = max(int(u.anim.z * clamp(140.0 / max(camDist, 1.0), 0.45, 1.0)), 8);
    float jitter = marchJitter(in.position.xy, f.scene.y);

    float3 accum = float3(0.0);
    float T = 1.0;
    float haze = 0.0;

    if (u.anim.w < 0.5) {
        // ---- tighten the march to the jet's bounding cylinder around the axis (big early-out) ----
        float Rmax = u.boundsMin.w;
        float3 oc = -u.exitPos.xyz;
        float3 dperp = oc - axis * dot(oc, axis);
        float3 rperp = rd - axis * dot(rd, axis);
        float qa = dot(rperp, rperp);
        if (qa > 1e-5) {
            float qb = 2.0 * dot(dperp, rperp);
            float qc = dot(dperp, dperp) - Rmax * Rmax;
            float disc = qb * qb - 4.0 * qa * qc;
            if (disc <= 0.0) return o;
            float sq = sqrt(disc);
            t0 = max(t0, (-qb - sq) / (2.0 * qa));
            t1 = min(t1, (-qb + sq) / (2.0 * qa));
            if (t1 <= t0) return o;
        }
        float dt = (t1 - t0) / float(steps);
        float zThroat = -1.54;
        for (int i = 0; i < steps; i++) {
            if (T < 0.03) break;
            float t = t0 + (float(i) + jitter) * dt;
            float3 p = rd * t;
            float3 q = p - u.exitPos.xyz;
            float z0 = dot(q, axis);
            if (z0 < zThroat) continue;
            float3 qc = q - bend * (max(z0, 0.0) * max(z0, 0.0) / (2.0 * L));   // far-field lag
            float z = dot(qc, axis);
            if (z > min(L, zImp + 0.6)) continue;
            float r = length(qc - axis * z);
            // never inside or through solid geometry; fades in the last ~0.6 m above any surface
            float surf = surfaceDistance(p + camW, outdoor, site);
            if (surf <= 0.0) continue;
            float clipK = smoothstep(0.0, 0.6, surf);

            float3 e = float3(0.0);
            float sigma = 0.0;
            if (flash > 0.01) {
                float fl = exp(-(z * z * 1.2 + r * r * 5.0)) * step(r, Re * 1.2);
                e += float3(1.0, 0.85, 1.0) * fl * flash * 260.0;
            }
            if (z < 0.0) {
                // ---- inside the bell: flame from the throat filling the nozzle, white-hot ----
                float Rb = bellInteriorRadius(z - zThroat);
                float x = r / Rb;
                // HOLLOW bell: only a thin, mostly transparent core here so the white-hot liner (drawn as
                // geometry, two-sided) reads through. Dense near the throat, faint mid-bell, thin again at the exit.
                if (x < 0.6) {
                    float core = smoothstep(0.6, 0.05, x);
                    float nearThroat = 1.0 - smoothstep(zThroat, zThroat + 0.55, z);
                    float nearExit = smoothstep(-0.35, 0.0, z);
                    float3 cIn = mix(float3(1.0, 0.95, 0.90), float3(1.0, 0.72, 0.45), rich);
                    e += cIn * core * (1.5 + 30.0 * nearThroat + 8.0 * nearExit) * bright;
                }
            } else {
                // ---- free jet ----
                // Column radius: shock-cell necking, then steady mixing-layer growth (~0.075 m per m, measured from
                // Raptor test-stand footage: ~2.2 exit radii at 8-10 exit diameters), not a fast-spreading cone.
                float Rb = Rj + (Re - Rj) * cos(6.2831853 * z / s) * exp(-z / (2.5 * s));
                float neck = 1.0 - 0.07 * exp(-z / (1.2 * s)) * (1.0 - cos(6.2831853 * z / s));
                float Rbn = Rb * neck;
                float zm = max(z - 0.5 * s, 0.0);
                float grow = 0.075 * min(zm, 24.0) + 0.05 * max(zm - 24.0, 0.0) + 0.12 * Re * smoothstep(0.3 * s, 1.5 * s, z);
                float R = mix(Rbn + grow, Re + z * spreadTan, vac);
                float nearG = smoothstep(zImp - 2.6 * Rj, zImp, z) * gf;          // flattens into the plate shock
                R *= 1.0 + 1.8 * nearG * nearG;
                R = max(R, 0.05);
                float farT = smoothstep(2.0 * s, 7.0 * s, z) * air;
                if (r < R * mix(1.9, 2.2, farT)) {
                    float Rn = max(R, 0.7);
                    float adv = time * 2.6 / (1.0 + 0.04 * z);
                    // 2 noise samples: (1) isotropic eddy-scale warp, (2) the same field stretched ~14x along the
                    // flow, which is what gives the real plume its fibrous, streaky look.
                    float3 tpW = float3(qc.x / (1.1 * Rn), z / (2.5 * Rn) - adv * 0.5, qc.z / (1.1 * Rn));
                    float w = noiseDetail(detailTex, tpW * 0.9) - 0.5;
                    float3 tpF = float3(qc.x / (0.42 * Rn) + w * 1.6, z / (6.0 * Rn) - adv * 0.25, qc.z / (0.42 * Rn) - w * 1.6);
                    float nb = noiseBase(noiseTex, tpF * 0.55).r;
                    // the Perlin-Worley texture is concentrated around 0.74 (sd 0.08): normalise before shaping
                    float fib = smoothstep(-1.3, 1.5, (nb - 0.74) / 0.08);
                    // ragged, eroded edge: grows downstream (wispy, fibrous boundary, no hard shell)
                    float edgeN = (fib - 0.5) * (0.14 + 0.75 * smoothstep(0.3 * s, 3.0 * s, z)) + w * (0.25 + 0.9 * farT);
                    float x = r / R + edgeN;
                    if (x < mix(1.4, 1.7, farT)) {
                        float core = smoothstep(1.0, 0.0, x);
                        float soft = smoothstep(mix(1.12, 1.35, farT), mix(0.55, 0.2, farT), x);
                        // 0 = transparent supersonic core, 1 = fully mixed column
                        float mixT = smoothstep(0.45 * s, 1.6 * s, z) * air;
                        float fade = exp(-z / (0.38 * L)) * (1.0 - smoothstep(0.65 * L, L, z));

                        // (a) supersonic core: translucent blue (the background shows through) + a lace-like
                        // sheath with fine interfering flow ripples in the first ~1.5 nozzle diameters
                        float3 cBlue = mix(mix(float3(0.34, 0.50, 1.0), float3(1.0, 0.55, 0.22), rich), float3(0.3, 1.0, 0.5), copper);
                        float cone = core * (1.0 - mixT) * exp(-z / (1.4 * s));
                        e += cBlue * cone * 3.0 * bright;
                        sigma += cone * 0.012;
                        float az = atan2(qc.x, qc.z);
                        float rip = 0.5 + 0.5 * sin(az * 23.0 + z * 7.5 + 9.0 * w) * sin(az * 9.0 - z * 3.1 + 5.0 * w);
                        float shell = (r / max(Rbn, 0.05) - 0.96) / 0.07;
                        float sheath = exp(-shell * shell) * exp(-z / (1.6 * s)) * (0.25 + 0.75 * rip * rip) * (1.0 - 0.8 * mixT);
                        e += mix(float3(0.30, 0.55, 1.0), float3(1.0, 0.5, 0.2), rich) * sheath * 9.0 * bright;

                        // (b) Mach diamonds: arrowheads, apex upstream, soft bright base downstream. Spacing is the
                        // physical ~3 exit diameters; each cell is weaker than the last (6 cells at most).
                        float kf = clamp(floor(z / s - 0.05), 0.0, 5.0);
                        float zk = s * (0.62 + kf);
                        float dia = 0.0;
                        float wedge = 0.0;
                        if (!(zk > zImp - 0.3 && gf > 0.05)) {
                            float hk = 0.40 * s;
                            float wr = (0.42 - 0.03 * kf) * max(Rbn, Re * 0.9);
                            float dd = (z - (zk - hk)) / hk;
                            float rad = r / (max(dd, 0.03) * wr);
                            wedge = smoothstep(0.0, 0.06, dd) * smoothstep(1.10, 0.92, dd) * smoothstep(1.02, 0.80, rad)
                                  * (0.25 + 0.75 * pow(clamp(dd, 0.0, 1.0), 1.5));
                            float dzk = (z - zk) / (0.10 * s);
                            float disk = exp(-dzk * dzk - pow(r / (0.62 * wr), 2.0));
                            dia = (wedge * 0.8 + disk * 0.55) * pow(0.62, kf);
                        }
                        dia *= 1.0 - 0.35 * mixT;
                        float3 cDia = mix(float3(0.70, 0.80, 1.0), float3(1.0, 0.95, 1.0), clamp(wedge, 0.0, 1.0));
                        cDia = mix(cDia, float3(1.0, 0.65, 0.35), rich);
                        e += cDia * dia * dstr * 48.0 * bright;

                        // (c) mixed column: translucent pink / lavender gas, streaky fibres + large billows. Thin
                        // gas is pink-magenta (bluish right behind the shock train, salmon far downstream), dense
                        // cores scatter whiter. Emission is LOW and absorption modest: the column stays see-through
                        // and the diamonds stay visible inside it, instead of clipping to opaque cream.
                        float billow = 0.25 + 1.0 * smoothstep(-1.2, 1.4, w / 0.11);
                        float dens = soft * mixT * fade * (0.06 + 1.5 * pow(fib, 1.9)) * billow;
                        dens *= 1.0 - 0.55 * smoothstep(0.8, 1.3, x);
                        float whiteness = smoothstep(0.2, 1.2, dens * 1.6) * (1.0 - smoothstep(0.5, 1.15, x) * 0.6);
                        float3 cThin = mix(float3(0.86, 0.30, 0.62), float3(1.0, 0.50, 0.46), smoothstep(2.0 * s, 8.0 * s, z) * after * 0.7);
                        cThin = mix(cThin, float3(0.55, 0.42, 1.0), (1.0 - smoothstep(0.3 * s, 2.2 * s, z)) * 0.8);
                        float3 cDense = mix(float3(0.92, 0.80, 1.0), float3(1.0, 0.78, 0.80), smoothstep(2.0 * s, 9.0 * s, z) * 0.7);
                        float3 cMix = mix(cThin, cDense, whiteness);
                        cMix = mix(cMix, float3(1.0, 0.45, 0.15), rich);
                        cMix = mix(cMix, float3(0.35, 1.0, 0.45), copper * (0.55 + 0.45 * fib));
                        // ground approach: the column turns orange-brown and smoky before it hits the pad
                        cMix = mix(cMix, float3(1.0, 0.47, 0.20), nearG * 0.6);
                        float spread = mix(1.0, clamp(2.5 * Rj / R, 0.30, 1.0), farT);
                        e += cMix * dens * 5.5 * bright * spread;
                        sigma += dens * 0.8;
                        // afterburning billows: orange fire balls rolling out of the column where it meets the pad
                        float burn = nearG * soft * smoothstep(0.35, 0.85, fib) * after;
                        e += float3(1.0, 0.50, 0.18) * burn * 16.0 * bright;
                        sigma += burn * 0.5;

                        // vacuum: wide, faint, smooth
                        float vplume = soft * vac * exp(-z / (0.35 * L));
                        e += float3(0.55, 0.5, 0.95) * vplume * 1.2 * bright;

                        // compressed, brightened stagnation zone right above the hit point
                        e += float3(1.0, 0.86, 0.85) * nearG * soft * 7.0 * bright;
                        haze += (soft * fade + cone) * dt * clipK;
                    }
                }
            }
            e *= clipK;
            sigma *= clipK;
            accum += T * e * dt;
            T *= exp(-sigma * dt);
        }
    } else {
        // ================= ground interaction: stagnation + radial wall jet hugging every surface =================
        float Rw = max(u.ground2.x, 1.0);
        float uVis = u.ground2.y;
        float ringAge = u.ground2.z;
        float tiltS = u.ground2.w;
        float2 hAxis = u.ground3.xy;
        float rj = max(Rj, Re) * 1.15;
        float3 impW = u.ground.xyz + camW;
        float dt = (t1 - t0) / float(steps);
        for (int i = 0; i < steps; i++) {
            if (T < 0.03) break;
            float t = t0 + (float(i) + jitter) * dt;
            float3 p = rd * t;
            float3 pw = p + camW;
            float hgt = surfaceDistance(pw, outdoor, site);          // distance to the nearest surface
            if (hgt <= 0.0) continue;
            float2 rel = pw.xz - impW.xz;
            float r = length(rel);
            float2 er = r > 1e-3 ? rel / r : float2(1.0, 0.0);
            float asym = max(1.0 + 2.5 * tiltS * dot(er, hAxis), 0.25);
            float rEff = r / sqrt(asym);
            float yAbove = max(pw.y - impW.y, 0.0);

            float scale = 1.0 / (1.6 + 0.12 * r);
            float3 nq = float3((rel.x - er.x * time * uVis * 0.5) * scale, yAbove * 1.4 * scale - time * 0.2,
                               (rel.y - er.y * time * uVis * 0.5) * scale);
            float turb = 0.5;
            if (r < Rw * 1.2 && yAbove < 0.45 * Rw + 1.5) {
                float2 nb = noiseBase(noiseTex, nq);
                turb = clamp((nb.r - 0.3) * 1.5, 0.0, 1.0);
            }

            float stag = exp(-pow(r / (rj * 1.15), 4.0)) * exp(-yAbove / 0.45);
            float delta = 0.3 + 0.11 * rEff;
            delta *= 1.0 + 1.4 * smoothstep(0.45 * Rw, Rw, rEff);                 // thickens / rolls up at its edge
            float on = smoothstep(0.4 * rj, 1.2 * rj, r);
            float decay = pow(rj / max(rEff, rj), 1.1);
            float reach = 1.0 - smoothstep(0.55 * Rw, Rw, rEff + (turb - 0.5) * Rw * 0.3);
            float wall = on * decay * reach * exp(-hgt / delta) * smoothstep(0.0, 0.05, hgt) * (0.3 + 1.4 * turb * turb);
            // rolling vortex ring lifting into billows at the outer edge
            float ringR = 0.78 * Rw;
            float ringH = 0.10 * Rw + 0.6;
            float dr = (rEff - ringR) / (0.20 * Rw);
            float dh = (yAbove - ringH) / (0.12 * Rw + 0.5);
            float edge = exp(-dr * dr - dh * dh) * smoothstep(0.35, 0.75, turb);

            float cool = clamp(r / (0.6 * Rw), 0.0, 1.0);
            float3 cStag = mix(float3(1.0, 0.90, 0.95), float3(1.0, 0.6, 0.3), rich);
            float3 cHot = mix(float3(1.0, 0.90, 0.85), float3(1.0, 0.50, 0.22), cool);
            // afterburning: fuel-rich gas re-ignites in the entrained air -> rolling orange billows
            float fire = wall * smoothstep(0.45, 0.85, turb) * smoothstep(0.15, 0.6, cool) * after;
            float3 e = cStag * stag * 45.0 + cHot * wall * 9.0 * (0.6 + 0.4 * after) * (1.0 - 0.5 * cool)
                     + float3(1.0, 0.48, 0.16) * fire * 14.0
                     + float3(1.0, 0.52, 0.26) * edge * (1.6 + 5.0 * after);
            if (ringAge < 0.5) {
                float rr = rj + 55.0 * pow(ringAge, 0.7);
                float ring = exp(-pow((r - rr) / (0.6 + rr * 0.08), 2.0)) * exp(-hgt / 0.8) * (1.0 - ringAge / 0.5);
                e += float3(1.0, 0.75, 0.6) * ring * 10.0;
            }
            float sigma = (wall * 0.6 + edge * 0.5 + stag * 0.3) * gf;
            accum += T * e * bright * gf * dt;
            T *= exp(-sigma * dt);
            haze += (wall * 2.0 + stag * 2.0 + edge) * gf * dt;
        }
    }
    o.color = float4(accum, 1.0 - T);
    o.distort = float4(min(haze * 0.12, 0.8), 0.0, 0.0, 0.0);
    return o;
}
