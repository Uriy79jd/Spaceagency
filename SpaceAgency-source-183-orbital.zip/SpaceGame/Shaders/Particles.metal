#include "ShaderCommon.h"

// GPU particle system: fixed-size ring buffer of GPUParticle, spawned from a small per-frame CPU queue,
// integrated + collided here (radial wall-jet flow field, buoyancy, gravity, collisions with the pad,
// flame-trench walls and stand legs via siteSDF), and drawn as camera-facing billboards into the
// half-resolution translucent target.

kernel void particleSpawn(device GPUParticle* parts [[buffer(0)]],
                          const device ParticleSpawn* sp [[buffer(1)]],
                          constant ParticleSimUniforms& u [[buffer(2)]],
                          uint id [[thread_position_in_grid]]) {
    if (id >= uint(u.counts.y)) return;
    ParticleSpawn s = sp[id];
    uint slot = min(s.slot.x, uint(u.counts.x) - 1u);
    parts[slot] = s.p;
}

// Gas velocity the particle is dragged toward: radial wall jet hugging the pad, lifting at its edge,
// entrainment toward the column above it.
inline float3 flowAt(float3 pos, constant ParticleSimUniforms& u) {
    float2 rel = pos.xz - u.imp.xz;
    float r = max(length(rel), 0.01);
    float2 er = rel / r;
    float rj = u.jet.x, rw = max(u.jet.y, 1.0), u0 = u.jet.z;
    float asym = max(1.0 + 2.5 * u.tilt.z * dot(er, u.tilt.xy), 0.25);
    float hgt = max(pos.y - u.imp.y, 0.0);
    float delta = 0.4 + 0.09 * r;
    if (hgt < delta * 3.0 && r < rw * 1.8) {
        float sp = u0 * asym * pow(min(1.0, rj / r), 0.8) * exp(-hgt / (delta * 2.0));
        float lift = r > rw * 0.6 ? 0.35 * sp : 0.05 * sp;
        return float3(er.x * sp, lift, er.y * sp) * u.counts.w + u.wind.xyz;
    }
    // entrainment toward the jet column higher up, weak buoyant drift everywhere, carried by the wind
    return float3(-er.x * 0.8, 0.4, -er.y * 0.8) * u.counts.w + u.wind.xyz;
}

kernel void particleUpdate(device GPUParticle* parts [[buffer(0)]],
                           constant ParticleSimUniforms& u [[buffer(2)]],
                           constant SiteShapes& site [[buffer(3)]],
                           uint id [[thread_position_in_grid]]) {
    if (id >= uint(u.counts.x)) return;
    GPUParticle q = parts[id];
    if (q.posLife.w <= 0.0) return;
    float dt = u.imp.w;
    float age = q.velAge.w + dt;
    if (age >= q.posLife.w) {
        q.posLife.w = 0.0;
        parts[id] = q;
        return;
    }
    float3 pos = q.posLife.xyz;
    float3 vel = q.velAge.xyz;
    int kind = int(q.params.x + 0.5);
    float life = q.posLife.w;
    bool ballistic = (kind == 3 || kind == 4 || kind == 5);
    if (ballistic) {
        vel *= 1.0 - min(1.0, 0.25 * dt);
        vel.y -= 9.81 * dt;
    } else {
        float3 w = flowAt(pos, u);
        float k = kind == 0 ? 1.6 : (kind == 1 ? 2.5 : 0.9);
        vel += (w - vel) * min(1.0, k * dt);
        if (kind == 0) vel.y -= 0.9 * dt;                                 // cold vapour sinks
        else if (kind == 1) vel.y -= 1.5 * dt;                            // grit settles
        else vel.y += 1.6 * dt * (1.0 - age / life);                      // hot gas / steam rises
        // gentle turbulence so billows don't move in lock-step
        float s = q.params.w * 6.2831853;
        vel.xz += float2(sin(age * 1.3 + s), cos(age * 1.1 + s * 1.7)) * 0.6 * dt;
    }
    float3 np = pos + vel * dt;
    // collisions: never pass through the pad, trench walls or legs
    float rad = ballistic ? 0.03 : 0.15;
    bool outdoor = u.axis.w > 0.5;
    float d = outdoor ? siteSDF(np, site) : np.y;
    if (d < rad) {
        float3 n = outdoor ? siteNormal(np, site) : float3(0.0, 1.0, 0.0);
        np += n * (rad - d);
        float vn = dot(vel, n);
        if (vn < 0.0) {
            float3 vt = vel - n * vn;
            if (ballistic) {
                vel = vt * 0.7 - n * vn * 0.3;                            // bounce, lose energy
            } else {
                vel = vt * 1.05;                                          // gas slides along the surface
            }
        }
    }
    q.posLife.xyz = np;
    q.velAge = float4(vel, age);
    parts[id] = q;
}

// ---------- rendering ----------
struct ParticleVOut {
    float4 position [[position]];
    float2 corner;
    float4 color;          // rgb albedo (lit) or emission (additive), a opacity
    float4 params;         // x lit, y seed, z soft edge (1) / hard (0), w kind
    float3 worldPos;       // camera-relative
    float size;
    float age;
};

vertex ParticleVOut particleVertex(uint vid [[vertex_id]], uint iid [[instance_id]],
                                   constant FrameUniforms& f [[buffer(1)]],
                                   const device GPUParticle* parts [[buffer(2)]],
                                   constant ParticleSimUniforms& u [[buffer(3)]]) {
    ParticleVOut o;
    GPUParticle pp = parts[iid];
    o.corner = float2(0.0);
    o.color = float4(0.0);
    o.params = float4(0.0);
    o.worldPos = float3(0.0);
    o.size = 0.0;
    o.age = 0.0;
    if (pp.posLife.w <= 0.0 || iid >= uint(u.counts.x)) {
        o.position = float4(0.0, 0.0, -2.0, 1.0);     // culled
        return o;
    }
    int kind = int(pp.params.x + 0.5);
    float life = pp.posLife.w;
    float age = pp.velAge.w;
    float t = clamp(age / life, 0.0, 1.0);
    float size = mix(pp.params.y, pp.params.z, sqrt(t));
    float fadeIn = min(1.0, age / 0.15);
    float seed = pp.params.w;
    float rich = u.counts.z;
    float4 color;
    float lit = 1.0;
    float softEdge = 1.0;
    if (kind == 0) {
        color = float4(0.92, 0.94, 0.97, 0.24 * fadeIn * (1.0 - t) * (1.0 - t));
    } else if (kind == 1) {
        color = float4(0.55, 0.50, 0.45, 0.11 * fadeIn * (1.0 - t));
    } else if (kind == 2) {
        float a = 0.11 * fadeIn * (1.0 - t) * min(1.0, (1.0 - t) * 3.0);
        color = float4(0.82, 0.80, 0.78, a);
    } else if (kind == 3) {
        float heat = 1.0 - t;
        color = float4(14.0 * heat + 2.0, 6.0 * heat * heat + 0.6, 1.5 * heat * heat * heat + 0.1, 0.0);
        // engine-rich: hot sparks pick up the copper-green of the eroding liner
        color.rgb = mix(color.rgb, float3(3.0 * heat + 0.4, 12.0 * heat + 1.2, 3.5 * heat * heat + 0.3), clamp(rich, 0.0, 1.0) * 0.7);
        lit = 0.0; softEdge = 0.0;
    } else if (kind == 5) {
        // copper burning: vivid green / white sparks; brighter and greener the more engine-rich the mixture
        // (the green-spark emitter only runs while engineRich > 0.15, so this ramps from its onset)
        float heat = 1.0 - t;
        float rk = clamp(rich, 0.0, 1.0);
        color = float4(2.0 * heat * heat + 0.3, 16.0 * heat + 1.5, 5.0 * heat * heat + 0.4, 0.0) * (0.55 + 0.9 * rk);
        color.rgb = mix(color.rgb, color.ggg * float3(0.85, 1.0, 0.9), (1.0 - heat) * 0.25 * (1.0 - rk));   // cooling: whiter
        lit = 0.0; softEdge = 0.0;
    } else {
        // debris: dark, glowing green-hot while the liner burns
        color = float4(0.08, 0.075, 0.07, 0.95 * (1.0 - t * t));
        softEdge = 0.0;
    }
    float3 rel = pp.posLife.xyz - f.cameraWorld.xyz;
    // stretch fast sparks along their motion (cheap motion blur)
    float2 c = float2(float(vid & 1u), float((vid >> 1u) & 1u)) * 2.0 - 1.0;
    float rot = seed * 6.2831853 + age * (seed - 0.5) * 0.6;
    float2 rc = float2(c.x * cos(rot) - c.y * sin(rot), c.x * sin(rot) + c.y * cos(rot));
    float3 right = float3(f.view[0][0], f.view[1][0], f.view[2][0]);
    float3 up = float3(f.view[0][1], f.view[1][1], f.view[2][1]);
    float3 wp = rel + (right * rc.x + up * rc.y) * size;
    if (kind == 3 || kind == 5) {
        float3 v = pp.velAge.xyz;
        float3 vs = float3(dot(v, right), dot(v, up), 0.0);
        float sl = length(vs.xy);
        if (sl > 0.5) {
            float2 dir = vs.xy / sl;
            float stretch = min(sl * 0.016, 1.2);
            float along = c.x * dir.x + c.y * dir.y;
            wp = rel + (right * c.x + up * c.y) * size + (right * dir.x + up * dir.y) * along * stretch;
        }
    }
    o.position = f.viewProj * float4(wp, 1.0);
    o.corner = c;
    o.color = color;
    o.params = float4(lit, seed, softEdge, float(kind));
    o.worldPos = wp;
    o.size = size;
    o.age = age;
    return o;
}

struct TransOut {
    float4 color [[color(0)]];
    float4 distort [[color(1)]];
};

fragment TransOut particleFragment(ParticleVOut in [[stage_in]],
                                   constant FrameUniforms& f [[buffer(1)]],
                                   depth2d<float> depth [[texture(0)]],
                                   texture3d<float> noiseTex [[texture(1)]]) {
    TransOut o;
    o.distort = float4(0.0);
    float r = length(in.corner);
    if (r > 1.0) discard_fragment();
    float seed = in.params.y;
    float shape;
    float n = 0.5;
    if (in.params.z > 0.5) {
        // billowy puff: Perlin-Worley eroded disc, slowly evolving
        float3 np = float3(in.corner * 0.32 + seed * 7.3, seed * 3.1 + in.age * 0.04);
        float2 nb = noiseBase(noiseTex, np);
        n = nb.r * 0.75 + nb.g * 0.25;
        shape = smoothstep(1.0, 0.2, r + (0.55 - n) * 1.1);
    } else {
        shape = smoothstep(1.0, 0.0, r);
    }
    // soft depth fade against the scene (translucent target is half resolution)
    uint2 px = uint2(in.position.xy * 2.0);
    float dz = depth.read(min(px, uint2(depth.get_width() - 1, depth.get_height() - 1)));
    float sd = 1e9;
    if (dz < 1.0) {
        float2 uv = (float2(px) + 0.5) * f.screen.zw;
        float4 w = f.invViewProj * float4(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0, dz, 1.0);
        sd = length(w.xyz / w.w);
    }
    float soft = clamp((sd - length(in.worldPos)) / max(in.size * 0.6, 0.15), 0.0, 1.0);
    float alpha = in.color.a * shape * soft;
    float3 col;
    if (in.params.x > 0.5) {
        // sphere-ish normal from the billboard corner: lit tops, darker bases, warm flame light from below
        float3 right = float3(f.view[0][0], f.view[1][0], f.view[2][0]);
        float3 up = float3(f.view[0][1], f.view[1][1], f.view[2][1]);
        float3 V = normalize(-in.worldPos);
        float3 N = normalize(right * in.corner.x + up * in.corner.y + V * sqrt(max(1.0 - r * r, 0.05)));
        float3 L = normalize(f.lightDir.xyz);
        float wrap = clamp((dot(N, L) + 0.6) / 1.6, 0.0, 1.0);
        float dens = 0.55 + 0.9 * n;
        float3 sun = f.lightColor.rgb * f.lightDir.w * (0.18 + 0.42 * wrap) * mix(1.0, 0.75, dens - 0.55);
        float3 amb = mix(float3(0.22, 0.21, 0.20), float3(0.48, 0.52, 0.58), N.y * 0.5 + 0.5) * f.sky.w;
        float3 lit = sun + amb;
        for (int li = 0; li < 2; li++) {
            float4 pl = li == 0 ? f.plumeLight0 : f.plumeLight1;
            float3 pc = li == 0 ? f.plumeLight0Color.rgb : f.plumeLight1Color.rgb;
            float3 Lv = pl.xyz - in.worldPos;
            float d2 = max(dot(Lv, Lv), 1.0);
            float3 Ln = Lv * rsqrt(d2);
            float facing = clamp(dot(N, Ln) * 0.5 + 0.5, 0.0, 1.0);
            float fwd = 0.5 + 0.8 * pow(max(dot(Ln, -V), 0.0), 3.0);
            lit += pc * pl.w / d2 * (0.35 + 0.65 * facing) * fwd * 0.6;
        }
        col = in.color.rgb * lit * alpha;   // premultiplied
        o.distort = float4(alpha * 0.04, 0.0, 0.0, 0.0);
    } else {
        col = in.color.rgb * shape * soft;  // additive emitter (alpha 0)
    }
    o.color = float4(col, alpha);
    return o;
}
