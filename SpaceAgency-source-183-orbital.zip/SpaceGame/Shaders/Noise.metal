#include "ShaderCommon.h"

// Tileable volumetric noise, generated once on the GPU at startup (lifted from Ren's Glass Weather
// volumetric clouds, branch glass-weather, Sky/CloudNoise.metal). Shared by the plume turbulence, the
// exhaust/steam billows (particles) and the sky clouds:
//   noiseBase   64^3 rg16f : R = Perlin-Worley (billowy base shape), G = Worley fbm (low-frequency shape)
//   noiseDetail 32^3 r16f  : Worley fbm for edge erosion
// Both are periodic over the texture, sampled with address::repeat.

inline uint pcg(uint v) {
    uint state = v * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
}
inline uint hash3u(int3 c) {
    return pcg(uint(c.x) * 73856093u ^ pcg(uint(c.y) * 19349663u ^ pcg(uint(c.z) * 83492791u)));
}
inline float3 rand3(int3 c) {
    uint h = hash3u(c);
    uint h2 = pcg(h), h3 = pcg(h2);
    return float3(float(h & 0xFFFFu), float(h2 & 0xFFFFu), float(h3 & 0xFFFFu)) / 65535.0;
}
inline int3 wrap3(int3 c, int period) { return ((c % period) + period) % period; }

// Tileable gradient (Perlin) noise, period in cells. Returns about -1…1.
inline float perlin3(float3 p, int period) {
    int3 i0 = int3(floor(p));
    float3 f = p - floor(p);
    float3 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float n[8];
    for (int k = 0; k < 8; k++) {
        int3 o = int3(k & 1, (k >> 1) & 1, (k >> 2) & 1);
        float3 g = normalize(rand3(wrap3(i0 + o, period) + int3(11, 23, 37)) * 2.0 - 1.0 + 1e-4);
        n[k] = dot(g, f - float3(o));
    }
    float x00 = mix(n[0], n[1], u.x), x10 = mix(n[2], n[3], u.x);
    float x01 = mix(n[4], n[5], u.x), x11 = mix(n[6], n[7], u.x);
    return mix(mix(x00, x10, u.y), mix(x01, x11, u.y), u.z) * 1.6;
}

// Tileable Worley (cellular) noise, inverted F1: 1 at feature points, 0 far from them.
inline float worley3(float3 p, int period) {
    int3 c = int3(floor(p));
    float3 f = p - floor(p);
    float d = 1e9;
    for (int z = -1; z <= 1; z++)
        for (int y = -1; y <= 1; y++)
            for (int x = -1; x <= 1; x++) {
                int3 o = int3(x, y, z);
                float3 fp = float3(o) + rand3(wrap3(c + o, period));
                float3 v = fp - f;
                d = min(d, dot(v, v));
            }
    return 1.0 - clamp(sqrt(d), 0.0, 1.0);
}

inline float worleyFbm(float3 uvw, int freq) {
    return worley3(uvw * float(freq), freq) * 0.625
         + worley3(uvw * float(freq * 2), freq * 2) * 0.25
         + worley3(uvw * float(freq * 4), freq * 4) * 0.125;
}

inline float remapF(float x, float a, float b, float c, float d) { return c + (x - a) * (d - c) / (b - a); }

kernel void noiseBaseKernel(texture3d<float, access::write> out [[texture(0)]],
                           uint3 gid [[thread_position_in_grid]]) {
    uint N = out.get_width();
    if (gid.x >= N || gid.y >= out.get_height() || gid.z >= out.get_depth()) return;
    float3 uvw = (float3(gid) + 0.5) / float(N);
    // Perlin fbm (4 octaves, base period 4)
    float pf = 0.0, amp = 0.5, nrm = 0.0;
    for (int o = 0; o < 4; o++) {
        int per = 4 << o;
        pf += perlin3(uvw * float(per), per) * amp;
        nrm += amp;
        amp *= 0.5;
    }
    pf = clamp(pf / nrm * 0.5 + 0.5, 0.0, 1.0);
    float wf = worleyFbm(uvw, 4);
    // Perlin-Worley: Perlin pushed up where Worley cells are, giving round billows with connected masses
    float pw = clamp(remapF(pf, 0.0, 1.0, wf, 1.0), 0.0, 1.0);
    float lowF = worleyFbm(uvw, 3);
    out.write(float4(pw, lowF, 0.0, 1.0), gid);
}

kernel void noiseDetailKernel(texture3d<float, access::write> out [[texture(0)]],
                             uint3 gid [[thread_position_in_grid]]) {
    uint N = out.get_width();
    if (gid.x >= N || gid.y >= out.get_height() || gid.z >= out.get_depth()) return;
    float3 uvw = (float3(gid) + 0.5) / float(N);
    float w = worleyFbm(uvw, 2);
    out.write(float4(w, 0.0, 0.0, 1.0), gid);
}


// ---------------- 2D tileable material detail map (512² rgba16f, mipmapped), generated once ----------------
// Procedural "texture set" for the PBR materials (no image assets):
//   r = brushed-metal streaks (varies fast along texture y, slowly along x → streaks run along x)
//   g = crack network (Worley F2−F1 edges, masked so only some cells crack)
//   b = low-frequency fbm (stains, roughness variation)
//   a = fine grain
inline float vnoisePer(float2 p, int2 per, int salt) {
    int2 i0 = int2(floor(p));
    float2 f = p - floor(p);
    float2 u = f * f * (3.0 - 2.0 * f);
    int2 i1 = i0 + int2(1, 1);
    int2 a = ((i0 % per) + per) % per, b = ((i1 % per) + per) % per;
    float v00 = rand3(int3(a.x, a.y, salt)).x, v10 = rand3(int3(b.x, a.y, salt)).x;
    float v01 = rand3(int3(a.x, b.y, salt)).x, v11 = rand3(int3(b.x, b.y, salt)).x;
    return mix(mix(v00, v10, u.x), mix(v01, v11, u.x), u.y);
}
inline float worleyEdge2(float2 p, int period) {
    int2 i0 = int2(floor(p));
    float2 f = p - floor(p);
    float d1 = 8.0, d2 = 8.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            int2 c = i0 + int2(x, y);
            int2 w = ((c % period) + period) % period;
            float2 r = rand3(int3(w.x, w.y, 7)).xy;
            float2 d = float2(float(x), float(y)) + r - f;
            float dd = dot(d, d);
            if (dd < d1) { d2 = d1; d1 = dd; } else if (dd < d2) { d2 = dd; }
        }
    }
    return sqrt(d2) - sqrt(d1);
}

kernel void materialDetailKernel(texture2d<float, access::write> outTex [[texture(0)]],
                                 uint2 gid [[thread_position_in_grid]]) {
    uint W = outTex.get_width(), H = outTex.get_height();
    if (gid.x >= W || gid.y >= H) return;
    float2 uv = (float2(gid) + 0.5) / float2(float(W), float(H));
    // brushed streaks
    float br = 0.0, amp = 0.5;
    for (int o = 0; o < 3; o++) {
        int2 per = int2(4 << o, 128 << o);
        br += amp * vnoisePer(uv * float2(per), per, 11 + o);
        amp *= 0.5;
    }
    br /= 0.875;
    // cracks: two scales of cell edges, only where a low-frequency mask allows
    float e1 = worleyEdge2(uv * 10.0, 10);
    float e2 = worleyEdge2(uv * 26.0 + 3.7, 26);
    float mask = vnoisePer(uv * 6.0, int2(6, 6), 3);
    float crack = (1.0 - smoothstep(0.0, 0.045, e1)) * smoothstep(0.45, 0.65, mask)
                + (1.0 - smoothstep(0.0, 0.035, e2)) * smoothstep(0.62, 0.8, mask) * 0.7;
    crack = clamp(crack, 0.0, 1.0);
    // stains / variation
    float fb = 0.0; amp = 0.5;
    for (int o = 0; o < 4; o++) {
        int2 per = int2(4 << o, 4 << o);
        fb += amp * vnoisePer(uv * float2(per), per, 21 + o);
        amp *= 0.5;
    }
    fb /= 0.9375;
    float grain = vnoisePer(uv * 128.0, int2(128, 128), 31) * 0.6 + vnoisePer(uv * 256.0, int2(256, 256), 32) * 0.4;
    outTex.write(float4(br, crack, fb, grain), gid);
}
