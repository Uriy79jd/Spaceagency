import SwiftUI

@main
struct SpaceGameApp: App {
    @StateObject private var controller = GameController()

    var body: some Scene {
        WindowGroup {
            ContentView(controller: controller, ui: controller.ui)
        }
    }
}
