import Foundation

/// Quasi-1D isentropic nozzle relations for a calorically perfect gas.
enum NozzleFlow {
    /// A/A* for Mach M.
    static func areaRatio(mach m: Double, gamma g: Double) -> Double {
        let t = (2 / (g + 1)) * (1 + (g - 1) / 2 * m * m)
        return (1 / m) * pow(t, (g + 1) / (2 * (g - 1)))
    }

    /// Supersonic Mach number for a given area ratio (bisection, robust).
    static func supersonicMach(areaRatio eps: Double, gamma g: Double) -> Double {
        var lo = 1.0001, hi = 50.0
        for _ in 0..<80 {
            let mid = 0.5 * (lo + hi)
            if areaRatio(mach: mid, gamma: g) > eps { hi = mid } else { lo = mid }
        }
        return 0.5 * (lo + hi)
    }

    /// p / p0 for Mach M.
    static func pressureRatio(mach m: Double, gamma g: Double) -> Double {
        pow(1 + (g - 1) / 2 * m * m, -g / (g - 1))
    }

    /// Mach number reached by isentropic expansion from p0 to p.
    static func machFromPressureRatio(p0OverP r: Double, gamma g: Double) -> Double {
        guard r > 1 else { return 0 }
        return sqrt(2 / (g - 1) * (pow(r, (g - 1) / g) - 1))
    }

    /// Prandtl–Meyer function ν(M), radians.
    static func prandtlMeyer(mach m: Double, gamma g: Double) -> Double {
        guard m > 1 else { return 0 }
        let a = sqrt((g + 1) / (g - 1))
        return a * atan(sqrt((g - 1) / (g + 1) * (m * m - 1))) - atan(sqrt(m * m - 1))
    }

    /// Vandenkerckhove function Γ(γ).
    static func vandenkerckhove(_ g: Double) -> Double {
        sqrt(g) * pow(2 / (g + 1), (g + 1) / (2 * (g - 1)))
    }

    /// Momentum part of the thrust coefficient (ideal), for exit/chamber pressure ratio.
    static func momentumThrustCoefficient(peOverPc r: Double, gamma g: Double) -> Double {
        vandenkerckhove(g) * sqrt(2 * g / (g - 1) * (1 - pow(r, (g - 1) / g)))
    }
}
