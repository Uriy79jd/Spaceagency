import Foundation
import simd

/// Orbital flight phases. ASCENT covers liftoff + the gravity turn; the
/// timeline events (below) are what the HUD shows.
enum OrbitalPhase: String {
    case idle = "READY"
    case countdown = "COUNTDOWN"
    case startup = "ENGINE START"
    case ascent = "ASCENT · GRAVITY TURN"
    case meco = "MECO"
    case coast = "COAST"
    case separation = "SEPARATION"
    case ses = "SECOND STAGE IGNITION"
    case s2Burn = "SECOND STAGE BURN"
    case apoapsisCoast = "COAST TO APOAPSIS"
    case circularization = "CIRCULARIZATION"
    case orbit = "ORBIT ACHIEVED"
    case deorbit = "DEORBIT BURN"
    case entryCoast = "ENTRY COAST"
    case preciseLanding = "PRECISE LANDING"
    case landed = "LANDED"
    case safing = "SAFING"
    case done = "SAFED"
    case aborted = "ABORTED"
    case lost = "VEHICLE LOST"
}

/// Orbital flight: couples the ECI rigid body, the 9+1 Raptor models and the
/// tank models at a fixed rate, and runs the autopilot to a 275 x 275 km
/// orbit. Everything is physics-driven: the autopilot only sets throttles,
/// attitude targets and engine start/stop, and it reads
/// `VehicleCapabilities` (detected from the snap stack) — never hard-coded
/// engine counts. Manual control is a stub in this milestone (see
/// `requestManualControl()`): the autopilot stays in charge.
final class OrbitalFlight {
    static let padECI = Planet.launchSiteECI()
    static let countdownLength = 10.0
    static let timelineEvents = ["STARTUP", "IGNITION", "LIFTOFF", "MECO", "SEPARATION", "SES", "CIRCULARIZATION", "ORBIT"]

    // Time warp: unlocks above 10 km AND supersonic (past max-Q). Rates 1/2/4/8x.
    // The warp is implemented in GameEngine by running extra fixed-timestep
    // substeps per frame — the physics dt never changes, so it stays stable.
    static let timeWarpMinAltitudeM = 10_000.0
    static let timeWarpRates: [Double] = [1, 2, 4, 8]
    static let timeWarpAutoDropPhases: Set<OrbitalPhase> = [
        .countdown, .startup, .meco, .separation, .ses, .circularization,
        .orbit, .landed, .aborted, .lost, .deorbit, .preciseLanding]

    let vehicle: OrbitalVehicle
    var booster: OrbitalBooster?
    let surfaces: ImpingementSystem

    // pilot — autopilot only in this milestone; manual is a stub (see below).
    var autopilot = true
    var manualThrottle = 0.7
    var manualStick = SIMD2<Double>(0, 0)

    // state
    private(set) var phase: OrbitalPhase = .idle
    private(set) var phaseTime = 0.0
    private(set) var missionTime = -1.0
    private(set) var maxAltitude = 0.0
    private(set) var events: [String] = []
    private(set) var warnings: [String] = []
    private(set) var countdownClock: Double? = nil
    private(set) var elements = OrbitalElements.from(position: OrbitalFlight.padECI, velocity: .zero)
    private(set) var timeToCircularization: Double = -1
    private(set) var separationDeltaV: Double = 0
    private(set) var orbitAchieved = false
    private(set) var lastRequest = ControlRequest()
    private var attitudeTargetECI = DVec3(0, 1, 0)
    private var startRetries = 0
    private var everLit = false
    private var lastNoLight = 0
    private var replanTimer = 0.0
    private var predictTimer = 0.0
    private var hoverTimer = 0.0
    private var manualWarningShown = false
    let substeps = 2

    // Fault tolerance / replanning (live, from detected capabilities).
    private(set) var dvNeeded: Double = 9_400
    private(set) var dvMargin: Double = 0
    private(set) var replannedMECOIn: Double = -1
    private(set) var engineOutWarning: String? = nil

    // Time warp (requested by the HUD; effective value is gated, see below).
    var warpRequest: Double = 1
    var timeWarpAvailable: Bool {
        vehicle.altitude > Self.timeWarpMinAltitudeM && vehicle.mach > 1.0
    }
    /// The warp actually applied: the request, but 1x whenever it is not
    /// available or the phase is one that must run in real time (staging,
    /// MECO/SECO, circularization burn, orbit achieved, landing, ...).
    var effectiveWarp: Double {
        (timeWarpAvailable && !Self.timeWarpAutoDropPhases.contains(phase)) ? warpRequest : 1
    }
    func setWarp(_ w: Double) {
        // Snap to the nearest supported rate.
        warpRequest = Self.timeWarpRates.min(by: { abs($0 - w) < abs($1 - w) }) ?? 1
    }

    // Map destination + fuel check.
    var selectedDestination: MapDestination? = nil
    private(set) var fuelCheck: FuelCheck? = nil

    var engineStartLead: Double {
        let e = vehicle.stage1Engines[0]
        return e.chillDuration + 0.9 + 0.6 + 0.25 + 1.45 + 0.6
    }

    init(def: PartDefinition, surfaces: ImpingementSystem) {
        self.surfaces = surfaces
        let assembly: VehicleAssembly
        switch OrbitalStacks.assembled() {
        case let .success(a): assembly = a
        case let .failure(errors):
            // The FX-9 stack is validated at build time; this is unreachable
            // in practice, but never build a broken stack silently.
            fatalError("Orbital stack failed validation: \(errors.map { $0.description }.joined(separator: "; "))")
        }
        let v0 = Planet.rotationVelocity(at: OrbitalFlight.padECI)
        vehicle = OrbitalVehicle(assembly: assembly, def: def,
                                 originECI: OrbitalFlight.padECI, velocityECI: v0)
        vehicle.holdDown = true
        replan()
    }

    // MARK: planning / replanning

    var thrustFullActive: Double {
        let pa = vehicle.stage == 1
            ? vehicle.stage1Engines[0].ambient.pressure
            : vehicle.stage2Engine.ambient.pressure
        // Vacuum correction from the same pressure term RaptorSim uses:
        // exit area from the part definition (exit diameter 1.33 m).
        let exitArea = Double.pi * pow(vehicle.def.exitDiameterM / 2, 2)
        let perEngine = vehicle.def.thrustSeaLevelN + (Atmosphere.p0 - pa) * exitArea
        return Double(vehicle.activeEngineCount) * perEngine
    }

    /// Replan from the detected capabilities: delta-v still needed to reach
    /// the 275 km orbit vs delta-v remaining. Called every 5 s in burn phases
    /// and immediately on any engine-out / RCS-out event. If the replanned
    /// delta-v genuinely cannot close, the orbit attempt is aborted — never
    /// before that point.
    func replan() {
        let caps = vehicle.capabilities
        let need = OrbitalMechanics.deltaVToCircularOrbit(position: vehicle.positionECI,
                                                          velocity: vehicle.velocityECI,
                                                          availableDV: caps.deltaVTotal)
        dvNeeded = need.needed
        dvMargin = need.margin
        if !need.canClose && phase != .idle && phase != .countdown && phase != .orbit && phase != .landed
            && phase != .aborted && phase != .lost && phase != .done {
            warn("ORBIT UNREACHABLE · ΔV SHORTFALL \(Int(-need.margin)) M/S")
            abort()
        }
    }

    private func warn(_ w: String) { if !warnings.contains(w) { warnings.append(w) } }
    private func event(_ e: String) { if !events.contains(e) { events.append(e) } }
    private func enter(_ p: OrbitalPhase) {
        phase = p; phaseTime = 0
        if Self.timeWarpAutoDropPhases.contains(p) { warpRequest = 1 }
    }

    var timelineProgress: Double {
        let ev = Self.timelineEvents
        var last = -1
        for (i, e) in ev.enumerated() where events.contains(e) { last = i }
        if last < 0 { return -0.5 }
        return Double(last)
    }

    // MARK: geometry shared with the renderer (local frame at the pad)

    /// Body -> local-frame rotation (local: +X east, +Y up, -Z north at the pad).
    var orientationLocal: simd_quatd {
        let (e, n, u) = Planet.enuBasis(at: OrbitalFlight.padECI)
        // Columns of the local->ECI rotation: east, up, -north.
        let m = simd_double3x3(e, u, -n)
        let qBasis = simd_quatd(m)
        return qBasis.inverse * vehicle.orientation
    }

    var exitLocal: DVec3 {
        let mountY = vehicle.stage == 1 ? OrbitalVehicle.s1MountY : OrbitalVehicle.s2MountY
        let e = vehicle.stage == 1 ? vehicle.stage1Engines[0] : vehicle.stage2Engine
        let q = e.gimbal.rotation
        let pivot = DVec3(0, Double(RaptorMesh.pivotY), 0)
        let exit = DVec3(0, -Double(RaptorMesh.height), 0)
        let local = DVec3(0, mountY, 0) + pivot + simd_act(q, exit - pivot)
        return vehicle.localPosition + simd_act(orientationLocal, local)
    }
    var exhaustAxisLocal: DVec3 {
        let e = vehicle.stage == 1 ? vehicle.stage1Engines[0] : vehicle.stage2Engine
        return simd_act(orientationLocal, e.gimbal.exhaustAxis)
    }
    /// World-frame versions (the shared local frame, pad at OrbitalSite.padCenter):
    /// the impingement surfaces and the renderer work in world coordinates,
    /// while the physics stays pad-relative. Directions are unchanged.
    var exitWorld: DVec3 { OrbitalSite.padCenter + exitLocal }
    var exhaustAxisWorld: DVec3 { exhaustAxisLocal }
    /// Booster body -> local-frame rotation (same pad-local frame as the vehicle).
    var boosterOrientationLocal: simd_quatd? {
        guard let b = booster else { return nil }
        let (e, n, u) = Planet.enuBasis(at: OrbitalFlight.padECI)
        let m = simd_double3x3(e, u, -n)
        return simd_quatd(m).inverse * b.orientation
    }

    /// Vehicle centre of mass in the shared local frame (pad at OrbitalSite.padCenter).
    var comWorld: DVec3 {
        OrbitalSite.padCenter + vehicle.localPosition + simd_act(orientationLocal, DVec3(0, vehicle.comHeight, 0))
    }

    var activeEngine: RaptorSim { vehicle.stage == 1 ? vehicle.stage1Engines[0] : vehicle.stage2Engine }
    var thrustToWeight: Double {
        vehicle.thrustTotal / max(vehicle.mass * simd_length(Planet.gravity(positionECI: vehicle.positionECI)), 1)
    }

    // MARK: commands

    func startCountdown() {
        guard phase == .idle else { return }
        autopilot = true
        countdownClock = -Self.countdownLength
        vehicle.holdDown = true
        vehicle.stage1Tanks.setVents(false)
        vehicle.stage2Tanks.setVents(false)
        enter(.countdown)
    }

    func begin() {
        guard phase == .idle else { return }
        for e in vehicle.stage1Engines { e.requestStart() }
        vehicle.holdDown = true
        event("STARTUP")
        enter(.startup)
    }

    func abort() {
        if phase == .countdown {
            warn(String(format: "HOLD · COUNTDOWN ABORTED AT T-%02.0f", max(0, -(countdownClock ?? 0)).rounded(.up)))
            countdownClock = nil
            events.removeAll()
            enter(.idle)
            return
        }
        warn("ABORT COMMANDED")
        for e in vehicle.stage1Engines { e.requestShutdown() }
        vehicle.stage2Engine.requestShutdown()
        enter(.aborted)
    }

    /// MANUAL CONTROL — STUB for this milestone. The autopilot flies to orbit;
    /// manual control comes later. Calling this warns once and keeps the
    /// autopilot in charge; it never hands over a half-wired manual path.
    func requestManualControl() {
        if !manualWarningShown {
            manualWarningShown = true
            warn("MANUAL CONTROL NOT YET AVAILABLE · AUTOPILOT ONLY (ORBITAL MILESTONE 1)")
        }
    }

    // MARK: fault tolerance — per-engine / per-RCS control (player-tappable)

    /// Shut down one Stage-1 engine by index (0 = centre E1, 1...8 outer).
    /// The autopilot compensates: throttle up the remaining engines (the
    /// thrust budget is recomputed from the active engines), gimbal
    /// feedforward cancels the thrust asymmetry, the burn extends (MECO is
    /// propellant-depletion based, so it moves later by itself), and the
    /// delta-v is replanned. Only if the replan cannot close is the attempt
    /// aborted. E.g. engine 7 (index 6) out: 8 engines, thrust 21.96 MN,
    /// T/W 4.35 at liftoff mass — still closes with margin.
    func shutDownEngine(_ i: Int) {
        guard vehicle.stage == 1 else { return }
        vehicle.shutDownEngine(i)
        engineOutWarning = "ENGINE OUT · E\(i + 1)"
        warn(engineOutWarning!)
        replan()
    }
    func relightEngine(_ i: Int) {
        vehicle.relightEngine(i)
        if vehicle.engineOut.allSatisfy({ !$0 }) { engineOutWarning = nil }
        replan()
    }

    /// Shut down the Stage-2 engine. A single-engine stage has NO engine-out
    /// redundancy: the autopilot safes and coasts and reports that orbit
    /// cannot be reached, rather than pretending it can.
    func shutDownStage2Engine() {
        guard vehicle.stage == 2 else { return }
        vehicle.stage2EngineOut = true
        vehicle.stage2Engine.requestShutdown()
        warn("S2 ENGINE OUT · SINGLE-ENGINE STAGE · ORBIT UNREACHABLE")
        enter(.aborted)
    }

    /// Turn one RCS thruster off (or back on). The allocator redistributes
    /// torque to the remaining thrusters (and to the gimbal while burning);
    /// a single thruster out is never a hard failure.
    func setRCSThruster(_ id: String, enabled: Bool) {
        vehicle.rcs.setEnabled(id, enabled)
        if enabled {
            warnings.removeAll { $0 == "RCS THRUSTER OUT · \(id)" }
        } else {
            warn("RCS THRUSTER OUT · \(id)")
        }
        replan()
    }

    // MARK: map destination

    func selectDestination(_ dest: MapDestination?) {
        selectedDestination = dest
        guard let d = dest else { fuelCheck = nil; return }
        let caps = vehicle.capabilities
        fuelCheck = MapFuelCheck.check(d, position: vehicle.positionECI, velocity: vehicle.velocityECI,
                                       availableDV: caps.deltaVTotal)
        if let w = fuelCheck?.warning { warn(w) }
    }

    /// Begin a deorbit + precise landing to the selected landing destination.
    /// Only from a stable orbit, only to a landing destination.
    func beginDeorbitLanding() {
        guard phase == .orbit, let d = selectedDestination else { return }
        guard case .landing = d.kind else {
            warn("DEORBIT NEEDS A LANDING DESTINATION SELECTED ON THE MAP")
            return
        }
        enter(.deorbit)
    }

    // MARK: step

    func step(dt: Double) {
        phaseTime += dt
        if missionTime >= 0 { missionTime += dt }
        if let c = countdownClock {
            countdownClock = (vehicle.holdDown && c >= 0 && phase != .aborted) ? 0 : c + dt
        }
        let v = vehicle
        let alt = max(v.altitude, 0)
        let amb = Atmosphere.sample(altitude: alt)
        elements = OrbitalElements.from(position: v.positionECI, velocity: v.velocityECI)
        maxAltitude = max(maxAltitude, alt)
        if let dest = selectedDestination, phaseTime.truncatingRemainder(dividingBy: 5) < dt {
            fuelCheck = MapFuelCheck.check(dest, position: v.positionECI, velocity: v.velocityECI,
                                           availableDV: v.capabilities.deltaVTotal)
        }
        if v.stage1Engines.contains(where: { $0.combustion > 0.5 }) || v.stage2Engine.combustion > 0.5 {
            everLit = true; event("IGNITION")
        }

        runAutopilot(dt: dt)

        // Engine <-> tanks: summed flows drain the stage tanks; starvation
        // feeds back into each engine. 9 S1 engines share the S1 feed (one
        // aggregated drain — the engines are identical RaptorSims, so the
        // split is even); the S2 engine has its own feed.
        for e in v.stage1Engines {
            e.ambient = amb
            e.freestreamVelocity = -v.velocityECI
            e.impingement = surfaces.cast(origin: exitWorld, direction: exhaustAxisWorld)
            e.step(dt: dt)
        }
        v.stage2Engine.ambient = amb
        v.stage2Engine.freestreamVelocity = -v.velocityECI
        v.stage2Engine.step(dt: dt)
        let s1Ox = v.stage1Engines.reduce(0) { $0 + $1.oxFlow }
        let s1Fuel = v.stage1Engines.reduce(0) { $0 + $1.fuelFlow }
        let s1Running = v.stage1Engines.contains { $0.combustion > 0.3 } ? 1.0 : 0.0
        v.stage1Tanks.step(dt: dt, oxFlow: s1Ox, fuelFlow: s1Fuel, running: s1Running,
                           ambientK: amb.temperature, ambientPa: amb.pressure)
        let s2Running = v.stage2Engine.combustion > 0.3 ? 1.0 : 0.0
        v.stage2Tanks.step(dt: dt, oxFlow: v.stage2Engine.oxFlow, fuelFlow: v.stage2Engine.fuelFlow,
                           running: s2Running, ambientK: amb.temperature, ambientPa: amb.pressure)
        for e in v.stage1Engines {
            e.externalFuelStarve = v.stage1Tanks.fuelStarve
            e.externalOxStarve = v.stage1Tanks.oxStarve
        }
        v.stage2Engine.externalFuelStarve = v.stage2Tanks.fuelStarve
        v.stage2Engine.externalOxStarve = v.stage2Tanks.oxStarve
        if v.stage1Engines.contains(where: { $0.phase == .failure }) { warn("ENGINE FAILURE") }

        // Replan on a 5 s cadence during burns.
        replanTimer += dt
        if replanTimer > 5 && (phase == .ascent || phase == .s2Burn || phase == .circularization) {
            replanTimer = 0
            replan()
            if phase == .aborted { /* replan aborted: stop stepping the vehicle */ }
        }

        let sdt = dt / Double(substeps)
        for _ in 0..<substeps {
            let req = controlRequest()
            lastRequest = req
            let axial = phase == .separation ? v.rcs.axialForce() : 0
            v.step(dt: sdt, torqueRequest: req.torque, axialPush: axial, ambient: amb)
            if let b = booster {
                b.step(dt: sdt)
                if phase == .separation {
                    // Opposite push on the booster (momentum): -axial * dt / m.
                    b.velocityECI -= simd_act(v.orientation, DVec3(0, 1, 0)) * (axial / b.mass) * sdt
                    separationDeltaV += axial * (1 / max(v.mass, 1) + 1 / b.mass) * sdt
                }
                if b.splashEvent {
                    b.splashEvent = false
                    warn("BOOSTER SPLASHDOWN · \(b.splashdownKind == .ocean ? "OCEAN" : "LAND") · \(Int(b.splashdownSpeed)) M/S\(b.destroyed ? " · STAGE LOST" : " · FLOATING")")
                }
            }
        }
        if missionTime < 0 && alt > 0.3 && v.thrustTotal > 0 {
            missionTime = 0
            event("LIFTOFF")
        }
        if v.crashed && phase != .lost {
            warn("VEHICLE LOST · IMPACT")
            enter(.lost)
        }
        if v.landed && phase == .preciseLanding {
            event("TOUCHDOWN")
            enter(.landed)
        }
    }

    // MARK: attitude control

    private func controlRequest() -> ControlRequest {
        let v = vehicle
        let mp = v.massProps
        var req = ControlRequest()
        let up = v.up
        let eW = simd_cross(up, attitudeTargetECI)
        let eB = simd_act(v.orientation.inverse, eW)
        let coasting = phase == .coast || phase == .separation || phase == .apoapsisCoast || phase == .entryCoast
        let wn = coasting ? 0.45 : 0.9, zeta = 0.9
        let kp = wn * wn, kd = 2 * zeta * wn
        let ax = kp * eB.x - kd * v.omegaBody.x
        let az = kp * eB.z - kd * v.omegaBody.z
        let ay = -1.0 * v.omegaBody.y
        req.torque = DVec3(ax * mp.iLat, ay * mp.iRoll, az * mp.iLat)
        return req
    }

    private func setThrottleFor(accel aUp: Double, engines: [RaptorSim]) {
        let m = vehicle.mass
        let gLocal = simd_length(Planet.gravity(positionECI: vehicle.positionECI))
        let thrustFull = thrustFullActive
        guard thrustFull > 1 else { return }
        let cmd = clampd(m * (gLocal + aUp) / thrustFull, vehicle.def.minThrottle, 1)
        for e in engines { e.throttleCmd = cmd }
    }

    /// Gravity-turn target: vertical at liftoff, pitching over toward prograde
    /// as speed builds (tilt from vertical follows speed, ~78 deg by 2.5 km/s).
    private func gravityTurnTarget() -> DVec3 {
        let v = vehicle
        let up = v.upECI
        let pro = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
        let tilt = smoothstepd(100, 2_500, v.speed) * (78 * .pi / 180)
        return simd_normalize(up * cos(tilt) + pro * sin(tilt))
    }

    // MARK: autopilot

    private func runAutopilot(dt: Double) {
        let v = vehicle
        let alt = v.altitude
        let localG = simd_length(Planet.gravity(positionECI: v.positionECI))
        _ = localG
        switch phase {
        case .idle, .done, .aborted, .lost, .orbit, .landed:
            attitudeTargetECI = v.upECI
            if phase == .orbit || phase == .landed { attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI) }
        case .countdown:
            for e in v.stage1Engines { e.throttleCmd = 0.9 }
            if let c = countdownClock, c >= -engineStartLead {
                for e in v.stage1Engines { e.requestStart() }
                event("STARTUP")
                enter(.startup)
            }
        case .startup:
            for e in v.stage1Engines { e.throttleCmd = 0.9 }
            if v.activeEngineCount == 0 {
                warn("ABORT · ALL S1 ENGINES OUT · NO THRUST AVAILABLE")
                enter(.aborted)
            } else if v.stage1Engines.contains(where: { $0.phase == .failure }) {
                warn("ABORT · ENGINE FAILURE ON PAD")
                enter(.aborted)
            } else if v.stage1Engines.contains(where: { $0.noLightEvents > lastNoLight }) {
                lastNoLight = v.stage1Engines.map { $0.noLightEvents }.max() ?? 0
                warn("NO LIGHT · MAIN CHAMBER DID NOT IGNITE")
                if startRetries >= 1 { enter(.aborted) } else { startRetries += 1 }
            } else if v.stage1Engines.allSatisfy({ $0.phase == .mainstage }) {
                hoverTimer = max(hoverTimer, 0) + dt
                let atT0 = (countdownClock ?? 0) >= -0.02
                if hoverTimer > 0.6 && atT0 {
                    v.holdDown = false
                    hoverTimer = 0
                    enter(.ascent)
                }
            }
        case .ascent:
            event("LIFTOFF")
            if v.activeEngineCount == 0 {
                warn("ABORT · ALL S1 ENGINES OUT · NO THRUST AVAILABLE")
                enter(.aborted)
                break
            }
            attitudeTargetECI = gravityTurnTarget()
            // Throttle for ~1.4 g net, throttled back near max-Q (q > 32 kPa).
            var aCmd = 14.0
            if v.dynamicPressure > 32_000 { aCmd = 4 }
            if v.dynamicPressure > 45_000 { aCmd = 2 }
            setThrottleFor(accel: aCmd, engines: v.activeStage1Engines)
            predictTimer += dt
            if predictTimer > 0.5 {
                predictTimer = 0
                replannedMECOIn = v.stage1Tanks.burnTime(massFlow: max(v.stage1Engines.reduce(0) { $0 + $1.massFlow }, 1),
                                                         mixtureRatio: v.def.mixtureRatio)
                let s1Empty = v.stage1Tanks.totalPropellant < 1_000 || replannedMECOIn < 2
                if s1Empty || v.speed > 3_000 {
                    for e in v.stage1Engines { e.requestShutdown() }
                    event("MECO")
                    enter(.meco)
                }
            }
        case .meco:
            attitudeTargetECI = gravityTurnTarget()
            if phaseTime > 1.0 { enter(.coast) }
        case .coast:
            // Ballistic, ~3 s: all nine S1 engines are off (MECO), the stack
            // coasts while the propellant settles, then separation.
            attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            if phaseTime > 3.0 {
                // Create the booster as its own ballistic body, then rebase the
                // vehicle to stage 2 (same ECI point, S2 base at y = 39 m in
                // the stacked frame — the frame itself does not change).
                booster = OrbitalBooster(positionECI: v.positionECI, velocityECI: v.velocityECI,
                                         orientation: v.orientation)
                v.stage = 2
                v.switchRCSToStage2()
                separationDeltaV = 0
                event("SEPARATION")
                enter(.separation)
            }
        case .separation:
            // RCS axial push separates the stages; hold S2 attitude with RCS.
            attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            if separationDeltaV >= 1.5 || phaseTime > 3.0 {
                if separationDeltaV < 1.0 { warn("SEPARATION SLOW · RCS PUSH WEAK — CHECK AXIAL THRUSTERS") }
                enter(.ses)
            }
        case .ses:
            attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            if phaseTime < 0.05 { v.stage2Engine.requestRelight() }
            v.stage2Engine.throttleCmd = 0.7
            if v.stage2Engine.combustion > 0.3 {
                event("SES")
                enter(.s2Burn)
            } else if phaseTime > 6 {
                warn("SES FAILED · S2 DID NOT LIGHT")
                enter(.aborted)
            }
        case .s2Burn:
            attitudeTargetECI = gravityTurnTarget()
            setThrottleFor(accel: 12, engines: [v.stage2Engine])
            if elements.apoapsisAltitude >= 274_000 {
                v.stage2Engine.requestShutdown()
                event("SECO-1")
                enter(.apoapsisCoast)
            } else if v.stage2Tanks.totalPropellant < 500 {
                warn("S2 PROPELLANT DEPLETED BEFORE TARGET APOAPSIS")
                v.stage2Engine.requestShutdown()
                enter(.apoapsisCoast)
            }
        case .apoapsisCoast:
            attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            timeToCircularization = OrbitalElements.timeToApoapsis(position: v.positionECI, velocity: v.velocityECI)
            if timeToCircularization < 5 {
                enter(.circularization)
            }
        case .circularization:
            attitudeTargetECI = OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            if phaseTime < 0.05 { v.stage2Engine.requestRelight() }
            v.stage2Engine.throttleCmd = 0.85
            if elements.periapsisAltitude >= 274_000 && elements.eccentricity < 0.02 {
                v.stage2Engine.requestShutdown()
                orbitAchieved = true
                event("ORBIT")
                enter(.orbit)
            } else if v.stage2Tanks.totalPropellant < 500 {
                warn("S2 PROPELLANT DEPLETED DURING CIRCULARIZATION")
                v.stage2Engine.requestShutdown()
                enter(.aborted)
            }
        case .deorbit:
            // Retro burn (thrust opposite prograde) to drop the periapsis to the surface.
            attitudeTargetECI = -OrbitalMechanics.progradeDirection(position: v.positionECI, velocity: v.velocityECI)
            v.stage2Engine.throttleCmd = 0.85
            if phaseTime < 0.05 { v.stage2Engine.requestRelight() }
            if elements.periapsisAltitude <= 50_000 {
                v.stage2Engine.requestShutdown()
                enter(.entryCoast)
            }
        case .entryCoast:
            // Ballistic entry; hold the velocity direction until the air thickens.
            if simd_length(v.velocityECI) > 15 {
                attitudeTargetECI = simd_normalize(v.velocityECI)
            }
            if alt < 80_000 { enter(.preciseLanding) }
        case .preciseLanding:
            guard let dest = selectedDestination, case let .landing(lat, lon) = dest.kind else {
                enter(.aborted)
                break
            }
            let target = Planet.radius * DVec3(cos(lat * .pi / 180) * cos(lon * .pi / 180),
                                               cos(lat * .pi / 180) * sin(lon * .pi / 180),
                                               sin(lat * .pi / 180))
            if let cmd = PreciseLandingGuidance.command(position: v.positionECI, velocity: v.velocityECI,
                                                        targetECI: target, capabilities: v.capabilities,
                                                        localG: simd_length(Planet.gravity(positionECI: v.positionECI))) {
                attitudeTargetECI = cmd.thrustDirectionECI
                v.stage2Engine.throttleCmd = cmd.throttle
                if phaseTime < 0.05 { v.stage2Engine.requestRelight() }
            } else if v.landed {
                event("TOUCHDOWN")
                enter(.landed)
            }
        case .safing:
            if phaseTime > 3 { enter(.done) }
        }
    }
}
