import Foundation
import simd

/// A collidable surface for exhaust impingement (and, on the GPU, particle collisions).
/// Kept to primitives a signed-distance query handles cheaply; a heightfield can be added as another case.
enum ImpingementSurface {
    case plane(point: DVec3, normal: DVec3)           // infinite plane (ground, landing pad)
    case box(center: DVec3, halfExtents: DVec3)       // axis-aligned solid (deck, curbs, legs, walls)
    case groundWithTrench(trenchCenter: DVec3, trenchHalf: DVec3)   // y = 0 ground with a box trench cut out

    static func boxDistance(_ p: DVec3, _ c: DVec3, _ h: DVec3) -> Double {
        let q = simd_abs(p - c) - h
        let outside = simd_length(simd_max(q, DVec3.zero))
        let inside = min(max(q.x, max(q.y, q.z)), 0)
        return outside + inside
    }

    func distance(_ p: DVec3) -> Double {
        switch self {
        case let .plane(point, normal):
            return simd_dot(p - point, normal)
        case let .box(c, h):
            return ImpingementSurface.boxDistance(p, c, h)
        case let .groundWithTrench(c, h):
            // subtract the trench from the half-space below y = 0 (extended upward so the cut is open at the top)
            let cut = ImpingementSurface.boxDistance(p, c + DVec3(0, 1, 0), h + DVec3(0, 1, 0))
            return max(p.y, -cut)
        }
    }
}

/// Result of casting one engine's exhaust axis against the world.
struct ImpingementHit {
    var hit = false
    var point = DVec3.zero          // world
    var normal = DVec3(0, 1, 0)
    var distance: Double = .infinity // along the exhaust axis from the nozzle exit (m)
    var incidence: Double = 0       // cos(angle) between the jet and the surface normal (1 = head-on)
    /// 0…1 how strongly the plume interacts with the surface: 1 when close, fading out by ~75 m,
    /// reduced for glancing hits. Drives stagnation glow, wall-jet radius, dust/debris and pad heating.
    var strength: Double = 0
}

/// Plume–ground interaction, independent of the test stand: each frame every engine casts its nozzle axis
/// against the collidable surface list (sphere tracing the combined signed distance) and gets the hit point,
/// normal and distance. The stand registers its deck/pad, curbs and legs; a future vehicle's landing uses the
/// same query against the ground / landing pad. The renderer clips the plume against the matching SDF and the
/// GPU particles collide with it (Shaders/ShaderCommon.h `siteSDF`, which mirrors the stand's surfaces).
final class ImpingementSystem {
    var surfaces: [ImpingementSurface] = []
    /// Distances (m) over which the interaction fades: full strength below `nearDistance`, none past `farDistance`.
    var nearDistance: Double = 20        // real-scale tripod: nozzle exit ≈ 35 m above the deflector
    var farDistance: Double = 75
    var maxRange: Double = 120

    func sceneDistance(_ p: DVec3) -> Double {
        var d = Double.infinity
        for s in surfaces { d = min(d, s.distance(p)) }
        return d
    }

    func normal(at p: DVec3) -> DVec3 {
        let e = 0.02
        let dx = sceneDistance(p + DVec3(e, 0, 0)) - sceneDistance(p - DVec3(e, 0, 0))
        let dy = sceneDistance(p + DVec3(0, e, 0)) - sceneDistance(p - DVec3(0, e, 0))
        let dz = sceneDistance(p + DVec3(0, 0, e)) - sceneDistance(p - DVec3(0, 0, e))
        let n = DVec3(dx, dy, dz)
        let l = simd_length(n)
        return l > 1e-9 ? n / l : DVec3(0, 1, 0)
    }

    /// The same surfaces packed for the GPU `SiteShapes` block (ShaderCommon.h): info, trench centre/half,
    /// 16 box centres, 16 box half-extents (35 × float4, world metres). Planes become the ground height.
    func gpuShapes() -> [SIMD4<Float>] {
        var info = SIMD4<Float>(0, 0, 0, 0)
        var trenchC = SIMD4<Float>(0, 0, 0, 0), trenchH = SIMD4<Float>(0, 0, 0, 0)
        var boxC = [SIMD4<Float>](repeating: .zero, count: 16)
        var boxH = [SIMD4<Float>](repeating: .zero, count: 16)
        var n = 0
        for s in surfaces {
            switch s {
            case let .plane(point, _):
                info.z = Float(point.y)
            case let .groundWithTrench(c, h):
                info.y = 1
                trenchC = SIMD4<Float>(Float(c.x), Float(c.y), Float(c.z), 0)
                trenchH = SIMD4<Float>(Float(h.x), Float(h.y), Float(h.z), 0)
            case let .box(c, h):
                guard n < 16 else { continue }
                boxC[n] = SIMD4<Float>(Float(c.x), Float(c.y), Float(c.z), 0)
                boxH[n] = SIMD4<Float>(Float(h.x), Float(h.y), Float(h.z), 0)
                n += 1
            }
        }
        info.x = Float(n)
        return [info, trenchC, trenchH] + boxC + boxH
    }

    /// Cast the exhaust axis from the nozzle exit.
    func cast(origin: DVec3, direction: DVec3) -> ImpingementHit {
        var r = ImpingementHit()
        guard !surfaces.isEmpty else { return r }
        let dir = simd_normalize(direction)
        var t = 0.0
        for _ in 0..<96 {
            let p = origin + dir * t
            let d = sceneDistance(p)
            if d < 0.01 {
                r.hit = true
                r.point = p
                r.normal = normal(at: p)
                r.distance = t
                r.incidence = max(0, -simd_dot(dir, r.normal))
                let fade = 1 - smoothstepd(nearDistance, farDistance, t)
                r.strength = fade * (0.35 + 0.65 * r.incidence)
                return r
            }
            t += max(d, 0.01)
            if t > maxRange { break }
        }
        return r
    }
}
