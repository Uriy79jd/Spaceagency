import Foundation
import simd

/// TV-1 launch pad (concrete pad with a water-filled flame trench) and its landing zone, in world metres.
/// The collidable shapes here are the single source for the plume raycast, the vehicle's ground contact and
/// (hand-mirrored, see ShaderCommon.h `siteSDF`) the GPU plume clip / particle collisions.
enum TV1Site {
    static let padCenter = DVec3(-400, 0, 0)
    static let landingZone = DVec3(-400, 0, -300)
    static let padHalf = 20.0
    static let lzRadius = 15.0
    /// Flame trench: runs from just behind the vehicle axis out along +X, 3.2 m wide, 3.5 m deep.
    /// Narrower than the Ø5.44 m skirt foot ring on purpose: the ring must bear on the deck on both lips of the
    /// trench (7 of its 8 contact points), otherwise the vehicle stands on a knife edge and tips into the trench.
    static var trenchCenter: DVec3 { padCenter + DVec3(13, -1.75, 0) }
    static let trenchHalf = DVec3(15.5, 1.75, 1.6)
    /// Flowing water in the trench (surface 2.6 m below the pad deck).
    static let waterLevel = -2.6
    static var waterCenter: DVec3 { padCenter + DVec3(13, waterLevel - 0.45, 0) }
    static let waterHalf = DVec3(15.5, 0.45, 1.6)

    /// Ground with the trench carved out, the water body, the landing-zone slab.
    static func surfaces() -> [ImpingementSurface] {
        [.groundWithTrench(trenchCenter: trenchCenter, trenchHalf: trenchHalf),
         .box(center: waterCenter, halfExtents: waterHalf),
         .box(center: landingZone + DVec3(0, -0.25, 0), halfExtents: DVec3(lzRadius, 0.25, lzRadius))]
    }

    /// True when a point (e.g. the plume hit point) is on the trench water.
    static func isWater(_ p: DVec3) -> Bool {
        let q = p - waterCenter
        return abs(q.x) <= waterHalf.x + 0.1 && abs(q.z) <= waterHalf.z + 0.1 && abs(p.y - waterLevel) < 0.4
    }
}
