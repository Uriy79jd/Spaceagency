import Foundation
import simd

/// Atmospheric wind: power-law boundary layer plus gusts (sum of incommensurate sines). m/s, world frame.
struct WindModel {
    var mean = DVec3.zero            // at 10 m
    var gust: Double = 0             // gust amplitude (m/s)
    func velocity(altitude h: Double, time t: Double) -> DVec3 {
        let prof = pow(max(h, 1) / 10, 0.14)
        let g = gust * (0.55 * sin(t * 0.73) + 0.3 * sin(t * 1.91 + 1.3) + 0.15 * sin(t * 4.37 + 0.4))
        let gz = gust * 0.5 * (0.6 * sin(t * 0.51 + 2.1) + 0.4 * sin(t * 2.63))
        let dir = simd_length(mean) > 1e-3 ? simd_normalize(mean) : DVec3(1, 0, 0)
        let side = DVec3(-dir.z, 0, dir.x)
        return mean * prof + dir * g + side * gz
    }
}

/// Body-frame force/torque request and what the actuators produced (for the HUD authority indicator).
struct ControlRequest {
    var torque = DVec3.zero          // body frame, N·m (x pitch, y roll, z yaw)
    var throttle: Double = 0
    /// Pilot RCS translation, body frame x / z, −1…1 (the RCS fires top and skirt pods together so the
    /// force passes through the CoM: translation without rotation).
    var translate = SIMD2<Double>(0, 0)
    /// Split the torque between the actuators in proportion to their authority (manual flight: the stick
    /// visibly drives the gimbal AND the RCS) instead of gimbal-first (autopilot: saves N₂).
    var parallel = false
}

/// Something that turns part of a torque request into real forces on the body. The allocator runs them in
/// order (gimbal → RCS today; aero flaps slot in later for the belly-flop milestone).
protocol ControlActuator: AnyObject {
    var name: String { get }
    /// Maximum body torque magnitude this actuator can produce right now (per axis, N·m).
    func authority(_ v: TV1Vehicle, _ engine: RaptorSim) -> DVec3
    /// Consume what it can of `remaining` (body torque) and return what it will produce.
    func allocate(_ remaining: DVec3, _ v: TV1Vehicle, _ engine: RaptorSim, dt: Double) -> DVec3
}

/// Engine gimbal: torque = arm × thrust deflection. Commands the engine's gimbal angles.
final class GimbalActuator: ControlActuator {
    let name = "Gimbal"
    func authority(_ v: TV1Vehicle, _ e: RaptorSim) -> DVec3 {
        let t = e.thrust * v.gimbalArm * sin(e.gimbal.maxAngle)
        return DVec3(t, 0, t)
    }
    func allocate(_ r: DVec3, _ v: TV1Vehicle, _ e: RaptorSim, dt: Double) -> DVec3 {
        let tl = max(e.thrust, 1) * v.gimbalArm
        guard e.thrust > 0.05 * e.def.thrustSeaLevelN else {
            e.gimbal.cmdPitch = 0; e.gimbal.cmdYaw = 0
            return .zero
        }
        // yaw > 0 swings the exhaust toward +x → body torque −z; pitch > 0 → exhaust toward −z → body torque −x
        let maxA = e.gimbal.maxAngle
        let yaw = clampd(asin(clampd(-r.z / tl, -1, 1)), -maxA, maxA)
        let pitch = clampd(asin(clampd(-r.x / tl, -1, 1)), -maxA, maxA)
        e.gimbal.cmdYaw = yaw
        e.gimbal.cmdPitch = pitch
        // what the actuator is actually delivering (its servo lags the command)
        return DVec3(-tl * sin(e.gimbal.pitch), 0, -tl * sin(e.gimbal.yaw))
    }
}

/// Cold-gas nitrogen RCS: four pods near the top. A single lateral thruster at the pod gives a torque about the
/// CoM (and a small side force); roll from tangential thrusters at the tank radius. Finite N₂ supply.
final class RCSActuator: ControlActuator {
    let name = "RCS"
    let thrusterForce = 6_000.0          // N per thruster
    let isp = 68.0                       // s, cold N₂
    var n2Mass = 420.0                   // kg
    let n2Capacity = 420.0
    var enabled = true
    var deadband = 0.04                  // fraction of authority below which nothing fires
    /// Pilot translation command, body x / z, −1…1.
    var translate = SIMD2<Double>(0, 0)
    /// Last firing per pod (for puffs/sound), body frame: the EXHAUST direction × thrust (N) — opposite to the
    /// force it puts on the vehicle. Pods 0–3 at the top (+x, −x, +z, −z), 4–7 on the skirt (same order);
    /// matches TV1Mesh.rcsPods.
    private(set) var podFiring: [DVec3] = Array(repeating: .zero, count: 8)
    private(set) var lastForceBody = DVec3.zero
    private(set) var lastTorqueBody = DVec3.zero

    func authority(_ v: TV1Vehicle, _ e: RaptorSim) -> DVec3 {
        guard enabled, n2Mass > 0 else { return .zero }
        let arm = TV1Vehicle.rcsHeight - v.comHeight
        return DVec3(thrusterForce * abs(arm), 2 * thrusterForce * TV1Vehicle.radius, thrusterForce * abs(arm))
    }

    func allocate(_ r: DVec3, _ v: TV1Vehicle, _ e: RaptorSim, dt: Double) -> DVec3 {
        podFiring = Array(repeating: .zero, count: 8)
        lastForceBody = .zero; lastTorqueBody = .zero
        guard enabled, n2Mass > 0 else { return .zero }
        let com = v.comHeight
        let armT = TV1Vehicle.rcsHeight - com          // top pods above the CoM (> 0)
        let armB = TV1Vehicle.rcsLowHeight - com       // skirt pods below it (< 0)
        let a = authority(v, e)
        // deadband + proportional-width firing (PWM averaged over the step)
        func duty(_ want: Double, _ maxT: Double) -> Double {
            guard maxT > 1 else { return 0 }
            let x = want / maxT
            return abs(x) < deadband ? 0 : clampd(x, -1, 1)
        }
        let dp = duty(r.x, a.x), dr = duty(r.y, a.y), dy = duty(r.z, a.z)
        // rotation: lateral force at the top pods. F along +z → torque (armT ŷ × F ẑ) = +x → pitch;
        // F along +x → torque −z·armT → yaw
        let sgn = armT >= 0 ? 1.0 : -1.0
        var fTop = DVec3(-dy * thrusterForce * sgn, 0, dp * thrusterForce * sgn)
        // translation: split the force between top and skirt pods so it acts through the CoM
        var fBot = DVec3.zero
        let tr = SIMD2<Double>(clampd(translate.x, -1, 1), clampd(translate.y, -1, 1))
        if simd_length(tr) > 0.05 && armT - armB > 0.5 {
            let kTop = -armB / (armT - armB), kBot = armT / (armT - armB)
            let fMax = thrusterForce / max(kTop, kBot)
            let fDes = DVec3(tr.x, 0, tr.y) * fMax
            fTop += fDes * kTop
            fBot += fDes * kBot
        }
        fTop = DVec3(clampd(fTop.x, -thrusterForce, thrusterForce), 0, clampd(fTop.z, -thrusterForce, thrusterForce))
        fBot = DVec3(clampd(fBot.x, -thrusterForce, thrusterForce), 0, clampd(fBot.z, -thrusterForce, thrusterForce))
        let rollT = DVec3(0, dr * a.y, 0)
        let torque = simd_cross(DVec3(0, armT, 0), fTop) + simd_cross(DVec3(0, armB, 0), fBot) + rollT
        let used = (abs(fTop.x) + abs(fTop.z) + abs(fBot.x) + abs(fBot.z) + 2 * abs(dr) * thrusterForce) / (isp * 9.80665) * dt
        n2Mass = max(0, n2Mass - used)
        lastForceBody = fTop + fBot
        lastTorqueBody = torque
        // the pod on the side OPPOSITE the force fires, its exhaust pointing outward (away from the force)
        func fire(_ f: DVec3, base: Int) {
            if f.z > 1 { podFiring[base + 3] += DVec3(0, 0, -1) * f.z } else if f.z < -1 { podFiring[base + 2] += DVec3(0, 0, 1) * -f.z }
            if f.x > 1 { podFiring[base + 1] += DVec3(-1, 0, 0) * f.x } else if f.x < -1 { podFiring[base + 0] += DVec3(1, 0, 0) * -f.x }
        }
        fire(fTop, base: 0)
        fire(fBot, base: 4)
        // roll: tangential thrusters on the ±x top pods (exhaust ±z)
        if abs(dr) > 0 { podFiring[0] += DVec3(0, 0, dr) * thrusterForce; podFiring[1] += DVec3(0, 0, -dr) * thrusterForce }
        return torque
    }
}

/// TV-1, a stainless-steel ground-test / hop vehicle (Ø5 m, ~14 m tall) on one Raptor-3-class engine.
/// 6-DOF rigid body in double precision: mass / CoM / inertia from structure, ballast and the live tank model;
/// thrust vector from the gimbal; gravity; aero drag + cross-flow normal force with a centre of pressure above
/// the CoM (weathervaning) and wind; RCS; ground contact at points around the skirt foot and the tank against
/// the same collidable surface list the plume uses (spring–damper normal force, Coulomb friction, restitution);
/// touchdown damage. Local origin = centre of the skirt foot, +Y = vehicle axis.
final class TV1Vehicle {
    static let radius = 2.5
    static let height = 14.0
    static let mountHeight = 4.2                 // engine mount (top of gimbal block)
    static let rcsHeight = 12.0
    static let rcsLowHeight = 2.4                // skirt RCS pods (translation pairs with the top pods)
    static let footRadius = 2.72
    static let cpHeight = 7.4                    // cross-flow centre of pressure
    static let dryStructureMass = 52_000.0       // kg, stainless structure, avionics, N₂ bottles
    static let ballastMass = 28_000.0            // kg, steel ballast ring at the skirt foot (test article)
    static let engineMass = 1_600.0
    static let g0 = 9.80665

    // state
    var position = DVec3.zero                    // world position of the local origin
    var velocity = DVec3.zero                    // m/s, of the CoM
    var orientation = simd_quatd(ix: 0, iy: 0, iz: 0, r: 1)   // body → world
    var omegaBody = DVec3.zero                   // rad/s, body frame
    var wind = WindModel()
    let tanks: PropellantSystem
    let gimbalAct = GimbalActuator()
    let rcs = RCSActuator()
    lazy var actuators: [ControlActuator] = [gimbalAct, rcs]

    // contact / damage
    private(set) var contactPoints: [DVec3] = []         // body frame
    private(set) var inContact = false
    private(set) var contactCount = 0
    private(set) var lastImpactSpeed: Double = 0
    private(set) var peakImpactSpeed: Double = 0
    private(set) var touchdownSpeed: Double? = nil
    private(set) var dent: Double = 0                    // m, skirt foot crumple
    private(set) var structuralFailure = false
    private(set) var impactEvents = 0
    private var wasInContact = true
    private var contactImpact = 0.0                      // largest closing speed in the current contact episode
    // aero / authority readouts
    private(set) var aeroTorqueBody = DVec3.zero
    private(set) var dynamicPressure: Double = 0
    private(set) var mach: Double = 0
    private(set) var achievedTorque = DVec3.zero
    var frost: Double = 1
    /// Pad hold-down clamps: the vehicle cannot leave the pad until the autopilot releases them.
    var holdDown = false
    var time: Double = 0

    init(fill: Double) {
        tanks = PropellantSystem(fill: fill)
        var pts: [DVec3] = []
        for i in 0..<8 {
            let a = Double(i) / 8 * 2 * .pi
            pts.append(DVec3(cos(a) * TV1Vehicle.footRadius, 0, sin(a) * TV1Vehicle.footRadius))
        }
        for y in [6.5, 13.2] {
            for i in 0..<8 {
                let a = (Double(i) + 0.5) / 8 * 2 * .pi
                pts.append(DVec3(cos(a) * TV1Vehicle.radius, y, sin(a) * TV1Vehicle.radius))
            }
        }
        pts.append(DVec3(0, TV1Vehicle.height, 0))
        contactPoints = pts
    }

    // MARK: mass properties (body frame)

    struct MassProps { var mass: Double; var comY: Double; var iLat: Double; var iRoll: Double }

    var massProps: MassProps {
        let r = TV1Vehicle.radius
        let lox = tanks.lox.liquidMass, ch4 = tanks.ch4.liquidMass
        // LOX tank barrel 4.6…7.7 m, CH4 7.9…10.1 m (liquid settles to the bottom of each)
        let area = Double.pi * r * r
        let loxH = tanks.lox.liquidVolume / area, ch4H = tanks.ch4.liquidVolume / area
        let loxC = 4.6 + loxH / 2, ch4C = 7.9 + ch4H / 2
        let parts: [(Double, Double)] = [(TV1Vehicle.dryStructureMass, 7.2), (TV1Vehicle.ballastMass, 0.9),
                                         (TV1Vehicle.engineMass, 2.6), (lox, loxC), (ch4, ch4C), (rcs.n2Mass, 11.5)]
        var m = 0.0, my = 0.0
        for (pm, py) in parts { m += pm; my += pm * py }
        let cy = my / m
        // lateral inertia: thin shell structure + ballast ring + liquid cylinders, parallel axis to the CoM
        var iLat = TV1Vehicle.dryStructureMass * (r * r / 2 + 14 * 14 / 12) + TV1Vehicle.dryStructureMass * pow(7.2 - cy, 2)
        iLat += TV1Vehicle.ballastMass * (r * r / 2 + pow(0.9 - cy, 2))
        iLat += TV1Vehicle.engineMass * pow(2.6 - cy, 2)
        iLat += lox * (r * r / 4 + loxH * loxH / 12 + pow(loxC - cy, 2))
        iLat += ch4 * (r * r / 4 + ch4H * ch4H / 12 + pow(ch4C - cy, 2))
        let iRoll = (TV1Vehicle.dryStructureMass + TV1Vehicle.ballastMass) * r * r + (lox + ch4) * r * r / 2
        return MassProps(mass: m, comY: cy, iLat: iLat, iRoll: iRoll)
    }
    var mass: Double { massProps.mass }
    var comHeight: Double { massProps.comY }
    /// Distance from the CoM down to the gimbal pivot (lever arm of a gimbal deflection).
    var gimbalArm: Double { max(comHeight - (TV1Vehicle.mountHeight + Double(RaptorMesh.pivotY)), 0.5) }

    var up: DVec3 { simd_act(orientation, DVec3(0, 1, 0)) }
    func toWorld(_ local: DVec3) -> DVec3 { position + simd_act(orientation, local) }
    var comWorld: DVec3 { toWorld(DVec3(0, comHeight, 0)) }
    var mountWorld: DVec3 { toWorld(DVec3(0, TV1Vehicle.mountHeight, 0)) }
    var tiltAngle: Double { acos(clampd(up.y, -1, 1)) }
    var omegaWorld: DVec3 { simd_act(orientation, omegaBody) }

    /// Height of the skirt foot above the surface below it (surface list).
    func groundClearance(_ surfaces: ImpingementSystem) -> Double {
        var d = surfaces.sceneDistance(position)
        for i in 0..<4 {
            let a = Double(i) * .pi / 2 + .pi / 4
            d = min(d, surfaces.sceneDistance(toWorld(DVec3(cos(a), 0, sin(a)) * TV1Vehicle.footRadius)))
        }
        return d
    }

    func place(at p: DVec3) {
        position = p
        velocity = .zero
        orientation = simd_quatd(ix: 0, iy: 0, iz: 0, r: 1)
        omegaBody = .zero
        wasInContact = true
    }

    // MARK: dynamics

    /// Advance the rigid body by `dt` (call at ≥ 240 Hz). `request` is the attitude controller's body torque;
    /// the actuators turn it into gimbal angles / RCS firings, and the engine's actual thrust vector is applied.
    func step(dt: Double, engine e: RaptorSim, request: ControlRequest, surfaces: ImpingementSystem, ambient: AtmosphereSample) {
        time += dt
        let mp = massProps
        let m = mp.mass
        let com = DVec3(0, mp.comY, 0)
        let comW = toWorld(com)
        var F = DVec3(0, -TV1Vehicle.g0 * m, 0)              // world
        var Tb = DVec3.zero                                    // body torque about the CoM

        // --- control allocation (actuators in order) ---
        rcs.translate = request.translate
        var remaining = request.torque
        var achieved = DVec3.zero
        if request.parallel {
            // proportional split by authority: every actuator answers the stick at once
            let auths = actuators.map { $0.authority(self, e) }
            var total = DVec3.zero
            for au in auths { total += au }
            for (i, a) in actuators.enumerated() {
                let share = DVec3(total.x > 1 ? auths[i].x / total.x : 0, total.y > 1 ? auths[i].y / total.y : 0,
                                  total.z > 1 ? auths[i].z / total.z : 0)
                achieved += a.allocate(request.torque * share, self, e, dt: dt)
            }
        } else {
            for a in actuators {
                let got = a.allocate(remaining, self, e, dt: dt)
                achieved += got
                remaining -= got
            }
        }
        achievedTorque = achieved

        // --- engine thrust through the gimballed axis, applied at the pivot ---
        let pivotB = DVec3(0, TV1Vehicle.mountHeight + Double(RaptorMesh.pivotY), 0)
        let thrustB = -e.gimbal.exhaustAxis * e.thrust
        F += simd_act(orientation, thrustB)
        Tb += simd_cross(pivotB - com, thrustB)

        // --- RCS force and torque (computed by the actuator, body frame) ---
        F += simd_act(orientation, rcs.lastForceBody)
        Tb += rcs.lastTorqueBody

        // --- aerodynamics: axial drag + cross-flow normal force at the CP (weathervaning) + rotational damping ---
        let windW = wind.velocity(altitude: max(position.y, 0), time: time)
        let vRelW = velocity - windW
        let vb = simd_act(orientation.inverse, vRelW)
        let rho = ambient.density
        let r = TV1Vehicle.radius
        let aRef = Double.pi * r * r
        let speed = simd_length(vb)
        dynamicPressure = 0.5 * rho * speed * speed
        mach = ambient.speedOfSound > 1 ? speed / ambient.speedOfSound : 0
        let machFactor = 1 + 0.6 * smoothstepd(0.75, 1.15, mach) - 0.25 * smoothstepd(1.3, 2.5, mach)
        let cdAx = (vb.y > 0 ? 0.55 : 1.05) * machFactor          // nose dome leading vs open skirt leading
        let fAx = -0.5 * rho * abs(vb.y) * vb.y * cdAx * aRef
        let vn = DVec3(vb.x, 0, vb.z)
        let cdN = 1.15
        let fN = -0.5 * rho * simd_length(vn) * cdN * (2 * r * TV1Vehicle.height) * vn
        let fAeroB = DVec3(0, fAx, 0) + fN
        let aeroT = simd_cross(DVec3(0, TV1Vehicle.cpHeight, 0) - com, fN)
        let h3: Double = pow(TV1Vehicle.height, 3)
        let qd: Double = 0.5 * rho * max(speed, 1)
        let damp: Double = qd * cdN * 2 * r * h3 / 48
        let dampT = DVec3(-damp * omegaBody.x, -damp * 0.02 * omegaBody.y, -damp * omegaBody.z)
        aeroTorqueBody = aeroT
        F += simd_act(orientation, fAeroB)
        Tb += aeroT + dampT

        // --- ground contact: stiff, (over-)critically damped, steel skirt on concrete ---
        // Per-point spring–damper against the surface list. Stiffness gives ω ≈ 45 rad/s with the 8 foot points
        // sharing the load (≈ 1.5 cm static sag); damping is set per point from the mass each TOUCHING point
        // carries (m / n), ζ = 1.15, so a first contact on one or two points is as dead as a full-ring contact
        // (build 180 used ζ = 0.32 for 8 points: e ≈ 0.35 and far less when fewer points touched → bouncy).
        // Stable at the 240 Hz step (2ζωdt ≈ 0.43). Restitution is enforced below (e ≈ 0.08).
        let wn = 45.0
        let k = m * wn * wn / 8
        let mu = 0.65
        let omegaW = simd_act(orientation, omegaBody)
        let dentDrop = dent
        var pen: [(DVec3, Double)] = []
        pen.reserveCapacity(8)
        for (i, pb) in contactPoints.enumerated() {
            var pLocal = pb
            if i < 8 { pLocal.y += dentDrop * 0.6 }            // crumpled skirt foot sits higher on the body
            let pw = toWorld(pLocal)
            let d = surfaces.sceneDistance(pw)
            if d < 0 { pen.append((pw, d)) }
        }
        let touching = pen.count
        var impact = 0.0
        if touching > 0 {
            let c = 2 * 1.15 * sqrt(k * m / Double(touching))
            for (pw, d) in pen {
                let n = surfaces.normal(at: pw)
                let rW = pw - comW
                let vp = velocity + simd_cross(omegaW, rW)
                let vnS = simd_dot(vp, n)
                impact = max(impact, -vnS)
                // no pull (max 0) and no push-out "kick": the spring term is limited so it can at most stop the
                // point's penetration velocity plus a slow recovery of the overlap, never launch it
                let fn = max(0, -k * d - c * vnS)
                let vt = vp - n * vnS
                let vtl = simd_length(vt)
                var ft = DVec3.zero
                if vtl > 1e-5 {
                    // regularised Coulomb: viscous below the slip limit (static), capped at μ·N (sliding)
                    let slip: Double = m / Double(max(touching, 4)) * vtl / max(dt * 4, 1e-4)
                    let mag: Double = min(mu * fn, slip)
                    ft = vt * (-mag / vtl)
                }
                let fW = n * fn + ft
                F += fW
                Tb += simd_act(orientation.inverse, simd_cross(rW, fW))
            }
        }
        contactCount = touching
        inContact = touching > 0
        if inContact && !wasInContact && impact > 0.3 {
            registerImpact(speed: impact)
        }
        if !inContact && simd_length(velocity) > 0.5 { wasInContact = false }
        if inContact { wasInContact = true }

        if holdDown {
            velocity = .zero
            omegaBody = .zero
            return
        }
        // --- integrate (semi-implicit Euler) ---
        // translate the CoM, rotate about it, then recover the body origin
        velocity += F / m * dt
        let comNew = comW + velocity * dt
        let I = DVec3(mp.iLat, mp.iRoll, mp.iLat)
        let Iw = I * omegaBody
        let gyro = simd_cross(omegaBody, Iw)
        omegaBody += (Tb - gyro) / I * dt
        let wq = simd_quatd(ix: omegaBody.x, iy: omegaBody.y, iz: omegaBody.z, r: 0)
        orientation = simd_normalize(orientation + (orientation * wq) * (0.5 * dt))
        position = comNew - simd_act(orientation, com)

        // restitution of a steel skirt on concrete (e ≈ 0.08): while the ground is carrying the vehicle (engine
        // not lifting it), the upward velocity it can leave with is capped at e × the impact speed of this
        // contact episode; spin from a one-sided hit is bled the same way. Hard hits crush the skirt instead
        // (registerImpact) rather than bouncing.
        if inContact {
            contactImpact = max(contactImpact, impact)
            let lift = simd_dot(simd_act(orientation, thrustB), DVec3(0, 1, 0))
            if lift < 0.9 * m * TV1Vehicle.g0 {
                let vMax = 0.08 * contactImpact + 0.02
                if velocity.y > vMax { velocity.y = vMax }
                let wl = simd_length(DVec3(omegaBody.x, 0, omegaBody.z))
                let wMax = 0.08 * contactImpact / 3 + 0.01
                if wl > wMax { omegaBody.x *= wMax / wl; omegaBody.z *= wMax / wl }
            }
        } else if position.y > 0.5 || simd_length(velocity) > 0.5 {
            contactImpact = 0
        }
    }

    private func registerImpact(speed v: Double) {
        lastImpactSpeed = v
        peakImpactSpeed = max(peakImpactSpeed, v)
        impactEvents += 1
        if touchdownSpeed == nil { touchdownSpeed = v }
        // crumple the skirt foot: energy above the ~2.5 m/s design limit goes into plastic deformation
        if v > 2.5 {
            let e = 0.5 * mass * (v * v - 2.5 * 2.5)
            dent = min(dent + e / 1.2e7, 1.6)
        }
        if v > 9 { structuralFailure = true }
    }

    func resetTouchdown() { touchdownSpeed = nil }
}
