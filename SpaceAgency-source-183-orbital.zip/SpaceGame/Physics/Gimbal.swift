import Foundation
import simd

/// Two-axis gimbal actuator model: second-order servo (slight overshoot), rate-limited, angle-limited.
struct GimbalState {
    var pitch: Double = 0      // rad, rotation about X (nozzle swings toward ±Z)
    var yaw: Double = 0        // rad, rotation about Z (nozzle swings toward ±X)
    var pitchRate: Double = 0
    var yawRate: Double = 0
    var cmdPitch: Double = 0
    var cmdYaw: Double = 0

    var maxAngle: Double = 15 * .pi / 180
    var maxRate: Double = 25 * .pi / 180
    var naturalFreq: Double = 11      // rad/s
    var damping: Double = 0.55        // < 0.7 → small overshoot then settle
    var pitchStuck = false            // failure injection: actuator seized (holds its last angle)

    mutating func step(dt: Double) {
        func axis(_ x: inout Double, _ v: inout Double, _ cmd: Double) {
            let c = clampd(cmd, -maxAngle, maxAngle)
            let a = naturalFreq * naturalFreq * (c - x) - 2 * damping * naturalFreq * v
            v = clampd(v + a * dt, -maxRate, maxRate)
            x = clampd(x + v * dt, -maxAngle * 1.02, maxAngle * 1.02)
        }
        if pitchStuck { pitchRate = 0 } else { axis(&pitch, &pitchRate, cmdPitch) }
        axis(&yaw, &yawRate, cmdYaw)
    }

    /// Rotation of the gimballed assembly.
    var rotation: simd_quatd {
        simd_quatd(angle: yaw, axis: DVec3(0, 0, 1)) * simd_quatd(angle: pitch, axis: DVec3(1, 0, 0))
    }

    /// Thrust-axis (nozzle pointing direction, i.e. exhaust flow direction) in world space.
    var exhaustAxis: DVec3 { simd_act(rotation, DVec3(0, -1, 0)) }

    var tiltAngle: Double { acos(clampd(-exhaustAxis.y, -1, 1)) }
}

enum GimbalPattern: String, CaseIterable {
    case none = "Off"
    case circle = "Circle"
    case sweep = "Sweep"

    func command(time t: Double, amplitude: Double) -> (Double, Double) {
        switch self {
        case .none: return (0, 0)
        case .circle:
            let w = 2 * Double.pi / 4.0
            return (amplitude * sin(w * t), amplitude * cos(w * t))
        case .sweep:
            // 8 s cycle: pitch sweep then yaw sweep
            let c = t.truncatingRemainder(dividingBy: 8)
            let s = sin(2 * Double.pi * c / 4)
            return c < 4 ? (amplitude * s, 0) : (0, amplitude * s)
        }
    }
}
