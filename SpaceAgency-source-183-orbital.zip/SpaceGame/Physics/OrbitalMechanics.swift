import Foundation
import simd

/// Earth-like planet + orbital mechanics for the orbital milestone.
/// Units are SI throughout (metres, m/s, kg, s). ECI frame: origin at Earth's centre,
/// +Z through the north pole, +X/+Y in the equatorial plane. `DVec3` is the codebase's
/// double-precision 3-vector (see MathUtil.swift).
///
/// Planet rotation is modelled only as the eastward velocity at the pad at liftoff
/// (v = omega x r, ~410 m/s at 28.5 deg latitude). The ground does not rotate under the
/// vehicle during flight — a rotating-planet frame is future work, and the error it
/// introduces (ground-track drift) does not affect the orbit itself.
enum Planet {
    static let radius = 6_371_000.0              // m, mean Earth radius
    static let mu = 3.986004418e14               // m^3/s^2, Earth's gravitational parameter
    static let rotationRate = 7.2921159e-5       // rad/s
    static let waterFraction = 0.71              // 71% water / 29% land — more water than land
    static let targetOrbitAltitude = 275_000.0   // m, 275 x 275 km target orbit

    /// Circular orbital velocity at an altitude: sqrt(mu / (R + h)). At 275 km = 7,744 m/s.
    static func circularVelocity(altitude h: Double) -> Double { sqrt(mu / (radius + h)) }
    /// Circular orbital period at an altitude: 2*pi*sqrt(r^3/mu). At 275 km = 89.9 min.
    static func orbitalPeriod(altitude h: Double) -> Double {
        let r = radius + h
        return 2 * .pi * sqrt(r * r * r / mu)
    }
    static func altitude(positionECI r: DVec3) -> Double { simd_length(r) - radius }
    /// Spherical gravity: g = -mu * r / |r|^3 (NOT the flat-earth constant g of TV-1).
    static func gravity(positionECI r: DVec3) -> DVec3 {
        let d = simd_length(r)
        return -mu / (d * d * d) * r
    }
    /// Eastward velocity of a point fixed to the rotating planet (omega x r).
    static func rotationVelocity(at r: DVec3) -> DVec3 {
        simd_cross(DVec3(0, 0, rotationRate), r)
    }

    // MARK: launch site (Cape-Canaveral-like coast: land to the west, ocean to the east)

    static let launchLatitude = 28.5 * .pi / 180
    static let launchLongitude = -80.5 * .pi / 180

    /// ECI position of the launch pad at the epoch (t = 0).
    static func launchSiteECI() -> DVec3 {
        let clat = cos(launchLatitude)
        return radius * DVec3(clat * cos(launchLongitude), clat * sin(launchLongitude), sin(launchLatitude))
    }

    /// East / north / up basis at an ECI position (unit vectors, ECI frame).
    static func enuBasis(at r: DVec3) -> (east: DVec3, north: DVec3, up: DVec3) {
        let d = simd_length(r)
        let lat = asin(clampd(r.z / d, -1, 1))
        let lon = atan2(r.y, r.x)
        let up = r / d
        let east = DVec3(-sin(lon), cos(lon), 0)
        let north = DVec3(-sin(lat) * cos(lon), -sin(lat) * sin(lon), cos(lat))
        return (east, north, up)
    }

    /// ECI -> local rendering frame at the pad. Local axes match the rest of the game:
    /// +X east, +Y up, -Z north (bearing 0 = north = -Z, as in TV-1). The local frame is a
    /// tangent plane at the pad: it is exact near the pad and a rendering convenience far
    /// away — the ECI state is always the truth for physics and the HUD.
    static func localFromECI(_ r: DVec3, originECI o: DVec3) -> DVec3 {
        let (e, n, u) = enuBasis(at: o)
        let d = r - o
        return DVec3(simd_dot(d, e), simd_dot(d, u), -simd_dot(d, n))
    }

    static func eciFromLocal(_ l: DVec3, originECI o: DVec3) -> DVec3 {
        let (e, n, u) = enuBasis(at: o)
        return o + e * l.x + u * l.y - n * l.z
    }

    // MARK: surface — stylised Earth-like land / ocean (71% water)

    enum SurfaceKind { case ocean, land }

    /// Deterministic land/ocean mask, calibrated to ~29% land. It is a stylised planet, not
    /// real coastline data: a hash of latitude/longitude, with a coastal override around the
    /// launch site — land to the west of the pad, open ocean to the east (the downrange /
    /// booster-splashdown corridor), so a booster falling back downrange splashes down.
    static func surfaceKind(latitude lat: Double, longitude lon: Double) -> SurfaceKind {
        let dLon = lon - launchLongitude
        let dLat = lat - launchLatitude
        // Coastal override: within ~15 deg of the pad, west = land, east = ocean.
        if abs(dLat) < 0.26 && abs(dLon) < 0.5 {
            return dLon >= 0 ? .ocean : .land
        }
        // Hash mask: ~29% land elsewhere.
        let h = sin(lat * 12.9898 + lon * 78.233) * 43758.5453
        let f = h - floor(h)
        return f < 0.29 ? .land : .ocean
    }

    static func surfaceKind(at positionECI r: DVec3) -> SurfaceKind {
        let d = simd_length(r)
        let lat = asin(clampd(r.z / d, -1, 1))
        let lon = atan2(r.y, r.x)
        return surfaceKind(latitude: lat, longitude: lon)
    }

    static func isOcean(at positionECI r: DVec3) -> Bool { surfaceKind(at: r) == .ocean }
}

/// Keplerian orbital elements from an ECI state vector. All altitudes in metres.
struct OrbitalElements {
    var semiMajorAxis: Double       // m, < 0 for a hyperbolic trajectory
    var eccentricity: Double
    var apoapsisAltitude: Double    // m above the surface; -inf-ish when hyperbolic
    var periapsisAltitude: Double
    var inclination: Double         // rad
    var period: Double              // s, .infinity when not closed
    var trueAnomaly: Double         // rad
    var speed: Double               // m/s, |v|

    var isClosed: Bool { semiMajorAxis > 0 && eccentricity < 1 }
    /// 275 x 275 km within 1 km and near-circular.
    var isTargetOrbit: Bool {
        abs(apoapsisAltitude - Planet.targetOrbitAltitude) < 1_000
            && abs(periapsisAltitude - Planet.targetOrbitAltitude) < 1_000 && eccentricity < 0.01
    }

    static func from(position r: DVec3, velocity v: DVec3) -> OrbitalElements {
        let mu = Planet.mu
        let rMag = simd_length(r), vMag = simd_length(v)
        let h = simd_cross(r, v)
        let hMag = simd_length(h)
        // Eccentricity vector: (v x h)/mu - r/|r|.
        let eVec = simd_cross(v, h) / mu - r / rMag
        let e = simd_length(eVec)
        // Semi-major axis from specific energy: a = 1 / (2/|r| - |v|^2/mu).
        let energy = vMag * vMag / 2 - mu / rMag
        let a = -mu / (2 * energy)
        let rp = a * (1 - e), ra = a * (1 + e)
        let inc = hMag > 1e-9 ? acos(clampd(h.z / hMag, -1, 1)) : 0
        // True anomaly from r and the eccentricity vector (0 when near-circular).
        var nu: Double = 0
        if e > 1e-6 {
            nu = acos(clampd(simd_dot(eVec, r) / (e * rMag), -1, 1))
            if simd_dot(r, v) < 0 { nu = 2 * .pi - nu }
        } else if rMag > 0 {
            // Near-circular: anomaly from the node line is undefined; use the angle from +X.
            nu = atan2(r.y, r.x)
        }
        let period = a > 0 ? 2 * .pi * sqrt(a * a * a / mu) : .infinity
        return OrbitalElements(semiMajorAxis: a, eccentricity: e,
                               apoapsisAltitude: ra - Planet.radius,
                               periapsisAltitude: rp - Planet.radius,
                               inclination: inc, period: period,
                               trueAnomaly: nu, speed: vMag)
    }

    /// Seconds until the next apoapsis, from the current state (Kepler's equation).
    /// Returns 0 when already at apoapsis, .infinity when the orbit is not closed.
    static func timeToApoapsis(position r: DVec3, velocity v: DVec3) -> Double {
        let el = OrbitalElements.from(position: r, velocity: v)
        guard el.isClosed, el.period.isFinite, el.period > 0 else { return .infinity }
        let e = el.eccentricity
        if e < 1e-4 {
            // Near-circular: apoapsis is half a period after periapsis; use the anomaly phase.
            let frac = 0.5 - el.trueAnomaly / (2 * .pi)
            return ((frac.truncatingRemainder(dividingBy: 1)) + 1).truncatingRemainder(dividingBy: 1) * el.period
        }
        // Eccentric anomaly from the true anomaly; sign from r.v (outbound vs inbound).
        let nu = el.trueAnomaly
        var eAnom = acos(clampd((e + cos(nu)) / (1 + e * cos(nu)), -1, 1))
        if simd_dot(r, v) < 0 { eAnom = 2 * .pi - eAnom }
        let mean = eAnom - e * sin(eAnom)
        let meanMotion = 2 * .pi / el.period
        var dt = (.pi - mean) / meanMotion
        if dt < 0 { dt += el.period }
        return dt
    }
}

enum OrbitalMechanics {
    /// Unit prograde direction (component of velocity perpendicular to radial).
    /// Falls back to east when the velocity is near-radial (e.g. just after liftoff).
    static func progradeDirection(position r: DVec3, velocity v: DVec3) -> DVec3 {
        let up = simd_normalize(r)
        let radial = simd_dot(v, up) * up
        let pro = v - radial
        if simd_length(pro) > 50 { return simd_normalize(pro) }
        let (east, _, _) = Planet.enuBasis(at: r)
        return east
    }

    /// Two-impulse (Hohmann-style) estimate of the delta-v still needed to reach the
    /// 275 km circular orbit from the current state, and whether the available delta-v
    /// can close it. Burn 1 at the current radius raises the apoapsis to the target;
    /// burn 2 at the target radius circularises. It is an estimate (it assumes the
    /// first burn happens near periapsis) — the autopilot replans from it, it does not
    /// steer by it.
    static func deltaVToCircularOrbit(position r: DVec3, velocity v: DVec3,
                                      availableDV: Double) -> (needed: Double, canClose: Bool, margin: Double) {
        let mu = Planet.mu
        let rMag = simd_length(r), vMag = simd_length(v)
        let rT = Planet.radius + Planet.targetOrbitAltitude
        // Already there (within tolerance)?
        let el = OrbitalElements.from(position: r, velocity: v)
        if el.isTargetOrbit { return (0, true, availableDV) }
        guard el.semiMajorAxis > 0 else { return (.infinity, false, -Double.infinity) }
        // Transfer ellipse from the current radius to the target radius.
        let aTr = (rMag + rT) / 2
        guard aTr > 0 else { return (.infinity, false, -Double.infinity) }
        let vTr1 = sqrt(max(mu * (2 / rMag - 1 / aTr), 0))
        let vTr2 = sqrt(max(mu * (2 / rT - 1 / aTr), 0))
        let vCircT = Planet.circularVelocity(altitude: Planet.targetOrbitAltitude)
        let dv1 = abs(vTr1 - vMag)
        let dv2 = abs(vCircT - vTr2)
        let needed = dv1 + dv2
        return (needed, availableDV >= needed, availableDV - needed)
    }

    /// Ideal (Tsiolkovsky) delta-v remaining from a mass / propellant / Isp budget.
    static func deltaVAvailable(mass m0: Double, propellant: Double, isp: Double) -> Double {
        guard m0 > 0, propellant > 0, m0 - propellant > 0 else { return 0 }
        return isp * 9.80665 * log(m0 / (m0 - propellant))
    }
}

// MARK: - Ocean (basic water physics, no fluid simulation)
//
// Sea level is altitude 0. Waves are a sum of three travelling sine waves
// (height and normal vary with position and time). Buoyancy is Archimedes'
// principle on the submerged volume of a vertical cylinder; water drag is
// velocity-squared with water density (1025 kg/m3, ~800x air). Stable at the
// 120 Hz fixed timestep: the buoyancy spring (rho*g*A) on a 24 t booster has
// omega ~ 2.9 rad/s, far below the step Nyquist frequency.

enum Ocean {
    static let density = 1_025.0            // kg/m3, seawater
    static let seaLevel = 0.0               // m altitude

    /// Wave height (m) at a point east/north of the pad (km), at time t (s).
    /// Three swells: amplitudes 0.55 / 0.35 / 0.22 m, wavelengths ~14 / 10 / 7 km.
    static func waveHeight(eastKm: Double, northKm: Double, time t: Double) -> Double {
        0.55 * sin(0.45 * eastKm + 0.9 * t)
            + 0.35 * sin(0.6 * northKm - 1.3 * t + 1.7)
            + 0.22 * sin(0.9 * (eastKm + northKm) + 2.1 * t)
    }

    /// Sea-surface normal (local ENU frame) from the analytic wave slopes.
    static func waveNormal(eastKm: Double, northKm: Double, time t: Double) -> DVec3 {
        let dhdx = 0.55 * 0.45 * cos(0.45 * eastKm + 0.9 * t)
            + 0.22 * 0.9 * cos(0.9 * (eastKm + northKm) + 2.1 * t)
        let dhdz = 0.35 * 0.6 * cos(0.6 * northKm - 1.3 * t + 1.7)
            + 0.22 * 0.9 * cos(0.9 * (eastKm + northKm) + 2.1 * t)
        // Slopes are per km; convert to per metre for the normal.
        return simd_normalize(DVec3(-dhdx / 1000, 1, dhdz / 1000))
    }

    /// Submerged volume (m3) of a vertical cylinder of radius r, submerged to
    /// depth d (0 = just touching, length = fully submerged).
    static func submergedVolume(radius r: Double, depth d: Double, length: Double) -> Double {
        .pi * r * r * clampd(d, 0, length)
    }

    /// Buoyant force (N, upward) on that submerged volume: rho * V * g.
    static func buoyancyForce(submergedVolume v: Double) -> Double { density * v * 9.80665 }

    /// Water drag force (N, world/ENU frame): -0.5 * rho * Cd * A * |v| * v.
    /// Cd ~ 1.0 for a blunt cylinder end-on, A = cross-section.
    static func dragForce(velocity v: DVec3, area: Double, cd: Double = 1.0) -> DVec3 {
        let s = simd_length(v)
        guard s > 1e-6 else { return .zero }
        return -0.5 * density * cd * area * s * v
    }
}

// MARK: - Terrain (deterministic procedural ground)

/// Terrain type by elevation / aridity. Colour / roughness are the visual
/// material for the type (used by the site apron today; a full terrain mesh
/// generated from `height(latitude:longitude:)` is future work).
enum TerrainType: String {
    case beach, plains, hills, mountains, desert

    var groundColor: (Double, Double, Double) {
        switch self {
        case .beach: return (0.76, 0.70, 0.55)
        case .plains: return (0.35, 0.48, 0.22)
        case .hills: return (0.30, 0.42, 0.20)
        case .mountains: return (0.45, 0.44, 0.42)
        case .desert: return (0.80, 0.68, 0.45)
        }
    }
    var roughness: Double {
        switch self {
        case .beach: return 0.9
        case .plains: return 1.0
        case .hills: return 1.0
        case .mountains: return 1.0
        case .desert: return 0.95
        }
    }
}

enum Terrain {
    /// Deterministic hash of a lat/lon cell (degrees) in [0, 1). Same location
    /// always gives the same terrain.
    private static func hash(_ latCell: Int, _ lonCell: Int) -> Double {
        let h = sin(Double(latCell) * 127.1 + Double(lonCell) * 311.7) * 43758.5453
        return h - floor(h)
    }

    /// Smooth value noise in [0, 1] over cells of `cellDegrees` degrees.
    private static func noise(latitude lat: Double, longitude lon: Double, cellDegrees: Double) -> Double {
        let x = lon / cellDegrees, y = lat / cellDegrees
        let xi = Int(floor(x)), yi = Int(floor(y))
        let xf = x - Double(xi), yf = y - Double(yi)
        let sx = xf * xf * (3 - 2 * xf), sy = yf * yf * (3 - 2 * yf)
        let a = hash(yi, xi), b = hash(yi, xi + 1), c = hash(yi + 1, xi), d = hash(yi + 1, xi + 1)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }

    /// Ground height (m above sea level) and terrain type at a lat/lon (degrees).
    /// Ocean returns height 0 (the sea surface; see Ocean). Land rises to ~1200 m
    /// in the mountains. The launch pad is graded flat: within ~2 km of the pad
    /// the height blends to 0 (coastal beach).
    static func height(latitude lat: Double, longitude lon: Double) -> (height: Double, type: TerrainType) {
        if Planet.surfaceKind(latitude: lat * .pi / 180, longitude: lon * .pi / 180) == .ocean {
            return (0, .beach)
        }
        let n = 0.65 * noise(latitude: lat, longitude: lon, cellDegrees: 3)
            + 0.35 * noise(latitude: lat, longitude: lon, cellDegrees: 1)
        let dry = noise(latitude: lat + 37, longitude: lon + 91, cellDegrees: 5)
        var h = pow(max(n, 0), 1.5) * 1_200
        // Coastal flattening near the pad (Cape Canaveral-like site).
        let padLat = Planet.launchLatitude * 180 / .pi, padLon = Planet.launchLongitude * 180 / .pi
        let dDeg = sqrt(pow(lat - padLat, 2) + pow((lon - padLon) * cos(padLat * .pi / 180), 2))
        let flat = smoothstepd(0.02, 0.005, dDeg)   // 1 within ~0.5 km, 0 past ~2 km
        h *= (1 - flat)
        let type: TerrainType
        if h < 4 { type = .beach }
        else if dry < 0.25 && h >= 20 && h < 250 { type = .desert }
        else if h < 80 { type = .plains }
        else if h < 300 { type = .hills }
        else { type = .mountains }
        return (h, type)
    }

    /// Ground altitude (m) under an ECI position: terrain height on land, sea
    /// level (plus waves, evaluated by the caller) on ocean. This is what the
    /// ground-contact / splashdown logic uses — a vehicle landing on hills
    /// touches down higher (and on rougher ground) than one landing on plains.
    static func groundAltitude(at positionECI r: DVec3) -> Double {
        let d = simd_length(r)
        let lat = asin(clampd(r.z / d, -1, 1)) * 180 / .pi
        let lon = atan2(r.y, r.x) * 180 / .pi
        return height(latitude: lat, longitude: lon).height
    }

    static func type(at positionECI r: DVec3) -> TerrainType {
        let d = simd_length(r)
        let lat = asin(clampd(r.z / d, -1, 1)) * 180 / .pi
        let lon = atan2(r.y, r.x) * 180 / .pi
        return height(latitude: lat, longitude: lon).type
    }
}
