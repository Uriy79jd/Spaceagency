import Foundation

/// U.S. Standard Atmosphere 1976.
/// 0–86 km: the seven geopotential layers of the standard (hydrostatic, piecewise-linear temperature).
/// 86–120 km: log-linear interpolation of the tabulated 1976 pressures/temperatures.
/// `vacuum` = true returns p = 0.
struct AtmosphereSample {
    var altitude: Double      // geometric, m
    var pressure: Double      // Pa
    var temperature: Double   // K
    var density: Double       // kg/m^3
    var speedOfSound: Double  // m/s
}

enum Atmosphere {
    static let p0 = 101_325.0
    static let g0 = 9.80665
    static let R = 287.053          // J/(kg K) dry air
    static let r0 = 6_356_766.0     // effective Earth radius for geopotential, m

    // base geopotential height (m), base temperature (K), lapse rate (K/m), base pressure (Pa)
    private static let layers: [(Double, Double, Double, Double)] = [
        (0, 288.15, -0.0065, 101_325.0),
        (11_000, 216.65, 0.0, 22_632.06),
        (20_000, 216.65, 0.001, 5_474.889),
        (32_000, 228.65, 0.0028, 868.0187),
        (47_000, 270.65, 0.0, 110.9063),
        (51_000, 270.65, -0.0028, 66.93887),
        (71_000, 214.65, -0.002, 3.956420),
        (84_852, 186.946, 0.0, 0.3734),
    ]

    // geometric altitude (km), pressure (Pa), temperature (K) — 1976 tables above 86 km
    private static let upper: [(Double, Double, Double)] = [
        (86, 0.3734, 186.87), (90, 0.18359, 186.87), (95, 0.07597, 188.42), (100, 0.032011, 195.08),
        (105, 0.014510, 208.84), (110, 0.0071042, 240.0), (115, 0.0040096, 300.0), (120, 0.0025382, 360.0),
    ]

    static func sample(altitude z: Double, vacuum: Bool = false) -> AtmosphereSample {
        if vacuum {
            return AtmosphereSample(altitude: z, pressure: 0, temperature: 3, density: 0, speedOfSound: 0)
        }
        let zc = max(0, z)
        var p: Double, t: Double
        if zc <= 86_000 {
            let h = r0 * zc / (r0 + zc) // geopotential
            var i = layers.count - 1
            while i > 0 && h < layers[i].0 { i -= 1 }
            let (hb, tb, lb, pb) = layers[i]
            t = tb + lb * (h - hb)
            if abs(lb) < 1e-12 {
                p = pb * exp(-g0 * (h - hb) / (R * tb))
            } else {
                p = pb * pow(tb / t, g0 / (R * lb))
            }
        } else {
            let km = min(zc / 1000, 120)
            var i = 0
            while i < upper.count - 2 && km > upper[i + 1].0 { i += 1 }
            let a = upper[i], b = upper[i + 1]
            let f = (km - a.0) / (b.0 - a.0)
            p = exp(log(a.1) + (log(b.1) - log(a.1)) * f)
            t = a.2 + (b.2 - a.2) * f
            if zc > 120_000 { p *= exp(-(zc - 120_000) / 7_000) }
        }
        let rho = p / (R * t)
        return AtmosphereSample(altitude: zc, pressure: p, temperature: t, density: rho, speedOfSound: sqrt(1.4 * R * t))
    }

    // MARK: sky / space transition (Swift side of the sky shader)

    /// The same altitude-driven sky model the Metal sky shader uses (`skyRadiance` in
    /// ShaderCommon.h — do not change one without the other). `thin` is the shader's
    /// altitude parameter: 0 = sea-level blue sky, 1 = black space (reached at ~60 km
    /// in the shader's zenith; the horizon band holds a thin blue line longer).
    /// The physics (pressure / density / drag / engine performance) always comes from
    /// `sample(altitude:)` above — this is only the visual / audio fade model, driven
    /// by the same altitude.
    struct SkyState {
        var altitude: Double
        var thin: Double              // 0 = sea-level sky, 1 = black space (shader scale)
        var starVisibility: Double    // 0 = no stars, 1 = full starfield
        var spaceFactor: Double       // 0 below 80 km, 1 above 100 km (music / "in space" logic)
        var isSpace: Bool { spaceFactor >= 1 }
        var zenith: (Double, Double, Double)   // linear RGB, matches the shader's zenith mix
        var horizon: (Double, Double, Double)  // linear RGB, matches the shader's horizon mix
    }

    /// Altitude (m) -> sky thinness on the shader's scale (altitude in km / 60, clamped).
    static func skyThin(altitude: Double) -> Double { clampd(max(altitude, 0) / 60_000, 0, 1) }

    /// Procedural-star visibility: stars fade in once the sky darkens (thin > 0.4, i.e.
    /// above ~24 km) and are full by thin 0.9 (~54 km). Mirrors the `thin > 0.4` gate
    /// and `smoothstep(0.4, 0.9, thin)` in `skyRadiance`.
    static func starVisibility(altitude: Double) -> Double {
        let thin = skyThin(altitude: altitude)
        guard thin > 0.4 else { return 0 }
        return smoothstepd(0.4, 0.9, thin)
    }

    /// "In space" factor for music and HUD: 0 up to 80 km, ramping to 1 at 100 km
    /// (the Karman line). The sky shader is already near-black by ~60 km; this is the
    /// slower, gameplay-facing fade so music does not cut in abruptly.
    static func spaceFactor(altitude: Double) -> Double { smoothstepd(80_000, 100_000, altitude) }

    static func skyState(altitude: Double) -> SkyState {
        let thin = skyThin(altitude: altitude)
        // Same mixes as skyRadiance: zenith sea-level (0.34, 0.45, 0.62) -> space
        // (0.002, 0.003, 0.010) with pow(thin, 0.6); horizon (0.70, 0.74, 0.78) ->
        // (0.05, 0.10, 0.25) with pow(thin, 0.8), then towards black past thin 0.7.
        let zt = pow(thin, 0.6), ht = pow(thin, 0.8)
        func mix(_ a: Double, _ b: Double, _ t: Double) -> Double { a + (b - a) * t }
        let zen = (mix(0.34, 0.002, zt), mix(0.45, 0.003, zt), mix(0.62, 0.010, zt))
        var hor = (mix(0.70, 0.05, ht), mix(0.74, 0.10, ht), mix(0.78, 0.25, ht))
        let black = smoothstepd(0.7, 1.0, thin) * 0.85
        hor = (hor.0 * (1 - black), hor.1 * (1 - black), hor.2 * (1 - black))
        return SkyState(altitude: altitude, thin: thin,
                        starVisibility: starVisibility(altitude: altitude),
                        spaceFactor: spaceFactor(altitude: altitude),
                        zenith: zen, horizon: hor)
    }
}
