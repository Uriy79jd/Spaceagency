import Foundation
import simd

// MARK: - Orbital RCS: per-thruster allocator
//
// One thruster = one valve + nozzle. The allocator is real, not scripted: each
// call it reads which thrusters are enabled, builds the torque each one can
// produce about the CoM, and greedily serves the requested torque axis by axis
// (strongest thruster first), skipping disabled ones. A single thruster out
// therefore degrades — never zeroes — the axis it served, and the attitude PD
// loop corrects the residual. Axial thrusters (separation push) are allocated
// separately: the separation phase integrates the achieved push and waits
// until the relative velocity is reached, so losing axial thrusters slows
// separation instead of breaking it.

struct RCSThruster {
    var id: String                 // e.g. "S2-TOP-1" — shown in the HUD panel
    var position: DVec3            // body local, stacked frame (origin = S1 base)
    var exhaust: DVec3             // unit exhaust direction, body frame
    var force: Double              // N at full duty
    var enabled: Bool = true
    var kind: String               // "attitude" or "axial"
}

final class OrbitalRCS {
    var thrusters: [RCSThruster]
    var n2Mass: Double
    let n2Capacity: Double
    let isp = 68.0                 // s, cold N2 (same as TV-1)
    private(set) var lastForceBody = DVec3.zero
    private(set) var lastTorqueBody = DVec3.zero
    private(set) var degradedAxes: [String] = []

    init(thrusters: [RCSThruster], n2Mass: Double) {
        self.thrusters = thrusters
        self.n2Mass = n2Mass
        self.n2Capacity = n2Mass
    }

    var outThrusters: [String] { thrusters.filter { !$0.enabled }.map { $0.id } }
    var activeCount: Int { thrusters.filter { $0.enabled }.count }
    var isFiring: Bool { simd_length(lastForceBody) > 1 || simd_length(lastTorqueBody) > 1 }

    func setEnabled(_ id: String, _ on: Bool) {
        guard let i = thrusters.firstIndex(where: { $0.id == id }) else { return }
        thrusters[i].enabled = on
    }

    /// Greedy per-axis torque allocation. Returns the torque actually produced.
    /// `comY` is the current CoM height (body frame). Cross-axis coupling is
    /// second-order; the attitude PD loop corrects the residual each step.
    func allocate(torque request: DVec3, comY: Double, dt: Double) -> DVec3 {
        lastForceBody = .zero; lastTorqueBody = .zero
        degradedAxes = []
        guard n2Mass > 0 else { degradedAxes = ["pitch", "yaw", "roll"]; return .zero }
        var remaining = request
        var achieved = DVec3.zero
        var usedForce: Double = 0
        // Serve each axis with the thrusters whose torque is strongest on it.
        for axis in 0..<3 {
            let axisName = ["pitch", "roll", "yaw"][axis]
            var candidates: [(RCSThruster, DVec3)] = []
            for t in thrusters where t.enabled && t.kind == "attitude" {
                let f = -t.exhaust * t.force
                let tau = simd_cross(t.position - DVec3(0, comY, 0), f)
                if abs(tau[axis]) > 100 { candidates.append((t, tau)) }
            }
            guard !candidates.isEmpty else {
                if abs(remaining[axis]) > 1000 { degradedAxes.append(axisName) }
                continue
            }
            candidates.sort { abs($0.1[axis]) > abs($1.1[axis]) }
            for (t, tau) in candidates {
                guard abs(remaining[axis]) > 1 else { break }
                let duty = clampd(remaining[axis] / tau[axis], -1, 1)
                let f = -t.exhaust * t.force * duty
                let produced = simd_cross(t.position - DVec3(0, comY, 0), f)
                achieved += produced
                remaining -= produced
                lastForceBody += f
                usedForce += abs(duty) * t.force
            }
        }
        lastTorqueBody = achieved
        n2Mass = max(0, n2Mass - usedForce / (isp * 9.80665) * dt)
        return achieved
    }

    /// Axial separation push (N along +Y body) from the enabled axial thrusters.
    func axialForce() -> Double {
        thrusters.filter { $0.enabled && $0.kind == "axial" }.reduce(0) { $0 + $1.force }
    }

    /// Thruster layout for a configuration. Stacked (stage 1): top ring on the
    /// fairing (y = 65 m), bottom ring on the S1 skirt (y = 2 m). Stage 2 alone:
    /// top ring at y = 65 m, bottom ring on the S2 engine bay (y = 41.5 m).
    /// Roll thrusters fire tangentially in opposing pairs (pure roll, no pitch).
    static func build(stage: Int) -> OrbitalRCS {
        let topY = 65.0
        let bottomY = stage == 1 ? 2.0 : 41.5
        var ts: [RCSThruster] = []
        let lat: [(DVec3, DVec3)] = [
            (DVec3(2.5, 0, 0), DVec3(1, 0, 0)), (DVec3(-2.5, 0, 0), DVec3(-1, 0, 0)),
            (DVec3(0, 0, 2.5), DVec3(0, 0, 1)), (DVec3(0, 0, -2.5), DVec3(0, 0, -1)),
        ]
        for (i, (p, e)) in lat.enumerated() {
            ts.append(RCSThruster(id: "S\(stage)-TOP-\(i + 1)", position: p + DVec3(0, topY, 0), exhaust: e, force: 8_000, kind: "attitude"))
            ts.append(RCSThruster(id: "S\(stage)-BOT-\(i + 1)", position: p + DVec3(0, bottomY, 0), exhaust: e, force: 8_000, kind: "attitude"))
        }
        // Roll pairs: (+x pod, +z exhaust) with (-x pod, -z exhaust), and the mirror pair.
        ts.append(RCSThruster(id: "S\(stage)-ROLL-1", position: DVec3(2.5, topY, 0), exhaust: DVec3(0, 0, 1), force: 8_000, kind: "attitude"))
        ts.append(RCSThruster(id: "S\(stage)-ROLL-2", position: DVec3(-2.5, topY, 0), exhaust: DVec3(0, 0, -1), force: 8_000, kind: "attitude"))
        ts.append(RCSThruster(id: "S\(stage)-ROLL-3", position: DVec3(0, topY, 2.5), exhaust: DVec3(-1, 0, 0), force: 8_000, kind: "attitude"))
        ts.append(RCSThruster(id: "S\(stage)-ROLL-4", position: DVec3(0, topY, -2.5), exhaust: DVec3(1, 0, 0), force: 8_000, kind: "attitude"))
        // Axial separation thrusters on the S2 base ring (exhaust -Y -> push +Y).
        for i in 0..<4 {
            let a = Double(i) * .pi / 2 + .pi / 4
            ts.append(RCSThruster(id: "S\(stage)-AX-\(i + 1)",
                                  position: DVec3(cos(a) * 2.0, 39.5, sin(a) * 2.0),
                                  exhaust: DVec3(0, -1, 0), force: 6_000, kind: "axial"))
        }
        return OrbitalRCS(thrusters: ts, n2Mass: 600)
    }
}

// MARK: - Orbital vehicle (assembled from snap modules)

/// The Falcon-size two-stage orbital vehicle, assembled from `VehicleAssembly`
/// (see VehicleModules.swift) — not hard-coded as one body. Local origin is
/// the S1 base (skirt foot), +Y the vehicle axis, in the stacked frame; the
/// frame does not change at separation (the S2 base sits at y = 39 m in it).
/// Position / velocity are ECI (from Earth's centre); the local frame is only
/// for rendering and for the vehicle's own geometry.
final class OrbitalVehicle {
    static let radius = 2.5
    static let stage1Height = 39.0
    static let stage2BaseY = 39.0
    static let totalHeight = 68.0
    static let octawebRadius = 1.45
    static let s1MountY = 3.5
    static let s2MountY = 42.5
    static let payloadMass = 10_000.0
    static let g0 = 9.80665

    /// Engine positions (body local): E1 centre, E2-E9 outer circle, 45 deg apart.
    /// Engine 7 (the user's example) is index 6, at 225 deg.
    static let enginePositions: [DVec3] = {
        var ps: [DVec3] = [DVec3(0, s1MountY, 0)]
        for k in 0..<8 {
            let a = Double(k) * .pi / 4
            ps.append(DVec3(cos(a) * octawebRadius, s1MountY, sin(a) * octawebRadius))
        }
        return ps
    }()

    let assembly: VehicleAssembly
    let def: PartDefinition
    var stage = 1

    // ECI state (truth for physics and the HUD)
    var positionECI: DVec3
    var velocityECI: DVec3
    var orientation = simd_quatd(ix: 0, iy: 0, iz: 0, r: 1)   // body -> ECI
    var omegaBody = DVec3.zero
    var holdDown = false
    var time: Double = 0
    var frost: Double = 1

    let stage1Engines: [RaptorSim]
    let stage2Engine: RaptorSim
    /// Per-engine out flags (S1, index 0 = centre E1). Set by the player (tap)
    /// or by a failure; the autopilot reads them and compensates.
    var engineOut: [Bool]
    var stage2EngineOut = false
    let stage1Tanks: PropellantSystem
    let stage2Tanks: PropellantSystem
    var rcs: OrbitalRCS

    // readouts
    private(set) var dynamicPressure: Double = 0
    private(set) var mach: Double = 0
    private(set) var vaporCone: Double = 0
    private(set) var thrustTotal: Double = 0
    private(set) var landed = false
    private(set) var touchdownSpeed: Double? = nil
    private(set) var crashed = false

    init(assembly: VehicleAssembly, def: PartDefinition, originECI: DVec3, velocityECI: DVec3) {
        self.assembly = assembly
        self.def = def
        self.positionECI = originECI
        self.velocityECI = velocityECI
        // Tanks from the tank modules: S1 LOX 261 / CH4 202, S2 LOX 65 / CH4 51.
        func tankVolumes(stage: Int) -> (Double, Double) {
            let mods = assembly.modules(ofStage: stage)
            return (mods.reduce(0) { $0 + $1.loxVolumeM3 }, mods.reduce(0) { $0 + $1.ch4VolumeM3 })
        }
        let (lox1, ch41) = tankVolumes(stage: 1)
        let (lox2, ch42) = tankVolumes(stage: 2)
        stage1Tanks = PropellantSystem(loxVolume: lox1, ch4Volume: ch41, fill: 1.0)
        stage2Tanks = PropellantSystem(loxVolume: lox2, ch4Volume: ch42, fill: 1.0)
        stage1Engines = (0..<9).map { _ in
            let e = RaptorSim(def: def)
            e.externalFeed = true
            e.throttleSlew = 1.6
            return e
        }
        stage2Engine = RaptorSim(def: def)
        stage2Engine.externalFeed = true
        stage2Engine.throttleSlew = 1.6
        engineOut = Array(repeating: false, count: 9)
        rcs = OrbitalRCS.build(stage: 1)
        // Orient the body axis along local up (radial) at the pad.
        let up = simd_normalize(originECI)
        orientation = OrbitalVehicle.quaternion(from: DVec3(0, 1, 0), to: up)
    }

    /// Rotation taking unit vector `from` onto unit vector `to`.
    static func quaternion(from: DVec3, to: DVec3) -> simd_quatd {
        let axis = simd_cross(from, to)
        let s = simd_length(axis)
        if s < 1e-9 { return simd_quatd(ix: 0, iy: 0, iz: 0, r: 1) }
        let angle = atan2(s, simd_dot(from, to))
        return simd_quatd(angle: angle, axis: axis / s)
    }

    // MARK: mass properties (from the modules + live propellant)

    struct MassProps { var mass: Double; var comY: Double; var iLat: Double; var iRoll: Double }

    var massProps: MassProps {
        let r = OrbitalVehicle.radius
        // (mass, centre height, vertical extent) in the stacked frame.
        var parts: [(Double, Double, Double)] = []
        let stageMods = stage == 1 ? assembly.modules : assembly.modules(ofStage: 2)
        for m in stageMods {
            let base = assembly.baseHeight(of: m)
            parts.append((m.dryMassKg, base + m.heightM / 2, m.heightM))
        }
        if stage == 1 {
            parts.append((stage1Tanks.lox.liquidMass, 15.0, 13.3))
            parts.append((stage1Tanks.ch4.liquidMass, 29.5, 10.3))
            parts.append((stage2Tanks.lox.liquidMass + stage2Tanks.ch4.liquidMass, 46.0, 10.0))
            parts.append((OrbitalVehicle.payloadMass, 55.0, 20.0)) // payload only: S2 dry is already in the modules above
        } else {
            parts.append((stage2Tanks.lox.liquidMass, 46.0, 3.3))
            parts.append((stage2Tanks.ch4.liquidMass, 51.5, 2.6))
            parts.append((OrbitalVehicle.payloadMass, 61.0, 14.0))
        }
        parts.append((rcs.n2Mass, stage == 1 ? 60.0 : 60.0, 1.0))
        var m = 0.0, my = 0.0
        for (pm, py, _) in parts { m += pm; my += pm * py }
        let cy = m > 0 ? my / m : 0
        var iLat = 0.0
        for (pm, py, len) in parts {
            iLat += pm * (r * r / 2 + len * len / 12 + pow(py - cy, 2))
        }
        let iRoll = m * r * r / 2
        return MassProps(mass: m, comY: cy, iLat: max(iLat, 1e6), iRoll: max(iRoll, 1e5))
    }

    var mass: Double { massProps.mass }
    var comHeight: Double { massProps.comY }
    var gimbalArm: Double {
        let mount = stage == 1 ? OrbitalVehicle.s1MountY : OrbitalVehicle.s2MountY
        return max(comHeight - mount, 0.5)
    }

    var altitude: Double { Planet.altitude(positionECI: positionECI) }
    var speed: Double { simd_length(velocityECI) }
    var upECI: DVec3 { simd_normalize(positionECI) }
    var up: DVec3 { simd_act(orientation, DVec3(0, 1, 0)) }   // body +Y in ECI
    func toLocal(_ eci: DVec3, originECI: DVec3) -> DVec3 { Planet.localFromECI(eci, originECI: originECI) }
    var localPosition: DVec3 { Planet.localFromECI(positionECI, originECI: OrbitalFlight.padECI) }
    var comECI: DVec3 { positionECI + simd_act(orientation, DVec3(0, comHeight, 0)) }

    /// Active engines for the current stage (S1: the 9, minus any out; S2: 1).
    var activeStage1Engines: [RaptorSim] {
        stage1Engines.enumerated().filter { !engineOut[$0.offset] }.map { $0.element }
    }
    var activeEngines: [RaptorSim] { stage == 1 ? activeStage1Engines : (stage2EngineOut ? [] : [stage2Engine]) }
    var activeEngineCount: Int { activeEngines.count }
    var thrustSeaLevelFull: Double { Double(activeEngineCount) * def.thrustSeaLevelN }

    /// Thrust centroid offset (body x/z, m) from asymmetric thrust — zero with
    /// all engines lit, non-zero with an outer engine out. The autopilot's
    /// gimbal feedforward cancels the torque this offset produces.
    var thrustCentroidOffset: DVec3 {
        guard stage == 1 else { return .zero }
        var fx = 0.0, fz = 0.0, f = 0.0
        for (i, e) in stage1Engines.enumerated() where !engineOut[i] {
            let t = max(e.thrust, 0)
            fx += t * OrbitalVehicle.enginePositions[i].x
            fz += t * OrbitalVehicle.enginePositions[i].z
            f += t
        }
        guard f > 1 else { return .zero }
        return DVec3(fx / f, 0, fz / f)
    }

    /// Torque the current asymmetric thrust applies about the CoM (body frame).
    var thrustOffsetTorque: DVec3 {
        let off = thrustCentroidOffset
        let f = thrustTotal
        // Thrust acts along -Y at the offset: tau = r x F = (off.z * f, 0, -off.x * f).
        return DVec3(off.z * f, 0, -off.x * f)
    }

    /// Shut down one S1 engine by index (0 = centre E1). Player-initiated
    /// (tap) or failure-injected; the autopilot compensates, it does not abort.
    func shutDownEngine(_ i: Int) {
        guard stage == 1, i >= 0, i < 9, !engineOut[i] else { return }
        engineOut[i] = true
        stage1Engines[i].requestShutdown()
    }
    func relightEngine(_ i: Int) {
        guard stage == 1, i >= 0, i < 9, engineOut[i] else { return }
        engineOut[i] = false
        stage1Engines[i].requestRelight()
    }

    /// Switch the RCS set to the stage-2 configuration at separation.
    func switchRCSToStage2() { rcs = OrbitalRCS.build(stage: 2) }

    // MARK: dynamics (ECI, 240 Hz substeps from the flight)

    /// Advance the rigid body. `torqueRequest` is the attitude PD torque
    /// (body frame) from the flight; the vehicle serves it with the gimbal
    /// while the engines burn and with the RCS allocator while coasting.
    /// `axialPush` is the separation push (N along +Y body) during staging.
    func step(dt: Double, torqueRequest: DVec3, axialPush: Double, ambient: AtmosphereSample) {
        time += dt
        let mp = massProps
        let m = mp.mass
        let com = DVec3(0, mp.comY, 0)
        var F = Planet.gravity(positionECI: positionECI) * m
        var Tb = DVec3.zero

        // --- engines: thrust through each gimballed axis, at its mount point ---
        let engines = activeEngines
        let mountY = stage == 1 ? OrbitalVehicle.s1MountY : OrbitalVehicle.s2MountY
        thrustTotal = engines.reduce(0) { $0 + $1.thrust }
        if stage == 1 {
            for (i, e) in stage1Engines.enumerated() where !engineOut[i] {
                let thrustB = -e.gimbal.exhaustAxis * e.thrust
                F += simd_act(orientation, thrustB)
                Tb += simd_cross(OrbitalVehicle.enginePositions[i] - com, thrustB)
            }
        } else if !stage2EngineOut {
            let thrustB = -stage2Engine.gimbal.exhaustAxis * stage2Engine.thrust
            F += simd_act(orientation, thrustB)
            Tb += simd_cross(DVec3(0, mountY, 0) - com, thrustB)
        }

        // --- attitude: gimbal while burning, RCS allocator while coasting ---
        // Gimbal torque comes from the deflected thrust itself (cross of the
        // thrust vector at each mount point, above) — it is NOT added again here.
        if thrustTotal > 0.05 * thrustSeaLevelFull && !engines.isEmpty {
            applyGimbal(torqueRequest: torqueRequest, totalThrust: thrustTotal)
        } else {
            let achieved = rcs.allocate(torque: torqueRequest, comY: mp.comY, dt: dt)
            F += simd_act(orientation, rcs.lastForceBody)
            Tb += achieved
        }
        // --- separation push (RCS axial thrusters, +Y body) ---
        if axialPush > 0 {
            F += simd_act(orientation, DVec3(0, axialPush, 0))
        }

        // --- aerodynamics: axial drag + cross-flow, air-relative velocity ---
        let vRel = velocityECI - Planet.rotationVelocity(at: positionECI)
        let vb = simd_act(orientation.inverse, vRel)
        let rho = ambient.density
        let aRef = Double.pi * OrbitalVehicle.radius * OrbitalVehicle.radius
        let speed = simd_length(vb)
        dynamicPressure = 0.5 * rho * speed * speed
        mach = ambient.speedOfSound > 1 ? speed / ambient.speedOfSound : 0
        let height = stage == 1 ? OrbitalVehicle.totalHeight : OrbitalVehicle.totalHeight - OrbitalVehicle.stage1Height
        let machFactor = 1 + 0.6 * smoothstepd(0.75, 1.15, mach) - 0.25 * smoothstepd(1.3, 2.5, mach)
        let cdAx = (vb.y > 0 ? 0.55 : 1.05) * machFactor
        let fAx = -0.5 * rho * abs(vb.y) * vb.y * cdAx * aRef
        let vn = DVec3(vb.x, 0, vb.z)
        let fN = -0.5 * rho * simd_length(vn) * 1.15 * (2 * OrbitalVehicle.radius * height) * vn
        let fAeroB = DVec3(0, fAx, 0) + fN
        let aeroT = simd_cross(DVec3(0, mp.comY + 10, 0) - com, fN)
        F += simd_act(orientation, fAeroB)
        Tb += aeroT

        // --- supersonic vapor cone (Prandtl-Glauert condensation) ---
        // Strongest Mach 0.95-1.2, in denser humid air, fading with altitude.
        // Zero in vacuum / orbit: density and Mach terms both vanish there.
        let machTerm = exp(-pow((mach - 1.05) / 0.18, 2)) * (mach > 0.85 && mach < 1.35 ? 1 : 0)
        let densityTerm = clampd(rho / 0.5, 0, 1)
        let altitudeTerm = 1 - smoothstepd(12_000, 20_000, altitude)
        let qTerm = clampd(dynamicPressure / 15_000, 0, 1)
        vaporCone = machTerm * densityTerm * altitudeTerm * qTerm

        if holdDown {
            velocityECI = .zero
            omegaBody = .zero
            return
        }
        // --- integrate (semi-implicit Euler, ECI) ---
        velocityECI += F / m * dt
        positionECI += velocityECI * dt
        let I = DVec3(mp.iLat, mp.iRoll, mp.iLat)
        let Iw = I * omegaBody
        let gyro = simd_cross(omegaBody, Iw)
        omegaBody += (Tb - gyro) / I * dt
        let wq = simd_quatd(ix: omegaBody.x, iy: omegaBody.y, iz: omegaBody.z, r: 0)
        orientation = simd_normalize(orientation + (orientation * wq) * (0.5 * dt))

        // --- ground contact (precise landing / crash) ---
        if altitude <= 0 && stage == 2 {
            let impact = abs(simd_dot(velocityECI, upECI))
            if touchdownSpeed == nil { touchdownSpeed = impact }
            landed = true
            if impact > 3 { crashed = true }
            velocityECI = .zero
            omegaBody = .zero
        }
    }

    /// Turn a body torque request into gimbal commands on all active engines
    /// (same command each — the cluster gimbals together), with a feedforward
    /// bias that cancels the asymmetric-thrust torque of an engine-out.
    private func applyGimbal(torqueRequest: DVec3, totalThrust: Double) {
        let tl = max(totalThrust, 1) * gimbalArm
        // Feedforward: the actuators must produce -offsetTorque to cancel it.
        let req = torqueRequest - thrustOffsetTorque
        let maxA = def.maxGimbalDeg * .pi / 180
        let yaw = clampd(asin(clampd(-req.z / tl, -1, 1)), -maxA, maxA)
        let pitch = clampd(asin(clampd(-req.x / tl, -1, 1)), -maxA, maxA)
        for e in activeEngines {
            e.gimbal.cmdYaw = yaw
            e.gimbal.cmdPitch = pitch
        }
    }

    /// Capabilities detected from the assembly + live state (what the
    /// autopilot reads — no hard-coded engine count).
    var capabilities: VehicleCapabilities {
        let stageProp = stage == 1 ? stage1Tanks.totalPropellant : stage2Tanks.totalPropellant
        let totalProp = stage1Tanks.totalPropellant + stage2Tanks.totalPropellant
        let ispSL = 330.0, ispVac = 355.0
        let dvStage = OrbitalMechanics.deltaVAvailable(mass: mass, propellant: stageProp, isp: stage == 1 ? ispSL : ispVac)
        let dvTotal: Double
        if stage == 1 {
            let mAfterS1 = mass - stage1Tanks.totalPropellant
            let dv2 = OrbitalMechanics.deltaVAvailable(mass: mAfterS1, propellant: stage2Tanks.totalPropellant, isp: ispVac)
            dvTotal = dvStage + dv2
        } else {
            dvTotal = dvStage
        }
        let localG = simd_length(Planet.gravity(positionECI: positionECI))
        return assembly.capabilities(activeEngines: activeEngineCount, activeRCS: rcs.activeCount,
                                     currentMassKg: mass, remainingPropellantKg: totalProp,
                                     stageDeltaV: dvStage, totalDeltaV: dvTotal,
                                     thrustPerEngineSL: def.thrustSeaLevelN,
                                     thrustPerEngineVac: def.thrustSeaLevelN + Atmosphere.p0 * (stage1Engines[0].exitArea),
                                     ispSL: ispSL, ispVac: ispVac, gimbalArmM: gimbalArm,
                                     currentStage: stage, localG: localG)
    }
}

// MARK: - Booster (expendable, ballistic after separation)

/// The spent Stage 1 after separation: a separate ballistic body that falls
/// back to the planet. No landing burn (expendable). Ocean splashdown uses
/// the water model (waves, buoyancy, water drag); land impact uses the
/// terrain height. High-speed water impact destroys it (it sinks); a slow
/// impact floats and bobs on the waves.
final class OrbitalBooster {
    var positionECI: DVec3
    var velocityECI: DVec3
    var orientation = simd_quatd(ix: 0, iy: 0, iz: 0, r: 1)
    var omegaBody = DVec3(0.05, 0.02, 0.03)   // slow tumble
    let mass = 24_000.0
    let radius = 2.5
    let length = 39.0
    var time: Double = 0
    private(set) var splashed = false
    private(set) var splashdownSpeed: Double = 0
    private(set) var splashdownKind: Planet.SurfaceKind = .ocean
    var splashEvent = false                 // set once, for splash particles; consumed by the flight
    private(set) var floating = false
    private(set) var sunk = false
    private(set) var destroyed = false

    init(positionECI: DVec3, velocityECI: DVec3, orientation: simd_quatd) {
        self.positionECI = positionECI
        self.velocityECI = velocityECI
        self.orientation = orientation
    }

    var altitude: Double { Planet.altitude(positionECI: positionECI) }

    func step(dt: Double) {
        time += dt
        if sunk { return }
        let local = Planet.localFromECI(positionECI, originECI: OrbitalFlight.padECI)
        let waveH = Ocean.waveHeight(eastKm: local.x / 1000, northKm: -local.z / 1000, time: time)
        if splashed && destroyed && splashdownKind == .ocean {
            // Destructive splashdown: the wreck sinks (water drag + negative buoyancy).
            velocityECI += Ocean.dragForce(velocity: velocityECI, area: .pi * radius * radius) / mass * dt
            velocityECI += simd_normalize(positionECI) * (-2.0) * dt
            positionECI += velocityECI * dt
            if altitude < -20 { sunk = true; velocityECI = .zero }
            return
        }
        if floating {
            // Bobbing on the waves: buoyancy spring + water drag, heavily damped.
            let depth = waveH - altitude
            let vSub = Ocean.submergedVolume(radius: radius, depth: depth, length: length)
            var f = Ocean.buoyancyForce(submergedVolume: vSub) - mass * 9.80665
            let vUp = simd_dot(velocityECI, simd_normalize(positionECI))
            f -= 120_000 * vUp   // water damping on the vertical motion
            velocityECI += simd_normalize(positionECI) * (f / mass) * dt
            velocityECI += Ocean.dragForce(velocity: velocityECI, area: .pi * radius * radius) / mass * dt
            positionECI += velocityECI * dt
            if simd_length(velocityECI) < 0.2 { velocityECI = .zero }
            return
        }
        if splashed { return }   // land wreck at rest (floating is handled above)
        // Ballistic fall: spherical gravity + air drag (tumbling, Cd 1.0).
        var f = Planet.gravity(positionECI: positionECI) * mass
        let vRel = velocityECI - Planet.rotationVelocity(at: positionECI)
        let rho = Atmosphere.sample(altitude: max(altitude, 0)).density
        let s = simd_length(vRel)
        if s > 1e-6 {
            f += -0.5 * rho * 1.0 * 30.0 * s * vRel
        }
        velocityECI += f / mass * dt
        positionECI += velocityECI * dt
        let wq = simd_quatd(ix: omegaBody.x, iy: omegaBody.y, iz: omegaBody.z, r: 0)
        orientation = simd_normalize(orientation + (orientation * wq) * (0.5 * dt))

        // Surface contact: ocean (waves) or terrain (land).
        let kind = Planet.surfaceKind(at: positionECI)
        let surfaceAlt = kind == .ocean ? waveH : Terrain.groundAltitude(at: positionECI)
        if altitude <= surfaceAlt {
            let speed = simd_length(velocityECI)
            splashed = true
            splashdownSpeed = speed
            splashdownKind = kind
            splashEvent = true
            if kind == .ocean {
                if speed > 30 {
                    // High-speed ocean impact: the stage breaks up and sinks.
                    destroyed = true
                    velocityECI *= 0.1
                } else {
                    floating = true
                    velocityECI *= 0.2
                }
            } else {
                // Land impact without legs: destroyed on any hard hit.
                destroyed = speed > 10
                velocityECI = .zero
                if destroyed { sunk = true }
            }
        }
    }
}
