import Foundation
import simd

enum FlightProfile: String, CaseIterable {
    case tenK = "10 KM"
    case hover = "HOVER HOP"
}

/// Test scenarios: parameter sets injected into the engine / tank / physics models (nothing is canned).
enum TestScenario: String, CaseIterable {
    case nominal = "Nominal"
    case hardStart = "Hard start"
    case slowIgnition = "Failed ignition"
    case engineRich = "Engine-rich"
    case gimbalStuck = "Gimbal stuck"
    case gusts = "Gusty crosswind"
    case lowPropellant = "Low propellant"
}

enum TV1Phase: String {
    case idle = "READY"
    case countdown = "COUNTDOWN"
    case startup = "ENGINE START"
    case ascent = "ASCENT"
    case hover = "HOVER"
    case divert = "DIVERT"
    case coast = "COAST"
    case descent = "DESCENT"
    case relight = "RELIGHT"
    case landingBurn = "LANDING BURN"
    case touchdown = "TOUCHDOWN"
    case safing = "SAFING"
    case depress = "VENTING"
    case done = "SAFED"
    case aborted = "ABORTED"
    case lost = "VEHICLE LOST"
}

/// TV-1 flight: couples the rigid body, the engine model and the tank model at a fixed rate, and runs the
/// autopilot (or the player's manual inputs). Everything here is physics-driven: the autopilot only sets the
/// throttle, the attitude torque request (→ gimbal / RCS) and engine start/stop.
final class TV1Flight {
    let vehicle: TV1Vehicle
    let engine: RaptorSim
    let surfaces: ImpingementSystem
    let padCenter: DVec3
    let landingZone: DVec3
    var profile: FlightProfile
    let scenario: TestScenario
    var landAtPad = false

    // pilot
    var autopilot = true
    var assistAttitude = true
    var assistHover = false
    var manualThrottle = 0.7
    /// Stick, −1…1. x right → tip / move toward body +x; y up → toward body −z (screen-up = forward / north).
    var manualStick = SIMD2<Double>(0, 0)
    /// TRANSLATE toggle: the stick drives RCS translation (attitude held) instead of rotation.
    var manualTranslate = false

    // state
    private(set) var phase: TV1Phase = .idle
    private(set) var phaseTime = 0.0
    private(set) var missionTime = -1.0          // s since liftoff
    private(set) var maxAltitude = 0.0
    private(set) var targetApogee = 10_000.0
    private(set) var reachableApogee = 0.0
    private(set) var propellantMarginKg = 0.0
    private(set) var landingAccuracy: Double? = nil
    private(set) var events: [String] = []       // timeline events reached (LIFTOFF, MECO, …)
    private(set) var warnings: [String] = []
    private(set) var lastRequest = ControlRequest()
    private var startRetries = 0
    private var relightRetries = 0
    private var everLit = false
    private var lastNoLight = 0
    private var scenarioStarve = 0.0
    private var predictTimer = 0.0
    private var predictedStop = 1e9
    private var hoverTimer = 0.0
    private var attitudeTarget = DVec3(0, 1, 0)
    private var ballisticHop = false
    /// Autopilot countdown clock, seconds relative to T-0 (−10 … 0 …); nil when launched without a countdown.
    private(set) var countdownClock: Double? = nil
    static let countdownLength = 10.0
    /// Engine start command lead so mainstage + the clamped health check complete right at T-0:
    /// chill-down + spin start 0.9 + preburners 0.6 + main ignition 0.25 + ramp 1.45 + health check 0.6.
    var engineStartLead: Double { engine.chillDuration + 0.9 + 0.6 + 0.25 + 1.45 + 0.6 }
    /// Countdown clock time of main-chamber ignition (for the HUD timeline).
    var ignitionLead: Double { 1.45 + 0.6 + 0.25 }
    let substeps = 2                             // 2 × 1/120 s → 240 Hz rigid body

    static let timelineEvents = ["STARTUP", "IGNITION", "LIFTOFF", "MECO", "APOGEE", "LANDING BURN", "TOUCHDOWN", "SAFING"]

    init(engine: RaptorSim, surfaces: ImpingementSystem, pad: DVec3, landingZone: DVec3, profile: FlightProfile, scenario: TestScenario) {
        self.engine = engine
        self.surfaces = surfaces
        self.padCenter = pad
        self.landingZone = landingZone
        self.profile = profile
        self.scenario = scenario
        let fill: Double
        switch scenario {
        case .lowPropellant: fill = 0.30
        default: fill = profile == .tenK ? 0.66 : 0.85
        }
        vehicle = TV1Vehicle(fill: fill)
        vehicle.place(at: pad + DVec3(0, -0.01, 0))
        vehicle.holdDown = true                 // on the pad the hold-down clamps are closed until release
        if profile == .hover { landAtPad = true }
        engine.externalFeed = true
        engine.throttleSlew = 1.6
        engine.fastStart = false
        engine.startOvershoot = scenario == .hardStart ? 0.42 : 0
        engine.ignitionFailures = scenario == .slowIgnition ? 1 : 0
        engine.gimbal.pitchStuck = false
        if scenario == .gusts { vehicle.wind = WindModel(mean: DVec3(9, 0, 3), gust: 8) }
        else { vehicle.wind = WindModel(mean: DVec3(2.5, 0, 1), gust: 1.2) }
        planPropellant()
    }

    // MARK: planning

    var thrustFull: Double {
        let pa = engine.ambient.pressure
        // derated when the fuel side is starved (engine-rich: chamber pressure sags)
        return (engine.def.thrustSeaLevelN + (Atmosphere.p0 - pa) * engine.exitArea) * (1 - 0.55 * engine.fuelStarve)
    }

    /// Ideal Δv check against the profile's needs (gravity + drag losses, landing burn from terminal velocity,
    /// hover/divert margin) → reachable apogee and the margin, reported on the HUD.
    func planPropellant() {
        let m0 = vehicle.mass
        let reserve = 1_500.0
        let mf = m0 - vehicle.tanks.totalPropellant + reserve
        let isp = 322.0
        let dvAvail = isp * TV1Vehicle.g0 * log(m0 / mf)
        let landingDV = 530.0                         // terminal velocity + gravity loss + divert (+10 %)
        let ascentDV = max(dvAvail - landingDV, 0)
        reachableApogee = pow(ascentDV / 1.58, 2) / (2 * TV1Vehicle.g0)
        if profile == .tenK {
            targetApogee = min(10_000, reachableApogee * 0.85)
            let needDV = 1.58 * sqrt(2 * TV1Vehicle.g0 * 10_000) + landingDV
            let needRatio = exp(needDV / (isp * TV1Vehicle.g0))
            let needProp = m0 - m0 / needRatio + reserve
            propellantMarginKg = vehicle.tanks.totalPropellant - needProp
            if targetApogee < 9_999 { warn("LOW PROPELLANT · APOGEE TARGET \(Int(targetApogee)) M") }
        } else {
            targetApogee = 60
            let needProp = 560.0 * 75 + reserve
            propellantMarginKg = vehicle.tanks.totalPropellant - needProp
        }
    }

    private func warn(_ w: String) { if !warnings.contains(w) { warnings.append(w) } }
    private func event(_ e: String) { if !events.contains(e) { events.append(e) } }
    private func enter(_ p: TV1Phase) { phase = p; phaseTime = 0 }

    /// 0…(events − 1) along the HUD timeline; −0.5 before STARTUP (nothing lit). Fractional between STARTUP,
    /// IGNITION and LIFTOFF while the countdown runs so the arc fills in step with the clock.
    var timelineProgress: Double {
        let ev = TV1Flight.timelineEvents
        var last = -1
        for (i, e) in ev.enumerated() where events.contains(e) { last = i }
        if last < 0 { return -0.5 }
        if let c = countdownClock, missionTime < 0 {
            if last == 0 {
                let span = max(engineStartLead - ignitionLead, 0.1)
                return clampd((c + engineStartLead) / span, 0, 0.95)
            }
            if last == 1 { return 1 + clampd((c + ignitionLead) / ignitionLead, 0, 0.95) }
        }
        return Double(last)
    }

    // MARK: commands

    /// Immediate autopilot start (no countdown; the clamps open as soon as the health check passes).
    func begin() {
        guard phase == .idle else { return }
        engine.requestStart()
        vehicle.holdDown = true
        event("STARTUP")
        enter(.startup)
    }

    /// START AUTOPILOT: T-10 countdown. The autopilot takes control and closes the tank vents at T-10, commands
    /// engine start at T-`engineStartLead` (chill-down → spin start → preburners → ignition → ramp), runs the
    /// clamped health check and opens the clamps at T-0. ABORT before engine start recycles to READY.
    func startCountdown() {
        guard phase == .idle else { return }
        autopilot = true
        countdownClock = -TV1Flight.countdownLength
        vehicle.holdDown = true
        vehicle.tanks.setVents(false)
        enter(.countdown)
    }

    /// Manual engine start / relight.
    func manualStart() {
        if phase == .countdown { return }
        event("STARTUP")
        if everLit { engine.requestRelight() } else { engine.requestStart() }
        if phase == .idle { enter(.startup) }
    }
    func manualShutdown() { engine.requestShutdown() }

    /// Abort: on the pad shut down; in flight go straight to the landing logic with what is left.
    func abort() {
        if phase == .countdown {
            // engine not started yet: hold and recycle to READY (START AUTOPILOT is available again)
            warn(String(format: "HOLD · COUNTDOWN ABORTED AT T-%02.0f", max(0, -(countdownClock ?? 0)).rounded(.up)))
            countdownClock = nil
            events.removeAll()
            enter(.idle)
            return
        }
        if missionTime < 0 { engine.requestShutdown(); countdownClock = nil; enter(.aborted); return }
        warn("ABORT COMMANDED")
        if engine.phase.isRunning { enter(.landingBurn) } else { enter(.descent) }
    }

    /// Autopilot taking over mid-flight: pick the phase from the state.
    func resumeAutopilot() {
        autopilot = true
        guard missionTime >= 0, phase != .done, phase != .lost else { return }
        let vy = vehicle.velocity.y
        if engine.phase.isRunning {
            if profile == .hover { enter(vy > -2 ? .hover : .landingBurn) }
            else { enter(vy > 0 && !events.contains("MECO") ? .ascent : .landingBurn) }
        } else if vehicle.inContact {
            enter(.touchdown)
        } else {
            enter(vy > 0 ? .coast : .descent)
        }
    }

    // MARK: geometry shared with the renderer

    var exitWorld: DVec3 {
        let q = engine.gimbal.rotation
        let pivot = DVec3(0, Double(RaptorMesh.pivotY), 0)
        let exitLocal = DVec3(0, -Double(RaptorMesh.height), 0)
        let local = DVec3(0, TV1Vehicle.mountHeight, 0) + pivot + simd_act(q, exitLocal - pivot)
        return vehicle.toWorld(local)
    }
    var exhaustAxisWorld: DVec3 { simd_act(vehicle.orientation, engine.gimbal.exhaustAxis) }
    var altitudeAGL: Double { vehicle.groundClearance(surfaces) }
    var thrustToWeight: Double { engine.thrust / (vehicle.mass * TV1Vehicle.g0) }

    // MARK: step

    func step(dt: Double) {
        phaseTime += dt
        if missionTime >= 0 { missionTime += dt }
        // the countdown clock holds at T-0 while the clamps are still closed (e.g. a no-light recycle)
        if let c = countdownClock { countdownClock = (vehicle.holdDown && c >= 0 && phase != .aborted) ? 0 : c + dt }
        let v = vehicle
        let alt = max(v.position.y, 0)
        let amb = Atmosphere.sample(altitude: alt)
        engine.ambient = amb
        let windW = v.wind.velocity(altitude: alt, time: v.time)
        engine.freestreamVelocity = windW - v.velocity
        engine.impingement = surfaces.cast(origin: exitWorld, direction: exhaustAxisWorld)
        maxAltitude = max(maxAltitude, alt)
        if engine.combustion > 0.5 { everLit = true; event("IGNITION") }

        if autopilot { runAutopilot(dt: dt) } else { runManual(dt: dt) }
        applyScenario(dt: dt)

        // engine ↔ tanks: engine flows drain the tanks; feed starvation goes back into the engine
        engine.step(dt: dt)
        let running = engine.combustion > 0.3 ? 1.0 : 0.0
        v.tanks.step(dt: dt, oxFlow: engine.oxFlow, fuelFlow: engine.fuelFlow, running: running,
                     ambientK: amb.temperature, ambientPa: amb.pressure)
        engine.externalFuelStarve = max(v.tanks.fuelStarve, scenarioStarve)
        engine.externalOxStarve = v.tanks.oxStarve
        if v.tanks.ch4.fillFraction < 0.06 && engine.phase.isRunning { warn("CH4 LOW · ENGINE-RICH RISK") }
        if v.tanks.lox.fillFraction < 0.06 && engine.phase.isRunning { warn("LOX LOW · FLAME-OUT RISK") }
        if engine.engineRich > 0.3 { warn("ENGINE-RICH · COPPER EROSION (GREEN PLUME)") }
        if engine.phase == .failure { warn("ENGINE FAILURE") }

        let sdt = dt / Double(substeps)
        for _ in 0..<substeps {
            let req = controlRequest()
            lastRequest = req
            v.step(dt: sdt, engine: engine, request: req, surfaces: surfaces, ambient: amb)
        }
        if v.structuralFailure && phase != .lost {
            warn("STRUCTURAL FAILURE · \(String(format: "%.1f", v.peakImpactSpeed)) M/S IMPACT")
            engine.requestShutdown()
            enter(.lost)
        }
        if missionTime < 0 && v.position.y > padCenter.y + 0.3 && engine.thrust > 0 {
            missionTime = 0
            event("LIFTOFF")
            v.resetTouchdown()
        }
        if v.tiltAngle > 1.0 && v.inContact && missionTime > 0 && phase != .lost {
            warn("VEHICLE TIPPED OVER")
            engine.requestShutdown()
            enter(.lost)
        }
    }

    private func applyScenario(dt: Double) {
        switch scenario {
        case .engineRich:
            if missionTime > 18 { scenarioStarve = min(0.72, scenarioStarve + dt * 0.25) }
        case .gimbalStuck:
            if missionTime > 6 && !engine.gimbal.pitchStuck {
                engine.gimbal.pitchStuck = true
                engine.gimbal.maxRate = 2 * .pi / 180
                warn("GIMBAL PITCH ACTUATOR STUCK")
            }
        default: break
        }
    }

    // MARK: attitude control → body torque request

    private func controlRequest() -> ControlRequest {
        let v = vehicle
        let mp = v.massProps
        var req = ControlRequest()
        if !autopilot {
            req.parallel = true
            if manualTranslate { req.translate = SIMD2(manualStick.x, -manualStick.y) }
        }
        if !autopilot && !assistAttitude {
            // raw stick: full actuator authority. Stick right tips the top toward +x (rotation about −z);
            // stick up tips it toward −z (rotation about −x) — the same directions as the assisted stick.
            // (Build 180 had the raw pitch sign inverted relative to the assisted mode.)
            if manualTranslate { return req }
            var auth = DVec3.zero
            for a in v.actuators { auth += a.authority(v, engine) }
            req.torque = DVec3(-manualStick.y * auth.x, 0, -manualStick.x * auth.z)
            return req
        }
        var target = attitudeTarget
        if !autopilot {
            // assist: stick tilts the attitude target up to 15° (translate mode: hold vertical)
            target = manualTranslate ? DVec3(0, 1, 0) : simd_normalize(DVec3(manualStick.x * 0.27, 1, -manualStick.y * 0.27))
        }
        let up = v.up
        let eW = simd_cross(up, target)                       // rotation that brings up → target
        let eB = simd_act(v.orientation.inverse, eW)
        let coasting = autopilot && (phase == .coast || phase == .descent)
        v.rcs.deadband = coasting ? 0.12 : 0.04
        let wn = coasting ? 0.45 : 1.25, zeta = 0.9
        let kp = wn * wn, kd = 2 * zeta * wn
        let ax = kp * eB.x - kd * v.omegaBody.x
        let az = kp * eB.z - kd * v.omegaBody.z
        let ay = -1.5 * v.omegaBody.y
        req.torque = DVec3(ax * mp.iLat, ay * mp.iRoll, az * mp.iLat)
        return req
    }

    // MARK: autopilot

    private func setThrottleFor(accel aUp: Double) {
        let m = vehicle.mass
        let cosT = max(vehicle.up.y, 0.6)
        engine.throttleCmd = clampd(m * (TV1Vehicle.g0 + aUp) / (thrustFull * cosT), engine.def.minThrottle, 1)
    }

    private func horizontalTarget() -> DVec3 { landAtPad ? padCenter : landingZone }

    private func runAutopilot(dt: Double) {
        let v = vehicle
        let h = altitudeAGL
        let vy = v.velocity.y
        let pcFrac = engine.chamberPressureBar / engine.def.chamberPressureBar
        attitudeTarget = DVec3(0, 1, 0)
        switch phase {
        case .idle, .done, .aborted, .lost:
            break
        case .countdown:
            engine.throttleCmd = 0.9
            if let c = countdownClock, c >= -engineStartLead {
                engine.requestStart()
                event("STARTUP")
                enter(.startup)
            }
        case .startup:
            engine.throttleCmd = 0.9
            if (engine.phase == .ramp || engine.phase == .mainstage) && pcFrac > 1.12 * max(engine.throttleActualValue, 0.4) && missionTime < 0 {
                warn("ABORT · CHAMBER PRESSURE REDLINE (HARD START)")
                engine.requestShutdown()
                vehicle.holdDown = true
                enter(.aborted)
            } else if engine.phase == .failure {
                warn("ABORT · ENGINE FAILURE ON PAD")
                enter(.aborted)
            } else if engine.noLightEvents > lastNoLight {
                lastNoLight = engine.noLightEvents
                warn("NO LIGHT · MAIN CHAMBER DID NOT IGNITE")
                if startRetries >= 1 { enter(.aborted) } else { startRetries += 1; hoverTimer = 0 }
            } else if engine.phase == .safed && startRetries > 0 && phaseTime > 1 {
                hoverTimer += dt
                if hoverTimer > 2 { warn("RECYCLE · SECOND START ATTEMPT"); engine.requestStart(); hoverTimer = -1e9 }
            } else if engine.phase == .mainstage {
                // healthy-engine check on the clamps, then release
                hoverTimer = max(hoverTimer, 0) + dt
                // with a countdown the clamps hold until T-0 even when the engine is healthy earlier
                let atT0 = (countdownClock ?? 0) >= -0.02
                if abs(pcFrac - engine.throttleActualValue) < 0.08 && hoverTimer > 0.6 && atT0 {
                    vehicle.holdDown = false
                    hoverTimer = 0
                    enter(profile == .tenK ? .ascent : .hover)
                }
            }
        case .ascent:
            event("LIFTOFF")
            // throttle for ~1.2 g net acceleration, max-Q limited
            var aCmd = 12.0
            if v.dynamicPressure > 22_000 { aCmd = 2 }
            setThrottleFor(accel: aCmd)
            // drift gently toward the landing zone (the landing burn removes the rest)
            let dx = horizontalTarget() - v.position
            let vhDes = DVec3(dx.x, 0, dx.z) / 150
            let vh = DVec3(v.velocity.x, 0, v.velocity.z)
            let ah = clampVec((vhDes - vh) * 0.4, 0.5)
            attitudeTarget = simd_normalize(ah + DVec3(0, TV1Vehicle.g0 + aCmd, 0))
            predictTimer += dt
            if predictTimer > 0.1 {
                predictTimer = 0
                let ap = predictApogee()
                if ap >= targetApogee || engine.engineRich > 0.3 || engine.gimbal.pitchStuck || (engine.phase.isRunning && pcFrac < 0.6 * engine.throttleActualValue) {
                    if engine.engineRich > 0.3 { warn("ABORT ASCENT · THRUST LOSS") }
                    if engine.gimbal.pitchStuck { warn("ABORT ASCENT · GIMBAL FAULT") }
                    engine.requestShutdown()
                    event("MECO")
                    enter(.coast)
                }
            }
            if !engine.phase.isRunning && engine.phase != .ramp { event("MECO"); enter(.coast) }
        case .coast, .descent:
            if engine.phase.isRunning { engine.requestShutdown() }
            let rel = v.velocity - v.wind.velocity(altitude: max(v.position.y, 0), time: v.time)
            if simd_length(rel) > 15 { attitudeTarget = simd_normalize(rel.y > 0 ? rel : -rel) }
            if vy < 0 && phase == .coast { event("APOGEE"); event("COAST"); enter(.descent) }
            predictTimer += dt
            if phase == .descent && predictTimer > 0.05 {
                predictTimer = 0
                let plan = engine.fuelStarve > 0.2 ? 0.7 : 0.78     // more margin with a derated engine
                predictedStop = predictLandingBurn(throttle: plan)
                if predictedStop < 45 || h < 400 {
                    engine.throttleCmd = plan
                    engine.requestRelight()
                    relightRetries = 0
                    lastNoLight = engine.noLightEvents
                    enter(.relight)
                }
            }
        case .relight:
            engine.throttleCmd = 0.78
            if engine.noLightEvents > lastNoLight {
                lastNoLight = engine.noLightEvents
                warn("LANDING RELIGHT NO LIGHT · RETRY")
                if relightRetries < 2 { relightRetries += 1; engine.requestRelight() }
            }
            if engine.combustion > 0.3 { event("LANDING BURN"); enter(.landingBurn) }
            landingGuidance(dt: dt, h: h)
        case .landingBurn:
            event("LANDING BURN")
            landingGuidance(dt: dt, h: h)
            checkTouchdown()
        case .hover:
            event("LIFTOFF")
            let vt = clampd(0.45 * (targetApogee - h), -4, 9)
            setThrottleFor(accel: 1.6 * (vt - vy))
            holdHorizontal(target: padCenter, maxTilt: 0.06)
            if abs(h - targetApogee) < 2 && abs(vy) < 0.8 { hoverTimer += dt } else { hoverTimer = max(0, hoverTimer - dt * 0.5) }
            let lowProp = v.tanks.burnTime(massFlow: max(engine.massFlow, 1), mixtureRatio: engine.def.mixtureRatio) < 30
            // a light vehicle can't hover: at minimum throttle it still out-thrusts its weight. Cut at the hop
            // height and fly it like the 10 km profile (coast → predictor-timed relight → landing burn).
            let twMin = engine.def.minThrottle * thrustFull / (v.mass * TV1Vehicle.g0)
            if twMin > 1.0 && h > targetApogee - 8 && vy > 0 {
                warn("T/W > 1 AT MIN THROTTLE · BALLISTIC HOP")
                ballisticHop = true
                engine.requestShutdown()
                event("MECO")
                enter(.coast)
                break
            }
            if hoverTimer > 4 || phaseTime > 30 || lowProp { hoverTimer = 0; enter(.divert); event("MECO") }
        case .divert:
            let vt = clampd(0.45 * (targetApogee - h), -3, 3)
            setThrottleFor(accel: 1.6 * (vt - vy))
            let tgt = horizontalTarget()
            holdHorizontal(target: tgt, maxTilt: 0.14)
            let dxy = DVec3(tgt.x - v.position.x, 0, tgt.z - v.position.z)
            // settle over the target, but never hover indefinitely (gusts can keep it a few metres off and the
            // landing guidance nulls the rest): go after 10 s within 6 m, after 20 s regardless, or on low propellant
            let settled = simd_length(dxy) < 1.5 && simd_length(DVec3(v.velocity.x, 0, v.velocity.z)) < 0.6
            let lowProp = v.tanks.burnTime(massFlow: max(engine.massFlow, 1), mixtureRatio: engine.def.mixtureRatio) < 25
            if settled || (phaseTime > 10 && simd_length(dxy) < 6) || phaseTime > 20 || lowProp {
                event("APOGEE"); event("COAST"); event("LANDING BURN")
                enter(.landingBurn)
            }
        case .touchdown:
            engine.throttleCmd = engine.def.minThrottle
            if engine.phase.isRunning { engine.requestShutdown() }
            if phaseTime > 3 { event("SAFING"); enter(.safing) }
        case .safing:
            if phaseTime > 3 { vehicle.tanks.setVents(true); enter(.depress) }
        case .depress:
            vehicle.frost = max(0, vehicle.frost - dt / 25)
            if vehicle.tanks.lox.pressure < 1.2e5 && vehicle.tanks.ch4.pressure < 1.2e5 && phaseTime > 8 { enter(.done) }
        }
    }

    private func clampVec(_ a: DVec3, _ maxLen: Double) -> DVec3 {
        let l = simd_length(a)
        return l > maxLen ? a * (maxLen / l) : a
    }

    private func holdHorizontal(target: DVec3, maxTilt: Double) {
        let v = vehicle
        let dx = DVec3(target.x - v.position.x, 0, target.z - v.position.z)
        let vh = DVec3(v.velocity.x, 0, v.velocity.z)
        let ah = clampVec(dx * 0.05 - vh * 0.45, tan(maxTilt) * TV1Vehicle.g0)
        attitudeTarget = simd_normalize(ah + DVec3(0, TV1Vehicle.g0, 0))
    }

    /// Powered descent: constant-deceleration vertical guidance to a soft touchdown + zero-effort-miss divert.
    private func landingGuidance(dt: Double, h: Double) {
        let v = vehicle
        let vy = v.velocity.y
        let vtd = 1.2
        let hEff = max(h - 0.05, 0.3)
        var aReq: Double
        if profile == .hover && phase == .landingBurn && !ballisticHop {
            let vt = -clampd(0.3 * h, 0.9, 6)
            aReq = 1.8 * (vt - vy)
        } else if vy < -vtd {
            aReq = (vy * vy - vtd * vtd) / (2 * hEff)
        } else {
            aReq = 1.5 * (-vtd - vy)
        }
        setThrottleFor(accel: aReq)
        // too much thrust even at minimum throttle very close to the ground → cut and drop the last bit
        if h < 0.8 && vy > -0.4 && engine.throttleCmd <= engine.def.minThrottle + 1e-3 && thrustToWeight > 1.05 {
            engine.requestShutdown()
        }
        // divert: zero-effort-miss toward the target, tilt-limited, vertical in the last metres
        let tgt = horizontalTarget()
        let dx = DVec3(tgt.x - v.position.x, 0, tgt.z - v.position.z)
        let vh = DVec3(v.velocity.x, 0, v.velocity.z)
        // ZEM/ZEV optimal divert (arrive over the target with zero horizontal velocity); time-to-go of a
        // constant-deceleration descent; last 3 m only null the drift
        let tgo = max(2 * hEff / max(-vy, 1.0), 2.0)
        let maxTilt = h > 120 ? 0.21 : (h > 15 ? 0.14 : (h > 5 ? 0.07 : 0.03))
        // velocity-target divert: head for the target only as fast as the remaining burn can still stop the
        // sideways motion; if the target is out of reach the vehicle lands short but upright and slow
        let aLatLow = tan(0.07) * TV1Vehicle.g0 * 1.5
        let vMax = h > 3 ? 0.45 * aLatLow * tgo + 0.6 * tan(maxTilt) * TV1Vehicle.g0 * max(tgo - 4, 0) * 0.25 : 0
        let vhDes = clampVec(dx * (2.2 / tgo), vMax)
        let aCap = tan(maxTilt) * (TV1Vehicle.g0 + max(aReq, 0))
        let aZem = dx * (6 / (tgo * tgo)) - vh * (4 / tgo)
        // optimal ZEM/ZEV divert while it is feasible, velocity-target fallback when it is not
        let aRaw = (h > 3 && simd_length(aZem) <= aCap) ? aZem : (vhDes - vh) * 1.2
        let ah = clampVec(aRaw, tan(maxTilt) * (TV1Vehicle.g0 + max(aReq, 0)))
        attitudeTarget = simd_normalize(ah + DVec3(0, TV1Vehicle.g0 + max(aReq, 0), 0))
        if !engine.phase.isRunning && engine.phase != .spinStart && engine.phase != .preburnerIgnition && phase == .landingBurn && !v.inContact {
            warn("ENGINE OUT DURING LANDING BURN")
        }
    }

    private func checkTouchdown() {
        let v = vehicle
        if v.inContact && v.contactCount >= 2 {
            engine.requestShutdown()
            let tgt = horizontalTarget()
            landingAccuracy = simd_length(DVec3(v.position.x - tgt.x, 0, v.position.z - tgt.z))
            if let s = v.touchdownSpeed, s > 2.5 { warn(String(format: "HARD LANDING · %.1f M/S · SKIRT DAMAGED", s)) }
            event("TOUCHDOWN")
            enter(.touchdown)
        }
    }

    // MARK: manual flight

    private func runManual(dt: Double) {
        let v = vehicle
        // manual launch: the clamps open once the engine reaches mainstage (the player then owns the throttle)
        if v.holdDown && missionTime < 0 && engine.phase == .mainstage && engine.combustion > 0.9 { v.holdDown = false }
        attitudeTarget = DVec3(0, 1, 0)
        if assistHover && engine.phase.isRunning {
            let vt = 0.0
            setThrottleFor(accel: 1.6 * (vt - v.velocity.y))
        } else {
            engine.throttleCmd = clampd(manualThrottle, engine.def.minThrottle, 1)
        }
        if missionTime >= 0 && v.inContact && !engine.phase.isRunning && simd_length(v.velocity) < 0.3 && phase != .touchdown && phase != .safing && phase != .depress && phase != .done {
            let tgt = horizontalTarget()
            landingAccuracy = simd_length(DVec3(v.position.x - tgt.x, 0, v.position.z - tgt.z))
            event("TOUCHDOWN")
            enter(.touchdown)
        }
        if phase == .touchdown || phase == .safing || phase == .depress { runAutopilotSafing(dt: dt) }
    }

    private func runAutopilotSafing(dt: Double) {
        switch phase {
        case .touchdown: if phaseTime > 3 { event("SAFING"); enter(.safing) }
        case .safing: if phaseTime > 3 { vehicle.tanks.setVents(true); enter(.depress) }
        case .depress:
            vehicle.frost = max(0, vehicle.frost - dt / 25)
            if vehicle.tanks.lox.pressure < 1.2e5 && vehicle.tanks.ch4.pressure < 1.2e5 && phaseTime > 8 { enter(.done) }
        default: break
        }
    }

    // MARK: predictors (1-D vertical, with drag and the engine start-up curve)

    private func drag(_ v: Double, _ h: Double) -> Double {
        let rho = Atmosphere.sample(altitude: max(h, 0)).density
        let a = Double.pi * TV1Vehicle.radius * TV1Vehicle.radius
        let cd = v > 0 ? 0.55 : 1.05
        return -0.5 * rho * abs(v) * v * cd * a
    }

    /// Apogee if the engine were cut now.
    func predictApogee() -> Double {
        var h = vehicle.position.y, vy = vehicle.velocity.y
        let m = vehicle.mass
        let dt = 0.1
        var n = 0
        // thrust tail-off adds a little
        vy += 0.12 * engine.thrust / m
        while vy > 0 && n < 3000 {
            vy += (-TV1Vehicle.g0 + drag(vy, h) / m) * dt
            h += vy * dt
            n += 1
        }
        return h - padCenter.y
    }

    /// Height above ground at which the descent would stop if the relight were commanded now.
    func predictLandingBurn(throttle: Double) -> Double {
        var h = altitudeAGL, vy = vehicle.velocity.y
        var m = vehicle.mass
        let dt = 0.05
        var t = 0.0
        let tf = engine.def.thrustSeaLevelN * (1 - 0.55 * engine.fuelStarve)
        while t < 120 {
            var thr = 0.0
            if t > 1.5 && t <= 1.75 { thr = 0.28 }
            else if t > 1.75 {
                let s = clampd((t - 1.75) / 1.45, 0, 1)
                thr = 0.28 + (throttle - 0.28) * s * s * (3 - 2 * s)
            }
            let f = thr * tf
            m -= f / (330 * TV1Vehicle.g0) * dt
            vy += (f / m - TV1Vehicle.g0 + drag(vy, h + padCenter.y) / m) * dt
            h += vy * dt
            t += dt
            if vy >= 0 { return h }
            if h <= 0 { return -abs(vy) * 3 }
        }
        return h
    }
}
