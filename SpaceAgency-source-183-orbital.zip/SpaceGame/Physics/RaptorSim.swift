import Foundation
import simd

enum EnginePhase: String {
    case safed = "Safed"
    case chilldown = "Chill-down"
    case spinStart = "Spin start"
    case preburnerIgnition = "Preburner ignition"
    case mainIgnition = "Main chamber ignition"
    case ramp = "Ramp to mainstage"
    case mainstage = "Mainstage"
    case shutdown = "Shutdown"
    case purge = "Purge"
    case failure = "ENGINE FAILURE"

    var isRunning: Bool { self == .mainIgnition || self == .ramp || self == .mainstage }
    var isStarting: Bool { self == .chilldown || self == .spinStart || self == .preburnerIgnition || self == .mainIgnition || self == .ramp }
}

/// Plume / flow-field parameters derived from the nozzle state and ambient pressure.
struct PlumeState {
    var active: Double = 0            // 0..1 combustion intensity
    var exitPressure: Double = 0      // Pa
    var ambientPressure: Double = 101_325
    var exitMach: Double = 0
    var jetMach: Double = 0           // fully-expanded Mach
    var jetRadius: Double = 0.665     // m, fully expanded jet radius
    var boundaryAngle: Double = 0     // rad, initial jet boundary turn (Prandtl-Meyer), + = expanding
    var shockSpacing: Double = 2.5    // m
    var diamondStrength: Double = 0
    var vacuumness: Double = 0        // 0 = dense air, 1 = vacuum
    var brightness: Double = 0
    var afterburn: Double = 0         // orange afterburning of fuel-rich exhaust with ambient O2
    var length: Double = 20
    var coreLength: Double = 2
    var expansionState: String = "—"
    // ground interaction
    var groundFactor: Double = 0      // 0..1 how much ground interaction to show (fades with altitude)
    var impingementDistance: Double = 5.2  // m along axis from exit to pad
    var wallJetRadius: Double = 0     // m
    var wallJetSpeed: Double = 0      // m/s at the stagnation edge
    var stagnationPressure: Double = 0 // Pa (estimate at the pad)
    var flash: Double = 0
    // oncoming airflow (retro-propulsion hook, not visualised yet): freestream velocity in the engine/world
    // frame (m/s) and dynamic pressure ½ρv² (Pa). Zero on the test stand.
    var freestreamVelocity = DVec3.zero
    var dynamicPressure: Double = 0
}

/// Raptor-class full-flow staged-combustion engine model: time-based start/shutdown state machine,
/// isentropic nozzle performance, altitude-dependent thrust, nozzle wall heating and pad heating.
final class RaptorSim {
    let def: PartDefinition
    // nozzle constants
    let gamma: Double
    let eps: Double
    let exitMach: Double
    let peOverPc: Double
    let throatArea: Double
    let exitArea: Double
    let pc100: Double
    let g0 = 9.80665

    // state
    private(set) var phase: EnginePhase = .safed
    private(set) var phaseTime: Double = 0
    private(set) var pcFrac: Double = 0          // Pc / Pc(100 %)
    private(set) var rpmFrac: Double = 0
    private(set) var vent: Double = 0            // cryogenic venting 0..1
    private(set) var flash: Double = 0           // ignition flash 0..1
    private(set) var combustion: Double = 0      // 0..1
    private(set) var wallTemp: Double = 293      // K, nozzle extension
    private(set) var padTemp: Double = 293       // K, concrete surface under the plume
    private(set) var scorch: Double = 0          // 0..1
    private(set) var shockRingAge: Double = 99   // s since main ignition (ground shock / dust ring)
    private(set) var ignitionEvents: Int = 0     // increments on main ignition (audio trigger)
    private(set) var popEvents: Int = 0          // preburner light / shutdown pop
    var throttleCmd: Double = 1.0
    /// Main-valve throttle slew (fraction / s). The hop controller uses a faster one.
    var throttleSlew: Double = 0.5
    private var throttleActual: Double = 1.0
    var fastStart = false                        // compress chill-down (demo / screenshots)
    // propellant run tanks (fractions of a full load) and engine-rich (fuel-starved) state
    var ch4Level: Double = 1.0
    var loxLevel: Double = 1.0
    let ch4Capacity: Double = 190 * 95      // kg — ≈95 s at 100 % (gameplay-sized run tank)
    let loxCapacity: Double = 650 * 115     // kg — ≈115 s at 100 %
    private(set) var mixtureRatio: Double = 3.6
    private(set) var engineRich: Double = 0      // 0..1 copper-attack severity (green plume)
    private(set) var richTime: Double = 0        // s spent heavily engine-rich
    private(set) var chamberWallTemp: Double = 293
    private(set) var instability: Double = 0     // 0..1 combustion roughness
    private(set) var failureEvents: Int = 0
    private var jitterRng = XorShift(seed: 77)
    private var jitter: Double = 0
    // vehicle feed / test-scenario hooks
    /// When true the propellant comes from an external tank model (vehicle) instead of the stand run tank.
    var externalFeed = false
    var externalFuelStarve: Double = 0           // 0…1 fuel-side starvation imposed by the feed system / scenario
    var externalOxStarve: Double = 0             // 0…1 LOX starvation (flame-out when it reaches 1)
    var startOvershoot: Double = 0               // hard-start scenario: chamber-pressure spike during ramp
    var ignitionFailures: Int = 0                // slow/failed-ignition scenario: next N main ignitions do not light
    private(set) var noLightEvents: Int = 0
    private(set) var timeSinceIgnition: Double = -1   // s since main ignition (−1 = not lit this run)
    var chillDuration: Double { fastStart ? 1.2 : 4.0 }
    /// Seconds until main-chamber ignition while starting (for the T− clock), nil otherwise.
    var countdownToIgnition: Double? {
        switch phase {
        case .chilldown: return max(0, chillDuration - phaseTime) + 0.9 + 0.6
        case .spinStart: return max(0, 0.9 - phaseTime) + 0.6
        case .preburnerIgnition: return max(0, 0.6 - phaseTime)
        default: return nil
        }
    }
    /// Fuel-rich start transient: orange/red flame for the first ~0.5–1 s after ignition.
    var richness: Double {
        guard timeSinceIgnition >= 0, combustion > 0.05 else { return 0 }
        return 1 - smoothstepd(0.45, 0.95, timeSinceIgnition)
    }

    // ambient & geometry
    var ambient = Atmosphere.sample(altitude: 0)
    var exitHeight: Double = 5.2                 // m, nozzle exit above pad (untilted)
    var impingement = ImpingementHit()           // from ImpingementSystem (generic surface raycast)
    var freestreamVelocity = DVec3.zero          // m/s, oncoming air (vehicle milestone drives this)
    var gimbal = GimbalState()

    // outputs
    private(set) var thrust: Double = 0          // N
    private(set) var massFlow: Double = 0        // kg/s
    private(set) var isp: Double = 0             // s
    private(set) var exitVelocity: Double = 0    // m/s
    private(set) var exitPressure: Double = 0    // Pa
    private(set) var plume = PlumeState()

    init(def: PartDefinition) {
        self.def = def
        gamma = def.gamma
        eps = def.expansionRatio
        exitMach = NozzleFlow.supersonicMach(areaRatio: eps, gamma: gamma)
        peOverPc = NozzleFlow.pressureRatio(mach: exitMach, gamma: gamma)
        pc100 = def.chamberPressureBar * 1e5
        // Size the throat so 100 % throttle at sea level gives the published thrust with the ideal
        // thrust coefficient for this ε and γ (absorbs real-gas / efficiency effects into Aₜ).
        let cfm = NozzleFlow.momentumThrustCoefficient(peOverPc: peOverPc, gamma: def.gamma)
        let cfSL = cfm + (peOverPc - Atmosphere.p0 / pc100) * def.expansionRatio
        throatArea = def.thrustSeaLevelN / (cfSL * pc100)
        exitArea = throatArea * def.expansionRatio
        gimbal.maxAngle = def.maxGimbalDeg * .pi / 180
        gimbal.maxRate = def.gimbalRateDegS * .pi / 180
    }

    var exitRadiusPhysical: Double { sqrt(exitArea / .pi) }

    func requestStart() {
        guard phase == .safed || phase == .purge else { return }
        enter(.chilldown)
    }

    /// In-flight hot restart: the engine is still chilled, so skip chill-down and go straight to spin start.
    func requestRelight() {
        guard phase == .shutdown || phase == .purge || phase == .safed else { return }
        enter(.spinStart)
    }

    func requestShutdown() {
        guard phase != .safed && phase != .shutdown && phase != .purge else { return }
        if phase == .chilldown || phase == .spinStart { enter(.purge); return }
        enter(.shutdown)
    }

    private func enter(_ p: EnginePhase) {
        phase = p
        phaseTime = 0
        switch p {
        case .mainIgnition:
            flash = 1
            timeSinceIgnition = 0
            ignitionEvents += 1
            shockRingAge = 0
        case .preburnerIgnition:
            popEvents += 1
        case .shutdown:
            popEvents += 1
        case .failure:
            failureEvents += 1
            flash = 1
        default: break
        }
    }

    func step(dt: Double) {
        phaseTime += dt
        gimbal.step(dt: dt)
        let thrTarget = clampd(throttleCmd, def.minThrottle, 1)
        // throttle actuation rate limit (~0.5 /s main valve slew)
        throttleActual += clampd(thrTarget - throttleActual, -throttleSlew * dt, throttleSlew * dt)

        let chillDur = chillDuration
        if timeSinceIgnition >= 0 { timeSinceIgnition += dt }
        func approach(_ x: inout Double, _ target: Double, _ tau: Double) { x += (target - x) * (1 - exp(-dt / tau)) }

        switch phase {
        case .safed:
            approach(&pcFrac, 0, 0.1); approach(&rpmFrac, 0, 1.2); approach(&vent, 0, 0.6)
            combustion = 0
        case .chilldown:
            if phaseTime < 0.02 { timeSinceIgnition = -1 }
            // LOX/CH4 bled through the pumps and engine to bring hardware to cryogenic temperature.
            approach(&vent, 1, 0.4)
            approach(&rpmFrac, 0.02, 1.0) // windmilling from bleed flow
            if phaseTime > chillDur { enter(.spinStart) }
        case .spinStart:
            // High-pressure helium spin-start of both turbopumps.
            approach(&vent, 0.55, 0.3)
            approach(&rpmFrac, 0.22, 0.35)
            approach(&pcFrac, 0.02, 0.3)
            if phaseTime > 0.9 { enter(.preburnerIgnition) }
        case .preburnerIgnition:
            // Ox-rich and fuel-rich preburners light; turbines now driven by their own hot gas (bootstrap).
            approach(&vent, 0.25, 0.3)
            approach(&rpmFrac, 0.48, 0.25)
            approach(&pcFrac, 0.10, 0.25)
            if phaseTime > 0.6 { enter(.mainIgnition) }
        case .mainIgnition:
            if ignitionFailures > 0 {
                // no light: torch fires but the chamber does not ignite → automatic abort to purge
                approach(&pcFrac, 0.06, 0.1)
                combustion = 0
                if phaseTime > 0.5 { ignitionFailures -= 1; noLightEvents += 1; enter(.purge) }
                break
            }
            // Torch igniters light the gas-gas main chamber.
            approach(&vent, 0.0, 0.2)
            approach(&pcFrac, 0.28, 0.08)
            approach(&combustion, 1, 0.05)
            approach(&rpmFrac, sqrt(pcFrac), 0.12)
            if phaseTime > 0.25 { enter(.ramp) }
        case .ramp:
            let t = clampd(phaseTime / 1.4, 0, 1)
            let s = t * t * (3 - 2 * t)
            var target = 0.28 + (throttleActual - 0.28) * s
            if startOvershoot > 0 {
                // hard start: pressure spike as excess propellant lights at once, rough combustion
                target *= 1 + startOvershoot * exp(-pow((phaseTime - 1.15) / 0.22, 2)) + 0.1 * startOvershoot * sin(phaseTime * 90)
            }
            approach(&pcFrac, target, 0.06)
            approach(&combustion, 1, 0.05)
            approach(&rpmFrac, sqrt(pcFrac), 0.12)
            if phaseTime > 1.45 { enter(.mainstage) }
        case .mainstage:
            // fuel starvation: as the CH4 run tank empties, fuel-pump inlet pressure falls and the
            // mixture ratio climbs oxidiser-rich; chamber pressure sags and becomes rough
            let starve = fuelStarve
            jitter += (jitterRng.unitD() * 2 - 1 - jitter) * min(1, dt * 25)
            let pcTarget = throttleActual * (1 - 0.55 * starve) * (1 + 0.18 * instability * jitter)
            approach(&pcFrac, pcTarget, 0.12)
            combustion = 1
            approach(&rpmFrac, sqrt(pcFrac), 0.12)
            if (!externalFeed && ch4Level <= 0.0005) || externalFuelStarve >= 0.999 || externalOxStarve >= 0.999
                || (richTime > 4.0 && engineRich > 0.85) { enter(.failure) }
        case .shutdown:
            // Main valves close: chamber pressure tail-off of a few hundred ms, pumps spin down.
            pcFrac *= exp(-dt / 0.12)
            approach(&rpmFrac, 0, 1.1)
            if pcFrac < 0.03 { approach(&combustion, 0, 0.05) }
            if phaseTime > 0.9 { enter(.purge) }
        case .failure:
            // Hardware failure: chamber breached, flame-out — pressure collapses, pumps coast down.
            pcFrac *= exp(-dt / 0.05)
            combustion = max(0, combustion - dt * 6)
            approach(&rpmFrac, 0, 0.6)
            vent = 0.9 * exp(-phaseTime / 2.5)
            if phaseTime > 5.0 { enter(.safed) }
        case .purge:
            // Inert purge of manifolds: intermittent white vapour.
            pcFrac *= exp(-dt / 0.1)
            combustion = max(0, combustion - dt * 4)
            approach(&rpmFrac, 0, 1.2)
            vent = 0.85 * exp(-phaseTime / 1.8)
            if phaseTime > 4.0 { enter(.safed) }
        }
        flash *= exp(-dt / 0.09)
        shockRingAge += dt

        computePropellant(dt: dt)
        computePerformance()
        computeThermal(dt: dt)
        computePlume()
    }

    /// Fuel-side starvation from the stand run tank or the vehicle feed system.
    var fuelStarve: Double { max(externalFeed ? 0 : smoothstepd(0.10, 0.0, ch4Level), externalFuelStarve) }

    private func computePropellant(dt: Double) {
        let starve = fuelStarve
        // O/F: nominal 3.6 → up to ~8 as fuel flow collapses
        let mrTarget = def.mixtureRatio + 4.6 * starve * starve
        mixtureRatio += (mrTarget - mixtureRatio) * min(1, dt * 3)
        if combustion < 0.05 { mixtureRatio = def.mixtureRatio }
        // above stoichiometric (≈4.0 for CH4/O2) hot excess oxygen attacks the copper-alloy liner
        engineRich = combustion * smoothstepd(4.3, 7.0, mixtureRatio)
        instability = min(1, engineRich * 1.2)
        richTime = engineRich > 0.6 ? richTime + dt : max(0, richTime - dt * 2)
        let fuelMdot = massFlow / (1 + mixtureRatio)
        let oxMdot = massFlow - fuelMdot
        if !externalFeed {
            ch4Level = max(0, ch4Level - fuelMdot * dt / ch4Capacity)
            loxLevel = max(0, loxLevel - oxMdot * dt / loxCapacity)
        }
        let wallTarget = 293 + (650 + 2200 * engineRich) * combustion * max(pcFrac, 0.3)
        chamberWallTemp += (wallTarget - chamberWallTemp) * min(1, dt / (wallTarget > chamberWallTemp ? 1.5 : 12))
    }

    func refill() { ch4Level = 1; loxLevel = 1; richTime = 0 }
    func starveFuel() { ch4Level = min(ch4Level, 0.12) }

    private func computePerformance() {
        let pc = pcFrac * pc100
        let pa = ambient.pressure
        exitPressure = pc * peOverPc
        let flowing = pcFrac > 0.005
        massFlow = flowing ? pc * throatArea / def.cStar : 0
        let cfm = NozzleFlow.momentumThrustCoefficient(peOverPc: peOverPc, gamma: gamma)
        exitVelocity = flowing ? cfm * def.cStar * max(combustion, 0.35) : 0
        let momentum = massFlow * exitVelocity
        var f = momentum + (exitPressure - pa) * exitArea
        // Summerfield criterion: below pe ≈ 0.4 pa the flow separates from the wall and the
        // pressure deficit no longer acts on the whole exit area.
        if exitPressure < 0.4 * pa {
            f = max(f, momentum * 0.72)
        }
        thrust = flowing ? max(0, f) : 0
        isp = massFlow > 1 ? thrust / (massFlow * g0) : 0
    }

    private func computeThermal(dt: Double) {
        let wallTarget = 293 + 1080 * pcFrac * combustion
        let tauW = wallTarget > wallTemp ? 6.0 : 22.0
        wallTemp += (wallTarget - wallTemp) * (1 - exp(-dt / tauW))
        let ground = plume.groundFactor
        let standoff = plume.impingementDistance / (2 * exitRadiusPhysical)
        let loading = thrust / def.thrustSeaLevelN * min(1, 4.5 / max(standoff, 1))
        let padTarget = 293 + 950 * loading * ground
        let tauP = padTarget > padTemp ? 3.5 : 16.0
        padTemp += (padTarget - padTemp) * (1 - exp(-dt / tauP))
        scorch = min(1, scorch + dt * 0.012 * loading * ground)
    }

    private func computePlume() {
        var p = PlumeState()
        let g = gamma
        let pa = ambient.pressure
        let pc = max(pcFrac * pc100, 1)
        let re = exitRadiusPhysical
        p.active = combustion
        p.flash = flash
        p.ambientPressure = pa
        p.exitPressure = exitPressure
        p.exitMach = exitMach
        // vacuumness on a log scale of ambient pressure: 1 kPa → 0, 0.01 Pa → 1
        let lp = log10(max(pa, 1e-6))
        p.vacuumness = clampd((3 - lp) / 5, 0, 1)
        if pa > 1 {
            p.jetMach = NozzleFlow.machFromPressureRatio(p0OverP: pc / pa, gamma: g)
        } else {
            p.jetMach = 12
        }
        let mj = max(p.jetMach, 1.05)
        // Fully-expanded jet radius from isentropic area ratio.
        let ar = NozzleFlow.areaRatio(mach: mj, gamma: g) / eps
        p.jetRadius = re * min(sqrt(ar), 6)
        // Initial boundary turn: Prandtl–Meyer angle difference (positive = under-expanded, plume balloons).
        p.boundaryAngle = NozzleFlow.prandtlMeyer(mach: mj, gamma: g) - NozzleFlow.prandtlMeyer(mach: exitMach, gamma: g)
        // Shock-cell spacing: Prandtl/Pack  s ≈ 1.22·Dⱼ·√(Mⱼ²−1), with a calibration factor (0.85) that
        // lands the strongly over-expanded sea-level case at ~3 exit diameters, as measured in Raptor test footage.
        p.shockSpacing = 1.22 * 2 * p.jetRadius * sqrt(mj * mj - 1) * 0.85
        let ratio = exitPressure / max(pa, 1e-3)
        if pa < 1 { p.expansionState = "Vacuum (fully under-expanded)" }
        else if ratio < 0.4 { p.expansionState = "Over-expanded (separation risk)" }
        else if ratio < 0.85 { p.expansionState = "Over-expanded" }
        else if ratio < 1.18 { p.expansionState = "Near ideal" }
        else { p.expansionState = "Under-expanded" }
        // Shock diamonds need surrounding air: strong when dense and off-design, weaker near ideal.
        let off = clampd(abs(log(max(ratio, 1e-4))) / 0.7, 0, 1)
        p.diamondStrength = combustion * pow(clampd(pa / 30_000, 0, 1), 0.6) * (0.4 + 0.6 * off)
        p.afterburn = combustion * pow(clampd(pa / Atmosphere.p0, 0, 1), 0.7)
        let thr = thrust / def.thrustSeaLevelN
        p.brightness = combustion * (0.35 + 0.65 * pcFrac) * (1 - 0.65 * p.vacuumness)
        // luminous column ≈ 30–45 exit diameters at sea level / 100 % (flight footage), fading out by ~70 m;
        // longer and wider as ambient pressure drops
        p.length = 2 * re * (22 + 30 * thr) * (1 + 0.6 * (1 - pow(clampd(pa / Atmosphere.p0, 0, 1), 0.3))) * (1 + 3 * p.vacuumness)
        p.coreLength = 2 * re * (1.4 + 2.5 * p.vacuumness)

        // Ground interaction
        let axis = gimbal.exhaustAxis
        let down = max(-axis.y, 0.2)
        _ = down
        let hit = impingement
        p.impingementDistance = hit.hit ? hit.distance : 1e4
        p.groundFactor = hit.hit ? combustion * pow(clampd(pa / 20_000, 0, 1), 0.5) * hit.strength : 0
        p.freestreamVelocity = freestreamVelocity
        let v2 = simd_length_squared(freestreamVelocity)
        p.dynamicPressure = 0.5 * ambient.density * v2
        // Jet centreline dynamic pressure decays past the supersonic core (~ 8 exit diameters here).
        let coreLen = 2 * re * 8
        let decay = p.impingementDistance < coreLen ? 1 : coreLen / p.impingementDistance
        p.stagnationPressure = thrust / (Double.pi * pow(max(p.jetRadius, re), 2)) * decay
        // Radial wall jet: momentum flux ≈ thrust; reach and speed scale ~ √F, reduced by standoff.
        let standoffD = p.impingementDistance / (2 * re)
        p.wallJetRadius = (2 * re) * (3.5 + 9 * sqrt(max(thr, 0))) * (1 / (1 + 0.04 * standoffD)) * (0.4 + 0.6 * p.groundFactor)
        p.wallJetSpeed = 320 * sqrt(max(thr, 0)) * decay * p.groundFactor
        plume = p
    }

    var thrustVector: DVec3 { -gimbal.exhaustAxis * thrust }
    var sideForce: Double { let v = thrustVector; return sqrt(v.x * v.x + v.z * v.z) }

    var oxFlow: Double { massFlow * mixtureRatio / (1 + mixtureRatio) }
    var fuelFlow: Double { massFlow / (1 + mixtureRatio) }
    var oxRPM: Double { rpmFrac * def.oxPumpRPM }
    var fuelRPM: Double { rpmFrac * def.fuelPumpRPM }
    var chamberPressureBar: Double { pcFrac * pc100 / 1e5 }
    var throttleActualValue: Double { throttleActual }
}
