import Foundation

// MARK: - Interplanetary future-proofing (planner only — no Mars flight yet)
//
// Earth -> Mars is a future milestone, not this one. This file is the seam
// it will plug into, so nothing in the orbital milestone hard-codes "Earth
// is the only body":
//  - `CelestialBody` is the body table (Earth today, Mars as data).
//  - `TransferPlanner.hohmannEarthToMars()` is a real Hohmann-transfer
//    estimate (circular, coplanar approximation) used by the map fuel check
//    so a Mars destination gets an honest "not yet available" answer.
//  - `MissionTarget` is the destination type the map and autopilot accept:
//    Earth orbit / Earth landing work now; `.marsTransfer` is accepted by
//    the interface and refused by the flight code with a message.
//  - What is NOT here (and must be built for Mars): a heliocentric state
//    (patched conics: Earth SOI -> heliocentric transfer -> Mars SOI),
//    ephemeris / departure windows, Mars atmosphere / terrain, and a Mars
//    landing model. `nextDepartureWindow()` is a stub that says so.

/// A body in the solar system (patched-conic model: each body has its own SOI;
/// transfers are heliocentric Hohmann arcs between circular orbits).
struct CelestialBody {
    var name: String
    var mu: Double              // m^3/s^2, gravitational parameter of the body
    var radius: Double          // m
    var orbitRadius: Double     // m, semi-major axis around the Sun (circular approx)
    var orbitalPeriod: Double   // s

    static let sunMu = 1.32712440018e20
    static let earth = CelestialBody(name: "Earth", mu: Planet.mu, radius: Planet.radius,
                                     orbitRadius: 1.495978707e11, orbitalPeriod: 365.25 * 86_400)
    static let mars = CelestialBody(name: "Mars", mu: 4.282837e13, radius: 3_389_500,
                                    orbitRadius: 2.2794382e11, orbitalPeriod: 686.98 * 86_400)
}

enum MissionTarget {
    case earthOrbit(altitude: Double)
    case earthLanding(latitude: Double, longitude: Double)
    case marsTransfer            // stub: accepted by the interface, not flyable yet
}

struct HohmannPlan {
    var departureDeltaV: Double  // m/s, from low Earth orbit to the transfer ellipse
    var arrivalDeltaV: Double    // m/s, to capture into low Mars orbit
    var transferTime: Double     // s, half the transfer ellipse period
    var transferDistanceKm: Double
}

enum TransferPlanner {
    /// Hohmann transfer Earth -> Mars (circular, coplanar approximation):
    /// departure ~3.6 km/s from LEO, arrival ~2.6 km/s into low Mars orbit,
    /// transfer ~259 days. This is a planning estimate for the map fuel check.
    static func hohmannEarthToMars() -> HohmannPlan {
        let muSun = CelestialBody.sunMu
        let r1 = CelestialBody.earth.orbitRadius, r2 = CelestialBody.mars.orbitRadius
        let v1 = sqrt(muSun / r1), v2 = sqrt(muSun / r2)
        let aT = (r1 + r2) / 2
        let vT1 = sqrt(muSun * (2 / r1 - 1 / aT))
        let vT2 = sqrt(muSun * (2 / r2 - 1 / aT))
        // Departure from LEO (275 km): hyperbolic excess + Earth escape.
        let vLEO = Planet.circularVelocity(altitude: 275_000)
        let vInfDep = abs(vT1 - v1)
        let dep = sqrt(vInfDep * vInfDep + 2 * Planet.mu / (Planet.radius + 275_000)) - vLEO
        let vInfArr = abs(vT2 - v2)
        let arr = sqrt(vInfArr * vInfArr + 2 * CelestialBody.mars.mu / (CelestialBody.mars.radius + 250_000))
            - sqrt(CelestialBody.mars.mu / (CelestialBody.mars.radius + 250_000))
        let tT = Double.pi * sqrt(aT * aT * aT / muSun)
        return HohmannPlan(departureDeltaV: dep, arrivalDeltaV: arr,
                           transferTime: tT, transferDistanceKm: (r2 - r1) / 1000)
    }

    /// Next Earth->Mars departure window. STUB: needs a real ephemeris (planet
    /// positions vs time). Returns nil and the caller must say "not yet available".
    static func nextDepartureWindow() -> Date? { nil }
}
