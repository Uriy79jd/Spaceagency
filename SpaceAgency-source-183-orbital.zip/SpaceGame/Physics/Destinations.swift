import Foundation
import simd

// MARK: - Map destinations
//
// The map destination system: the player opens the map (destination picker in
// the orbital panel) and selects a place. The game computes the delta-v /
// distance required from the current vehicle state, compares it to the
// vehicle's remaining delta-v (from VehicleCapabilities, detected from the
// snap stack), warns clearly if fuel will run out, and suggests a closer
// reachable destination. Destinations are planet-agnostic: `body` is Earth
// today; a Mars destination is accepted by the same interface and answered
// by the transfer planner stub (see TransferPlanner.swift) — no Mars flight
// is implemented in this milestone.

enum DestinationBody: String {
    case earth, mars
}

enum DestinationKind {
    case orbit(altitude: Double)                 // circular orbit at this altitude
    case landing(latitude: Double, longitude: Double)  // precise landing point (degrees)
    case interplanetaryTransfer                  // Mars — planner stub only
}

struct MapDestination: Equatable {
    var id: String
    var name: String
    var body: DestinationBody
    var kind: DestinationKind

    static func == (lhs: MapDestination, rhs: MapDestination) -> Bool { lhs.id == rhs.id }
}

enum DestinationCatalog {
    static let earthOrbit275 = MapDestination(id: "orbit-275", name: "Orbit · 275 km", body: .earth,
                                              kind: .orbit(altitude: 275_000))
    static let landingPad = MapDestination(id: "lz-pad", name: "Landing Zone · Launch Pad", body: .earth,
                                           kind: .landing(latitude: 28.5, longitude: -80.5))
    static let landingOcean = MapDestination(id: "lz-ocean", name: "Recovery Zone · Downrange Ocean", body: .earth,
                                             kind: .landing(latitude: 28.5, longitude: -78.0))
    static let landingPlains = MapDestination(id: "lz-plains", name: "Landing Site · Inland Plains", body: .earth,
                                              kind: .landing(latitude: 28.9, longitude: -81.5))
    static let marsTransfer = MapDestination(id: "mars", name: "Mars Transfer", body: .mars,
                                             kind: .interplanetaryTransfer)

    static let earthDestinations: [MapDestination] = [earthOrbit275, landingPad, landingOcean, landingPlains]
    static let all: [MapDestination] = earthDestinations + [marsTransfer]
}

struct FuelCheck {
    var destination: MapDestination
    var deltaVRequired: Double        // m/s, .infinity when not computable
    var deltaVAvailable: Double       // m/s
    var reachable: Bool
    var warning: String?              // set when NOT reachable (or interplanetary)
    var suggestedAlternative: MapDestination?
    var distanceKm: Double            // great-circle / orbital distance, km
}

enum MapFuelCheck {
    /// Delta-v required from the current ECI state to a destination, vs the
    /// vehicle's remaining delta-v. Landing targets add a 500 m/s landing-burn
    /// reserve (the TV-1 landing budget pattern). Interplanetary targets are
    /// answered by the transfer planner, not flown.
    static func check(_ dest: MapDestination, position r: DVec3, velocity v: DVec3,
                      availableDV: Double, from catalog: [MapDestination] = DestinationCatalog.earthDestinations)
        -> FuelCheck {
        switch dest.kind {
        case .interplanetaryTransfer:
            let plan = TransferPlanner.hohmannEarthToMars()
            return FuelCheck(destination: dest, deltaVRequired: plan.departureDeltaV,
                             deltaVAvailable: availableDV, reachable: false,
                             warning: "INTERPLANETARY NOT YET AVAILABLE · Mars transfer needs ~\(Int(plan.departureDeltaV)) m/s and a heliocentric flight model (future milestone)",
                             suggestedAlternative: DestinationCatalog.earthOrbit275, distanceKm: plan.transferDistanceKm)
        case let .orbit(alt):
            let need = OrbitalMechanics.deltaVToCircularOrbit(position: r, velocity: v, availableDV: availableDV)
            let dist = max(Planet.altitude(positionECI: r), 0) / 1000
            return finish(dest: dest, needed: need.needed, available: availableDV,
                          distanceKm: abs(alt / 1000 - dist), catalog: catalog)
        case let .landing(lat, lon):
            // From orbit: deorbit to lower the periapsis to the surface + landing
            // reserve. From the ground / suborbital: the distance to the target
            // plus the landing reserve. Either way this is an estimate the
            // precise-landing guidance refines in flight.
            let el = OrbitalElements.from(position: r, velocity: v)
            let target = Planet.radius * DVec3(cos(lat * .pi / 180) * cos(lon * .pi / 180),
                                               cos(lat * .pi / 180) * sin(lon * .pi / 180),
                                               sin(lat * .pi / 180))
            let groundDist = simd_length(r - target) / 1000
            let deorbit: Double
            if el.isClosed {
                // Circularise-then-drop estimate: lower periapsis to the surface.
                let vCirc = Planet.circularVelocity(altitude: max(Planet.altitude(positionECI: r), 0))
                deorbit = abs(el.speed - vCirc) + 500
            } else {
                deorbit = 500
            }
            let needed = deorbit + min(groundDist * 0.5, 1_000)
            return finish(dest: dest, needed: needed, available: availableDV,
                          distanceKm: groundDist, catalog: catalog)
        }
    }

    private static func finish(dest: MapDestination, needed: Double, available: Double,
                               distanceKm: Double, catalog: [MapDestination]) -> FuelCheck {
        let ok = needed.isFinite && available >= needed
        var warning: String? = nil
        var alt: MapDestination? = nil
        if !ok {
            warning = "LOW FUEL FOR \(dest.name.uppercased()) · NEED \(Int(needed)) M/S, HAVE \(Int(available)) M/S — YOU WILL PROBABLY RUN OUT OF FUEL"
            // Suggest the closest reachable destination (lowest requirement that closes).
            alt = catalog.filter { $0.id != dest.id }.first
        }
        return FuelCheck(destination: dest, deltaVRequired: needed, deltaVAvailable: available,
                         reachable: ok, warning: warning, suggestedAlternative: alt, distanceKm: distanceKm)
    }
}

// MARK: - Precise landing guidance (generalised ZEM/ZEV)
//
// The TV-1 landing guidance pattern (constant-deceleration vertical profile +
// zero-effort-miss / zero-effort-velocity divert), generalised from a flat
// pad to any target point on the planet, and from TV-1's fixed numbers to the
// detected VehicleCapabilities (thrust, min throttle, T/W). The target is a
// surface point; the guidance works in the local ENU frame at the target, so
// it is valid anywhere on the planet. Touchdown altitude is the terrain
// height at the target, not sea level.

struct PreciseLandingGuidance {
    /// Desired thrust direction (unit, ECI) + throttle 0...1 for a powered
    /// descent to `targetECI`, or nil when the vehicle is already on the ground.
    /// - Parameters: `capabilities` gates the burn: if T/W at min throttle is
    ///   above ~1 the vehicle cannot hover, so the guidance commands a
    ///   hoverslam (constant-deceleration burn, cut at the last moment) exactly
    ///   like TV-1's landing logic.
    static func command(position r: DVec3, velocity v: DVec3, targetECI: DVec3,
                        capabilities: VehicleCapabilities, localG: Double)
        -> (thrustDirectionECI: DVec3, throttle: Double, timeToGo: Double)? {
        let targetAlt = Terrain.groundAltitude(at: targetECI)
        let (east, north, up) = Planet.enuBasis(at: targetECI)
        let rel = r - targetECI
        let downrange = DVec3(simd_dot(rel, east), simd_dot(rel, up), -simd_dot(rel, north))
        let h = downrange.y - targetAlt
        guard h > 0.5 else { return nil }
        let vLocal = DVec3(simd_dot(v, east), simd_dot(v, up), -simd_dot(v, north))
        // Time-to-go of a constant-deceleration descent to 1.2 m/s touchdown.
        let vtd = 1.2
        let tgo = max(2 * h / max(-vLocal.y, 1.0), 2.0)
        // Vertical: constant-deceleration acceleration demand.
        let aReq: Double
        if vLocal.y < -vtd {
            aReq = (vLocal.y * vLocal.y - vtd * vtd) / (2 * max(h, 0.3))
        } else {
            aReq = 1.5 * (-vtd - vLocal.y)
        }
        // Horizontal: ZEM/ZEV divert (arrive over the target with zero velocity).
        let dx = DVec3(downrange.x, 0, downrange.z)
        let vh = DVec3(vLocal.x, 0, vLocal.z)
        let maxTilt = h > 120 ? 0.21 : (h > 15 ? 0.14 : 0.07)
        let aCap = tan(maxTilt) * (localG + max(aReq, 0))
        let aZem = dx * (6 / (tgo * tgo)) - vh * (4 / tgo)
        let aLat = simd_length(aZem) <= aCap ? aZem : {
            let vhDes = dx * (2.2 / tgo)
            return (vhDes - vh) * 1.2
        }()
        let aLatClamped = simd_length(aLat) > aCap ? aLat * (aCap / simd_length(aLat)) : aLat
        // Thrust direction (local frame): acceleration demand + gravity, then to ECI.
        let aLocal = DVec3(aLatClamped.x, localG + max(aReq, 0), aLatClamped.z)
        let dirLocal = simd_normalize(aLocal)
        let dirECI = east * dirLocal.x + up * dirLocal.y - north * dirLocal.z
        // Throttle from the acceleration demand and the detected thrust.
        let aMag = simd_length(aLocal)
        let thrustNeeded = capabilities.wetMassKg * aMag
        let throttle = clampd(thrustNeeded / max(capabilities.totalThrustVacuumN, 1), 0.4, 1.0)
        return (simd_normalize(dirECI), throttle, tgo)
    }
}
