import Foundation
import simd

// MARK: - Snap interface
//
// Every major piece of a spacecraft is a snap module with a top node and a bottom
// node. A stack is built bottom-up: module N+1's bottom node must snap onto module
// N's top node. The existing data-driven PartDefinition / parts.json system is the
// pattern: modules are data (defined below and, in future, loadable from JSON),
// the assembler validates them, and the vehicle is built from the assembly —
// never hard-coded as one monolithic body. TV-1 and the test-stand Raptor
// placement are untouched: the snap system is for vehicle assembly.

/// Structural interface type of an attach node. Two nodes snap only when their
/// interface types match (a 5 m flange does not snap onto a Raptor engine mount).
enum ModuleInterface: String, Codable {
    case flange5m = "FLANGE-5M"          // Ø5 m structural flange (tanks, interstage, fairing)
    case engineMount = "ENGINE-MOUNT"    // Raptor thrust-structure mount
    case payloadAdapter = "PAYLOAD-5M"   // payload / fairing adapter (same Ø5 m flange, payload side)
}

/// One attach node: where a module connects to its neighbour.
/// `height` is measured from the module's own base (0 = bottom face, heightM = top face).
struct AttachNode: Equatable {
    var height: Double                   // m from the module base
    var axis: DVec3                      // unit; +Y (vehicle axis) for all stack modules
    var diameter: Double                 // m, mating diameter
    var interface: ModuleInterface
}

enum ModuleKind: String {
    case engineBay, tank, interstage, fairing, payload, engine, rcsPod
}

/// One snap module: a piece of a spacecraft. Mass, size and (for tanks) propellant
/// volume live here — the assembled vehicle's numbers fall out of its modules.
struct VehicleModule: Equatable {
    var id: String
    var name: String
    var kind: ModuleKind
    var stage: Int                       // 1 = booster, 2 = upper stage
    var heightM: Double                  // m, including domes / ullage / structure
    var diameterM: Double                // m
    var dryMassKg: Double                // kg, structure (+ engines for an engine bay)
    var loxVolumeM3: Double = 0          // tank modules only
    var ch4VolumeM3: Double = 0          // tank modules only
    var engineCount: Int = 0             // engine-bay modules only
    var rcsThrusterCount: Int = 0        // RCS thrusters carried by this module
    var bottomNode: AttachNode
    var topNode: AttachNode
    /// True for the interstage: it stays with the lower stage at separation.
    var separatesWithLowerStage: Bool = false

    var propellantVolumeM3: Double { loxVolumeM3 + ch4VolumeM3 }
    /// Loaded propellant mass at fill = 1 (CryoTank: volume * 0.94 * subcooled density).
    var loadedPropellantKg: Double {
        loxVolumeM3 * 0.94 * (1141 + 4.8 * 18) + ch4VolumeM3 * 0.94 * (422 + 1.35 * 12)
    }
}

// MARK: - Stack assembler / validator

enum AssemblyError: CustomStringConvertible {
    case interfaceMismatch(lower: String, upper: String, lowerInterface: ModuleInterface, upperInterface: ModuleInterface)
    case diameterMismatch(lower: String, upper: String, lowerDiameter: Double, upperDiameter: Double)
    case axisMisaligned(lower: String, upper: String)
    case emptyStack
    case noEngines(stage: Int)
    case noTanks(stage: Int)

    var description: String {
        switch self {
        case let .interfaceMismatch(l, u, li, ui):
            return "SNAP REJECTED · \(u) (\(ui.rawValue)) does not fit \(l) (\(li.rawValue))"
        case let .diameterMismatch(l, u, ld, ud):
            return "SNAP REJECTED · \(u) Ø\(String(format: "%.2f", ud)) m does not fit \(l) Ø\(String(format: "%.2f", ld)) m"
        case let .axisMisaligned(l, u):
            return "SNAP REJECTED · \(u) axis is not aligned with \(l)"
        case .emptyStack: return "SNAP REJECTED · empty stack"
        case let .noEngines(s): return "STACK INVALID · stage \(s) has no engines"
        case let .noTanks(s): return "STACK INVALID · stage \(s) has no propellant tanks"
        }
    }
}

/// Wrapper so a list of validation errors can be a `Result` failure
/// (a `Result` failure type must conform to `Error`, and `[AssemblyError]` does not).
struct AssemblyErrors: Error, CustomStringConvertible {
    var errors: [AssemblyError]
    var description: String { errors.map { $0.description }.joined(separator: "; ") }
}

/// A validated stack: the ordered modules, their base heights, and the totals that
/// fall out of them. `VehicleAssembly` is the only way to build an `OrbitalVehicle`.
struct VehicleAssembly {
    var modules: [VehicleModule]
    /// Base height (m from the stack foot) of each module, in order.
    var baseHeights: [Double]
    var totalHeightM: Double { baseHeights.last.map { $0 + modules.last!.heightM } ?? 0 }
    var dryMassKg: Double { modules.reduce(0) { $0 + $1.dryMassKg } }
    var loadedPropellantKg: Double { modules.reduce(0) { $0 + $1.loadedPropellantKg } }
    var stageCount: Int { Set(modules.map { $0.stage }).count }
    var engineCount: Int { modules.reduce(0) { $0 + $1.engineCount } }
    var rcsThrusterCount: Int { modules.reduce(0) { $0 + $1.rcsThrusterCount } }

    func modules(ofStage s: Int) -> [VehicleModule] { modules.filter { $0.stage == s } }
    func baseHeight(of module: VehicleModule) -> Double {
        guard let i = modules.firstIndex(of: module) else { return 0 }
        return baseHeights[i]
    }
    /// Dry centre of mass (m from the stack foot), modules at their centres.
    var dryComY: Double {
        var m = 0.0, my = 0.0
        for (i, mod) in modules.enumerated() {
            m += mod.dryMassKg; my += mod.dryMassKg * (baseHeights[i] + mod.heightM / 2)
        }
        return m > 0 ? my / m : 0
    }
}

enum StackBuilder {
    /// Snap tolerance: mating diameters must agree within 5 cm, axes within ~1 deg.
    static let diameterToleranceM = 0.05
    static let axisTolerance = 0.999

    /// Validate an ordered (bottom-up) module list and assemble it. Returns the
    /// assembly, or the list of reasons the stack was rejected — never a silently
    /// broken stack.
    static func assemble(_ modules: [VehicleModule]) -> Result<VehicleAssembly, AssemblyErrors> {
        guard !modules.isEmpty else { return .failure(AssemblyErrors(errors: [.emptyStack])) }
        var errors: [AssemblyError] = []
        for (lower, upper) in zip(modules, modules.dropFirst()) {
            if lower.topNode.interface != upper.bottomNode.interface {
                errors.append(.interfaceMismatch(lower: lower.id, upper: upper.id,
                                                lowerInterface: lower.topNode.interface,
                                                upperInterface: upper.bottomNode.interface))
            }
            if abs(lower.topNode.diameter - upper.bottomNode.diameter) > diameterToleranceM {
                errors.append(.diameterMismatch(lower: lower.id, upper: upper.id,
                                               lowerDiameter: lower.topNode.diameter,
                                               upperDiameter: upper.bottomNode.diameter))
            }
            if simd_dot(lower.topNode.axis, upper.bottomNode.axis) < axisTolerance {
                errors.append(.axisMisaligned(lower: lower.id, upper: upper.id))
            }
        }
        for s in Set(modules.map { $0.stage }) {
            let stageMods = modules.filter { $0.stage == s }
            if stageMods.reduce(0, { $0 + $1.engineCount }) == 0 { errors.append(.noEngines(stage: s)) }
            if stageMods.reduce(0, { $0 + $1.propellantVolumeM3 }) <= 0 { errors.append(.noTanks(stage: s)) }
        }
        guard errors.isEmpty else { return .failure(AssemblyErrors(errors: errors)) }
        var bases: [Double] = []
        var h = 0.0
        for m in modules { bases.append(h); h += m.heightM }
        return .success(VehicleAssembly(modules: modules, baseHeights: bases))
    }
}

// MARK: - Vehicle capabilities (what the autopilot reads — never hard-coded counts)

/// Everything the autopilot needs to know about a vehicle, detected from its
/// assembled snap stack + live state. The autopilot reads this struct: it never
/// assumes 9 engines, an RCS, or any particular stage count. A 30-engine vehicle
/// reports 30 engines here and the autopilot throttles / gimbals / shuts down
/// individual engines from it; a vehicle with no RCS reports `canRCSAttitude =
/// false` and the autopilot says so instead of trying RCS-only control.
struct VehicleCapabilities {
    var engineCount: Int
    var activeEngineCount: Int
    var totalThrustSeaLevelN: Double     // active engines, sea level
    var totalThrustVacuumN: Double       // active engines, vacuum (pressure term)
    var ispSeaLevel: Double              // s, mass-flow-weighted
    var ispVacuum: Double                // s
    var dryMassKg: Double
    var wetMassKg: Double
    var payloadKg: Double
    var propellantKg: Double             // remaining, current stage(s)
    var deltaVStage: Double              // m/s, Tsiolkovsky for the current stage
    var deltaVTotal: Double              // m/s, all remaining stages
    var thrustToWeight: Double           // at the current mass, local g
    var rcsThrusterCount: Int
    var activeRCSCount: Int
    var rcsTorqueAuthorityNm: Double     // approx, per axis
    var canRCSAttitude: Bool { activeRCSCount >= 4 }
    var gimbalAuthorityNm: Double
    var canGimbal: Bool { activeEngineCount > 0 }
    var stageCount: Int
    var currentStage: Int
    var separationMethod: String
    var hasLandingLegs: Bool
    var hasHeatShield: Bool
    var notes: [String]
}

extension VehicleAssembly {
    /// Capabilities from the assembly + live state. `thrustPerEngineSL` /
    /// `thrustPerEngineVac` come from the engine PartDefinition (Raptor 3 here);
    /// `gimbalArmM` is the distance from the CoM to the gimbal pivot.
    func capabilities(activeEngines: Int, activeRCS: Int, currentMassKg: Double,
                      remainingPropellantKg: Double, stageDeltaV: Double, totalDeltaV: Double,
                      thrustPerEngineSL: Double, thrustPerEngineVac: Double,
                      ispSL: Double, ispVac: Double, gimbalArmM: Double,
                      currentStage: Int, localG: Double) -> VehicleCapabilities {
        let rcsForce = 8_000.0
        let arm = 25.0               // m, RCS pods near the top of the stack
        return VehicleCapabilities(
            engineCount: engineCount, activeEngineCount: activeEngines,
            totalThrustSeaLevelN: Double(activeEngines) * thrustPerEngineSL,
            totalThrustVacuumN: Double(activeEngines) * thrustPerEngineVac,
            ispSeaLevel: ispSL, ispVacuum: ispVac,
            dryMassKg: dryMassKg, wetMassKg: currentMassKg, payloadKg: 10_000,
            propellantKg: remainingPropellantKg,
            deltaVStage: stageDeltaV, deltaVTotal: totalDeltaV,
            thrustToWeight: Double(activeEngines) * thrustPerEngineSL / max(currentMassKg * localG, 1),
            rcsThrusterCount: rcsThrusterCount, activeRCSCount: activeRCS,
            rcsTorqueAuthorityNm: Double(max(activeRCS, 0)) * rcsForce * arm / 4,
            gimbalAuthorityNm: Double(activeEngines) * thrustPerEngineSL * gimbalArmM * sin(15 * .pi / 180),
            stageCount: stageCount, currentStage: currentStage,
            separationMethod: "Pyro interstage + RCS separation push",
            hasLandingLegs: false, hasHeatShield: false,
            notes: (activeRCS < 4 ? ["NO RCS ATTITUDE CONTROL — GIMBAL ONLY"] : [])
                + (activeEngines < engineCount ? ["ENGINE OUT — \(engineCount - activeEngines) ENGINE(S) OFF"] : []))
    }
}

// MARK: - The Falcon-size orbital stack, as snap modules (the first example)
//
// Booster (stage 1, 39 m): Engine Bay 9x Raptor + LOX tank + CH4 tank + Interstage.
// Stage 2 (29 m): Engine Bay 1x Raptor + LOX tank + CH4 tank + Fairing/payload.
// Total: 68 m, dry 29,000 kg (24,000 + 5,000), payload 10,000 kg,
// loaded propellant 477,042 kg (S1 381,864 + S2 95,178; usable at mixture 3.6:
// S1 371,376 kg, S2 92,844 kg), liftoff ~516,000 kg loaded (514,000 kg nominal).

enum OrbitalStacks {
    private static func flange(_ y: Double) -> AttachNode {
        AttachNode(height: y, axis: DVec3(0, 1, 0), diameter: 5.0, interface: .flange5m)
    }

    static let boosterModules: [VehicleModule] = [
        VehicleModule(id: "EB-9", name: "Engine Bay · 9x Raptor 3", kind: .engineBay, stage: 1,
                      heightM: 7, diameterM: 5.0, dryMassKg: 15_500, engineCount: 9, rcsThrusterCount: 4,
                      bottomNode: AttachNode(height: 0, axis: DVec3(0, 1, 0), diameter: 5.0, interface: .flange5m),
                      topNode: flange(7)),
        VehicleModule(id: "LOX-261", name: "LOX Tank · 261 m3", kind: .tank, stage: 1,
                      heightM: 16, diameterM: 5.0, dryMassKg: 4_500, loxVolumeM3: 261,
                      bottomNode: flange(0), topNode: flange(16)),
        VehicleModule(id: "CH4-202", name: "CH4 Tank · 202 m3", kind: .tank, stage: 1,
                      heightM: 13, diameterM: 5.0, dryMassKg: 3_000, ch4VolumeM3: 202,
                      bottomNode: flange(0), topNode: flange(13)),
        VehicleModule(id: "IS-5M", name: "Interstage · 5 m", kind: .interstage, stage: 1,
                      heightM: 3, diameterM: 5.0, dryMassKg: 1_000, rcsThrusterCount: 4,
                      bottomNode: flange(0), topNode: flange(3), separatesWithLowerStage: true),
    ]

    static let stage2Modules: [VehicleModule] = [
        VehicleModule(id: "EB-1", name: "Engine Bay · 1x Raptor 3", kind: .engineBay, stage: 2,
                      heightM: 4, diameterM: 5.0, dryMassKg: 2_600, engineCount: 1, rcsThrusterCount: 4,
                      bottomNode: flange(0), topNode: flange(4)),
        VehicleModule(id: "LOX-65", name: "LOX Tank · 65 m3", kind: .tank, stage: 2,
                      heightM: 6, diameterM: 5.0, dryMassKg: 900, loxVolumeM3: 65,
                      bottomNode: flange(0), topNode: flange(6)),
        VehicleModule(id: "CH4-51", name: "CH4 Tank · 51 m3", kind: .tank, stage: 2,
                      heightM: 5, diameterM: 5.0, dryMassKg: 700, ch4VolumeM3: 51,
                      bottomNode: flange(0), topNode: flange(5)),
        VehicleModule(id: "FAIR-5M", name: "Fairing + Payload · 10 t", kind: .fairing, stage: 2,
                      heightM: 14, diameterM: 5.0, dryMassKg: 800, rcsThrusterCount: 4,
                      bottomNode: flange(0),
                      topNode: AttachNode(height: 14, axis: DVec3(0, 1, 0), diameter: 5.0, interface: .payloadAdapter)),
    ]

    static var fullStack: [VehicleModule] { boosterModules + stage2Modules }

    /// The assembled FX-9 stack, or the validation errors (never a broken stack).
    static func assembled() -> Result<VehicleAssembly, AssemblyErrors> {
        StackBuilder.assemble(fullStack)
    }
}
