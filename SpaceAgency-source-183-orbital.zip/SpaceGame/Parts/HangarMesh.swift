import simd
import Foundation

/// Hangar test bay + vertical ground test stand.
enum HangarMesh {
    /// Height of the engine mount (top of gimbal) above the pad.
    static let mountHeight: Float = 8.30
    static let legOffset: Float = 2.4

    static func corrugatedWall(width: Float, height: Float, period: Float = 0.2, amplitude: Float = 0.022) -> MeshData {
        var m = MeshData()
        let cols = Int(width / period * 8)
        let k = 2 * Float.pi / period
        for i in 0...cols {
            let x = -width / 2 + Float(i) / Float(cols) * width
            // trapezoid-ish rib: smoothed square wave
            let s = sinf(k * x)
            let shaped = tanhf(2.2 * s) / tanhf(2.2)
            let dz = amplitude * shaped
            let dshape = (2.2 * k * cosf(k * x)) * (1 - tanhf(2.2 * s) * tanhf(2.2 * s)) / tanhf(2.2)
            let slope = amplitude * dshape
            let n = simd_normalize(Vec3(-slope, 0, 1))
            for y in [Float(0), height] {
                m.vertices.append(Vertex(position: Vec4(x, y, dz, 1), normal: Vec4(n, shaped * 0.5 + 0.5), uv: Vec4(x, y, 0, 0)))
            }
        }
        for i in 0..<UInt32(cols) {
            let a = i * 2
            m.indices += [a, a + 2, a + 1, a + 1, a + 2, a + 3]
        }
        return m
    }

    static func buildHangar() -> [MeshPart] {
        var floor = MeshData()
        // tessellated floor so vertex AO can darken around the stand feet
        let n = 48
        let half: Float = 40
        for j in 0...n {
            for i in 0...n {
                let x = -half + Float(i) / Float(n) * 2 * half
                let z = -16 + Float(j) / Float(n) * 56
                m_addFloorVertex(&floor, x, z)
            }
        }
        for j in 0..<UInt32(n) {
            for i in 0..<UInt32(n) {
                let a = j * UInt32(n + 1) + i, b = a + UInt32(n + 1)
                floor.indices += [a, b, a + 1, a + 1, b, b + 1]
            }
        }
        var walls = MeshData()
        walls.append(corrugatedWall(width: 80, height: 22), transform: float4x4(translation: Vec3(0, 0, -16)))
        walls.append(corrugatedWall(width: 34, height: 22), transform: float4x4(translation: Vec3(-40, 0, 1)) * float4x4(rotationAxis: Vec3(0, 1, 0), angle: .pi / 2))
        walls.append(corrugatedWall(width: 34, height: 22), transform: float4x4(translation: Vec3(40, 0, 1)) * float4x4(rotationAxis: Vec3(0, 1, 0), angle: -.pi / 2))

        var structure = MeshData()
        // roof trusses (open roof, sky visible between)
        for zi in 0..<6 {
            let z = -14 + Float(zi) * 6
            structure.append(MeshBuilder.beam(from: Vec3(-40, 21.5, z), to: Vec3(40, 21.5, z), width: 0.45))
            structure.append(MeshBuilder.beam(from: Vec3(-40, 19.5, z), to: Vec3(40, 19.5, z), width: 0.3))
            var x: Float = -40
            while x < 40 {
                structure.append(MeshBuilder.beam(from: Vec3(x, 19.5, z), to: Vec3(x + 2.5, 21.5, z), width: 0.14))
                structure.append(MeshBuilder.beam(from: Vec3(x + 2.5, 21.5, z), to: Vec3(x + 5, 19.5, z), width: 0.14))
                x += 5
            }
        }
        // wall columns
        for xi in 0...8 {
            let x = -40 + Float(xi) * 10
            structure.append(MeshBuilder.box(size: Vec3(0.5, 22, 0.5)), transform: float4x4(translation: Vec3(x, 11, -15.6)))
        }
        var lights = MeshData()
        for zi in 0..<3 {
            for xi in 0..<4 {
                let p = Vec3(-21 + Float(xi) * 14, 18.6, -10 + Float(zi) * 9)
                lights.append(MeshBuilder.box(size: Vec3(2.4, 0.08, 0.5)), transform: float4x4(translation: p))
                structure.append(MeshBuilder.box(size: Vec3(2.6, 0.18, 0.7)), transform: float4x4(translation: p + Vec3(0, 0.14, 0)))
                structure.append(MeshBuilder.beam(from: p + Vec3(-1, 0.2, 0), to: p + Vec3(-1, 2.9, 0), width: 0.03))
                structure.append(MeshBuilder.beam(from: p + Vec3(1, 0.2, 0), to: p + Vec3(1, 2.9, 0), width: 0.03))
            }
        }
        return [
            MeshPart(name: "floor", data: floor, material: .concrete),
            MeshPart(name: "walls", data: walls, material: .corrugated),
            MeshPart(name: "structure", data: structure, material: .structureGray),
            MeshPart(name: "lights", data: lights, material: .lightPanel, castsShadow: false),
        ]
    }

    private static func m_addFloorVertex(_ m: inout MeshData, _ x: Float, _ z: Float) {
        // contact AO near stand legs and under walls
        var ao: Float = 1
        let L = legOffset
        for (lx, lz) in [(L, L), (-L, L), (L, -L), (-L, -L)] {
            let d = simd_length(SIMD2<Float>(x - lx, z - lz))
            ao = min(ao, 0.55 + 0.45 * clampf((d - 0.2) / 1.2, 0, 1))
        }
        ao = min(ao, 0.6 + 0.4 * clampf((z + 16) / 3, 0, 1))
        ao = min(ao, 0.6 + 0.4 * clampf((40 - abs(x)) / 3, 0, 1))
        m.vertices.append(Vertex(position: Vec4(x, 0, z, ao), normal: Vec4(0, 1, 0, 0), uv: Vec4(x, z, 0, 0)))
    }

    /// Four-legged lattice test stand; engine hangs from the top deck and fires down onto the pad.
    static func buildStand() -> [MeshPart] {
        var paint = MeshData()
        var steel = MeshData()
        let L = legOffset
        let top = mountHeight + 0.30
        let corners = [Vec3(L, 0, L), Vec3(-L, 0, L), Vec3(-L, 0, -L), Vec3(L, 0, -L)]
        for c in corners {
            paint.append(MeshBuilder.box(size: Vec3(0.32, top, 0.32)), transform: float4x4(translation: Vec3(c.x, top / 2, c.z)))
            steel.append(MeshBuilder.box(size: Vec3(0.7, 0.05, 0.7)), transform: float4x4(translation: Vec3(c.x, 0.025, c.z)))
            for i in 0..<4 {
                let a = Float(i) / 4 * 2 * .pi + .pi / 4
                steel.append(MeshBuilder.bolt(radius: 0.025, height: 0.05), transform: float4x4(translation: Vec3(c.x + 0.25 * cosf(a), 0.05, c.z + 0.25 * sinf(a))))
            }
        }
        // Faces: 0 = front (+Z), 1 = left (-X), 2 = back (-Z), 3 = right (+X).
        // Front and right faces stay open (only top/bottom ties) so the engine and plume are visible.
        let levels: [Float] = [0.4, 3.0, 5.7, top - 0.15]
        for (li, lv) in levels.enumerated() {
            for i in 0..<4 {
                let braced = (i == 1 || i == 2)
                if !braced && li != 0 && li != levels.count - 1 { continue }
                let a = corners[i], b = corners[(i + 1) % 4]
                paint.append(MeshBuilder.beam(from: Vec3(a.x, lv, a.z), to: Vec3(b.x, lv, b.z), width: 0.22))
            }
        }
        for li in 0..<(levels.count - 1) {
            let y0 = levels[li], y1 = levels[li + 1]
            for i in [1, 2] {
                let a = corners[i], b = corners[(i + 1) % 4]
                paint.append(MeshBuilder.beam(from: Vec3(a.x, y0, a.z), to: Vec3(b.x, y1, b.z), width: 0.12))
                paint.append(MeshBuilder.beam(from: Vec3(b.x, y0, b.z), to: Vec3(a.x, y1, a.z), width: 0.12))
            }
        }
        // top deck cross beams and the thrust/mount plate
        paint.append(MeshBuilder.beam(from: Vec3(-L, top - 0.15, 0), to: Vec3(L, top - 0.15, 0), width: 0.3))
        paint.append(MeshBuilder.beam(from: Vec3(0, top - 0.15, -L), to: Vec3(0, top - 0.15, L), width: 0.3))
        steel.append(MeshBuilder.cylinder(radius: 0.42, height: 0.14, segments: 48), transform: float4x4(translation: Vec3(0, mountHeight + 0.07, 0)))
        for i in 0..<16 {
            let a = Float(i) / 16 * 2 * .pi
            steel.append(MeshBuilder.bolt(radius: 0.018, height: 0.03), transform: float4x4(translation: Vec3(0.34 * sinf(a), mountHeight - 0.03, 0.34 * cosf(a)))
                         * float4x4(rotationAxis: Vec3(1, 0, 0), angle: .pi))
        }
        // feed lines coming down the stand
        steel.append(MeshBuilder.tube(points: [Vec3(L, top + 0.3, -L + 0.3), Vec3(L - 0.4, top - 0.2, -L + 0.5), Vec3(0.6, mountHeight - 0.25, -0.5), Vec3(0.28, mountHeight - 0.70, -0.12)], radius: 0.07))
        steel.append(MeshBuilder.tube(points: [Vec3(-L, top + 0.3, -L + 0.3), Vec3(-L + 0.4, top - 0.2, -L + 0.5), Vec3(-0.6, mountHeight - 0.3, -0.5), Vec3(-0.25, mountHeight - 0.60, -0.15)], radius: 0.06))
        return [
            MeshPart(name: "standPaint", data: paint, material: .whitePaint),
            MeshPart(name: "standSteel", data: steel, material: .brushedSteel),
        ]
    }
}
