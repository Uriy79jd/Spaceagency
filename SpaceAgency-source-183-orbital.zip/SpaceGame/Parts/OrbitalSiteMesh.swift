import simd
import Foundation

/// Meshes of the Falcon-like orbital pad (concrete deck with a water-filled flame
/// duct, transporter-erector / strongback, hold-down clamps, lightning masts,
/// deluge headers) on its coastal site, plus the beach apron and the ocean to
/// the east. Geometry follows OrbitalSite (local metres).
enum OrbitalSiteMesh {
    static func build() -> [MeshPart] {
        var deck = MeshData()
        var trench = MeshData()
        var water = MeshData()
        var steel = MeshData()
        var strongback = MeshData()
        var masts = MeshData()
        var beach = MeshData()
        var ocean = MeshData()
        let P = OrbitalSite.padCenter.float
        let H = Float(OrbitalSite.padHalf)
        let tc = OrbitalSite.trenchCenter.float
        let th = OrbitalSite.trenchHalf.float
        let x0 = tc.x - th.x, x1 = tc.x + th.x, z0 = tc.z - th.z, z1 = tc.z + th.z
        let y = Float(0.012)
        // deck: slabs around the trench opening (trench runs off the +X edge of the pad)
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: P.x + H, minZ: P.z - H, maxZ: z0, y: y))
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: P.x + H, minZ: z1, maxZ: P.z + H, y: y))
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: x0, minZ: z0, maxZ: z1, y: y))
        if x1 < P.x + H { deck.append(MeshBuilder.plane(minX: x1, maxX: P.x + H, minZ: z0, maxZ: z1, y: y)) }
        // trench walls (facing into the trench) and floor
        let d = Float(2 * th.y)
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z0), to: SIMD2(x1, z0), y0: -d, y1: y, facing: Vec3(0, 0, 1)))
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z1), to: SIMD2(x1, z1), y0: -d, y1: y, facing: Vec3(0, 0, -1)))
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z0), to: SIMD2(x0, z1), y0: -d, y1: y, facing: Vec3(1, 0, 0)))
        trench.append(MeshBuilder.plane(minX: x0, maxX: x1, minZ: z0, maxZ: z1, y: -d))
        // deluge water surface (animated in the shader)
        water.append(MeshBuilder.plane(minX: x0, maxX: x1, minZ: z0, maxZ: z1, y: Float(OrbitalSite.waterLevel)))
        // deluge headers along both trench lips
        for z in [z0 - 0.35, z1 + 0.35] {
            steel.append(MeshBuilder.tube(points: [Vec3(x0 - 1.0, 0.35, z), Vec3(x0 + 10, 0.35, z), Vec3(x0 + 20, 0.35, z)], radius: 0.16))
        }
        steel.append(MeshBuilder.tube(points: [Vec3(x0 - 1.0, 0.35, z0 - 0.35), Vec3(x0 - 1.2, 0.35, P.z), Vec3(x0 - 1.0, 0.35, z1 + 0.35)], radius: 0.16))
        // hold-down clamps around the skirt foot
        for p in OrbitalSite.holdDownPositions {
            let f = p.float
            steel.append(MeshBuilder.box(size: Vec3(0.6, 0.8, 0.6)), transform: float4x4(translation: Vec3(f.x, 0.4, f.z)))
        }
        // transporter-erector / strongback: leaning beam + hinge + cradle arms at the fairing
        let b0 = OrbitalSite.strongbackBase.float, b1 = OrbitalSite.strongbackTop.float
        strongback.append(MeshBuilder.beam(from: Vec3(b0.x, 0, b0.z), to: Vec3(b1.x, b1.y, b1.z), width: 1.1))
        strongback.append(MeshBuilder.cylinder(radius: 0.9, height: 1.2, segments: 24),
                          transform: float4x4(translation: Vec3(b0.x, 0.6, b0.z)))
        for cy in [Float(20), 40, 55] {
            let t = cy / 58
            let cx = b0.x + (b1.x - b0.x) * t
            strongback.append(MeshBuilder.box(size: Vec3(1.4, 0.5, 0.5)),
                              transform: float4x4(translation: Vec3(cx + 0.7, cy, 0)))
        }
        // lightning masts (70 m) at the pad corners
        for p in OrbitalSite.mastPositions {
            let f = p.float
            masts.append(MeshBuilder.cylinder(radius: 0.25, height: 70, segments: 16),
                        transform: float4x4(translation: Vec3(f.x, 35, f.z)))
            masts.append(MeshBuilder.cylinder(radius: 0.06, height: 2, segments: 8),
                        transform: float4x4(translation: Vec3(f.x, 71, f.z)))
        }
        // beach apron around the pad (sand) and the ocean to the east (downrange)
        beach.append(MeshBuilder.plane(minX: P.x - 200, maxX: P.x + 150, minZ: P.z - 200, maxZ: P.z + 200, y: -0.05))
        ocean.append(MeshBuilder.plane(minX: P.x + 150, maxX: P.x + 600, minZ: P.z - 300, maxZ: P.z + 300, y: -0.5))
        return [
            MeshPart(name: "orbDeck", data: deck, material: Material(baseColor: Vec3(0.46, 0.45, 0.42), metallic: 0, roughness: 0.85, kind: .concrete)),
            MeshPart(name: "orbTrench", data: trench, material: Material(baseColor: Vec3(0.22, 0.21, 0.2), metallic: 0, roughness: 0.9, kind: .concrete)),
            MeshPart(name: "orbWater", data: water, material: Material(baseColor: Vec3(0.05, 0.07, 0.07), metallic: 0, roughness: 0.06, kind: .water), castsShadow: false),
            MeshPart(name: "orbPadSteel", data: steel, material: Material(baseColor: Vec3(0.5, 0.5, 0.52), metallic: 0.8, roughness: 0.5, kind: .paint)),
            MeshPart(name: "orbStrongback", data: strongback, material: .structureGray),
            MeshPart(name: "orbMasts", data: masts, material: .structureGray),
            MeshPart(name: "orbBeach", data: beach, material: Material(baseColor: Vec3(0.76, 0.70, 0.55), metallic: 0, roughness: 0.9)),
            MeshPart(name: "orbOcean", data: ocean, material: Material(baseColor: Vec3(0.04, 0.12, 0.20), metallic: 0, roughness: 0.08, kind: .water), castsShadow: false),
        ]
    }
}
