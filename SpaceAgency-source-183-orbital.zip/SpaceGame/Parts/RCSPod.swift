import simd
import Foundation

/// RCS thruster pod variants.
///
/// Pod-local frame: origin on the vehicle skin, +Z outward from the skin, +Y vehicle-up, +X tangent (up × outward).
enum RCSVariant: String, CaseIterable {
    /// Apollo / Gemini-style quad: a housing on the skin with four bell nozzles that STICK OUT of it (±tangent,
    /// ±axial), each canted outward so the plumes clear the skin.
    case quad
    /// Shuttle-style bank: a doubler plate with three nozzle ports FLUSH with the skin, exhausting radially.
    case flush
}

/// One thruster nozzle of a pod (pod-local).
struct RCSNozzle {
    let root: Vec3          // chamber / valve end
    let dir: Vec3           // unit exhaust direction
    let exit: Vec3          // centre of the exit plane
    let exitRadius: Float
    /// How far the exit plane sits proud of the skin (0 = flush).
    var protrusion: Float { max(exit.z, 0) }
}

struct RCSPodSpec {
    let variant: RCSVariant
    let nozzles: [RCSNozzle]

    // quad geometry (metres, scaled for a Ø5 m vehicle with ~6 kN cold-gas thrusters)
    static let quadHalf: Float = 0.28           // housing half-width / half-height
    static let quadDepth: Float = 0.30
    static let quadCant: Float = 35 * .pi / 180 // bells lean outward by this angle
    static let bellLength: Float = 0.52
    static let bellThroat: Float = 0.035
    static let bellExit: Float = 0.17
    // flush geometry
    static let portSpacing: Float = 0.36
    static let portRadius: Float = 0.14
    static let portCant: Float = 12 * .pi / 180

    static func make(_ v: RCSVariant) -> RCSPodSpec {
        switch v {
        case .quad:
            let h = quadHalf, zc = quadDepth * 0.5 + 0.02
            var ns: [RCSNozzle] = []
            for t in [Vec3(1, 0, 0), Vec3(-1, 0, 0), Vec3(0, 1, 0), Vec3(0, -1, 0)] {
                let root = t * h + Vec3(0, 0, zc)
                let dir = simd_normalize(t * cosf(quadCant) + Vec3(0, 0, sinf(quadCant)))
                ns.append(RCSNozzle(root: root, dir: dir, exit: root + dir * bellLength, exitRadius: bellExit))
            }
            return RCSPodSpec(variant: v, nozzles: ns)
        case .flush:
            var ns: [RCSNozzle] = []
            for k in [-1, 0, 1] {
                let y = Float(k) * portSpacing
                let a = Float(k) * portCant
                let dir = Vec3(0, sinf(a), cosf(a))
                ns.append(RCSNozzle(root: Vec3(0, y, -0.2), dir: dir, exit: Vec3(0, y, 0), exitRadius: portRadius))
            }
            return RCSPodSpec(variant: v, nozzles: ns)
        }
    }
}

enum RCSMesh {
    struct Meshes {
        var steel = MeshData()      // housings, doubler plates, bolts
        var bronze = MeshData()     // bell nozzles, port rims (double-sided part)
        var dark = MeshData()       // nozzle linings, recesses, valve cartridges
    }

    static let bronzeMaterial = Material(baseColor: Vec3(0.60, 0.50, 0.28), metallic: 1.0, roughness: 0.34, kind: .brushed)

    /// Rotation taking +Y onto `d`.
    static func aligned(to d: Vec3) -> float4x4 {
        let up = Vec3(0, 1, 0)
        let axis = simd_cross(up, d)
        let sn = simd_length(axis)
        if sn < 1e-4 {
            return simd_dot(up, d) >= 0 ? matrix_identity_float4x4 : float4x4(rotationAxis: Vec3(1, 0, 0), angle: .pi)
        }
        return float4x4(rotationAxis: axis / sn, angle: atan2f(sn, simd_dot(up, d)))
    }

    /// Bell nozzle along +Y: valve body → throat → parabolic bell to the exit lip. Profiles run so that the
    /// outer wall faces outward; the inner lining runs the other way and faces the axis.
    static func bell(length: Float, throat: Float, exit: Float) -> (outer: MeshData, inner: MeshData) {
        let chamberR = throat * 2.0
        let chamberTop = length * 0.22
        let throatY = length * 0.30
        var outer: [SIMD2<Float>] = []
        var inner: [SIMD2<Float>] = []
        let n = 10
        for i in stride(from: n, through: 1, by: -1) {         // exit → throat (outer surface, walking down)
            let t = Float(i) / Float(n)
            outer.append(SIMD2(throat + (exit - throat) * powf(t, 0.55) + 0.012, throatY + (length - throatY) * t))
        }
        outer += [SIMD2(chamberR * 0.8, chamberTop), SIMD2(chamberR, chamberTop * 0.85), SIMD2(chamberR, 0)]
        for i in 1...n {                                         // throat → exit (inner lining, walking up)
            let t = Float(i) / Float(n)
            inner.append(SIMD2(throat + (exit - throat) * powf(t, 0.55), throatY + (length - throatY) * t))
        }
        inner.insert(SIMD2(throat * 0.6, throatY - 0.01), at: 0)
        return (MeshBuilder.lathe(outer, segments: 20), MeshBuilder.lathe(inner, segments: 20))
    }

    /// Adds one pod (in the pod-local frame, placed by `frame`) to the meshes.
    static func add(_ spec: RCSPodSpec, frame: float4x4, to out: inout Meshes) {
        switch spec.variant {
        case .quad:
            let h = RCSPodSpec.quadHalf, d = RCSPodSpec.quadDepth
            // mounting plate + machined housing (sunk slightly so it sits on the curved skin)
            out.steel.append(MeshBuilder.box(size: Vec3(2 * h + 0.14, 2 * h + 0.14, 0.05)), transform: frame * float4x4(translation: Vec3(0, 0, 0.0)))
            out.steel.append(MeshBuilder.box(size: Vec3(2 * h, 2 * h, d)), transform: frame * float4x4(translation: Vec3(0, 0, d * 0.5 + 0.02)))
            // four propellant cartridge valves on the housing face + two feed fittings
            for (vx, vy) in [(Float(-0.1), Float(-0.1)), (0.1, -0.1), (-0.1, 0.1), (0.1, 0.1)] {
                out.dark.append(MeshBuilder.cylinder(radius: 0.035, height: 0.09, segments: 12),
                                transform: frame * float4x4(translation: Vec3(vx, vy, d + 0.02 + 0.04)) * aligned(to: Vec3(0, 0, 1)))
            }
            for fy in [Float(-0.2), 0.2] {
                out.steel.append(MeshBuilder.cylinder(radius: 0.025, height: 0.07, segments: 10),
                                 transform: frame * float4x4(translation: Vec3(0, fy, d + 0.02 + 0.03)) * aligned(to: Vec3(0, 0, 1)))
            }
            for (bx, by) in [(Float(-1), Float(-1)), (1, -1), (-1, 1), (1, 1)] {
                out.steel.append(MeshBuilder.bolt(radius: 0.016, height: 0.03),
                                 transform: frame * float4x4(translation: Vec3(bx * (h + 0.045), by * (h + 0.045), 0.025)) * aligned(to: Vec3(0, 0, 1)))
            }
            // the four protruding bells
            let b = bell(length: RCSPodSpec.bellLength, throat: RCSPodSpec.bellThroat, exit: RCSPodSpec.bellExit)
            for nz in spec.nozzles {
                let m = frame * float4x4(translation: nz.root) * aligned(to: nz.dir)
                out.bronze.append(b.outer, transform: m)
                out.dark.append(b.inner, transform: m)
            }
        case .flush:
            // doubler plate + the three ports, flush with the skin: a bronze rim, a dark funnel recess
            let span = RCSPodSpec.portSpacing * 2 + 0.5
            out.steel.append(MeshBuilder.box(size: Vec3(0.56, span, 0.03)), transform: frame * float4x4(translation: Vec3(0, 0, 0.0)))
            for (bx, by) in [(Float(-1), Float(-1)), (1, -1), (-1, 1), (1, 1)] {
                out.steel.append(MeshBuilder.bolt(radius: 0.014, height: 0.025),
                                 transform: frame * float4x4(translation: Vec3(bx * 0.24, by * (span * 0.5 - 0.04), 0.015)) * aligned(to: Vec3(0, 0, 1)))
            }
            for nz in spec.nozzles {
                let place = frame * float4x4(translation: Vec3(nz.exit.x, nz.exit.y, 0.016)) * aligned(to: nz.dir)
                out.bronze.append(MeshBuilder.torus(major: RCSPodSpec.portRadius + 0.012, minor: 0.014, majorSegments: 28, minorSegments: 6), transform: place)
                let funnel: [SIMD2<Float>] = [SIMD2(RCSPodSpec.portRadius, 0.0), SIMD2(RCSPodSpec.portRadius * 0.9, -0.03),
                                              SIMD2(0.05, -0.14), SIMD2(0.0, -0.14)]
                out.dark.append(MeshBuilder.lathe(funnel, segments: 24), transform: place)
            }
        }
    }
}
