import Foundation

/// Data-driven part definition, loaded from parts.json in the app bundle.
struct PartDefinition: Codable, Identifiable, Equatable {
    var id: String
    var name: String
    var category: String
    var mesh: String
    var massKg: Double
    var heightM: Double
    var exitDiameterM: Double
    var chamberPressureBar: Double
    var thrustSeaLevelN: Double
    var expansionRatio: Double
    var gamma: Double
    var cStar: Double
    var mixtureRatio: Double
    var minThrottle: Double
    var maxGimbalDeg: Double
    var gimbalRateDegS: Double
    var oxPumpRPM: Double
    var fuelPumpRPM: Double
    var pickRadius: Double
    var description: String

    static let raptor3Fallback = PartDefinition(
        id: "raptor3", name: "Raptor 3", category: "engine", mesh: "raptor3", massKg: 1525, heightM: 3.10,
        exitDiameterM: 1.33, chamberPressureBar: 350, thrustSeaLevelN: 2_745_000, expansionRatio: 34.34, gamma: 1.2,
        cStar: 1830, mixtureRatio: 3.6, minThrottle: 0.4, maxGimbalDeg: 15, gimbalRateDegS: 25,
        oxPumpRPM: 20_000, fuelPumpRPM: 30_000, pickRadius: 0.75,
        description: "Full-flow staged combustion methalox engine, sea-level nozzle.")
}

private struct PartFile: Codable { var parts: [PartDefinition] }

final class PartCatalog {
    static let shared = PartCatalog()
    let parts: [PartDefinition]

    private init() {
        if let url = Bundle.main.url(forResource: "parts", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let file = try? JSONDecoder().decode(PartFile.self, from: data), !file.parts.isEmpty {
            parts = file.parts
        } else {
            parts = [PartDefinition.raptor3Fallback]
        }
    }

    func part(_ id: String) -> PartDefinition? { parts.first { $0.id == id } }
}

/// Procedural mesh generators keyed by `PartDefinition.mesh`.
enum PartMeshLibrary {
    static func build(_ key: String) -> [MeshPart] {
        switch key {
        case "raptor3": return RaptorMesh.build()
        default: return RaptorMesh.build()
        }
    }
}
