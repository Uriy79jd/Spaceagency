import Foundation
import simd

/// One generic South-Texas scrub tree (multi-stem trunk + a canopy of lumpy blobs), instanced by Trees.metal.
/// The vertex shader turns it into a wide, flat, airy MESQUITE or a dense, rounded LIVE OAK per instance
/// (canopy-only scale, colour, sway), so one mesh serves both. Unit size: ~6 m tall, canopy ~7 m wide.
/// Vertex packing (Vertex): position.w = ambient occlusion; normal.w = 0;
/// uv.x = sway weight (0 at the ground → 1 at the crown), uv.y = part (0 wood, 1 canopy),
/// uv.z = per-blob random (leaf colour variation), uv.w = canopy-shell radius fraction (inner → outer).
enum TreeMesh {
    static func build() -> MeshData {
        var m = MeshData()
        // three leaning stems from a short bole (mesquite habit; reads as a single trunk on the oak)
        let stems: [(Vec3, Float)] = [(Vec3(0.55, 3.0, 0.15), 0.16), (Vec3(-0.5, 2.7, 0.4), 0.13), (Vec3(0.05, 3.3, -0.55), 0.12)]
        m.append(wood(from: Vec3(0, -0.2, 0), to: Vec3(0, 1.1, 0), r0: 0.24, r1: 0.2))
        for (tip, r) in stems {
            m.append(wood(from: Vec3(0, 1.0, 0), to: tip, r0: r, r1: r * 0.55))
            // a branch splaying out from each stem toward the canopy edge
            let out = simd_normalize(Vec3(tip.x, 0, tip.z) + Vec3(0.01, 0, 0))
            m.append(wood(from: tip, to: tip + out * 1.6 + Vec3(0, 0.9, 0), r0: r * 0.55, r1: r * 0.25))
        }
        // canopy: lumpy blobs around a flattened dome
        let blobs: [(Vec3, Float)] = [
            (Vec3(0, 4.4, 0), 2.1), (Vec3(1.9, 4.0, 0.5), 1.6), (Vec3(-1.8, 4.1, 0.7), 1.55), (Vec3(0.4, 4.2, -1.9), 1.5),
            (Vec3(-0.9, 3.8, -1.3), 1.3), (Vec3(1.2, 3.7, 1.7), 1.25), (Vec3(0.1, 5.2, 0.3), 1.35)
        ]
        for (i, (c, r)) in blobs.enumerated() {
            m.append(blob(center: c, radius: r, seed: Float(i) * 0.137 + 0.05))
        }
        return m
    }

    /// Tapered 6-sided branch.
    private static func wood(from a: Vec3, to b: Vec3, r0: Float, r1: Float) -> MeshData {
        var m = MeshData()
        let seg = 6
        let d = b - a
        let len = simd_length(d)
        let dir = d / max(len, 1e-4)
        let ref = abs(dir.y) < 0.95 ? Vec3(0, 1, 0) : Vec3(1, 0, 0)
        let u = simd_normalize(simd_cross(dir, ref)), w = simd_cross(dir, u)
        for ring in 0...1 {
            let p = ring == 0 ? a : b
            let r = ring == 0 ? r0 : r1
            for i in 0...seg {
                let ang = Float(i) / Float(seg) * 2 * .pi
                let n = u * cosf(ang) + w * sinf(ang)
                let sway = max(p.y, 0) / 6.0
                m.vertices.append(Vertex(position: Vec4(p + n * r, 0.55 + 0.25 * Float(ring)), normal: Vec4(n, 0),
                                         uv: Vec4(sway * sway, 0, 0, 0)))
            }
        }
        let row = UInt32(seg + 1)
        for i in 0..<UInt32(seg) {
            m.indices += [i, i + row, i + 1, i + 1, i + row, i + row + 1]
        }
        return m
    }

    /// Lumpy low-poly sphere (8 × 6) with a radial bump; normals blended toward the canopy-dome normal so the
    /// crown shades as one soft mass instead of faceted balls.
    private static func blob(center c: Vec3, radius r: Float, seed: Float) -> MeshData {
        var m = MeshData()
        let nu = 9, nv = 6
        let dome = Vec3(0, 4.0, 0)
        for j in 0...nv {
            let v = Float(j) / Float(nv)
            let phi = v * .pi
            for i in 0...nu {
                let uu = Float(i) / Float(nu)
                let th = uu * 2 * .pi
                var n = Vec3(sinf(phi) * cosf(th), cosf(phi), sinf(phi) * sinf(th))
                if i == nu { n = Vec3(sinf(phi), cosf(phi), 0) }
                let bump = 1 + 0.18 * sinf(th * 3 + seed * 17) * sinf(phi * 2 + seed * 9)
                let p = c + n * r * bump * Vec3(1, 0.78, 1)
                let domeN = simd_normalize(p - dome)
                let nn = simd_normalize(n * 0.45 + domeN * 0.55)
                // ambient occlusion: underside and the inside of the crown are darker
                let ao: Float = 0.45 + 0.55 * max(0, min(1, (nn.y + 0.6) / 1.4))
                let sway = max(p.y, 0) / 6.0
                m.vertices.append(Vertex(position: Vec4(p, ao), normal: Vec4(nn, 0),
                                         uv: Vec4(sway * sway, 1, fmodf(seed * 7.31, 1), simd_length(p - dome) / 3.5)))
            }
        }
        let row = UInt32(nu + 1)
        for j in 0..<UInt32(nv) {
            for i in 0..<UInt32(nu) {
                let a = j * row + i
                m.indices += [a, a + 1, a + row, a + 1, a + row + 1, a + row]
            }
        }
        return m
    }
}
