import simd
import Foundation

/// Meshes of the TV-1 launch pad (concrete deck with a water-filled flame trench, deluge headers) and the
/// marked landing zone. Geometry follows TV1Site (world metres).
enum TV1SiteMesh {
    static func build() -> [MeshPart] {
        var deck = MeshData()
        var trench = MeshData()
        var water = MeshData()
        var lz = MeshData()
        var steel = MeshData()
        let P = TV1Site.padCenter.float
        let H = Float(TV1Site.padHalf)
        let tc = TV1Site.trenchCenter.float
        let th = TV1Site.trenchHalf.float
        let x0 = tc.x - th.x, x1 = tc.x + th.x, z0 = tc.z - th.z, z1 = tc.z + th.z
        let y = Float(0.012)
        // deck: four slabs around the trench opening (trench runs off the +X edge of the pad)
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: P.x + H, minZ: P.z - H, maxZ: z0, y: y))
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: P.x + H, minZ: z1, maxZ: P.z + H, y: y))
        deck.append(MeshBuilder.plane(minX: P.x - H, maxX: x0, minZ: z0, maxZ: z1, y: y))
        if x1 < P.x + H { deck.append(MeshBuilder.plane(minX: x1, maxX: P.x + H, minZ: z0, maxZ: z1, y: y)) }
        // trench walls (facing into the trench) and floor
        let d = Float(2 * th.y)
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z0), to: SIMD2(x1, z0), y0: -d, y1: y, facing: Vec3(0, 0, 1)))
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z1), to: SIMD2(x1, z1), y0: -d, y1: y, facing: Vec3(0, 0, -1)))
        trench.append(MeshBuilder.wall(from: SIMD2(x0, z0), to: SIMD2(x0, z1), y0: -d, y1: y, facing: Vec3(1, 0, 0)))
        trench.append(MeshBuilder.plane(minX: x0, maxX: x1, minZ: z0, maxZ: z1, y: -d))
        // water surface (animated in the shader)
        water.append(MeshBuilder.plane(minX: x0, maxX: x1, minZ: z0, maxZ: z1, y: Float(TV1Site.waterLevel)))
        // deluge headers along both trench lips with spray nozzles
        for z in [z0 - 0.35, z1 + 0.35] {
            steel.append(MeshBuilder.tube(points: [Vec3(x0 - 1.0, 0.35, z), Vec3(x0 + 6, 0.35, z), Vec3(x0 + 12, 0.35, z)], radius: 0.16))
        }
        steel.append(MeshBuilder.tube(points: [Vec3(x0 - 1.0, 0.35, z0 - 0.35), Vec3(x0 - 1.2, 0.35, P.z), Vec3(x0 - 1.0, 0.35, z1 + 0.35)], radius: 0.16))
        // landing zone: a raised marked slab
        let L = TV1Site.landingZone.float
        let R = Float(TV1Site.lzRadius)
        lz.append(MeshBuilder.plane(minX: L.x - R, maxX: L.x + R, minZ: L.z - R, maxZ: L.z + R, y: 0.015))
        return [
            MeshPart(name: "tv1Deck", data: deck, material: Material(baseColor: Vec3(0.46, 0.45, 0.42), metallic: 0, roughness: 0.85, kind: .concrete)),
            MeshPart(name: "tv1Trench", data: trench, material: Material(baseColor: Vec3(0.22, 0.21, 0.2), metallic: 0, roughness: 0.9, kind: .concrete)),
            MeshPart(name: "tv1Water", data: water, material: Material(baseColor: Vec3(0.05, 0.07, 0.07), metallic: 0, roughness: 0.06, kind: .water), castsShadow: false),
            MeshPart(name: "tv1LZ", data: lz, material: Material(baseColor: Vec3(0.50, 0.49, 0.46), metallic: 0, roughness: 0.85, kind: .landingPad), castsShadow: false),
            MeshPart(name: "tv1PadSteel", data: steel, material: Material(baseColor: Vec3(0.5, 0.5, 0.52), metallic: 0.8, roughness: 0.5, kind: .paint)),
        ]
    }
}
