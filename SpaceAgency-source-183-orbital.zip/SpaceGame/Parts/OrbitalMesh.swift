import simd
import Foundation

/// Orbital vehicle mesh — the Falcon-size two-stage rocket, built to match the
/// user's two reference photos, with stainless steel substituted for white:
///
/// - Photo 1 (underside): nine dark engine bells, 1 in the centre and 8 in an
///   outer circle, each with a light centre, on the octaweb thrust structure.
///   The 8 outer bells are built here from the same `RaptorMesh.bellRadius`
///   profile as the live Raptor, at the octaweb positions (radius 1.45 m,
///   45 deg apart); the centre bell is the live RaptorMesh itself, drawn by
///   the renderer at the centre engine (so it is never drawn twice). Each
///   outer bell has a small polished-steel disc at its throat — the light
///   centre seen in the photo.
/// - Photo 2 (in flight): slender two-stage body, black interstage band,
///   ogive fairing on top, single plume. The same shape and proportions are
///   kept here, with brushed stainless steel throughout — including the
///   fairing — instead of white paint. No coloured livery.
///
/// EXPENDABLE: no landing legs and no large fins anywhere on this vehicle.
/// The booster does not land — after MECO / separation it falls back and
/// splashes down in the ocean. There is no leg module, no leg deployment and
/// no leg mass in the mass budget.
///
/// Local origin = S1 base (skirt foot), +Y the vehicle axis, in the stacked
/// frame (S1 y 0...39, S2 y 39...68). The mesh is split into stage-1 and
/// stage-2 part lists so the renderer can draw the booster separately after
/// separation.
enum OrbitalMesh {
    static let r: Float = 2.5
    static let s1Top: Float = 39
    static let totalTop: Float = 68

    struct Parts { var parts: [(MeshPart, Bool)] }   // (part, double-sided)

    /// The 8 outer engine bells (nozzleBlack) with their chambers, built from
    /// the live Raptor bell profile so they match it exactly. Bell local y
    /// runs from bellTopY (-1.90) to -height (-3.10) below the mount.
    private static func outerBells(into bells: inout MeshData, chambers: inout MeshData, centres: inout MeshData) {
        var prof: [SIMD2<Float>] = []
        let nB = 24
        for i in 0...nB {
            let t = Float(i) / Float(nB)
            let y = RaptorMesh.bellTopY - t * (RaptorMesh.height + RaptorMesh.bellTopY)
            prof.append(SIMD2(RaptorMesh.bellRadius(y), y))
        }
        prof.append(SIMD2(RaptorMesh.exitRadius - 0.004, -RaptorMesh.height - 0.006))
        prof.append(SIMD2(RaptorMesh.exitRadius - 0.014, -RaptorMesh.height))
        let mountY = Float(OrbitalVehicle.s1MountY)
        for p in OrbitalVehicle.enginePositions.dropFirst() {
            let t = float4x4(translation: Vec3(Float(p.x), mountY, Float(p.z)))
            bells.append(MeshBuilder.lathe(prof, segments: 64, creaseDegrees: 40), transform: t)
            // Chamber / head above the bell top, under the octaweb plate.
            chambers.append(MeshBuilder.cylinder(radius: 0.30, height: 0.55, segments: 24),
                            transform: float4x4(translation: Vec3(Float(p.x), mountY - 1.35, Float(p.z))))
            // Light centre at the throat — the bright disc inside each bell in the photo.
            centres.append(MeshBuilder.cylinder(radius: 0.22, height: 0.05, segments: 24),
                           transform: float4x4(translation: Vec3(Float(p.x), mountY - 1.56, Float(p.z))))
        }
    }

    /// Stage 1 (y 0...39): skirt, octaweb plate, 8 outer bells, tanks, black interstage.
    static func buildStage1() -> Parts {
        var tank = MeshData()
        var skirt = MeshData()
        var octaweb = MeshData()
        var bells = MeshData()
        var chambers = MeshData()
        var centres = MeshData()
        var interstage = MeshData()
        var steel = MeshData()
        var rcs = MeshData()
        // Tank barrels (frosted stainless): LOX 7...23, CH4 23...36, one barrel.
        tank.append(MeshBuilder.lathe([SIMD2(r, 36), SIMD2(r, 23.3), SIMD2(r, 7.3), SIMD2(r - 0.3, 7.0),
                                       SIMD2(0.95, 6.8), SIMD2(0.85, 6.8)], segments: 72))
        // Engine-bay skirt: straight shell with a slight flare at the foot (double-sided).
        skirt.append(MeshBuilder.lathe([SIMD2(r - 0.02, 7.5), SIMD2(r - 0.02, 1.4), SIMD2(r + 0.08, 0.5),
                                        SIMD2(r + 0.2, 0.0)], segments: 96))
        // Octaweb thrust plate the bells mount to (photo 1) + centre thrust puck.
        octaweb.append(MeshBuilder.cylinder(radius: 2.45, height: 0.18, segments: 72),
                       transform: float4x4(translation: Vec3(0, Float(OrbitalVehicle.s1MountY), 0)))
        octaweb.append(MeshBuilder.cylinder(radius: 0.9, height: 0.42, segments: 32),
                       transform: float4x4(translation: Vec3(0, Float(OrbitalVehicle.s1MountY) + 0.21, 0)))
        outerBells(into: &bells, chambers: &chambers, centres: &centres)
        // Black interstage band (photo 2) — the ring between the stages, 36...39 m.
        interstage.append(MeshBuilder.lathe([SIMD2(r + 0.006, s1Top), SIMD2(r + 0.006, 36)], segments: 72))
        // Weld rings at the module joints + raceway + skirt stiffener ribs.
        for y in [Float(7), 23, 36] {
            steel.append(MeshBuilder.torus(major: r + 0.012, minor: 0.03, majorSegments: 72, minorSegments: 4),
                         transform: float4x4(translation: Vec3(0, y, 0)))
        }
        steel.append(MeshBuilder.beam(from: Vec3(0.5, 1.2, r + 0.13), to: Vec3(0.5, 35, r + 0.13), width: 0.24))
        for i in 0..<4 {
            let a = Float(i) / 4 * 2 * .pi + .pi / 4
            let p0 = Vec3(cosf(a) * (r + 0.05), 0.3, sinf(a) * (r + 0.05)), p1 = Vec3(cosf(a) * (r + 0.05), 7, sinf(a) * (r + 0.05))
            steel.append(MeshBuilder.beam(from: p0, to: p1, width: 0.14))
        }
        // RCS pods on the S1 skirt ring (y = 2 m, matching OrbitalRCS.build(stage: 1)).
        for i in 0..<4 {
            let a = Float(i) * .pi / 2
            rcs.append(MeshBuilder.box(size: Vec3(0.5, 0.4, 0.25)),
                       transform: float4x4(translation: Vec3(cosf(a) * (r + 0.12), 2, sinf(a) * (r + 0.12)))
                           * float4x4(rotationAxis: Vec3(0, 1, 0), angle: -a))
        }
        let frosted = Material(baseColor: Vec3(0.70, 0.69, 0.67), metallic: 1.0, roughness: 0.24, kind: .frostedSteel)
        let skirtMat = Material(baseColor: Vec3(0.64, 0.63, 0.61), metallic: 1.0, roughness: 0.3, kind: .brushed)
        return Parts(parts: [
            (MeshPart(name: "orbS1Tank", data: tank, material: frosted), false),
            (MeshPart(name: "orbS1Skirt", data: skirt, material: skirtMat), true),
            (MeshPart(name: "orbOctaweb", data: octaweb, material: .darkSteel), false),
            (MeshPart(name: "orbBells", data: bells, material: .nozzleBlack), false),
            (MeshPart(name: "orbBellChambers", data: chambers, material: .coatedBlack), false),
            (MeshPart(name: "orbBellCentres", data: centres, material: .polishedSteel), false),
            (MeshPart(name: "orbInterstage", data: interstage, material: .coatedBlack), false),
            (MeshPart(name: "orbS1Steel", data: steel, material: .brushedSteel), false),
            (MeshPart(name: "orbS1Rcs", data: rcs, material: .darkSteel), false),
        ])
    }

    /// Stage 2 (y 39...68): engine bay, tanks, stainless ogive fairing.
    /// The S2 engine bell is NOT built here — the live RaptorMesh is drawn at
    /// the S2 engine during the second-stage burn. No fins, no landing legs.
    static func buildStage2() -> Parts {
        var tank = MeshData()
        var bay = MeshData()
        var fairing = MeshData()
        var rcs = MeshData()
        // Tank barrels (frosted stainless): LOX 43...49, CH4 49...54.
        tank.append(MeshBuilder.lathe([SIMD2(r, 54), SIMD2(r, 49.3), SIMD2(r, 43.3), SIMD2(r - 0.3, 43.0),
                                       SIMD2(0.95, 42.8), SIMD2(0.85, 42.8)], segments: 72))
        // Engine bay (39...43) + weld rings + fairing adapter ring.
        bay.append(MeshBuilder.lathe([SIMD2(r, 43), SIMD2(r, 39)], segments: 72))
        for y in [Float(43), 49, 54] {
            bay.append(MeshBuilder.torus(major: r + 0.012, minor: 0.03, majorSegments: 72, minorSegments: 4),
                       transform: float4x4(translation: Vec3(0, y, 0)))
        }
        bay.append(MeshBuilder.torus(major: r + 0.02, minor: 0.06, majorSegments: 72, minorSegments: 6),
                   transform: float4x4(translation: Vec3(0, 54, 0)))
        // Ogive fairing (54...68), stainless steel — NOT white paint (photo 2, steel substituted).
        var nose: [SIMD2<Float>] = []
        for i in 0...12 {
            let t = Float(i) / 12
            nose.append(SIMD2(r * powf(cosf(t * .pi / 2), 0.7), 54 + 14 * t))
        }
        fairing.append(MeshBuilder.lathe(nose, segments: 72))
        // RCS pods: S2 base ring (y = 41.5 m) and fairing top ring (y = 65 m),
        // matching OrbitalRCS.build(stage: 2).
        for y in [Float(41.5), 65] {
            for i in 0..<4 {
                let a = Float(i) * .pi / 2
                rcs.append(MeshBuilder.box(size: Vec3(0.5, 0.4, 0.25)),
                           transform: float4x4(translation: Vec3(cosf(a) * (r + 0.12), y, sinf(a) * (r + 0.12)))
                               * float4x4(rotationAxis: Vec3(0, 1, 0), angle: -a))
            }
        }
        let frosted = Material(baseColor: Vec3(0.70, 0.69, 0.67), metallic: 1.0, roughness: 0.24, kind: .frostedSteel)
        return Parts(parts: [
            (MeshPart(name: "orbS2Tank", data: tank, material: frosted), false),
            (MeshPart(name: "orbS2Bay", data: bay, material: .brushedSteel), false),
            (MeshPart(name: "orbFairing", data: fairing, material: .brushedSteel), false),
            (MeshPart(name: "orbS2Rcs", data: rcs, material: .darkSteel), false),
        ])
    }
}
