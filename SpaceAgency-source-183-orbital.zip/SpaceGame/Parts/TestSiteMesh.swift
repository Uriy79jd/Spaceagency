import simd
import Foundation

/// Outdoor vertical test stand modelled on SpaceX McGregor's tripod/A-frame stands:
/// tapered weathered-concrete legs with cross beams, thick concrete deck with the engine hung underneath,
/// a tall white run tank and equipment buildings on the deck, a steel lattice access tower with stairs,
/// a ladder, a dark concrete flame deflector at the base, a concrete apron, ploughed field and a fence line.
enum TestSiteMesh {
    /// Underside of the deck = engine mount (top of the gimbal block). Real-scale McGregor tripod: deck top
    /// ≈ 41 m above the pad, nozzle exit ≈ 35 m above the flame deflector.
    static let mountHeight: Float = 38.0
    static let deckThickness: Float = 3.0
    static let legX: Float = 8.5
    static let legZ: Float = 6.0
    static let legBottom: Float = 3.2
    static let legTop: Float = 2.2
    /// Flame deflector half size and curbs (shared by the mesh and the collision surfaces).
    static let deflectorHalf: Float = 5.5
    static let apronHalf: Float = 18
    static let tankX: Float = -3.2
    static let tankRadius: Float = 1.55
    static var deckTop: Float { mountHeight + deckThickness }
    /// Grass starts this far from the stand (ploughed soil inside).
    static let grassInner: Float = 30
    static let grassOuter: Float = 170

    /// Vent / relief valve outlets (world position, jet direction): tank top vent, tank relief valve,
    /// and two valves on the feed plumbing at deck level.
    static var vents: [(Vec3, Vec3)] {
        let dt = deckTop
        return [
            (Vec3(tankX, dt + 15.7, 0), simd_normalize(Vec3(0.25, 1, 0.1))),
            (Vec3(tankX + tankRadius + 0.25, dt + 9.5, 0.4), simd_normalize(Vec3(1, 0.15, 0.25))),
            (Vec3(-1.4, dt + 0.9, 2.1), simd_normalize(Vec3(-0.3, 0.2, 1))),
            (Vec3(1.8, dt + 0.9, 2.1), simd_normalize(Vec3(0.4, 0.1, 1))),
        ]
    }

    /// Collidable surfaces for plume impingement (mirrors `siteSDF` in ShaderCommon.h): pad/apron plane,
    /// deflector curbs, the four legs.
    static func impingementSurfaces() -> [ImpingementSurface] {
        // ground (with the TV-1 pad's flame trench carved out) + trench water + landing zone, then the stand
        var s: [ImpingementSurface] = TV1Site.surfaces()
        let dh = Double(deflectorHalf)
        s.append(.box(center: DVec3(0, 0.35, -dh - 0.3), halfExtents: DVec3(dh + 0.6, 0.35, 0.3)))
        s.append(.box(center: DVec3(dh + 0.3, 0.25, 0), halfExtents: DVec3(0.3, 0.25, dh)))
        s.append(.box(center: DVec3(-dh - 0.3, 0.25, 0), halfExtents: DVec3(0.3, 0.25, dh)))
        let hh = Double(mountHeight) / 2
        let lh = Double(legBottom + legTop) / 4          // mean half width of the tapered leg
        for sx in [-1.0, 1.0] {
            for sz in [-1.0, 1.0] {
                s.append(.box(center: DVec3(sx * Double(legX), hh, sz * Double(legZ)), halfExtents: DVec3(lh, hh, lh)))
            }
        }
        return s
    }

    /// Tapered leg as a box-like frustum (bottom size → top size), built from a 4-sided lathe so normals are clean.
    static func taperedLeg(base: Vec3, height: Float, bottom: Float, top: Float) -> MeshData {
        var m = MeshData()
        let hb = bottom / 2, ht = top / 2
        let b = [Vec3(-hb, 0, -hb), Vec3(hb, 0, -hb), Vec3(hb, 0, hb), Vec3(-hb, 0, hb)]
        let t = [Vec3(-ht, height, -ht), Vec3(ht, height, -ht), Vec3(ht, height, ht), Vec3(-ht, height, ht)]
        for i in 0..<4 {
            let j = (i + 1) % 4
            let p0 = b[i], p1 = b[j], p2 = t[i], p3 = t[j]
            // outward face normal: winding p0, p1, p2 must be CCW from outside
            var n = simd_normalize(simd_cross(p1 - p0, p2 - p0))
            let mid = (p0 + p1 + p2 + p3) / 4
            let outward = simd_dot(n, Vec3(mid.x, 0, mid.z)) > 0
            if !outward { n = -n }
            let base0 = UInt32(m.vertices.count)
            let w = simd_length(p1 - p0)
            for (k, p) in [p0, p1, p2, p3].enumerated() {
                let u: Float = (k == 1 || k == 3) ? w : 0
                let ao: Float = p.y < 1.0 ? 0.75 : 1.0
                m.vertices.append(Vertex(position: Vec4(p + base, ao), normal: Vec4(n, 0), uv: Vec4(u, p.y, 0, 0)))
            }
            m.indices += outward ? [base0, base0 + 1, base0 + 2, base0 + 2, base0 + 1, base0 + 3]
                                 : [base0, base0 + 2, base0 + 1, base0 + 1, base0 + 2, base0 + 3]
        }
        return m
    }

    static func buildSite() -> [MeshPart] {
        var concrete = MeshData()      // weathered structural concrete
        var deflector = MeshData()     // dark scorched concrete
        var apron = MeshData()
        var field = MeshData()
        var white = MeshData()         // run tank, equipment sheds
        var steel = MeshData()         // tower, railings, ladder, pipes
        var redMast = MeshData()
        var tank = MeshData()          // brushed stainless, frosted (cryogenic)

        let H = mountHeight
        let deckTop = H + deckThickness
        // --- legs (front pair at +Z, back pair at -Z), tapering toward the top
        for sx in [Float(-1), 1] {
            for sz in [Float(-1), 1] {
                concrete.append(taperedLeg(base: Vec3(sx * legX, 0, sz * legZ), height: H, bottom: legBottom, top: legTop))
            }
        }
        // --- cross beams: back face and both side faces (front face left open so the engine is visible)
        for y in [Float(9), 19, 29] {
            concrete.append(MeshBuilder.box(size: Vec3(2 * legX, 1.4, 1.6)), transform: float4x4(translation: Vec3(0, y, -legZ)))
            for sx in [Float(-1), 1] {
                concrete.append(MeshBuilder.box(size: Vec3(1.6, 1.4, 2 * legZ)), transform: float4x4(translation: Vec3(sx * legX, y, 0)))
            }
        }
        // --- deck: thick slab with a lip, plus a mounting boss under it
        concrete.append(MeshBuilder.box(size: Vec3(2 * legX + 3.2, deckThickness, 2 * legZ + 3.0)), transform: float4x4(translation: Vec3(0, H + deckThickness / 2, 0)))
        concrete.append(MeshBuilder.box(size: Vec3(2 * legX + 3.6, 0.35, 2 * legZ + 3.4)), transform: float4x4(translation: Vec3(0, deckTop - 0.17, 0)))
        steel.append(MeshBuilder.cylinder(radius: 0.55, height: 0.25, segments: 40), transform: float4x4(translation: Vec3(0, H - 0.0, 0)))
        // thrust-structure I-beams under the deck
        for z in [Float(-0.8), 0.8] {
            steel.append(MeshBuilder.box(size: Vec3(2 * legX, 0.45, 0.25)), transform: float4x4(translation: Vec3(0, H - 0.22, z)))
        }
        // --- run tank (tall white vertical tank) with a ring platform on top
        tank.append(MeshBuilder.lathe([SIMD2(0, deckTop + 14.6), SIMD2(1.1, deckTop + 14.4), SIMD2(1.55, deckTop + 13.6),
                                        SIMD2(1.55, deckTop + 1.0), SIMD2(1.3, deckTop + 0.3), SIMD2(1.3, deckTop)], segments: 48),
                     transform: float4x4(translation: Vec3(tankX, 0, 0)))
        steel.append(MeshBuilder.torus(major: 1.75, minor: 0.04, majorSegments: 48, minorSegments: 6), transform: float4x4(translation: Vec3(tankX, deckTop + 15.4, 0)))
        steel.append(MeshBuilder.torus(major: 1.75, minor: 0.05, majorSegments: 48, minorSegments: 6), transform: float4x4(translation: Vec3(tankX, deckTop + 14.6, 0)))
        for i in 0..<8 {
            let a = Float(i) / 8 * 2 * .pi
            steel.append(MeshBuilder.beam(from: Vec3(tankX + 1.75 * cosf(a), deckTop + 14.6, 1.75 * sinf(a)),
                                          to: Vec3(tankX + 1.75 * cosf(a), deckTop + 15.4, 1.75 * sinf(a)), width: 0.05))
        }
        steel.append(MeshBuilder.beam(from: Vec3(tankX + 1.62, deckTop + 0.2, 0.3), to: Vec3(tankX + 1.62, deckTop + 14.6, 0.3), width: 0.06))
        steel.append(MeshBuilder.beam(from: Vec3(tankX + 1.62, deckTop + 0.2, -0.3), to: Vec3(tankX + 1.62, deckTop + 14.6, -0.3), width: 0.06))
        // feed line from tank down through the deck to the engine
        steel.append(MeshBuilder.tube(points: [Vec3(tankX + 0.9, deckTop + 0.5, 1.2), Vec3(-1.4, deckTop + 0.4, 1.6), Vec3(-0.9, deckTop - 0.2, 1.4),
                                               Vec3(-0.9, H - 0.4, 1.2), Vec3(-0.5, H - 0.6, 0.6)], radius: 0.16))
        steel.append(MeshBuilder.tube(points: [Vec3(1.8, deckTop + 0.4, 1.6), Vec3(0.9, deckTop - 0.2, 1.4), Vec3(0.9, H - 0.4, 1.2), Vec3(0.5, H - 0.6, 0.6)], radius: 0.13))
        // vent / relief valve bodies with short stacks at each outlet
        for (pos, dir) in vents {
            let up = Vec3(0, 1, 0)
            let axis = simd_cross(up, dir)
            let sn = simd_length(axis)
            let rot = sn > 1e-4 ? float4x4(rotationAxis: axis / sn, angle: atan2f(sn, simd_dot(up, dir))) : matrix_identity_float4x4
            steel.append(MeshBuilder.cylinder(radius: 0.09, height: 0.5, segments: 16), transform: float4x4(translation: pos - dir * 0.25) * rot)
            steel.append(MeshBuilder.box(size: Vec3(0.26, 0.22, 0.26)), transform: float4x4(translation: pos - dir * 0.55))
        }
        // --- equipment buildings on the deck
        white.append(MeshBuilder.box(size: Vec3(4.0, 3.4, 3.6)), transform: float4x4(translation: Vec3(2.6, deckTop + 1.7, -0.6)))
        white.append(MeshBuilder.box(size: Vec3(2.2, 1.6, 2.4)), transform: float4x4(translation: Vec3(2.0, deckTop + 4.2, -0.8)))
        steel.append(MeshBuilder.box(size: Vec3(1.6, 1.2, 1.2)), transform: float4x4(translation: Vec3(6.2, deckTop + 0.6, 1.4)))
        steel.append(MeshBuilder.cylinder(radius: 0.5, height: 1.4, segments: 20), transform: float4x4(translation: Vec3(-0.6, deckTop + 0.7, -1.6)))
        steel.append(MeshBuilder.cylinder(radius: 0.4, height: 1.1, segments: 20), transform: float4x4(translation: Vec3(0.5, deckTop + 0.55, -2.0)))
        // --- deck railings
        let rx = legX + 1.6, rz = legZ + 1.5
        let corners = [Vec3(rx, 0, rz), Vec3(-rx, 0, rz), Vec3(-rx, 0, -rz), Vec3(rx, 0, -rz)]
        for i in 0..<4 {
            let a = corners[i], b = corners[(i + 1) % 4]
            for hgt in [Float(0.55), 1.1] {
                steel.append(MeshBuilder.beam(from: Vec3(a.x, deckTop + hgt, a.z), to: Vec3(b.x, deckTop + hgt, b.z), width: 0.05))
            }
            let len = simd_length(b - a)
            let nPosts = Int(len / 1.5)
            for k in 0...nPosts {
                let p = a + (b - a) * (Float(k) / Float(max(nPosts, 1)))
                steel.append(MeshBuilder.beam(from: Vec3(p.x, deckTop, p.z), to: Vec3(p.x, deckTop + 1.1, p.z), width: 0.05))
            }
        }
        // --- steel lattice access tower with stairs (left side)
        let tx: Float = -legX - 4.6, tw: Float = 1.4
        let towerTop = deckTop + 2.0
        let tc = [Vec3(tx - tw, 0, -tw), Vec3(tx + tw, 0, -tw), Vec3(tx + tw, 0, tw), Vec3(tx - tw, 0, tw)]
        for c in tc { steel.append(MeshBuilder.beam(from: c, to: Vec3(c.x, towerTop, c.z), width: 0.16)) }
        var y: Float = 0
        while y < towerTop - 0.1 {
            let y1 = min(y + 2.0, towerTop)
            for i in 0..<4 {
                let a = tc[i], b = tc[(i + 1) % 4]
                steel.append(MeshBuilder.beam(from: Vec3(a.x, y1, a.z), to: Vec3(b.x, y1, b.z), width: 0.08))
                steel.append(MeshBuilder.beam(from: Vec3(a.x, y, a.z), to: Vec3(b.x, y1, b.z), width: 0.05))
            }
            // stair flight inside (zig-zag)
            let flip: Float = Int(y / 2.0) % 2 == 0 ? 1 : -1
            steel.append(MeshBuilder.beam(from: Vec3(tx - flip * (tw - 0.3), y + 0.05, -0.4), to: Vec3(tx + flip * (tw - 0.3), y1, -0.4), width: 0.1))
            steel.append(MeshBuilder.beam(from: Vec3(tx - flip * (tw - 0.3), y + 0.05, 0.4), to: Vec3(tx + flip * (tw - 0.3), y1, 0.4), width: 0.1))
            steel.append(MeshBuilder.box(size: Vec3(2 * tw, 0.06, 2 * tw)), transform: float4x4(translation: Vec3(tx, y1, 0)))
            y = y1
        }
        // walkway from the tower to the deck
        steel.append(MeshBuilder.box(size: Vec3(3.4, 0.08, 1.2)), transform: float4x4(translation: Vec3(tx + tw + 1.7, deckTop, 0)))
        // lightning / antenna masts
        redMast.append(MeshBuilder.beam(from: Vec3(tx - tw - 0.6, 0, -tw), to: Vec3(tx - tw - 0.6, towerTop + 8, -tw), width: 0.12))
        // --- ladder on the right side, leaning against the deck
        let l0 = Vec3(legX + 3.4, 0, legZ + 0.6), l1 = Vec3(legX + 1.4, deckTop, legZ + 0.6)
        steel.append(MeshBuilder.beam(from: l0 + Vec3(0, 0, -0.3), to: l1 + Vec3(0, 0, -0.3), width: 0.08))
        steel.append(MeshBuilder.beam(from: l0 + Vec3(0, 0, 0.3), to: l1 + Vec3(0, 0, 0.3), width: 0.08))
        let rungs = Int(simd_length(l1 - l0) / 0.32)
        for k in 0..<rungs {
            let p = l0 + (l1 - l0) * (Float(k) / Float(rungs))
            steel.append(MeshBuilder.beam(from: p + Vec3(0, 0, -0.3), to: p + Vec3(0, 0, 0.3), width: 0.03))
        }

        // --- flame deflector: dark concrete pad flush with the apron, curbs, and an angled backstop
        let dh: Float = deflectorHalf
        deflector.append(MeshBuilder.plane(minX: -dh, maxX: dh, minZ: -dh, maxZ: dh, y: 0.005))
        deflector.append(MeshBuilder.box(size: Vec3(2 * dh + 1.2, 0.7, 0.6)), transform: float4x4(translation: Vec3(0, 0.35, -dh - 0.3)))
        for sx in [Float(-1), 1] {
            deflector.append(MeshBuilder.box(size: Vec3(0.6, 0.5, 2 * dh)), transform: float4x4(translation: Vec3(sx * (dh + 0.3), 0.25, 0)))
        }
        // angled deflector wedge behind the impingement point
        deflector.append(MeshBuilder.box(size: Vec3(2 * dh, 0.6, 4.0)),
                         transform: float4x4(translation: Vec3(0, 0.9, -dh - 2.0)) * float4x4(rotationAxis: Vec3(1, 0, 0), angle: 0.42))

        // --- concrete apron (tessellated for contact AO around the legs), field around it
        let n = 40
        for j in 0...n {
            for i in 0...n {
                let x = -apronHalf + Float(i) / Float(n) * 2 * apronHalf
                let z = -apronHalf + Float(j) / Float(n) * 2 * apronHalf
                var ao: Float = 1
                for sx in [Float(-1), 1] {
                    for sz in [Float(-1), 1] {
                        let d = simd_length(SIMD2<Float>(x - sx * legX, z - sz * legZ))
                        ao = min(ao, 0.5 + 0.5 * clampf((d - legBottom * 0.5) / 2.5, 0, 1))
                    }
                }
                apron.vertices.append(Vertex(position: Vec4(x, 0, z, ao), normal: Vec4(0, 1, 0, 0), uv: Vec4(x, z, 0, 0)))
            }
        }
        for j in 0..<UInt32(n) {
            for i in 0..<UInt32(n) {
                let a = j * UInt32(n + 1) + i, b = a + UInt32(n + 1)
                apron.indices += [a, b, a + 1, a + 1, b, b + 1]
            }
        }
        let F: Float = 30000, A = apronHalf      // ground out to the horizon for 10 km flights
        field.append(MeshBuilder.plane(minX: -F, maxX: F, minZ: A, maxZ: F, y: -0.02))
        field.append(MeshBuilder.plane(minX: -F, maxX: F, minZ: -F, maxZ: -A, y: -0.02))
        field.append(MeshBuilder.plane(minX: -F, maxX: -A, minZ: -A, maxZ: A, y: -0.02))
        field.append(MeshBuilder.plane(minX: A, maxX: F, minZ: -A, maxZ: A, y: -0.02))
        // --- fence line in the distance + utility poles
        var fx: Float = -260
        while fx <= 260 {
            steel.append(MeshBuilder.beam(from: Vec3(fx, -0.02, -95), to: Vec3(fx, 1.6, -95), width: 0.08))
            fx += 4
        }
        for hgt in [Float(0.5), 1.0, 1.5] {
            steel.append(MeshBuilder.beam(from: Vec3(-260, hgt, -95), to: Vec3(260, hgt, -95), width: 0.02))
        }
        var px: Float = -300
        while px <= 300 {
            redMast.append(MeshBuilder.beam(from: Vec3(px, -0.02, -140), to: Vec3(px, 10, -140), width: 0.3))
            steel.append(MeshBuilder.beam(from: Vec3(px - 1.2, 9.2, -140), to: Vec3(px + 1.2, 9.2, -140), width: 0.15))
            px += 60
        }

        return [
            MeshPart(name: "siteConcrete", data: concrete, material: Material(baseColor: Vec3(0.56, 0.53, 0.48), metallic: 0, roughness: 0.85, kind: .weatheredConcrete)),
            MeshPart(name: "deflector", data: deflector, material: Material(baseColor: Vec3(0.20, 0.19, 0.18), metallic: 0, roughness: 0.9, kind: .concrete)),
            MeshPart(name: "apron", data: apron, material: Material(baseColor: Vec3(0.48, 0.46, 0.42), metallic: 0, roughness: 0.85, kind: .concrete)),
            MeshPart(name: "field", data: field, material: Material(baseColor: Vec3(0.30, 0.215, 0.15), metallic: 0, roughness: 0.95, kind: .field), castsShadow: false),
            MeshPart(name: "white", data: white, material: Material(baseColor: Vec3(0.82, 0.82, 0.80), metallic: 0.1, roughness: 0.45, kind: .paint)),
            MeshPart(name: "siteSteel", data: steel, material: Material(baseColor: Vec3(0.52, 0.52, 0.53), metallic: 0.8, roughness: 0.5, kind: .paint)),
            MeshPart(name: "runTank", data: tank, material: Material(baseColor: Vec3(0.68, 0.67, 0.65), metallic: 1.0, roughness: 0.28, kind: .frostedSteel)),
            MeshPart(name: "mast", data: redMast, material: Material(baseColor: Vec3(0.55, 0.12, 0.08), metallic: 0, roughness: 0.6, kind: .paint)),
        ]
    }
}
