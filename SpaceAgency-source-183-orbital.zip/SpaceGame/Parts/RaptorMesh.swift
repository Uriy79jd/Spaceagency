import simd
import Foundation

/// Procedural Raptor 3 model, built to match the public reference photo.
/// Local origin = top of the gimbal block, engine hangs down -Y. Overall height 3.10 m, nozzle exit Ø 1.33 m.
enum RaptorMesh {
    static let height: Float = 3.10
    static let exitRadius: Float = 0.665
    static let bellTopY: Float = -1.90
    /// Gimbal pivot (centre of the polished thrust block), local y.
    static let pivotY: Float = -0.13
    /// Actuator attach points on the engine head (local, untilted): pitch actuator on +Z, yaw actuator on +X.
    static let actuatorEngineEnds: [Vec3] = [Vec3(0, -0.70, 0.28), Vec3(0.28, -0.70, 0)]
    /// Actuator attach points on the stand (local to the engine mount, fixed).
    static let actuatorStandEnds: [Vec3] = [Vec3(0, 0.05, 0.95), Vec3(0.95, 0.05, 0)]

    /// Exterior bell radius as a function of local y (between bellTopY and -height).
    static func bellRadius(_ y: Float) -> Float {
        let t = clampf((bellTopY - y) / (height + bellTopY), 0, 1)
        return 0.42 + 0.245 * (1 - powf(1 - t, 1.9))
    }

    static func build() -> [MeshPart] {
        var steelDark = MeshData()     // machined head hardware
        var coated = MeshData()        // black coated chamber, collar, ducts
        var nozzle = MeshData()        // matte nozzle exterior (decal, wear)
        var nozzleInner = MeshData()   // nozzle interior liner
        var polished = MeshData()
        var bolts = MeshData()
        var inconel = MeshData()
        var copper = MeshData()
        var blue = MeshData()
        var plastic = MeshData()
        var fixedDark = MeshData()      // gimbal block top (does not tilt)
        var fixedPolished = MeshData()

        // 1. Gimbal / thrust block
        fixedDark.append(MeshBuilder.lathe([SIMD2(0, 0), SIMD2(0.105, 0), SIMD2(0.118, -0.012), SIMD2(0.118, -0.062), SIMD2(0.13, -0.066)], segments: 48))
        fixedPolished.append(MeshBuilder.lathe([SIMD2(0.13, -0.066), SIMD2(0.136, -0.072), SIMD2(0.136, -0.150), SIMD2(0.142, -0.156),
                                           SIMD2(0.142, -0.200), SIMD2(0.158, -0.212), SIMD2(0.158, -0.262)], segments: 64))
        // 2. Upper bolted flange
        steelDark.append(MeshBuilder.lathe([SIMD2(0.158, -0.262), SIMD2(0.255, -0.262), SIMD2(0.255, -0.300), SIMD2(0.205, -0.312)], segments: 64))
        for i in 0..<24 {
            let a = Float(i) / 24 * 2 * .pi
            bolts.append(MeshBuilder.bolt(radius: 0.013, height: 0.032), transform: float4x4(translation: Vec3(0.222 * sinf(a), -0.262, 0.222 * cosf(a))))
        }
        // 3. Head / injector / turbopump body
        steelDark.append(MeshBuilder.lathe([SIMD2(0.205, -0.312), SIMD2(0.222, -0.330), SIMD2(0.222, -0.600), SIMD2(0.272, -0.640),
                                            SIMD2(0.272, -0.700), SIMD2(0.242, -0.720), SIMD2(0.242, -0.880)], segments: 64,
                                           aoFn: { _, y in y < -0.70 ? 0.8 : 1 }))
        copper.append(MeshBuilder.torus(major: 0.274, minor: 0.016, majorSegments: 64, minorSegments: 10), transform: float4x4(translation: Vec3(0, -0.62, 0)))
        // front ports (three round housings)
        let toFront = float4x4(rotationAxis: Vec3(1, 0, 0), angle: .pi / 2)
        for (k, x) in [Float(-0.15), -0.04, 0.07].enumerated() {
            let z: Float = 0.215
            steelDark.append(MeshBuilder.cylinder(radius: 0.058, height: 0.09, segments: 28), transform: float4x4(translation: Vec3(x, -0.46, z)) * toFront)
            plastic.append(MeshBuilder.cylinder(radius: 0.036, height: 0.012, segments: 24), transform: float4x4(translation: Vec3(x, -0.46, z + 0.048)) * toFront)
            inconel.append(MeshBuilder.torus(major: 0.058, minor: 0.008, majorSegments: 28, minorSegments: 8),
                           transform: float4x4(translation: Vec3(x, -0.46, z + 0.04)) * toFront)
            if k == 1 {
                bolts.append(MeshBuilder.box(size: Vec3(0.05, 0.03, 0.05)), transform: float4x4(translation: Vec3(x, -0.395, z)))
            }
        }
        // valve / sensor cluster on the right
        var rng = XorShift(seed: 3)
        for _ in 0..<9 {
            let p = Vec3(0.24 + rng.unit() * 0.2, -0.50 - rng.unit() * 0.26, -0.12 + rng.unit() * 0.26)
            let s = Vec3(0.04 + rng.unit() * 0.06, 0.04 + rng.unit() * 0.07, 0.04 + rng.unit() * 0.06)
            if rng.unit() < 0.5 { steelDark.append(MeshBuilder.box(size: s), transform: float4x4(translation: p)) }
            else { inconel.append(MeshBuilder.box(size: s), transform: float4x4(translation: p)) }
        }
        steelDark.append(MeshBuilder.cylinder(radius: 0.060, height: 0.12, segments: 24), transform: float4x4(translation: Vec3(0.41, -0.60, -0.02)))
        blue.append(MeshBuilder.lathe([SIMD2(0, 0.04), SIMD2(0.05, 0.04), SIMD2(0.058, 0.03), SIMD2(0.058, -0.035), SIMD2(0, -0.035)], segments: 28),
                    transform: float4x4(translation: Vec3(0.41, -0.505, -0.02)))
        polished.append(MeshBuilder.tube(points: [Vec3(0.20, -0.40, 0.10), Vec3(0.30, -0.36, 0.12), Vec3(0.37, -0.40, 0.08), Vec3(0.40, -0.47, 0.03)], radius: 0.021))
        polished.append(MeshBuilder.tube(points: [Vec3(-0.21, -0.38, -0.08), Vec3(-0.30, -0.40, -0.04), Vec3(-0.32, -0.52, 0.02), Vec3(-0.24, -0.62, 0.08)], radius: 0.017))
        plastic.append(MeshBuilder.tube(points: [Vec3(0.22, -0.66, 0.16), Vec3(0.34, -0.70, 0.14), Vec3(0.44, -0.66, 0.02), Vec3(0.40, -0.56, -0.08)], radius: 0.010, capEnds: false))
        for (x, y, z) in [(Float(0.30), Float(-0.70), Float(0.16)), (-0.27, -0.66, 0.12), (0.12, -0.74, 0.24)] {
            inconel.append(MeshBuilder.cylinder(radius: 0.028, height: 0.07, segments: 16), transform: float4x4(translation: Vec3(x, y, z)) * toFront)
        }
        // 4. Mid flange with silver bolts
        steelDark.append(MeshBuilder.lathe([SIMD2(0.242, -0.880), SIMD2(0.335, -0.880), SIMD2(0.335, -0.930), SIMD2(0.262, -0.940)], segments: 64))
        for i in 0..<32 {
            let a = Float(i) / 32 * 2 * .pi
            bolts.append(MeshBuilder.bolt(radius: 0.012, height: 0.03), transform: float4x4(translation: Vec3(0.302 * sinf(a), -0.880, 0.302 * cosf(a))))
        }
        // 5. Manifold collar (big black shoulder)
        coated.append(MeshBuilder.lathe([SIMD2(0.262, -0.940), SIMD2(0.52, -0.950), SIMD2(0.552, -0.975), SIMD2(0.552, -1.030),
                                         SIMD2(0.50, -1.060), SIMD2(0.30, -1.070)], segments: 72,
                                        aoFn: { r, y in y < -1.05 ? 0.55 + 0.4 * clampf((0.5 - r) / 0.2, 0, 1) : 1 }))
        // 6. Combustion chamber with regen cooling bands
        coated.append(MeshBuilder.lathe([SIMD2(0.30, -1.070), SIMD2(0.272, -1.10), SIMD2(0.272, -1.45), SIMD2(0.24, -1.52), SIMD2(0.222, -1.56)],
                                        segments: 64, heat: { _ in 0.25 },
                                        aoFn: { _, y in 0.55 + 0.45 * clampf((-1.10 - y) / 0.25, 0, 1) }))
        for (major, minor, y) in [(Float(0.292), Float(0.044), Float(-1.13)), (0.286, 0.040, -1.27), (0.272, 0.034, -1.40)] {
            coated.append(MeshBuilder.torus(major: major, minor: minor, heat: 0.3), transform: float4x4(translation: Vec3(0, y, 0)))
        }
        // 7. Throat jacket and first diverging section
        nozzle.append(MeshBuilder.lathe([SIMD2(0.222, -1.56), SIMD2(0.262, -1.62), SIMD2(0.34, -1.72), SIMD2(0.40, -1.78), SIMD2(0.41, -1.86), SIMD2(0.42, -1.90)],
                                        segments: 72, heat: { _ in 0.55 }, detail: 1))
        // 8. Big inlet manifold ring at top of the bell
        coated.append(MeshBuilder.torus(major: 0.405, minor: 0.058, majorSegments: 72, minorSegments: 14, heat: 0.4), transform: float4x4(translation: Vec3(0, -1.82, 0)))
        // 9. Bell exterior (decal + wear), lip, and interior liner
        var bellProf: [SIMD2<Float>] = []
        let nB = 40
        for i in 0...nB {
            let t = Float(i) / Float(nB)
            let y = bellTopY - t * (height + bellTopY)
            bellProf.append(SIMD2(bellRadius(y), y))
        }
        bellProf.append(SIMD2(exitRadius - 0.004, -height - 0.006))
        bellProf.append(SIMD2(exitRadius - 0.014, -height))
        nozzle.append(MeshBuilder.lathe(bellProf, segments: 96, creaseDegrees: 40,
                                        heat: { y in 0.55 + 0.45 * clampf((bellTopY - y) / 0.8, 0, 1) - 0.35 * clampf((-2.6 - y) / 0.5, 0, 1) },
                                        decal: true, detail: 2))
        // interior: walk bottom -> top so normals face inward
        var inner: [SIMD2<Float>] = []
        for i in stride(from: nB, through: 0, by: -1) {
            let t = Float(i) / Float(nB)
            let y = bellTopY - t * (height + bellTopY)
            inner.append(SIMD2(bellRadius(y) - 0.014, y))
        }
        inner += [SIMD2(0.30, -1.80), SIMD2(0.20, -1.68), SIMD2(0.125, -1.56), SIMD2(0.16, -1.42), SIMD2(0.20, -1.30), SIMD2(0.16, -1.16), SIMD2(0.0, -1.12)]
        nozzleInner.append(MeshBuilder.lathe(inner, segments: 72, creaseDegrees: 40,
                                             heat: { y in 0.7 + 0.3 * clampf((y + 2.4) / 0.8, 0, 1) },
                                             aoFn: { _, y in 0.35 + 0.65 * clampf((-1.6 - y) / 1.4, 0, 1) }))

        // 10. Large curved ducts wrapping down the right side into the manifold ring
        coated.append(MeshBuilder.tube(points: [Vec3(0.24, -0.73, 0.17), Vec3(0.44, -0.80, 0.16), Vec3(0.50, -0.98, 0.20),
                                                Vec3(0.38, -1.36, 0.30), Vec3(0.16, -1.62, 0.36), Vec3(0.04, -1.76, 0.40)], radius: 0.066, heat: 0.15))
        coated.append(MeshBuilder.tube(points: [Vec3(0.24, -0.76, -0.06), Vec3(0.50, -0.86, -0.08), Vec3(0.58, -1.10, -0.04),
                                                Vec3(0.52, -1.46, 0.02), Vec3(0.42, -1.76, 0.08)], radius: 0.07, heat: 0.15))
        coated.append(MeshBuilder.tube(points: [Vec3(-0.26, -1.08, 0.14), Vec3(-0.36, -1.30, 0.18), Vec3(-0.40, -1.55, 0.16), Vec3(-0.36, -1.77, 0.18)], radius: 0.028))
        coated.append(MeshBuilder.tube(points: [Vec3(-0.20, -1.06, -0.22), Vec3(-0.30, -1.36, -0.26), Vec3(-0.33, -1.74, -0.22)], radius: 0.024))
        // duct joint flanges with bolts
        for (c, axisPt) in [(Vec3(0.50, -0.98, 0.20), Vec3(0.47, -1.10, 0.23)), (Vec3(0.58, -1.10, -0.04), Vec3(0.57, -1.22, -0.02))] {
            let d = simd_normalize(axisPt - c)
            let axis = simd_cross(Vec3(0, 1, 0), d)
            let s = simd_length(axis)
            let rot = s > 1e-5 ? float4x4(rotationAxis: axis / s, angle: atan2f(s, simd_dot(Vec3(0, 1, 0), d))) : matrix_identity_float4x4
            steelDark.append(MeshBuilder.cylinder(radius: 0.10, height: 0.035, segments: 28), transform: float4x4(translation: c) * rot)
            for i in 0..<10 {
                let a = Float(i) / 10 * 2 * .pi
                bolts.append(MeshBuilder.bolt(radius: 0.008, height: 0.04),
                             transform: float4x4(translation: c) * rot * float4x4(translation: Vec3(0.085 * sinf(a), -0.02, 0.085 * cosf(a))))
            }
        }

        return [
            MeshPart(name: "fixedDark", data: fixedDark, material: .darkSteel, gimballed: false),
            MeshPart(name: "fixedPolished", data: fixedPolished, material: .polishedSteel, gimballed: false),
            MeshPart(name: "steelDark", data: steelDark, material: .darkSteel),
            MeshPart(name: "coated", data: coated, material: .coatedBlack),
            MeshPart(name: "nozzle", data: nozzle, material: .nozzleBlack),
            MeshPart(name: "nozzleInner", data: nozzleInner, material: Material(baseColor: Vec3(0.20, 0.17, 0.15), metallic: 1.0, roughness: 0.55, kind: .nozzleInterior)),
            MeshPart(name: "polished", data: polished, material: .polishedSteel),
            MeshPart(name: "bolts", data: bolts, material: .boltSteel),
            MeshPart(name: "inconel", data: inconel, material: .inconel),
            MeshPart(name: "copper", data: copper, material: .copperish),
            MeshPart(name: "blueCap", data: blue, material: .blueCap),
            MeshPart(name: "plastic", data: plastic, material: .blackPlastic),
        ]
    }
}
