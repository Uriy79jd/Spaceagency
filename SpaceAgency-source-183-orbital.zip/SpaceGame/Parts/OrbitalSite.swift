import Foundation
import simd

/// Falcon-like orbital launch pad, in the shared local frame (metres; +X east,
/// +Y up, -Z north — the same frame TV1Site uses). The pad sits 800 m east of
/// the TV-1 stand area, on the coast: land to the west, open ocean downrange
/// to the east, so the expendable booster falls back into the ocean.
///
/// The pad is a new site: the TV-1 pad / stand / hangar are untouched and
/// keep working. The collidable shapes here are the single source for the
/// plume raycast at this pad, mirroring TV1Site.
enum OrbitalSite {
    /// Pad centre in the local frame. The orbital vehicle's local position is
    /// measured from this point (OrbitalFlight.padECI is the same point in ECI).
    static let padCenter = DVec3(800, 0, 0)
    static let padHalf = 30.0
    /// Flame duct / trench: runs from just behind the vehicle axis out along
    /// +X (downrange, toward the ocean), 8 m wide, 6 m deep.
    static var trenchCenter: DVec3 { padCenter + DVec3(22, -3, 0) }
    static let trenchHalf = DVec3(20, 3, 4)
    /// Water deluge in the trench (surface 5 m below the pad deck).
    static let waterLevel = -5.0
    static var waterCenter: DVec3 { padCenter + DVec3(22, waterLevel - 0.45, 0) }
    static let waterHalf = DVec3(20, 0.45, 4)
    /// Transporter-erector / strongback: base 14 m west of the vehicle, top
    /// leaning against the fairing at ~58 m. Retracts before launch (the mesh
    /// is static; retraction is a future animation, not a physics state).
    static var strongbackBase: DVec3 { padCenter + DVec3(-14, 0, 0) }
    static var strongbackTop: DVec3 { padCenter + DVec3(-3, 58, 0) }
    /// Four lightning masts at the pad corners, 70 m tall.
    static var mastPositions: [DVec3] {
        [padCenter + DVec3(-28, 0, -28), padCenter + DVec3(28, 0, -28),
         padCenter + DVec3(-28, 0, 28), padCenter + DVec3(28, 0, 28)]
    }
    /// Hold-down clamps around the skirt foot (radius 3 m).
    static var holdDownPositions: [DVec3] {
        (0..<4).map { i in
            let a = Double(i) * .pi / 2 + .pi / 4
            return padCenter + DVec3(cos(a) * 3.0, 0, sin(a) * 3.0)
        }
    }

    /// Ground with the trench carved out, plus the trench water body.
    static func surfaces() -> [ImpingementSurface] {
        [.groundWithTrench(trenchCenter: trenchCenter, trenchHalf: trenchHalf),
         .box(center: waterCenter, halfExtents: waterHalf)]
    }

    /// True when a point (e.g. the plume hit point) is on the trench water.
    static func isWater(_ p: DVec3) -> Bool {
        let q = p - waterCenter
        return abs(q.x) <= waterHalf.x + 0.1 && abs(q.z) <= waterHalf.z + 0.1 && abs(p.y - waterLevel) < 0.4
    }
}
