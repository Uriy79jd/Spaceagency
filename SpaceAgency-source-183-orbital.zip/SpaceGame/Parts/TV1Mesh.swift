import simd
import Foundation

/// Test Vehicle 1 (TV-1): Ren's own stainless ground-test / hop vehicle. Ø5 m, ~14 m tall: open engine-bay
/// skirt with a heavy foot ring, aft LOX tank and forward CH4 tank in one frosted brushed-stainless barrel,
/// a forward equipment ring with four N₂ RCS pods, low nose dome with vent stacks, external raceway and
/// pressurisation lines. Local origin = centre of the skirt foot, +Y up (matches TV1Vehicle).
enum TV1Mesh {
    static let r = Float(TV1Vehicle.radius)
    static let mount = Float(TV1Vehicle.mountHeight)
    static let tankBottom: Float = 4.6
    static let tankTop: Float = 10.3
    static let ringTop: Float = 12.8
    static let top = Float(TV1Vehicle.height)

    /// Vent outlets (local position, local jet direction).
    static let vents: [(Vec3, Vec3)] = [
        (Vec3(0.9, top - 0.05, 0.5), simd_normalize(Vec3(0.25, 1, 0.1))),
        (Vec3(-0.8, top - 0.1, -0.6), simd_normalize(Vec3(-0.25, 1, -0.15))),
        (Vec3(r + 0.18, 9.6, 0.9), simd_normalize(Vec3(1, 0.1, 0.2))),
        (Vec3(-r - 0.18, 6.4, -0.9), simd_normalize(Vec3(-1, 0.1, -0.2))),
    ]
    /// RCS pods at +x, −x, +z, −z: top ring (0–3) and skirt ring (4–7), matching RCSActuator.podFiring.
    static let rcsPods: [Vec3] = [Vec3(r + 0.35, 12.0, 0), Vec3(-r - 0.35, 12.0, 0), Vec3(0, 12.0, r + 0.35), Vec3(0, 12.0, -r - 0.35),
                                  Vec3(r + 0.35, 2.4, 0), Vec3(-r - 0.35, 2.4, 0), Vec3(0, 2.4, r + 0.35), Vec3(0, 2.4, -r - 0.35)]
    /// Pod hardware per station: the top ring uses protruding Apollo-style quads, the skirt ring flush Shuttle-style ports.
    static let rcsVariants: [RCSVariant] = [.quad, .quad, .quad, .quad, .flush, .flush, .flush, .flush]
    static let rcsSpecs: [RCSPodSpec] = rcsVariants.map { RCSPodSpec.make($0) }

    /// Pod frame in vehicle-local space: origin on the skin, +Z outward, +Y up, +X tangent.
    static func rcsFrame(_ i: Int) -> float4x4 {
        let p = rcsPods[i]
        let outward = simd_normalize(Vec3(p.x, 0, p.z))
        return float4x4(translation: Vec3(outward.x * r, p.y, outward.z * r)) * float4x4(rotationAxis: Vec3(0, 1, 0), angle: atan2f(outward.x, outward.z))
    }

    /// Nozzles of pod `i` in vehicle-local space: exit-plane centre, exhaust direction, exit radius.
    static func rcsNozzles(pod i: Int) -> [(exit: Vec3, dir: Vec3, radius: Float)] {
        let f = rcsFrame(i)
        return rcsSpecs[i].nozzles.map { n in
            let e = f * Vec4(n.exit.x, n.exit.y, n.exit.z, 1)
            let d = f * Vec4(n.dir.x, n.dir.y, n.dir.z, 0)
            return (Vec3(e.x, e.y, e.z), simd_normalize(Vec3(d.x, d.y, d.z)), n.exitRadius)
        }
    }

    struct Parts {
        var parts: [(MeshPart, Bool)]       // (part, double-sided)
        var skirtIndex: Int                 // part whose vertices crumple on hard landings
    }

    static func build() -> Parts {
        var tank = MeshData()
        var skirt = MeshData()
        var steel = MeshData()
        var dark = MeshData()
        // tank barrel (frosted): aft dome edge → barrel → forward bulkhead edge
        tank.append(MeshBuilder.lathe([SIMD2(r, tankTop), SIMD2(r, tankBottom + 0.3), SIMD2(r - 0.35, tankBottom),
                                        SIMD2(0.95, tankBottom - 0.2), SIMD2(0.85, tankBottom - 0.2)], segments: 72))
        // forward equipment ring (bare stainless, not frosted) + low nose dome
        var nose: [SIMD2<Float>] = [SIMD2(0, top)]
        for i in 1...6 {
            let a = Float(i) / 6 * (.pi / 2)
            nose.append(SIMD2(r * sinf(a), ringTop + (top - ringTop) * cosf(a)))
        }
        nose.append(SIMD2(r, tankTop))
        steel.append(MeshBuilder.lathe(nose, segments: 72))
        // weld rings: common bulkhead, barrel seams, ring joints
        for y in [tankBottom + 1.6, 7.85, 9.1, tankTop, 11.6] {
            steel.append(MeshBuilder.torus(major: r + 0.012, minor: 0.03, majorSegments: 72, minorSegments: 4), transform: float4x4(translation: Vec3(0, y, 0)))
        }
        // thrust puck under the aft dome
        steel.append(MeshBuilder.cylinder(radius: 0.9, height: 0.42, segments: 32), transform: float4x4(translation: Vec3(0, mount + 0.21, 0)))
        // engine-bay skirt: straight shell with a slight flare at the foot (double-sided; crumples)
        skirt.append(MeshBuilder.lathe([SIMD2(r - 0.02, tankBottom + 0.5), SIMD2(r - 0.02, 1.4), SIMD2(r + 0.08, 0.5),
                                         SIMD2(r + 0.2, 0.0)], segments: 96))
        // heavy foot ring the vehicle stands on (ballast ring sits inside it)
        dark.append(MeshBuilder.lathe([SIMD2(r + 0.22, 0.32), SIMD2(Float(TV1Vehicle.footRadius) + 0.02, 0.28),
                                        SIMD2(Float(TV1Vehicle.footRadius) + 0.02, 0.0)], segments: 96))
        dark.append(MeshBuilder.lathe([SIMD2(r - 0.05, 0.4), SIMD2(r - 0.45, 0.4), SIMD2(r - 0.45, 1.1), SIMD2(r - 0.05, 1.1)], segments: 72))
        // four skirt stiffener ribs + an access hatch frame
        for i in 0..<4 {
            let a = Float(i) / 4 * 2 * .pi + .pi / 4
            let p0 = Vec3(cosf(a) * (r + 0.05), 0.3, sinf(a) * (r + 0.05)), p1 = Vec3(cosf(a) * (r + 0.05), tankBottom, sinf(a) * (r + 0.05))
            steel.append(MeshBuilder.beam(from: p0, to: p1, width: 0.14))
        }
        steel.append(MeshBuilder.box(size: Vec3(0.08, 1.6, 1.1)), transform: float4x4(translation: Vec3(r + 0.02, 1.9, -1.2)))
        // RCS pods: protruding quads on the top ring, flush port banks on the skirt ring (see RCSPod.swift)
        var rcs = RCSMesh.Meshes()
        for (k, spec) in rcsSpecs.enumerated() { RCSMesh.add(spec, frame: rcsFrame(k), to: &rcs) }
        steel.append(rcs.steel)
        dark.append(rcs.dark)
        // vent stacks
        for (pos, dir) in vents {
            let up = Vec3(0, 1, 0)
            let axis = simd_cross(up, dir)
            let sn = simd_length(axis)
            let rot = sn > 1e-4 ? float4x4(rotationAxis: axis / sn, angle: atan2f(sn, simd_dot(up, dir))) : matrix_identity_float4x4
            steel.append(MeshBuilder.cylinder(radius: 0.12, height: 0.55, segments: 16), transform: float4x4(translation: pos - dir * 0.27) * rot)
        }
        // external raceway and two pressurisation lines down the barrel into the skirt
        steel.append(MeshBuilder.beam(from: Vec3(0.5, 1.2, r + 0.13), to: Vec3(0.5, ringTop, r + 0.13), width: 0.24))
        steel.append(MeshBuilder.tube(points: [Vec3(-r - 0.12, 1.5, 0.6), Vec3(-r - 0.14, 6.0, 0.6), Vec3(-r - 0.12, 10.0, 0.4)], radius: 0.07))
        steel.append(MeshBuilder.tube(points: [Vec3(-0.6, 1.4, -r - 0.12), Vec3(-0.6, 7.6, -r - 0.14)], radius: 0.06))
        // painted "TV-1" band (dark) on the equipment ring
        dark.append(MeshBuilder.lathe([SIMD2(r + 0.006, 11.25), SIMD2(r + 0.006, 10.95)], segments: 72))

        let frosted = Material(baseColor: Vec3(0.70, 0.69, 0.67), metallic: 1.0, roughness: 0.24, kind: .frostedSteel)
        let skirtMat = Material(baseColor: Vec3(0.64, 0.63, 0.61), metallic: 1.0, roughness: 0.3, kind: .brushed)
        let darkMat = Material(baseColor: Vec3(0.10, 0.10, 0.11), metallic: 0.6, roughness: 0.5, kind: .paint)
        let parts: [(MeshPart, Bool)] = [
            (MeshPart(name: "tv1Tank", data: tank, material: frosted), false),
            (MeshPart(name: "tv1Skirt", data: skirt, material: skirtMat), true),
            (MeshPart(name: "tv1Steel", data: steel, material: .brushedSteel), false),
            (MeshPart(name: "tv1Dark", data: dark, material: darkMat), false),
            (MeshPart(name: "tv1Rcs", data: rcs.bronze, material: RCSMesh.bronzeMaterial), true),
        ]
        return Parts(parts: parts, skirtIndex: 1)
    }

    /// Crumple the skirt foot: compress the lowest metre (proportional to `dent`, m) with a buckling wrinkle.
    static func dentSkirt(_ base: [Vertex], dent: Float) -> [Vertex] {
        guard dent > 0.001 else { return base }
        var out = base
        let zone: Float = 1.4
        for i in out.indices {
            let p = out[i].position
            let y = p.y
            guard y < zone else { continue }
            let t = 1 - y / zone                                    // 1 at the foot
            let ang = atan2f(p.z, p.x)
            let wr = sinf(ang * 23) * 0.5 + sinf(ang * 7 + 1.3) * 0.5
            let ny = y + dent * t * (0.75 + 0.25 * wr)
            let push = 1 + dent * 0.08 * t * wr
            out[i].position = Vec4(p.x * push, min(ny, zone), p.z * push, p.w * (1 - 0.3 * t * min(dent, 1)))
        }
        return out
    }
}
