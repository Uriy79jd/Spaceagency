import SwiftUI

// Compact orbital HUD panels: flight controls (right), orbit telemetry + time warp (left).
// The FX-9 flies on autopilot only in this milestone; manual control is a clearly-marked stub.

struct OrbitalLeftPanel: View {
    @ObservedObject var ui: GameUIModel
    let engine: GameEngine
    var body: some View {
        let t = ui.orbital
        GlassPanel {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    TinyLabel(text: "FX-9 · " + t.phase)
                    Spacer()
                    Text(t.autopilot ? "AP" : "MAN").font(.system(size: 7, weight: .bold))
                        .foregroundColor(t.autopilot ? .green : .orange)
                }
                HStack(spacing: 8) {
                    readout("ALT", t.altitude < 1000 ? String(format: "%.0f m", t.altitude) : String(format: "%.1f km", t.altitude / 1000))
                    readout("VEL", String(format: "%.2f km/s", t.orbitalVelocity / 1000))
                    readout("APO", String(format: "%.0f km", t.apoapsis / 1000))
                    readout("PERI", String(format: "%.0f km", t.periapsis / 1000))
                }
                HStack(spacing: 8) {
                    readout("T/W", String(format: "%.2f", t.tw))
                    readout("MACH", String(format: "%.2f", t.mach))
                    readout("Q", String(format: "%.1f kPa", t.dynPressureKPa))
                    readout("STAGE", "\(t.stage)")
                }
                HStack(spacing: 8) {
                    readout("T-CIRC", t.timeToCircularization < 0 ? "—" : String(format: "%.0f s", t.timeToCircularization))
                    readout("ΔV MARGIN", String(format: "%+.0f m/s", t.dvMargin))
                    readout("MASS", String(format: "%.0f t", t.massT))
                }
                Divider().background(Color.white.opacity(0.2))
                propBar("S1 PROP", t.s1PropPct)
                propBar("S2 PROP", t.s2PropPct)
                propBar("N₂ RCS", t.n2Pct)
                HStack(spacing: 8) {
                    readout("VAPOR", String(format: "%.0f%%", t.vaporCone * 100))
                    readout("STARS", String(format: "%.0f%%", t.starVisibility * 100))
                    readout("BOOSTER", t.boosterStatus)
                }
                // Time warp: 1× / 2× / 4× / 8×, only above 10 km and supersonic (past max-Q).
                HStack(spacing: 4) {
                    TinyLabel(text: "Warp")
                    ForEach([1.0, 2.0, 4.0, 8.0], id: \.self) { w in
                        Button {
                            engine.orbitalSetWarp(w)
                        } label: {
                            Text("\(Int(w))×")
                                .font(.system(size: 8, weight: .semibold))
                                .foregroundColor(t.warp == w && t.warpAvailable ? .black : .white)
                                .padding(.horizontal, 6).frame(height: 20)
                                .background(Capsule().fill(t.warp == w && t.warpAvailable ? Color.white : Color.white.opacity(0.12)))
                        }
                        .disabled(!t.warpAvailable)
                        .opacity(t.warpAvailable ? 1 : 0.4)
                    }
                    Spacer()
                    Text(t.warpAvailable ? "WARP \(Int(t.warp))×" : "LOCKED · >10 KM + MACH 1")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundColor(t.warpAvailable ? .green : .white.opacity(0.5))
                }
                ForEach(Array(t.warnings.suffix(3)), id: \.self) { w in
                    Text(w).font(.system(size: 7.5, weight: .bold)).foregroundColor(Color(red: 1, green: 0.55, blue: 0.3)).lineLimit(1)
                }
            }
        }
        .frame(width: 196)
    }

    private func readout(_ k: String, _ v: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            TinyLabel(text: k)
            Text(v).font(.system(size: 9, weight: .medium)).monospacedDigit().foregroundColor(.white).lineLimit(1)
        }
    }

    private func propBar(_ k: String, _ pct: Double) -> some View {
        HStack(spacing: 4) {
            TinyLabel(text: k)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.12))
                    Capsule().fill(pct > 20 ? Color.green : Color.red)
                        .frame(width: g.size.width * CGFloat(max(0, min(1, pct / 100))))
                }
            }
            .frame(height: 4)
            Text(String(format: "%.0f%%", pct)).font(.system(size: 7)).monospacedDigit()
                .foregroundColor(.white.opacity(0.7)).frame(width: 30, alignment: .trailing)
        }
    }
}

struct OrbitalPanel: View {
    @ObservedObject var ui: GameUIModel
    let engine: GameEngine

    var body: some View {
        let t = ui.orbital
        let inFlight = t.missionTime >= 0 && t.phase != "SAFED" && t.phase != "ORBIT ACHIEVED" && t.phase != "LANDED" && t.phase != "ABORTED" && t.phase != "VEHICLE LOST"
        GlassPanel {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("FX-9").font(.system(size: 11, weight: .semibold)).tracking(1).foregroundColor(.white)
                    Spacer()
                    TinyLabel(text: "Falcon-size · 2-stage")
                }
                Text(t.capabilitiesNote).font(.system(size: 7)).foregroundColor(.white.opacity(0.6)).lineLimit(1)
                Button(action: { engine.orbitalLaunch() }) {
                    Text(launchTitle(t))
                        .lineLimit(1).minimumScaleFactor(0.8)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(HUDButtonStyle(prominent: true))
                .disabled(t.phase != "READY")
                .opacity(t.phase != "READY" && t.phase != "COUNTDOWN" ? 0.4 : 1)
                HStack(spacing: 6) {
                    Button("ABORT") { engine.orbitalAbort() }
                        .buttonStyle(HUDButtonStyle(destructive: true))
                    Button("RESET") { engine.resetOrbitalFlight() }
                        .buttonStyle(HUDButtonStyle())
                        .disabled(inFlight)
                        .opacity(inFlight ? 0.4 : 1)
                }
                Toggle(isOn: Binding(get: { ui.orbitalAutopilot }, set: { v in ui.orbitalAutopilot = v; engine.orbitalSetAutopilot(v) })) {
                    Text("AUTOPILOT").font(.system(size: 9, weight: .semibold)).tracking(0.6).foregroundColor(.white)
                }
                .tint(.green)
                .controlSize(.mini)
                Text("MANUAL CONTROL NOT YET AVAILABLE — AUTOPILOT ONLY IN THIS MILESTONE")
                    .font(.system(size: 6.5, weight: .semibold)).foregroundColor(.white.opacity(0.5)).lineLimit(2)
                Divider().background(Color.white.opacity(0.2))
                // Engines: tap E1–E9 (or the single S2 engine) to select, then shut down / restart.
                // One S1 engine out is compensated (throttle-up + gimbal + replan); the S2 engine
                // has no redundancy — shutting it down safes the vehicle and ends the orbit attempt.
                TinyLabel(text: t.stage == 1 ? "Stage 1 engines · tap to select" : "Stage 2 engine · single, no redundancy")
                if t.stage == 1 {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 3), spacing: 3) {
                        ForEach(0..<9, id: \.self) { i in
                            engineChip(i)
                        }
                    }
                    if let sel = ui.orbitalSelectedEngine {
                        HStack(spacing: 6) {
                            if t.engineOut.contains(sel) {
                                Button("RESTART E\(sel + 1)") { engine.orbitalRelightEngine(sel) }
                                    .buttonStyle(HUDButtonStyle(prominent: true))
                            } else {
                                Button("SHUT DOWN E\(sel + 1)") { engine.orbitalShutdownEngine(sel) }
                                    .buttonStyle(HUDButtonStyle(destructive: true))
                            }
                        }
                    }
                } else {
                    HStack(spacing: 6) {
                        Button("SHUT DOWN S2 ENGINE") { engine.orbitalShutdownStage2Engine() }
                            .buttonStyle(HUDButtonStyle(destructive: true))
                    }
                    Text("S2 HAS NO ENGINE-OUT REDUNDANCY — SHUTDOWN SAFES THE VEHICLE, ORBIT UNREACHABLE")
                        .font(.system(size: 6.5, weight: .semibold)).foregroundColor(.orange).lineLimit(2)
                }
                // RCS thrusters: tap to toggle one off/on — the allocator redistributes.
                if !t.rcsIds.isEmpty {
                    TinyLabel(text: "RCS thrusters · tap to toggle")
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 4), spacing: 3) {
                        ForEach(t.rcsIds, id: \.self) { id in
                            let out = t.rcsOut.contains(id)
                            let short = id.split(separator: "-").last.map(String.init) ?? id
                            Button {
                                engine.orbitalToggleRCSThruster(id, enabled: out)
                            } label: {
                                Text("\(id.contains("TOP") ? "T" : (id.contains("BOT") ? "B" : (id.contains("ROLL") ? "R" : "A")))\(short)")
                                    .font(.system(size: 7, weight: .bold))
                                    .foregroundColor(out ? .red : .white)
                                    .frame(maxWidth: .infinity, minHeight: 22)
                                    .background(RoundedRectangle(cornerRadius: 5).fill(out ? Color.red.opacity(0.25) : Color.white.opacity(0.1)))
                            }
                        }
                    }
                    if !t.rcsOut.isEmpty {
                        Text("RCS OUT: \(t.rcsOut.joined(separator: ", ")) — ALLOCATOR REDISTRIBUTED")
                            .font(.system(size: 6.5, weight: .semibold)).foregroundColor(.orange).lineLimit(2)
                    }
                }
                Divider().background(Color.white.opacity(0.2))
                // Map destination + fuel check.
                TinyLabel(text: "Map destination")
                Menu {
                    Button("None") { engine.orbitalSelectDestination(nil) }
                    ForEach(DestinationCatalog.all, id: \.id) { d in
                        Button(d.name) { engine.orbitalSelectDestination(d) }
                    }
                } label: {
                    HStack {
                        Text((ui.orbitalDestination?.name ?? "SELECT DESTINATION").uppercased())
                            .font(.system(size: 8, weight: .semibold)).foregroundColor(.white).lineLimit(1)
                        Spacer()
                        Image(systemName: "chevron.down").font(.system(size: 7)).foregroundColor(.white.opacity(0.6))
                    }
                    .padding(.horizontal, 6).padding(.vertical, 3)
                    .frame(minHeight: UIMetrics.minTap)
                    .background(RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.1)))
                }
                if let w = t.fuelWarning {
                    Text(w).font(.system(size: 7, weight: .bold)).foregroundColor(.red).lineLimit(3)
                    if !t.fuelSuggestionName.isEmpty {
                        Text("TRY INSTEAD: \(t.fuelSuggestionName.uppercased())")
                            .font(.system(size: 7, weight: .bold)).foregroundColor(.yellow).lineLimit(1)
                    }
                }
                if t.phase == "ORBIT ACHIEVED" && t.destinationIsLanding {
                    Button("DEORBIT & PRECISE LAND") { engine.orbitalBeginDeorbit() }
                        .buttonStyle(HUDButtonStyle(prominent: true))
                }
                Divider().background(Color.white.opacity(0.2))
                // Space music: calm ambient pad, off / volume, persisted.
                Toggle(isOn: Binding(get: { ui.spaceMusicEnabled }, set: { v in engine.orbitalSetSpaceMusicEnabled(v) })) {
                    Text("SPACE MUSIC").font(.system(size: 9, weight: .semibold)).tracking(0.6).foregroundColor(.white)
                }
                .tint(.green)
                .controlSize(.mini)
                HStack(spacing: 6) {
                    TinyLabel(text: "Volume")
                    Slider(value: Binding(get: { ui.spaceMusicVolume }, set: { v in engine.orbitalSetSpaceMusicVolume(v) }), in: 0...1)
                        .tint(.white).controlSize(.mini)
                    Text(String(format: "%.0f%%", ui.spaceMusicVolume * 100))
                        .font(.system(size: 8, weight: .medium)).monospacedDigit().foregroundColor(.white)
                }
            }
        }
        .frame(width: UIMetrics.panelWidth)
    }

    private func engineChip(_ i: Int) -> some View {
        let t = ui.orbital
        let out = t.engineOut.contains(i)
        let selected = ui.orbitalSelectedEngine == i
        return Button {
            ui.orbitalSelectedEngine = i
            ui.orbitalSelectedRCSThruster = nil
        } label: {
            Text("E\(i + 1)")
                .font(.system(size: 8, weight: .bold))
                .foregroundColor(out ? .red : (selected ? .black : .white))
                .frame(maxWidth: .infinity, minHeight: 24)
                .background(RoundedRectangle(cornerRadius: 5)
                    .fill(out ? Color.red.opacity(0.3) : (selected ? Color.white : Color.white.opacity(0.12))))
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(selected ? Color.white : Color.clear, lineWidth: 1))
        }
    }

    private func launchTitle(_ t: OrbitalTelemetry) -> String {
        if t.phase == "COUNTDOWN", let c = t.countdown { return String(format: "COUNTDOWN  T-%02.0f", (-c).rounded(.up)) }
        if t.phase == "ENGINE START" { return "ENGINE START" }
        return "START AUTOPILOT"
    }
}
