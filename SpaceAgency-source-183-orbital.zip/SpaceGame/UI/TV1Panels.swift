import SwiftUI

// Compact TV-1 HUD panels: flight controls (right), tank telemetry + flight readout (left), camera bar (top).

struct Sparkline: View {
    let values: [Float]
    var body: some View {
        GeometryReader { geo in
            Path { p in
                guard values.count > 1 else { return }
                let lo = values.min() ?? 0, hi = values.max() ?? 1
                let span = max(hi - lo, 0.05)
                for (i, v) in values.enumerated() {
                    let x = geo.size.width * CGFloat(i) / CGFloat(values.count - 1)
                    let y = geo.size.height * (1 - CGFloat((v - lo) / span))
                    if i == 0 { p.move(to: CGPoint(x: x, y: y)) } else { p.addLine(to: CGPoint(x: x, y: y)) }
                }
            }
            .stroke(Color.white.opacity(0.8), lineWidth: 1)
        }
    }
}

struct TankRow: View {
    let t: TankReadout
    var body: some View {
        HStack(spacing: 5) {
            Text(t.name).font(.system(size: 7.5, weight: .bold)).foregroundColor(.white.opacity(0.7)).frame(width: 22, alignment: .leading)
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 2) {
                    Text(String(format: "%4.1f psi", t.psi)).font(.system(size: 9, weight: .medium)).monospacedDigit().foregroundColor(.white)
                    Image(systemName: t.trend > 0 ? "arrow.up" : (t.trend < 0 ? "arrow.down" : "minus"))
                        .font(.system(size: 6, weight: .bold)).foregroundColor(.white.opacity(0.6))
                    if t.venting { Text("VENT").font(.system(size: 6, weight: .bold)).foregroundColor(.cyan) }
                }
                Text(String(format: "%.0f K liq · %.0f K ull · %3.0f%%", t.liquidK, t.ullageK, t.fillPct))
                    .font(.system(size: 6.5)).monospacedDigit().foregroundColor(.white.opacity(0.55)).lineLimit(1)
            }
            Spacer(minLength: 2)
            Sparkline(values: t.history).frame(width: 34, height: 14)
            // fill bar
            ZStack(alignment: .bottom) {
                Rectangle().fill(Color.white.opacity(0.12))
                Rectangle().fill(Color.white.opacity(0.85)).frame(height: max(1, 18 * CGFloat(t.fillPct / 100)))
            }
            .frame(width: 4, height: 18)
        }
    }
}

struct TV1LeftPanel: View {
    @ObservedObject var ui: GameUIModel
    var body: some View {
        let t = ui.tv1
        GlassPanel {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    TinyLabel(text: "TV-1 · " + t.phase)
                    Spacer()
                    Text(t.autopilot ? "AP" : "MAN").font(.system(size: 7, weight: .bold))
                        .foregroundColor(t.autopilot ? .green : .orange)
                }
                HStack(spacing: 8) {
                    readout("ALT", t.altitude < 1000 ? String(format: "%.0f m", t.altitude) : String(format: "%.2f km", t.altitude / 1000))
                    readout("V/S", String(format: "%+.1f", t.vSpeed))
                    readout("H/S", String(format: "%.1f", t.hSpeed))
                }
                HStack(spacing: 8) {
                    readout("TARGET", String(format: "%.0f m · %03.0f°", t.lzDistance, t.lzBearing))
                    readout("T/W", String(format: "%.2f", t.tw))
                    readout("Q", String(format: "%.1f kPa", t.dynPressureKPa))
                }
                if let a = t.accuracy {
                    Text(String(format: "TOUCHDOWN %.1f m from target · %.1f m/s", a, t.touchdownSpeed ?? 0))
                        .font(.system(size: 7.5, weight: .semibold)).foregroundColor(.white)
                }
                Divider().background(Color.white.opacity(0.2))
                TankRow(t: t.lox)
                TankRow(t: t.ch4)
                HStack(spacing: 8) {
                    readout("BURN LEFT", String(format: "%.0f s", t.burnTime))
                    readout("N₂", String(format: "%.0f%%", t.n2Pct))
                    readout("MARGIN", String(format: "%+.1f t", t.marginKg / 1000))
                }
                // control authority: available torque vs aerodynamic disturbance
                HStack(spacing: 4) {
                    TinyLabel(text: "Authority")
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.12))
                            Capsule().fill(t.authority > 2 ? Color.green : (t.authority > 1 ? Color.yellow : Color.red))
                                .frame(width: g.size.width * CGFloat(min(t.authority / 10, 1)))
                        }
                    }
                    .frame(height: 4)
                    Text(t.authority > 99 ? ">99×" : String(format: "%.1f×", t.authority))
                        .font(.system(size: 7)).monospacedDigit().foregroundColor(.white.opacity(0.7)).frame(width: 30, alignment: .trailing)
                }
                ForEach(Array(t.warnings.suffix(3)), id: \.self) { w in
                    Text(w).font(.system(size: 7.5, weight: .bold)).foregroundColor(Color(red: 1, green: 0.55, blue: 0.3)).lineLimit(1)
                }
            }
        }
        .frame(width: 196)
    }

    private func readout(_ k: String, _ v: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            TinyLabel(text: k)
            Text(v).font(.system(size: 9, weight: .medium)).monospacedDigit().foregroundColor(.white).lineLimit(1)
        }
    }
}

struct TV1Panel: View {
    @ObservedObject var ui: GameUIModel
    let engine: GameEngine

    var body: some View {
        let t = ui.tv1
        let inFlight = t.missionTime >= 0 && t.phase != "SAFED" && t.phase != "VEHICLE LOST"
        GlassPanel {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text("TV-1").font(.system(size: 11, weight: .semibold)).tracking(1).foregroundColor(.white)
                    Spacer()
                    TinyLabel(text: "Test vehicle 1")
                }
                if ui.tv1Autopilot {
                    // START AUTOPILOT → T-10 countdown (clock + timeline on the HUD), engine start at the right
                    // time, clamps open at T-0. ABORT below holds the count.
                    Button(action: { engine.tv1Launch() }) {
                        Text(launchTitle(t))
                            .lineLimit(1).minimumScaleFactor(0.8)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(HUDButtonStyle(prominent: true))
                    .disabled(t.phase != "READY")
                    .opacity(t.phase != "READY" && t.phase != "COUNTDOWN" ? 0.4 : 1)
                }
                HStack(spacing: 6) {
                    if !ui.tv1Autopilot {
                        Button("IGNITE") { engine.tv1Launch() }
                            .buttonStyle(HUDButtonStyle(prominent: true))
                    }
                    Button("ABORT") { engine.tv1Abort() }
                        .buttonStyle(HUDButtonStyle(destructive: true))
                    Button("RESET") { engine.resetFlight() }
                        .buttonStyle(HUDButtonStyle())
                        .disabled(inFlight)
                        .opacity(inFlight ? 0.4 : 1)
                }
                Toggle(isOn: Binding(get: { ui.tv1Autopilot }, set: { v in ui.tv1Autopilot = v; engine.tv1SetAutopilot(v) })) {
                    Text("AUTOPILOT").font(.system(size: 9, weight: .semibold)).tracking(0.6).foregroundColor(.white)
                }
                .tint(.green)
                .controlSize(.mini)
                HStack(spacing: 4) {
                    Menu {
                        ForEach(FlightProfile.allCases, id: \.self) { p in
                            Button(p.rawValue) { ui.tv1Profile = p; engine.resetFlight() }
                        }
                    } label: { chip("PROFILE", ui.tv1Profile.rawValue) }
                    .disabled(inFlight)
                    Menu {
                        ForEach(TestScenario.allCases, id: \.self) { s in
                            Button(s.rawValue) { ui.tv1Scenario = s; engine.resetFlight() }
                        }
                    } label: { chip("SCENARIO", ui.tv1Scenario.rawValue) }
                    .disabled(inFlight)
                }
                Button {
                    ui.tv1LandAtPad.toggle()
                    engine.resetFlight()
                } label: { chip("LAND ON", ui.tv1LandAtPad ? "LAUNCH PAD" : "LANDING ZONE") }
                .disabled(inFlight || ui.tv1Profile == .hover)
                if !ui.tv1Autopilot {
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            TinyLabel(text: "Throttle")
                            Spacer()
                            Text(String(format: "%.0f%%", ui.throttle * 100)).font(.system(size: 9, weight: .medium)).monospacedDigit().foregroundColor(.white)
                        }
                        Slider(value: $ui.throttle, in: 0.4...1.0).tint(.white).controlSize(.mini)
                        HStack(spacing: 6) {
                            Button("ENGINE ON") { engine.tv1EngineStart() }.buttonStyle(HUDButtonStyle(prominent: true))
                            Button("CUT") { engine.tv1EngineStop() }.buttonStyle(HUDButtonStyle(destructive: true))
                        }
                        Toggle(isOn: $ui.tv1AssistAttitude) {
                            Text("ATTITUDE HOLD").font(.system(size: 8, weight: .semibold)).foregroundColor(.white)
                        }.controlSize(.mini).tint(.green)
                        Toggle(isOn: $ui.tv1AssistHover) {
                            Text("HOVER HOLD").font(.system(size: 8, weight: .semibold)).foregroundColor(.white)
                        }.controlSize(.mini).tint(.green)
                        Toggle(isOn: $ui.tv1Translate) {
                            Text("TRANSLATE (RCS)").font(.system(size: 8, weight: .semibold)).foregroundColor(.white)
                        }.controlSize(.mini).tint(.cyan)
                    }
                }
            }
        }
        .frame(width: UIMetrics.panelWidth)
    }

    private func launchTitle(_ t: TV1Telemetry) -> String {
        if t.phase == "COUNTDOWN", let c = t.countdown { return String(format: "COUNTDOWN  T-%02.0f", (-c).rounded(.up)) }
        if t.phase == "ENGINE START" { return "ENGINE START" }
        return "START AUTOPILOT"
    }

    private func chip(_ k: String, _ v: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            TinyLabel(text: k)
            Text(v.uppercased()).font(.system(size: 8, weight: .semibold)).foregroundColor(.white).lineLimit(1)
        }
        .padding(.horizontal, 6).padding(.vertical, 3)
        .frame(minHeight: UIMetrics.minTap)
        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.1)))
    }
}

/// Camera selection: MAIN (follow/orbit) and the vehicle's mounted cameras. Double-tap the scene to reset.
struct CameraBar: View {
    @ObservedObject var ui: GameUIModel
    var body: some View {
        HStack(spacing: 4) {
            ForEach(Array(ui.cameraNames.enumerated()), id: \.offset) { i, name in
                Button {
                    ui.cameraMode = i
                } label: {
                    Text(name).font(.system(size: 8, weight: .semibold)).tracking(0.6)
                        .foregroundColor(ui.cameraMode == i ? .black : .white)
                        .padding(.horizontal, 8).frame(height: 22)
                        .background(Capsule().fill(ui.cameraMode == i ? Color.white : Color.black.opacity(0.45)))
                        .frame(minHeight: UIMetrics.minTap)
                        .contentShape(Rectangle())
                }
            }
        }
    }
}
