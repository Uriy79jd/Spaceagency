import SwiftUI
import MetalKit
import UIKit

/// MTKView with the editor's touch camera: one-finger orbit, two-finger pan, pinch zoom, tap to select.
final class GameMTKView: MTKView, UIGestureRecognizerDelegate {
    weak var engine: GameEngine?
    private var lastPan = CGPoint.zero
    private var lastOrbit = CGPoint.zero
    private var lastPinch: CGFloat = 1

    private var observers: [NSObjectProtocol] = []

    /// Stop rendering entirely while the app is in the background / inactive (no GPU work, no heat).
    func installLifecycleObservers() {
        let nc = NotificationCenter.default
        let pause: @Sendable (Notification) -> Void = { [weak self] _ in
            MainActor.assumeIsolated { self?.isPaused = true }
        }
        let resume: @Sendable (Notification) -> Void = { [weak self] _ in
            MainActor.assumeIsolated { self?.isPaused = false }
        }
        observers.append(nc.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: .main, using: pause))
        observers.append(nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main, using: pause))
        observers.append(nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main, using: resume))
    }

    func installGestures() {
        isMultipleTouchEnabled = true
        let orbit = UIPanGestureRecognizer(target: self, action: #selector(onOrbit(_:)))
        orbit.maximumNumberOfTouches = 1
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.minimumNumberOfTouches = 2
        pan.maximumNumberOfTouches = 2
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(onPinch(_:)))
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        tap.require(toFail: doubleTap)
        for g in [orbit, pan, pinch, tap, doubleTap] as [UIGestureRecognizer] {
            g.delegate = self
            addGestureRecognizer(g)
        }
    }

    func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool {
        let twoFinger = { (x: UIGestureRecognizer) -> Bool in
            x is UIPinchGestureRecognizer || ((x as? UIPanGestureRecognizer)?.minimumNumberOfTouches ?? 0) == 2
        }
        return twoFinger(g) && twoFinger(other)
    }

    @objc private func onOrbit(_ g: UIPanGestureRecognizer) {
        engine?.noteInteraction()
        let t = g.translation(in: self)
        if g.state == .began { lastOrbit = .zero }
        engine?.camera.orbit(dx: Double(t.x - lastOrbit.x), dy: Double(t.y - lastOrbit.y))
        lastOrbit = t
    }

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        engine?.noteInteraction()
        let t = g.translation(in: self)
        if g.state == .began { lastPan = .zero }
        engine?.camera.pan(dx: Double(t.x - lastPan.x), dy: Double(t.y - lastPan.y), viewHeight: Double(bounds.height))
        lastPan = t
    }

    @objc private func onPinch(_ g: UIPinchGestureRecognizer) {
        engine?.noteInteraction()
        if g.state == .began { lastPinch = 1 }
        engine?.camera.zoom(scale: Double(g.scale / lastPinch))
        lastPinch = g.scale
    }

    @objc private func onDoubleTap(_ g: UITapGestureRecognizer) {
        engine?.noteInteraction()
        engine?.resetCamera()
    }

    @objc private func onTap(_ g: UITapGestureRecognizer) {
        engine?.noteInteraction()
        engine?.tap(at: g.location(in: self))
    }
}

struct MetalView: UIViewRepresentable {
    let engine: GameEngine

    final class Coordinator {
        var renderer: Renderer?
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> GameMTKView {
        let v = GameMTKView(frame: .zero, device: MTLCreateSystemDefaultDevice())
        // drawable at the native scale (a reduced drawable reads as soft/grainy); the 3-D scene renders at the
        // quality tier's px-per-point density and is upscaled in the composite, so this costs only the final pass
        v.contentScaleFactor = UIScreen.main.nativeScale
        v.engine = engine
        v.installGestures()
        v.installLifecycleObservers()
        if let r = Renderer(view: v, engine: engine) {
            context.coordinator.renderer = r
            v.delegate = r
        }
        return v
    }

    func updateUIView(_ uiView: GameMTKView, context: Context) {}
}
