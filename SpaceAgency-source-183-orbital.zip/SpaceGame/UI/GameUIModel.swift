import Foundation
import Combine
import CoreGraphics

struct Telemetry: Equatable {
    var phase: String = "Safed"
    var chamberPressureBar: Double = 0
    var thrustKN: Double = 0
    var oxRPM: Double = 0
    var fuelRPM: Double = 0
    var massFlow: Double = 0
    var oxFlow: Double = 0
    var fuelFlow: Double = 0
    var isp: Double = 0
    var exitPressureBar: Double = 0
    var ambientPressurePa: Double = 101_325
    var expansionState: String = "—"
    var nozzleTempK: Double = 293
    var padTempK: Double = 293
    var gimbalPitchDeg: Double = 0
    var gimbalYawDeg: Double = 0
    var sideForceKN: Double = 0
    var throttleActual: Double = 1
    var shockSpacing: Double = 0
    var clockText: String = "T- 00:00:00"
    var timelineProgress: Double = 0      // 0..4 across CHILL-DOWN, SPIN START, IGNITION, MAINSTAGE, SHUTDOWN
    var engineState: Int = 0              // 0 off, 1 starting / shutting down, 2 running
    var vacuum = false
    var engineRich: Double = 0
    var ch4Pct: Double = 100
    var mixtureRatio: Double = 3.6
    var warning = ""

    static let lbfPerNewton = 0.2248089431
    var thrustLbf: Double { thrustKN * 1000 * Telemetry.lbfPerNewton }
    var sideForceLbf: Double { sideForceKN * 1000 * Telemetry.lbfPerNewton }
}

/// One propellant tank as shown on the HUD.
struct TankReadout: Equatable {
    var name = ""
    var psi: Double = 0
    var bar: Double = 0
    var liquidK: Double = 0
    var ullageK: Double = 0
    var wallK: Double = 0
    var fillPct: Double = 0
    var massKg: Double = 0
    var trend: Int = 0                  // −1 falling, 0 steady, 1 rising (pressure)
    var history: [Float] = []           // pressure (bar) sparkline
    var venting = false
}

/// TV-1 flight telemetry (pushed at ~10 Hz).
struct TV1Telemetry: Equatable {
    var phase = "READY"
    var altitude: Double = 0            // m above ground
    var vSpeed: Double = 0
    var hSpeed: Double = 0
    var maxAltitude: Double = 0
    var targetApogee: Double = 0
    var lzDistance: Double = 0
    var lzBearing: Double = 0           // deg, 0 = north (−Z), clockwise
    var accuracy: Double? = nil
    var touchdownSpeed: Double? = nil
    var marginKg: Double = 0
    var tw: Double = 0
    var massT: Double = 0
    var lox = TankReadout()
    var ch4 = TankReadout()
    var burnTime: Double = 0
    var n2Pct: Double = 100
    var authority: Double = 0           // available control torque / disturbance torque
    var gimbalShare: Double = 0         // fraction of the achieved torque from the gimbal
    var warnings: [String] = []
    var timelineProgress: Double = 0
    var autopilot = true
    var missionTime: Double = -1
    var countdown: Double? = nil        // autopilot countdown clock (s relative to T-0), nil without one
    var mach: Double = 0
    var dynPressureKPa: Double = 0
}

/// Orbital flight telemetry (pushed at ~10 Hz).
struct OrbitalTelemetry: Equatable {
    var phase = "READY"
    var altitude: Double = 0            // m above the surface (ECI radius − Earth radius)
    var apoapsis: Double = 0            // m above the surface
    var periapsis: Double = 0           // m above the surface
    var orbitalVelocity: Double = 0     // m/s
    var tw: Double = 0
    var stage: Int = 1
    var mach: Double = 0
    var dynPressureKPa: Double = 0
    var timeToCircularization: Double = -1
    var dvMargin: Double = 0            // m/s of delta-v margin vs the 275 km orbit
    var dvNeeded: Double = 0
    var warp: Double = 1
    var warpAvailable = false
    var vaporCone: Double = 0           // 0..1 transonic condensation strength
    var starVisibility: Double = 0      // 0..1, from Atmosphere.skyState
    var spaceFactor: Double = 0         // 0..1, 1 = black space above ~100 km
    var boosterStatus = "—"
    var s1PropPct: Double = 100
    var s2PropPct: Double = 100
    var n2Pct: Double = 100
    var warnings: [String] = []
    var timelineProgress: Double = 0
    var autopilot = true
    var missionTime: Double = -1
    var countdown: Double? = nil        // autopilot countdown clock (s relative to T-0), nil without one
    var engineOut: [Int] = []           // S1 engine indices out (0 = centre E1)
    var rcsOut: [String] = []           // RCS thruster ids out
    var rcsIds: [String] = []           // all RCS thruster ids for the current stage
    var destinationName = ""
    var destinationIsLanding = false
    var fuelWarning: String? = nil
    var fuelSuggestionName = ""
    var massT: Double = 0
    var engineCount: Int = 9
    var activeEngineCount: Int = 9
    var capabilitiesNote = ""           // one-line summary of the detected capabilities
}

/// SwiftUI-facing state. Updated by `GameEngine` at ~10 Hz (telemetry) or on events.
final class GameUIModel: ObservableObject {
    @Published var enginePlaced = false
    @Published var engineSelected = false
    @Published var running = false
    @Published var starting = false
    @Published var telemetry = Telemetry()
    @Published var throttle: Double = 1.0
    @Published var altitudeSlider: Double = 0      // 0..1, 1 = vacuum
    @Published var gimbalMode = false
    @Published var gimbalPattern: GimbalPattern = .none
    @Published var dragging = false
    @Published var dragSnaps = false
    @Published var qualityName = "High"
    @Published var fps: Double = 60
    @Published var gpuMs: Double = 0
    @Published var thermalName = "OK"
    @Published var showHint = true
    @Published var outdoor = true
    @Published var uiHidden = false
    // TV-1 (launch pad site)
    @Published var site = "stand"                 // "stand", "pad", "orbital", "hangar"
    // Orbital (Falcon-like pad site, 275 x 275 km target orbit)
    @Published var orbital = OrbitalTelemetry()
    @Published var orbitalWarp: Double = 1        // requested time warp 1 / 2 / 4 / 8
    @Published var orbitalWarpAvailable = false   // altitude > 10 km and supersonic
    @Published var orbitalAutopilot = true        // autopilot only in this milestone; manual is a stub
    @Published var orbitalSelectedEngine: Int? = nil     // tapped S1 engine index (0 = E1 centre)
    @Published var orbitalSelectedRCSThruster: String? = nil
    @Published var orbitalDestination: MapDestination? = nil
    @Published var spaceMusicEnabled = true       // persisted in UserDefaults (see SynthAudio)
    @Published var spaceMusicVolume: Double = 0.8 // 0..1, persisted in UserDefaults
    @Published var tv1 = TV1Telemetry()
    @Published var tv1Autopilot = true
    @Published var tv1AssistAttitude = true
    @Published var tv1AssistHover = false
    @Published var tv1Translate = false              // manual: stick → RCS translation instead of rotation
    @Published var tv1Profile: FlightProfile = .tenK
    @Published var tv1Scenario: TestScenario = .nominal
    @Published var tv1LandAtPad = false
    @Published var cameraMode = 0                 // 0 = MAIN, then the vehicle's mounts
    @Published var cameraNames: [String] = ["MAIN", "ENGINE"]

    /// Slider → altitude (m). Quadratic so low altitudes get resolution; last 3 % = vacuum.
    static func altitude(forSlider t: Double) -> (Double, Bool) {
        if t >= 0.97 { return (120_000, true) }
        let u = t / 0.97
        return (120_000 * u * u, false)
    }
}
