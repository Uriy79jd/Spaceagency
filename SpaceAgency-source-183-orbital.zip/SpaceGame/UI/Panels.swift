import SwiftUI
import UIKit

struct GlassPanel<Content: View>: View {
    let content: Content
    init(@ViewBuilder _ content: () -> Content) { self.content = content() }
    var body: some View {
        content
            .padding(9)
            .background(
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(Color.black.opacity(0.55))
                    .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
            )
    }
}

/// Little line drawing of the Raptor for the parts tray.
struct RaptorGlyph: View {
    var body: some View {
        Canvas { ctx, size in
            let w = size.width, h = size.height
            func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: w * 0.5 + x * h, y: y * h) }
            var bell = Path()
            bell.move(to: pt(-0.07, 0.50))
            bell.addCurve(to: pt(-0.22, 0.98), control1: pt(-0.16, 0.62), control2: pt(-0.21, 0.80))
            bell.addLine(to: pt(0.22, 0.98))
            bell.addCurve(to: pt(0.07, 0.50), control1: pt(0.21, 0.80), control2: pt(0.16, 0.62))
            bell.closeSubpath()
            ctx.fill(bell, with: .color(Color(white: 0.12)))
            ctx.stroke(bell, with: .color(.white.opacity(0.5)), lineWidth: 0.8)
            ctx.fill(Path(CGRect(x: w * 0.5 - h * 0.18, y: h * 0.33, width: h * 0.36, height: h * 0.04)), with: .color(Color(white: 0.2)))
            ctx.fill(Path(CGRect(x: w * 0.5 - h * 0.09, y: h * 0.12, width: h * 0.18, height: h * 0.22)), with: .color(Color(white: 0.3)))
            ctx.fill(Path(CGRect(x: w * 0.5 - h * 0.05, y: h * 0.02, width: h * 0.10, height: h * 0.10)), with: .color(Color(white: 0.8)))
            var duct = Path()
            duct.move(to: pt(0.09, 0.22)); duct.addCurve(to: pt(0.02, 0.56), control1: pt(0.20, 0.26), control2: pt(0.16, 0.48))
            ctx.stroke(duct, with: .color(Color(white: 0.25)), lineWidth: h * 0.035)
            ctx.draw(Text("1").font(.system(size: h * 0.12, weight: .bold)).foregroundColor(.white), at: pt(0.05, 0.72))
        }
    }
}

struct PartsTray: View {
    @ObservedObject var ui: GameUIModel
    let engine: GameEngine
    @State private var dragOffset: CGSize = .zero

    var body: some View {
        GlassPanel {
            VStack(alignment: .leading, spacing: 7) {
                TinyLabel(text: "Parts · Engines")
                if ui.enginePlaced {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Raptor 3 is on the stand").font(.system(size: 10, weight: .medium)).foregroundColor(.white)
                        Text("Tap the engine to open its controls.").font(.system(size: 8.5)).foregroundColor(.white.opacity(0.6))
                        HStack {
                            Button("Controls") { ui.engineSelected = true }.buttonStyle(HUDButtonStyle(prominent: true))
                            Button("Remove") { engine.removeEngine() }.buttonStyle(HUDButtonStyle())
                                .disabled(ui.running || ui.starting)
                        }
                    }
                } else {
                    VStack(spacing: 6) {
                        RaptorGlyph().frame(width: 50, height: 62)
                        Text("RAPTOR 3").font(.system(size: 9.5, weight: .semibold)).tracking(0.8).foregroundColor(.white)
                        Text("280 tf · 617,000 lbf SL").font(.system(size: 7)).foregroundColor(.white.opacity(0.55))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(6)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(ui.dragging ? 0.14 : 0.06)))
                    .offset(dragOffset)
                    .gesture(
                        DragGesture(minimumDistance: 4, coordinateSpace: .global)
                            .onChanged { v in
                                dragOffset = v.translation
                                engine.dragUpdate(v.location)
                            }
                            .onEnded { v in
                                let screenW = UIScreen.main.bounds.width
                                engine.dragEnd(v.location, overTray: v.location.x > screenW - 240)
                                dragOffset = .zero
                            }
                    )
                    .onTapGesture { engine.quickPlace() }
                    Text(ui.dragging ? (ui.dragSnaps ? "Release to mount on the stand" : "Drag onto the test stand") : "Drag onto the stand, or tap to place")
                        .font(.system(size: 8)).foregroundColor(.white.opacity(0.6))
                }
            }
        }
        .frame(width: UIMetrics.panelWidth)
    }
}

struct HUDButtonStyle: ButtonStyle {
    var prominent = false
    var destructive = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 9, weight: .semibold))
            .tracking(0.6)
            .lineLimit(1)
            .minimumScaleFactor(0.65)           // never truncate to "LAU…" in a narrow row
            .foregroundColor(prominent ? .black : .white)
            .padding(.horizontal, 7)
            .padding(.vertical, 5)
            .background(
                Capsule().fill(prominent ? Color.white : (destructive ? Color.red.opacity(0.55) : Color.white.opacity(0.14)))
            )
            .frame(minHeight: UIMetrics.minTap)          // visual capsule is small, hit area stays 36 pt
            .contentShape(Rectangle())
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

struct EnginePanel: View {
    @ObservedObject var ui: GameUIModel
    let engine: GameEngine
    @State private var showDetails = false

    var body: some View {
        GlassPanel {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    VStack(alignment: .leading, spacing: 1) {
                        Text("RAPTOR 3").font(.system(size: 11, weight: .semibold)).tracking(1).foregroundColor(.white)
                        Text(ui.telemetry.phase.uppercased()).font(.system(size: 7, weight: .medium)).tracking(0.6).lineLimit(1)
                            .foregroundColor(ui.running ? Color(red: 0.6, green: 0.8, blue: 1) : .white.opacity(0.55))
                    }
                    Spacer()
                    Button { ui.engineSelected = false } label: {
                        Image(systemName: "xmark").font(.system(size: 8, weight: .bold)).foregroundColor(.white.opacity(0.7))
                            .frame(width: 20, height: 20).background(Circle().fill(Color.white.opacity(0.1)))
                            .frame(width: 36, height: 36).contentShape(Rectangle())
                    }
                }
                HStack(spacing: 6) {
                    Button("START") { engine.start() }
                        .buttonStyle(HUDButtonStyle(prominent: true))
                        .disabled(ui.running || ui.starting)
                        .opacity(ui.running || ui.starting ? 0.4 : 1)
                    Button("SHUTDOWN") { engine.shutdown() }
                        .buttonStyle(HUDButtonStyle(destructive: true))
                        .disabled(!(ui.running || ui.starting))
                        .opacity(ui.running || ui.starting ? 1 : 0.4)
                }
                HStack(spacing: 6) {
                    Button("STARVE CH4") { engine.starveMethane() }
                        .buttonStyle(HUDButtonStyle(destructive: true))
                    Button("REFILL") { engine.refillRunTank() }
                        .buttonStyle(HUDButtonStyle())
                        .disabled(ui.running || ui.starting)
                        .opacity(ui.running || ui.starting ? 0.4 : 1)
                }
                HStack {
                    TinyLabel(text: String(format: "CH4 %.0f%% · O/F %.1f", ui.telemetry.ch4Pct, ui.telemetry.mixtureRatio))
                    Spacer()
                }
                if !ui.telemetry.warning.isEmpty {
                    Text(ui.telemetry.warning).font(.system(size: 7.5, weight: .bold))
                        .foregroundColor(ui.telemetry.engineRich > 0.15 ? Color(red: 0.4, green: 1, blue: 0.5) : Color(red: 1, green: 0.5, blue: 0.3))
                        .lineLimit(1)
                }
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        TinyLabel(text: "Throttle")
                        Spacer()
                        Text(String(format: "%.0f%%", ui.throttle * 100)).font(.system(size: 9, weight: .medium)).monospacedDigit().foregroundColor(.white)
                    }
                    Slider(value: $ui.throttle, in: 0.4...1.0)
                        .tint(.white)
                        .controlSize(.mini)
                        .onChange(of: ui.throttle) { _, v in engine.setThrottle(v) }
                }
                Toggle(isOn: $ui.gimbalMode) {
                    Text("GIMBAL MODE").font(.system(size: 9, weight: .semibold)).tracking(0.6).foregroundColor(.white)
                }
                .tint(Color(red: 0.4, green: 0.65, blue: 1))
                .controlSize(.mini)
                if ui.gimbalMode {
                    HStack(spacing: 3) {
                        TinyLabel(text: "Test")
                        ForEach(GimbalPattern.allCases, id: \.self) { p in
                            Button(p.rawValue.uppercased()) { ui.gimbalPattern = p }
                                .buttonStyle(HUDButtonStyle(prominent: ui.gimbalPattern == p))
                        }
                    }
                }
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { showDetails.toggle() }
                } label: {
                    HStack {
                        TinyLabel(text: showDetails ? "Hide telemetry" : "Telemetry")
                        Image(systemName: showDetails ? "chevron.up" : "chevron.down").font(.system(size: 7)).foregroundColor(.white.opacity(0.5))
                    }
                }
                if showDetails {
                    ScrollView {
                        TelemetryList(t: ui.telemetry)
                    }
                    .frame(height: 110)
                }
            }
        }
        .frame(width: UIMetrics.panelWidth)
    }
}

struct TelemetryList: View {
    let t: Telemetry
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            row("Chamber pressure", String(format: "%.0f bar", t.chamberPressureBar))
            row("Thrust", "\(WebcastHUD.grouped(t.thrustLbf)) lbf", String(format: "%.0f kN", t.thrustKN))
            row("Specific impulse", String(format: "%.0f s", t.isp))
            row("Mass flow", String(format: "%.0f kg/s", t.massFlow), String(format: "LOX %.0f · CH4 %.0f", t.oxFlow, t.fuelFlow))
            row("Turbopumps", String(format: "%.0f / %.0f rpm", t.oxRPM, t.fuelRPM), "ox / fuel")
            row("Exit / ambient p", String(format: "%.2f bar / %@", t.exitPressureBar, Self.pressure(t.ambientPressurePa)))
            row("Nozzle flow", t.expansionState)
            row("Shock spacing", t.shockSpacing > 0 && t.engineState == 2 ? String(format: "%.1f m", t.shockSpacing) : "—")
            row("Nozzle wall", String(format: "%.0f K", t.nozzleTempK))
            row("Pad surface", String(format: "%.0f K", t.padTempK))
            row("Gimbal", String(format: "P %+.1f° · Y %+.1f°", t.gimbalPitchDeg, t.gimbalYawDeg))
            row("Side force", "\(WebcastHUD.grouped(t.sideForceLbf)) lbf", String(format: "%.0f kN", t.sideForceKN))
        }
    }

    static func pressure(_ pa: Double) -> String {
        if pa <= 0 { return "vacuum" }
        if pa >= 1000 { return String(format: "%.2f bar", pa / 1e5) }
        if pa >= 1 { return String(format: "%.1f Pa", pa) }
        return String(format: "%.1e Pa", pa)
    }

    private func row(_ k: String, _ v: String, _ sub: String? = nil) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(k.uppercased()).font(.system(size: 6.5, weight: .semibold)).tracking(0.4).foregroundColor(.white.opacity(0.45))
            Spacer(minLength: 6)
            VStack(alignment: .trailing, spacing: 0) {
                Text(v).font(.system(size: 9, weight: .regular)).monospacedDigit().lineLimit(1).foregroundColor(.white)
                if let s = sub { Text(s).font(.system(size: 6.5)).foregroundColor(.white.opacity(0.45)) }
            }
        }
    }
}

/// Vertical altitude slider (0 → 120 km, top end = vacuum).
struct AltitudeSlider: View {
    @Binding var value: Double
    var body: some View {
        VStack(spacing: 6) {
            TinyLabel(text: "Alt")
            GeometryReader { geo in
                let h = geo.size.height
                ZStack(alignment: .bottom) {
                    Capsule().fill(Color.white.opacity(0.12)).frame(width: 4)
                    Capsule().fill(Color.white.opacity(0.85)).frame(width: 4, height: max(4, h * value))
                    Circle().fill(Color.white).frame(width: 13, height: 13)
                        .shadow(color: .white.opacity(0.5), radius: 4)
                        .offset(y: -h * value + 6.5)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { g in
                    value = min(1, max(0, 1 - g.location.y / h))
                })
            }
            .frame(width: 36)
            TinyLabel(text: value >= 0.97 ? "Vac" : "SL")
        }
        .padding(.vertical, 7)
        .background(Capsule().fill(Color.black.opacity(0.4)))
    }
}

/// Virtual joystick for gimbal control. Output x/y in -1...1 (y up = +).
struct GimbalJoystick: View {
    let onChange: (SIMD2<Double>) -> Void
    @State private var knob: CGSize = .zero
    private let radius: CGFloat = 40

    var body: some View {
        ZStack {
            Circle().fill(Color.black.opacity(0.35))
            Circle().stroke(Color.white.opacity(0.3), lineWidth: 1)
            Path { p in
                p.move(to: CGPoint(x: radius, y: 6)); p.addLine(to: CGPoint(x: radius, y: radius * 2 - 6))
                p.move(to: CGPoint(x: 6, y: radius)); p.addLine(to: CGPoint(x: radius * 2 - 6, y: radius))
            }
            .stroke(Color.white.opacity(0.15), lineWidth: 1)
            Circle().fill(Color.white.opacity(0.9)).frame(width: 26, height: 26)
                .shadow(color: .white.opacity(0.4), radius: 5)
                .offset(knob)
            VStack { Spacer(); TinyLabel(text: "Gimbal").padding(.bottom, 4) }
        }
        .frame(width: radius * 2, height: radius * 2)
        .contentShape(Circle())
        .gesture(DragGesture(minimumDistance: 0)
            .onChanged { g in
                var v = CGSize(width: g.location.x - radius, height: g.location.y - radius)
                let l = sqrt(v.width * v.width + v.height * v.height)
                if l > radius { v.width *= radius / l; v.height *= radius / l }
                knob = v
                onChange(SIMD2(Double(v.width / radius), Double(-v.height / radius)))
            }
            .onEnded { _ in
                withAnimation(.spring(response: 0.25, dampingFraction: 0.6)) { knob = .zero }
                onChange(.zero)
            })
    }
}
