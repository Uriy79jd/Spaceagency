# Space Agency — milestone 1 (Raptor 3 test stand) + orbital milestone (FX-9)

Custom engine in Swift + Metal (no SceneKit/RealityKit/Unity). Landscape only, iOS 26.

## Controls
- **One finger drag** — orbit camera · **two fingers** — pan · **pinch** — zoom
- **Tap** the engine to select it (opens the engine panel), tap empty space to deselect
- **Parts tray** (right): drag the Raptor 3 card onto the test stand (snaps when close), or tap the card to place it
- **Engine panel**: START / SHUTDOWN, throttle 40–100 %, GIMBAL MODE toggle with CIRCLE / SWEEP test patterns, collapsible telemetry
- **Gimbal joystick** (bottom-left, when gimbal mode is on): ±15° pitch/yaw, rate-limited actuators
- **Altitude slider** (left): sea level → 120 km, top end = vacuum
- **Speaker button** (top-right): sound on/off (remembered)
- **HANGAR / TEST STAND button** (top bar): switch between the outdoor McGregor-style vertical test stand (default) and the indoor hangar (only while the engine is safed; remembered)
- **Site cycle** (top bar): STAND → TV-1 PAD → ORBITAL PAD → HANGAR

## Orbital milestone — FX-9 (Falcon-size, stainless, expendable)
- **Vehicle**: Ø5 m, 68 m tall, 514 t liftoff (516 t loaded). Stage 1: 9× Raptor 3 (1 centre + 8 outer circle, r = 1.45 m), dry 24 t, propellant ~371 t usable. Stage 2: 1× Raptor 3, dry 5 t, propellant ~93 t, payload 10 t. Target **275 × 275 km orbit** (7.744 km/s, 89.9 min period). Total Δv ~11.2 km/s vs ~9.4 km/s needed.
- **Planet**: Earth radius 6371 km, μ = 398600.4418 km³/s², spherical gravity, 71% ocean / 29% land, launch site 28.5° N, 80.5° W on a coast (ocean downrange east). US Standard Atmosphere 1976 drives drag and engine performance; sky fades blue → black above ~100 km, stars fade in.
- **Autopilot to orbit** (autopilot only; manual is a stub): COUNTDOWN (T-10) → LIFTOFF / gravity turn → MECO → COAST 3 s → SEPARATION (RCS push ~1.5 m/s) → SES → S2 BURN (cutoff at 274 km apoapsis) → COAST TO APOAPSIS → CIRCULARIZATION → ORBIT ACHIEVED. The booster falls back ballistically and splashes down in the ocean (no landing legs — expendable).
- **Time warp**: 1×/2×/4×/8×, unlocked above 10 km and supersonic (past max-Q); extra fixed-timestep substeps per frame, never scaled dt. Auto-drops to 1× at MECO, separation, SES, circularization, orbit, and landing.
- **Vapor cone**: transonic condensation, strongest Mach 0.95–1.2, fading above ~Mach 1.3 and with altitude; never in vacuum.
- **Space music**: procedural calm ambient pad, fades in with altitude, ducks under the engine; toggle + volume slider in the orbital panel (persisted as `spaceMusicEnabled` / `spaceMusicVolume`).
- **Fault tolerance**: tap any of the 9 S1 engines to shut it down — the autopilot throttles up the remaining 8, cancels the thrust asymmetry with gimbal feedforward, extends the burn and replans Δv; it only aborts if the replan genuinely cannot close. Tap any RCS thruster off — the allocator redistributes to the rest. Stage 2 is single-engine: shutting it down safes the vehicle and reports orbit unreachable.
- **Snap modules**: Engine Bay / Tank (LOX, CH4) / Interstage / Fairing with top/bottom attach nodes; `VehicleAssembly` / `StackBuilder` validates diameter/interface and computes mass/CoM/inertia. `VehicleCapabilities` is detected from the stack and drives the autopilot (no hard-coded engine count). Map destinations (orbit 275 km, three landing zones, Mars transfer stub) come with a fuel check that warns when Δv runs out and suggests a closer target; from orbit, DEORBIT & PRECISE LAND flies a ZEM/ZEV landing to the selected point. Earth→Mars is a Hohmann planner stub only.
- **Water & terrain**: ocean waves (sum of 3 sine waves), buoyancy (Archimedes) and velocity-squared water drag, splashdown spray; terrain is deterministic seeded noise — beach, plains, hills, mountains, desert — with ground height feeding landing behaviour.
- **Look**: Falcon 9 shape from the user's reference photos — stainless steel throughout (including the fairing), black interstage band, 9 dark engine bells with light centres on the octaweb — no side boosters, no white, no livery, no fins, no landing legs.

## Layout
- `Engine/` fixed-timestep loop (120 Hz), entities, orbit camera, ray picking, particles
- `Renderer/` forward PBR renderer, procedural geometry, GPU types
- `Shaders/` PBR (GGX, procedural materials), plume raymarch, SSAO, IBL, bloom, ACES, FXAA
- `Parts/` data-driven part definitions (`parts.json`), procedural Raptor 3 + hangar/stand meshes
- `Physics/` US Standard Atmosphere 1976, isentropic nozzle flow, Raptor start/shutdown state machine, gimbal servo
- `Audio/` AVAudioEngine: recorded static-fire samples + procedural synth layer
- `UI/` SwiftUI overlay (webcast-style HUD, panels)

## TV-1 RCS pods
- `Parts/RCSPod.swift` defines pod variants with a per-nozzle table (exit position, exhaust direction, exit radius):
  **quad** (Apollo-style housing, four bell nozzles that stick out, canted 35 degrees outward) on the top ring and
  **flush** (Shuttle-style bank of three ports flush with the skin) on the skirt ring. Assignment: `TV1Mesh.rcsVariants`.
- Firing is per nozzle: each pod's summed exhaust request (`RCSActuator.podFiring`) is projected onto its nozzle
  directions, so a radial request fires all four canted bells, a roll request fires one, and a flush bank fires its ports.
- Plume: translucent blue core, arrowhead Mach diamonds at ~3 exit diameters, narrow streaky pink/lavender column.

## Launch arguments (CI screenshots)
- `-demoScreenshot` — Raptor pre-mounted, camera framed
- `-demoScreenshot -demoFire` — also starts the engine automatically (short chill-down)
- `-hangar` — start in the indoor hangar instead of the outdoor test stand

## Orbital demo screenshots (real in-game renders of the actual mesh)
AI concept images are **not** a substitute — judge the rocket by the real in-game render:
- `-demoScreenshot -demoOrbital` — places the FX-9 (stainless, black interstage, 9 dark bells) on the Falcon-like pad, camera framed on the full 68 m vehicle. Capture the screenshot from the simulator / device.
- `-demoScreenshot -demoOrbital -demoFire` — same, then starts the launch countdown automatically (T-10 → liftoff), so a timed capture can show the ascent/plume.
- In the app, tap the top-bar site button to cycle to ORBITAL PAD, or relaunch with the arguments above.
